﻿using ASodium;
using Jering.Javascript.NodeJS;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace TestApplication.ArweaveLocalHelper
{
    public static class ArweaveCreateAndPostDataHelper
    {
        /// <summary>
        /// Creates, signs, and posts a transaction to Arweave.
        /// </summary>
        /// <param name="jwkJson">Wallet key JSON string</param>
        /// <param name="data">Transaction data (string or byte[])</param>
        /// <returns>Tuple of transactionId and responseStatus</returns>
        private static async Task<(string TransactionId, int Status)> PostTransactionAsync(string jwkJson, object data)
        {
            if (data is not string && data is not byte[])
                throw new ArgumentException("Data must be string or byte[]");

            string jsModule = @"
            const Arweave = require('arweave');

            module.exports = async function (jwkJson, data, isString) {
                const arweave = Arweave.init({
                    host: 'arweave.net',
                    port: 443,
                    protocol: 'https'
                });

                const jwk = JSON.parse(jwkJson);

                // Prepare data
                let txData;
                if (isString) {
                    txData = data;
                } else {
                    txData = Buffer.from(data, 'base64');
                }

                // Create transaction
                let transaction = await arweave.createTransaction({ data: txData }, jwk);

                // Sign transaction
                await arweave.transactions.sign(transaction, jwk);

                // Post transaction
                const response = await arweave.transactions.post(transaction);

                return JSON.stringify({
                    id: transaction.id,
                    status: response.status
                });
            };
        ";

            string resultJson = await StaticNodeJSService.InvokeFromStringAsync<string>(
                jsModule,
                args: new object[]
                {
                jwkJson,
                data is string s ? s : Convert.ToBase64String((byte[])data),
                data is string
                }
            );

            var parsed = System.Text.Json.JsonDocument.Parse(resultJson);
            string id = parsed.RootElement.GetProperty("id").GetString() ?? "";
            int status = parsed.RootElement.GetProperty("status").GetInt32();

            return (id, status);
        }

        private static async Task<(string TransactionId, int Status)> SendArAsync(
            string jwkJson,
            string targetAddress,
            decimal arAmount)
        {
            // Convert AR to Winston (1 AR = 1e12 Winston)
            var winstonAmount = ((BigInteger)(arAmount * 1000000000000)).ToString();

            string jsModule = @"
                const Arweave = require('arweave');

                module.exports = async function (jwkJson, target, winstonQty) {
                const arweave = Arweave.init({
                    host: 'arweave.net',
                    port: 443,
                    protocol: 'https'
                });

                const jwk = JSON.parse(jwkJson);

                // Create a transfer transaction
                let transaction = await arweave.createTransaction({
                    target: target,
                    quantity: winstonQty
                }, jwk);

                // Sign transaction
                await arweave.transactions.sign(transaction, jwk);

                // Post transaction
                const response = await arweave.transactions.post(transaction);

                return JSON.stringify({
                    id: transaction.id,
                    status: response.status
                });
                };
            ";

            string resultJson = await StaticNodeJSService.InvokeFromStringAsync<string>(
                jsModule,
                args: new object[]
                {
                    jwkJson,
                    targetAddress,
                    winstonAmount
                }
            );

            var parsed = System.Text.Json.JsonDocument.Parse(resultJson);
            string id = parsed.RootElement.GetProperty("id").GetString() ?? "";
            int status = parsed.RootElement.GetProperty("status").GetInt32();

            return (id, status);
        }

        private static void DisposeNodeProcess()
        {
            StaticNodeJSService.DisposeServiceProvider();
        }

        public static async Task<String> SubmitDataToArweave(String DataString = "", Byte[] DataBytes = null) 
        {
            string jwk = @"";
            String TxId = "";
            int StatusInt = 0;
            if (DataString.CompareTo("") != 0) 
            {
                var (txId, status) = await PostTransactionAsync(jwk, DataString);
                TxId = txId;
                StatusInt = status;
            }
            else 
            {
                var (txId, status) = await PostTransactionAsync(jwk, DataBytes);
                TxId = txId;
                StatusInt = status;
            }
            SodiumSecureMemory.SecureClearString(jwk);
            DisposeNodeProcess();

            if(StatusInt == 200) 
            {
                return TxId;
            }
            else 
            {
                return "";
            }
        }

        public static async Task<String> SendMoneyToTarget(String jwk,String targetAddress, decimal decimalValue,Boolean IsAR=true)
        {
            if (jwk == null)
            {
                throw new ArgumentException("Error: jwk must not be null");
            }
            else 
            {
                if (jwk.CompareTo("") == 0) 
                {
                    throw new ArgumentException("Error: jwk must not be empty");
                }
            }
            String TxId = "";
            int StatusInt = 0;
            
            decimal ConvertedARAmount = 0;
            if(IsAR == true)
            {
                var (txId, status) = await SendArAsync(jwk, targetAddress, decimalValue);
                TxId = txId;
                StatusInt = status;
            }
            else 
            {
                ConvertedARAmount = await GetArRequiredForUsd(decimalValue);
                var (txId, status) = await SendArAsync(jwk, targetAddress, ConvertedARAmount);
                TxId = txId;
                StatusInt = status;
            }

            SodiumSecureMemory.SecureClearString(jwk);
            DisposeNodeProcess();

            if (StatusInt == 200)
            {
                return TxId;
            }
            else
            {
                return "";
            }
        }

        private static async Task<decimal> GetArRequiredForUsd(decimal usdAmount)
        {
            using HttpClient client = new HttpClient();
            string url = "https://api.coingecko.com/api/v3/simple/price?ids=arweave&vs_currencies=usd";
            string json = await client.GetStringAsync(url);
            var document = JsonDocument.Parse(json);
            decimal arPrice = document.RootElement
                                     .GetProperty("arweave")
                                     .GetProperty("usd")
                                     .GetDecimal();
            return usdAmount / arPrice;
        }
    }
}
