﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.ArweaveModel
{
    public class GetTransactionOffsetModel
    {
        public String offset { get; set; }

        public String size { get; set; }
    }
}
