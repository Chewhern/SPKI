﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.ArweaveHelper
{
    public static class GetWalletBalanceHelper
    {
        public static String GetWalletBalance(String address)
        {
            String RetrievedData = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://arweave.net/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync($"wallet/{address}/balance");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    RetrievedData = Result;
                }
                else 
                {
                    RetrievedData = "0";
                }
            }
            return RetrievedData;
        }
    }
}
