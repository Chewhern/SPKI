﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.DataModel;
using SPKITL_ServerApp.Helper;
using SPKITL_ServerApp.PostDataModel;
using SPKITL_ServerApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Web;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PNodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        //==Current parent node => Current parent node's users and current parent node
        //Fetch full chain of trust from other nodes as it's a request from current parent node
        //Verify full chain of trust from other nodes as it's a request from current parent node

        //Current parent node will be responsible in creating partial chain of trust

        [HttpGet]
        public NodeArweaveCertModel GiveTLCertificateToPNodeUser(String User_ID) 
        {
            NodeArweaveCertModel MyCertModel = new NodeArweaveCertModel();
            String TempString = "";
            String[] SignerArweaveIDs = new String[] { };
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String CurrentNodeIPAddress = "";
            int Count = 0;
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyCertModel.NodeAUCertInfoArweaveID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyCertModel.NodeAUInfoArweaveID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Signer_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    TempString = MySQLGeneralQuery.ExecuteScalar().ToString();
                    SignerArweaveIDs = TempString.Split(";");
                    MyCertModel.ONodeAUInfoArweaveIDs = SignerArweaveIDs;
                    MyCertModel.Status = "Success: All necessary certificate information had been retrieved for this AU";
                }
                else
                {
                    MyCertModel.Status = "Error: This user does not get signed by other node's authorized users";
                }
            }
            else
            {
                MyCertModel.Status = "Error: This specified user had not been registered";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyCertModel;
        }

        [HttpGet("UserHelper")]
        public String GetONodeAPIIPAddress(String IP_Address) 
        {
            String API_IP_Address = "";
            String Final_API_IP_Address = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetNodeAPIIPAddress");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    Final_API_IP_Address = Result;
                }
                else
                {
                    throw new Exception("Error: Other Node encounter some issues");
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();

            return Final_API_IP_Address;
        }
    }
}
