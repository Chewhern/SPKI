﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.Helper;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetNodeAPIIPAddress : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();
        private static Boolean UsesPublicPrivateIPAddress = true;

        [HttpGet]
        public String GetInfo()
        {
            String ResultString = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String API_IP_Address = "";
            DateTime LastPKUpdateDT = new DateTime();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            if (UsesPublicPrivateIPAddress) 
            {
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `Node_OInformation`";
            }
            else 
            {
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `Node_Information`";
            }
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `Node_OInformation`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            //Add your own contact here
            ResultString = API_IP_Address;
            return ResultString;
        }
    }
}
