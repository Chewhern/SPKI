﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.DataModel;
using SPKITL_ServerApp.Helper;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ONodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        //Parent node request certificate from other node
        [HttpGet]
        public NodeArweaveCertModel GenerateTLCertForONAUs(String IP_Address, String SignedChallenge,String User_ID) 
        {
            NodeArweaveCertModel MyCertModel = new NodeArweaveCertModel();
            List<String> SignerUserIDs = new List<String>();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String CurrentNodeIPAddress = "";
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            int ValidDay = 0;
            int ValidMonth = 0;
            int ValidYear = 0;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_Day`,`Valid_Month`,`Valid_Year` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DataReader = MySQLGeneralQuery.ExecuteReader();
                                while (DataReader.Read()) 
                                {
                                    ValidDay = DataReader.GetInt16("Valid_Day");
                                    ValidMonth = DataReader.GetInt16("Valid_Month");
                                    ValidYear = DataReader.GetInt16("Valid_Year");
                                }
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                DatabaseDateTime = new DateTime(ValidYear,ValidMonth,ValidDay);
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays >= 0 && MyTimeSpan.TotalDays<=1) 
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_Cert_Info` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0) 
                                    {
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `ONode_Users_Cert_Info` WHERE `ONode_User_ID`=@ONode_User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        MyCertModel.NodeAUCertInfoArweaveID = MySQLGeneralQuery.ExecuteScalar().ToString();
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `ONode_Users_SBPNU_Log` WHERE `ONode_User_ID`=@ONode_User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        DataReader = MySQLGeneralQuery.ExecuteReader();
                                        while (DataReader.Read()) 
                                        {
                                            SignerUserIDs.Add(DataReader.GetString("User_ID"));
                                        }
                                        MyCertModel.ONodeAUInfoArweaveIDs = new String[SignerUserIDs.Count];
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        while (Loop < SignerUserIDs.Count) 
                                        {
                                            MySQLGeneralQuery = new MySqlCommand();
                                            MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = SignerUserIDs[Loop];
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            MyCertModel.ONodeAUInfoArweaveIDs[Loop] = MySQLGeneralQuery.ExecuteScalar().ToString();
                                            Loop += 1;
                                        }
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `ONode_Users` WHERE `User_ID`=@User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        MyCertModel.NodeAUInfoArweaveID = MySQLGeneralQuery.ExecuteScalar().ToString();
                                        MyCertModel.Status = "Success: Arweave certificate had been retrieved for this user..";
                                    }
                                    else 
                                    {
                                        MyCertModel.Status = "Error: This onode user does not have any signed records..";
                                    }
                                }
                                else 
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    MyCertModel.Status = "Error: This ONode User's public keys had expired.. deleting this ONode_User..";
                                }
                            }
                            else
                            {
                                MyCertModel.Status = "Error: This ONode user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            MyCertModel.Status = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        MyCertModel.Status = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    MyCertModel.Status = "Error: This other node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                MyCertModel.Status = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyCertModel;
        }

    }
}
