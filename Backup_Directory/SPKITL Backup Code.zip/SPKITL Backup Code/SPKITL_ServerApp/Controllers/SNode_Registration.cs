﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.Helper;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SNode_Registration : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String RegisterNodeInformation(String IP_Address, String API_IP_Address, String SNode_Auth_PK, String UpdateTimeString)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address AND `API_IP_Address`=@API_IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Parameters.Add("@API_IP_Address", MySqlDbType.Text).Value = API_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 0)
            {
                if (API_IP_Address.Contains(IP_Address) == true)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "INSERT INTO `SNode_Information`(`IP_Address`, `API_IP_Address`, `SNode_Auth_PK`, `Update_Date`) VALUES (@IP_Address,@API_IP_Address,@SNode_Auth_PK,@Update_Date)";
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Parameters.Add("@API_IP_Address", MySqlDbType.Text).Value = API_IP_Address;
                    MySQLGeneralQuery.Parameters.Add("@SNode_Auth_PK", MySqlDbType.Text).Value = SNode_Auth_PK;
                    MySQLGeneralQuery.Parameters.Add("@Update_Date", MySqlDbType.DateTime).Value = DateTime.Parse(UpdateTimeString);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    ResultString = "Success: Specified sub node had been added";
                }
                else
                {
                    ResultString = "Error: Kindly make sure the API IP address is an extension IP address and not different IP address";
                }
            }
            else
            {
                ResultString = "Error: This pair of IP addresses exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("CheckNodeExistence")]
        public String CheckNodeCount(String IP_Address)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            int Count = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return Count.ToString();
        }


        [HttpGet("UpdateNodeAuthPK")]
        public String UpdateNewAuthPK(String IP_Address, String API_IP_Address, String SignedChallenge, String New_SNode_Auth_PK,
            String UpdateTimeString)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String SNode_API_IP_Address = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address AND `API_IP_Address`=@API_IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Parameters.Add("@API_IP_Address", MySqlDbType.Text).Value = API_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `SNode_Auth_PK` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                IsSNodePKNotChanged = VerifySNodePK.IsSNodePKChanged(SNode_Auth_PK, SNode_API_IP_Address);
                if (IsSNodePKNotChanged == true)
                {
                    SNode_Auth_PK_Bytes = Convert.FromBase64String(SNode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (SNode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, SNode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(SNode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "INSERT INTO `SNode_PK_Log`(`IP_Address`, `Auth_PK`, `Update_DT`) VALUES (@IP_Address,@Auth_PK,@Update_DT)";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = SNode_Auth_PK;
                            MySQLGeneralQuery.Parameters.Add("@Update_DT", MySqlDbType.DateTime).Value = DatabaseDateTime;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "UPDATE `SNode_Information` SET `SNode_Auth_PK`=@SNode_Auth_PK,`Update_Date`=@Update_Date WHERE `IP_Address`=@IP_Address AND `API_IP_Address`=@API_IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@API_IP_Address", MySqlDbType.Text).Value = API_IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@SNode_Auth_PK", MySqlDbType.Text).Value = New_SNode_Auth_PK;
                            MySQLGeneralQuery.Parameters.Add("@Update_Date", MySqlDbType.DateTime).Value = DateTime.Parse(UpdateTimeString);
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            ResultString = "Success: Record logged and authentication public key changed..";
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from sub node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This sub node's PK does not match with parent node's PK";
                }
            }
            else
            {
                ResultString = "Error: This pair of IP addresses don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        //Update SNode PK also needs to be triggered after parent node updated its authentication key
        [HttpGet("UpdateNodeIP")]
        public String ChangeNodeIPInformation(String IP_Address, String API_IP_Address, String SignedChallenge, String New_IP_Address, String New_API_IP_Address)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String SNode_API_IP_Address = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address AND `API_IP_Address`=@API_IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Parameters.Add("@API_IP_Address", MySqlDbType.Text).Value = API_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `SNode_Auth_PK` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                IsSNodePKNotChanged = VerifySNodePK.IsSNodePKChanged(SNode_Auth_PK, SNode_API_IP_Address);
                if (IsSNodePKNotChanged == true)
                {
                    SNode_Auth_PK_Bytes = Convert.FromBase64String(SNode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (SNode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, SNode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(SNode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "UPDATE `SNode_Information` SET `IP_Address`=@New_IP_Address,`API_IP_Address`=@New_API_IP_Address WHERE `IP_Address`=@IP_Address AND `API_IP_Address`=@API_IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@API_IP_Address", MySqlDbType.Text).Value = API_IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@New_IP_Address", MySqlDbType.Text).Value = New_IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@New_API_IP_Address", MySqlDbType.Text).Value = New_API_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            ResultString = "Success: This SNode's IP Addresses pair had been updated";
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from sub node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This sub node's PK does not match with parent node's PK";
                }
            }
            else
            {
                ResultString = "Error: This pair of IP addresses don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}
