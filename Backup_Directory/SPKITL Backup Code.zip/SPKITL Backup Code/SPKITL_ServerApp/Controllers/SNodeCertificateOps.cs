﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Bcpg.Sig;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.DataModel;
using SPKITL_ServerApp.Helper;
using SPKITL_ServerApp.PostDataModel;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SNodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public SNodeArweaveCertModel GenerateMLCertForSNAUs(String IP_Address, String SignedChallenge, String User_ID)
        {
            SNodeArweaveCertModel MyCertModel = new SNodeArweaveCertModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String SNode_API_IP_Address = "";
            String CurrentNodeIPAddress = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            int ValidDay = 0;
            int ValidMonth = 0;
            int ValidYear = 0;
            List<String> SignerUserIDs = new List<String>();
            List<String> SignerUserArweaveIDs = new List<String>();
            List<String> SignerUserArweaveCertIDs = new List<String>();
            List<String> ONodeUserIDs = new List<String>();
            List<String> ONodeUserArweaveIDs = new List<String>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `SNode_Auth_PK` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                IsSNodePKNotChanged = VerifySNodePK.IsSNodePKChanged(SNode_Auth_PK, SNode_API_IP_Address);
                if (IsSNodePKNotChanged == true)
                {
                    SNode_Auth_PK_Bytes = Convert.FromBase64String(SNode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (SNode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, SNode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(SNode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_Day`,`Valid_Month`,`Valid_Year` FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DataReader = MySQLGeneralQuery.ExecuteReader();
                                while (DataReader.Read())
                                {
                                    ValidDay = DataReader.GetInt16("Valid_Day");
                                    ValidMonth = DataReader.GetInt16("Valid_Month");
                                    ValidYear = DataReader.GetInt16("Valid_Year");
                                }
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                DatabaseDateTime = new DateTime(ValidYear, ValidMonth, ValidDay);
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays >= 0 && MyTimeSpan.TotalDays <= 1)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_Cert_Info` WHERE `SNode_User_ID`=@SNode_User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0)
                                    {
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `SNode_Users_Cert_Info` WHERE `SNode_User_ID`=@SNode_User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        MyCertModel.SNodeAUCertInfoArweaveID = MySQLGeneralQuery.ExecuteScalar().ToString();
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `SNode_Users_SBPNU_Log` WHERE `SNode_User_ID`=@SNode_User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        DataReader = MySQLGeneralQuery.ExecuteReader();
                                        while (DataReader.Read()) 
                                        {
                                            SignerUserIDs.Add(DataReader.GetString("User_ID"));
                                        }
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        while (Loop < SignerUserIDs.Count) 
                                        {
                                            MySQLGeneralQuery = new MySqlCommand();
                                            MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = SignerUserIDs[Loop];
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            SignerUserArweaveIDs.Add(MySQLGeneralQuery.ExecuteScalar().ToString());
                                            Loop += 1;
                                        }
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        Loop = 0;
                                        while (Loop < SignerUserIDs.Count)
                                        {
                                            MySQLGeneralQuery = new MySqlCommand();
                                            MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID`,`Signer_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = SignerUserIDs[Loop];
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            DataReader = MySQLGeneralQuery.ExecuteReader();
                                            while (DataReader.Read()) 
                                            {
                                                SignerUserArweaveCertIDs.Add(DataReader.GetString("Arweave_ID"));
                                                ONodeUserArweaveIDs.Add(DataReader.GetString("Signer_Arweave_IDs"));
                                            }
                                            myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                            myMyOwnMySQLConnection.ClearConnectionString();
                                            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                            Loop += 1;
                                        }
                                        MyCertModel.NodeAUInfoArweaveIDs = SignerUserArweaveIDs.ToArray();
                                        MyCertModel.NodeAUCertInfoArweaveIDs = SignerUserArweaveCertIDs.ToArray();
                                        MyCertModel.ONodeAUInfoArweaveIDs = ONodeUserArweaveIDs.ToArray();
                                        MyCertModel.Status = "Success: Full certificate had been fetched for this sub node user";
                                        //The format will be Cert Info's Arweave_ID followed by the users who sign the cert
                                        //Sample format = Arweave_ID (Cert); Arweave_ID1 (AU and its info who signed the cert); Arweave_ID2......; Arweave_IDN
                                    }
                                    else
                                    {
                                        MyCertModel.SNodeAUCertInfoArweaveID = "";
                                        MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                                        MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                                        MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                                        MyCertModel.Status = "Error: This onode user does not have any signed records..";
                                    }
                                }
                                else
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    MyCertModel.SNodeAUCertInfoArweaveID = "";
                                    MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                                    MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                                    MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                                    MyCertModel.Status = "Error: This SNode User's public keys had expired.. deleting this ONode_User..";
                                }
                            }
                            else
                            {
                                MyCertModel.SNodeAUCertInfoArweaveID = "";
                                MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                                MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                                MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                                MyCertModel.Status = "Error: This SNode user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            MyCertModel.SNodeAUCertInfoArweaveID = "";
                            MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                            MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                            MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                            MyCertModel.Status = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        MyCertModel.SNodeAUCertInfoArweaveID = "";
                        MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                        MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                        MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                        MyCertModel.Status = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    MyCertModel.SNodeAUCertInfoArweaveID = "";
                    MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                    MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                    MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                    MyCertModel.Status = "Error: This sub node's PK does not match with parent node";
                }
            }
            else
            {
                MyCertModel.SNodeAUCertInfoArweaveID = "";
                MyCertModel.NodeAUInfoArweaveIDs = new String[] { };
                MyCertModel.NodeAUCertInfoArweaveIDs = new String[] { };
                MyCertModel.ONodeAUInfoArweaveIDs = new String[] { };
                MyCertModel.Status = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyCertModel;
        }
    }
}
