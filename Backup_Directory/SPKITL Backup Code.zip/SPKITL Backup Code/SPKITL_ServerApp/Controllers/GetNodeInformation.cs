﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.Helper;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetNodeInformation : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();
        private static Boolean UsesPublicPrivateIPAddress = true;

        [HttpGet]
        public String GetInfo() 
        {
            String ResultString = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String IP_Address = "";
            DateTime LastPKUpdateDT = new DateTime();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            if (UsesPublicPrivateIPAddress) 
            {
                MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_OInformation`";
            }
            else 
            {
                MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            }
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            //Add your own contact here
            String NodeOperator_Contact = "";
            String NodeOperator_OOB_Auth_PK = "";
            String NodeOperator_AuthorizedUsers_CommunicationChannel = "";
            ResultString = IP_Address + "," + NodeOperator_Contact + "," + NodeOperator_OOB_Auth_PK + ","+NodeOperator_AuthorizedUsers_CommunicationChannel;
            return ResultString;
        }
    }
}
