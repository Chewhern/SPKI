﻿using System.Net.Http.Headers;

namespace SPKITL_ServerApp.APIHelper
{
    public static class VerifySNodePK
    {
        public static Boolean IsSNodePKChanged(String SNode_Auth_PK, String API_IP_Address)
        {
            Boolean PKNotChanged = true;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetSNodePK");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    if (Result.Contains("Error") == false)
                    {
                        String TrimmedResult = Result.Substring(1, Result.Length - 2);
                        if (SNode_Auth_PK.CompareTo(TrimmedResult) != 0)
                        {
                            PKNotChanged = false;
                        }
                    }
                    else
                    {
                        PKNotChanged = false;
                    }
                }
                else
                {
                    Console.WriteLine("Error: Other Node encounter some issues");
                }
            }
            return PKNotChanged;
        }
    }
}
