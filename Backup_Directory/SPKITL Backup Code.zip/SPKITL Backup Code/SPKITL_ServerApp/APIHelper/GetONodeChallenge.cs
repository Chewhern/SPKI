﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp.Helper;
using System.Net.Http.Headers;
using System.Web;

namespace SPKITL_ServerApp.APIHelper
{
    public class GetONodeChallenge
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static Byte[] GetChallenge(String ONode_API_IP_Address) 
        {
            Byte[] Challenge = new Byte[] { };
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                IP_Address = MyReader.GetString("IP_Address");
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(ONode_API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ONChallengeRequestor?IP_Address=" + HttpUtility.UrlEncode(IP_Address));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    if (Result.Contains("Error") == true)
                    {
                        throw new Exception("Error:" + Result);
                    }
                    else
                    {
                        Challenge = Convert.FromBase64String(Result);
                    }
                }
                else
                {
                    throw new Exception("Error: Other Node encounter some issues");
                }
            }

            return Challenge;
        }
    }
}
