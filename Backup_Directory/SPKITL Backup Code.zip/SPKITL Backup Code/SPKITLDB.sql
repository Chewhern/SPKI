-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 08, 2026 at 06:53 AM
-- Server version: 8.0.45-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SPKITLDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Compromised_NUS_Info`
--

CREATE TABLE `Compromised_NUS_Info` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Challenge`
--

CREATE TABLE `Node_Challenge` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Information`
--

CREATE TABLE `Node_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Node_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Node_Info_Register_DT` datetime DEFAULT NULL,
  `Node_Info_Update_DT` datetime DEFAULT NULL,
  `PK_Update_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_OInformation`
--

CREATE TABLE `Node_OInformation` (
  `Public_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_PK_Log`
--

CREATE TABLE `Node_PK_Log` (
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Add_DT` datetime DEFAULT NULL,
  `NPKL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users`
--

CREATE TABLE `Node_Users` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Pub_Contact` text COLLATE utf8mb4_general_ci,
  `Priv_Contact` text COLLATE utf8mb4_general_ci,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `OOB_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `ASPK_ValidDay` int DEFAULT NULL,
  `ASPK_ValidMonth` int DEFAULT NULL,
  `ASPK_ValidYear` int DEFAULT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users_Cert_Info`
--

CREATE TABLE `Node_Users_Cert_Info` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signer_Arweave_IDs` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Challenge`
--

CREATE TABLE `ONode_Challenge` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Information`
--

CREATE TABLE `ONode_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `ONode_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_PK_Log`
--

CREATE TABLE `ONode_PK_Log` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_DT` datetime NOT NULL,
  `OPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Users`
--

CREATE TABLE `ONode_Users` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Day` int DEFAULT NULL,
  `Valid_Month` int NOT NULL,
  `Valid_Year` int NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Users_Cert_Info`
--

CREATE TABLE `ONode_Users_Cert_Info` (
  `ONode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signer_Arweave_IDs` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Users_SBPNU_Log`
--

CREATE TABLE `ONode_Users_SBPNU_Log` (
  `ONode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_Day` int DEFAULT NULL,
  `Sign_Month` int DEFAULT NULL,
  `Sign_Year` int DEFAULT NULL,
  `Valid_Day` int DEFAULT NULL,
  `Valid_Month` int DEFAULT NULL,
  `Valid_Year` int DEFAULT NULL,
  `OUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Challenge`
--

CREATE TABLE `SNode_Challenge` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Information`
--

CREATE TABLE `SNode_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `SNode_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_PK_Log`
--

CREATE TABLE `SNode_PK_Log` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_DT` datetime DEFAULT NULL,
  `SPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Users`
--

CREATE TABLE `SNode_Users` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Day` int DEFAULT NULL,
  `Valid_Month` int DEFAULT NULL,
  `Valid_Year` int DEFAULT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Users_Cert_Info`
--

CREATE TABLE `SNode_Users_Cert_Info` (
  `SNode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signer_Arweave_IDs` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Users_SBPNU_Log`
--

CREATE TABLE `SNode_Users_SBPNU_Log` (
  `SNode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_Day` int DEFAULT NULL,
  `Sign_Month` int DEFAULT NULL,
  `Sign_Year` int DEFAULT NULL,
  `Valid_Day` int DEFAULT NULL,
  `Valid_Month` int DEFAULT NULL,
  `Valid_Year` int DEFAULT NULL,
  `SUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Compromised_NUS_Info`
--
ALTER TABLE `Compromised_NUS_Info`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `Node_Challenge`
--
ALTER TABLE `Node_Challenge`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Information`
--
ALTER TABLE `Node_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `Node_OInformation`
--
ALTER TABLE `Node_OInformation`
  ADD PRIMARY KEY (`Public_IP_Address`);

--
-- Indexes for table `Node_PK_Log`
--
ALTER TABLE `Node_PK_Log`
  ADD PRIMARY KEY (`NPKL_ID`);

--
-- Indexes for table `Node_Users`
--
ALTER TABLE `Node_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Users_Cert_Info`
--
ALTER TABLE `Node_Users_Cert_Info`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `ONode_Challenge`
--
ALTER TABLE `ONode_Challenge`
  ADD PRIMARY KEY (`IP_Address`);

--
-- Indexes for table `ONode_Information`
--
ALTER TABLE `ONode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `ONode_PK_Log`
--
ALTER TABLE `ONode_PK_Log`
  ADD PRIMARY KEY (`OPL_ID`);

--
-- Indexes for table `ONode_Users`
--
ALTER TABLE `ONode_Users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `ONode_Users_Cert_Info`
--
ALTER TABLE `ONode_Users_Cert_Info`
  ADD PRIMARY KEY (`ONode_User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `ONode_Users_SBPNU_Log`
--
ALTER TABLE `ONode_Users_SBPNU_Log`
  ADD PRIMARY KEY (`OUSL_ID`);

--
-- Indexes for table `SNode_Challenge`
--
ALTER TABLE `SNode_Challenge`
  ADD PRIMARY KEY (`IP_Address`);

--
-- Indexes for table `SNode_Information`
--
ALTER TABLE `SNode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `SNode_PK_Log`
--
ALTER TABLE `SNode_PK_Log`
  ADD PRIMARY KEY (`IP_Address`);

--
-- Indexes for table `SNode_Users`
--
ALTER TABLE `SNode_Users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `SNode_Users_Cert_Info`
--
ALTER TABLE `SNode_Users_Cert_Info`
  ADD PRIMARY KEY (`SNode_User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `SNode_Users_SBPNU_Log`
--
ALTER TABLE `SNode_Users_SBPNU_Log`
  ADD PRIMARY KEY (`SUSL_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ONode_Users_SBPNU_Log`
--
ALTER TABLE `ONode_Users_SBPNU_Log`
  MODIFY `OUSL_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `SNode_Users_SBPNU_Log`
--
ALTER TABLE `SNode_Users_SBPNU_Log`
  MODIFY `SUSL_ID` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
