﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeLocalDeleteNodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void DeleteNodeUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            String[] EncryptedNodeUsersSignaturePrivateKeyPath = NCOperations.GetEncryptedUserPrivateKeysPath();
            List<String> NodeUsersIDsToBeDeleted = new List<String>();
            int Loop = 0;
            int Loop2 = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users` WHERE DATEDIFF( CURDATE(), STR_TO_DATE( CONCAT(ASPK_ValidYear, '-', ASPK_ValidMonth, '-', ASPK_ValidDay), '%Y-%m-%d' ) ) > 0";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read()) 
            {
                NodeUsersIDsToBeDeleted.Add(DataReader.GetString("User_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            while (Loop < EncryptedNodeUsersSignaturePrivateKeyPath.Length) 
            {
                while (Loop2 < NodeUsersIDsToBeDeleted.Count) 
                {
                    if (EncryptedNodeUsersSignaturePrivateKeyPath[Loop].Contains(NodeUsersIDsToBeDeleted[Loop2]) == true) 
                    {
                        File.Delete(EncryptedNodeUsersSignaturePrivateKeyPath[Loop]);
                    }
                    Loop2 += 1;
                }
                Loop2 = 0;
                Loop += 1;
            }
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            Loop2 = 0;
            while (Loop2 < NodeUsersIDsToBeDeleted.Count) 
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDsToBeDeleted[Loop2];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDsToBeDeleted[Loop2];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                Loop2 += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
