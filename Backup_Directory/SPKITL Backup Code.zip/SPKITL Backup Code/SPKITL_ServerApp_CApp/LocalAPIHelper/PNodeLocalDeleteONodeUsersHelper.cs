﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeLocalDeleteONodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void DeleteONodeUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            List<String> ONodeUsersIDsToBeDeleted = new List<String>();
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Users` WHERE DATEDIFF( CURDATE(), STR_TO_DATE( CONCAT(Valid_Year, '-', Valid_Month, '-', Valid_Day), '%Y-%m-%d' ) ) > 0";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read())
            {
                ONodeUsersIDsToBeDeleted.Add(DataReader.GetString("User_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            while (Loop < ONodeUsersIDsToBeDeleted.Count)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = ONodeUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users_Cert_Info` WHERE `ONode_User_ID`=@ONode_User_ID";
                MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users_SBPNU_Log` WHERE `ONode_User_ID`=@ONode_User_ID";
                MySQLGeneralQuery.Parameters.Add("@ONodeUser_ID", MySqlDbType.Text).Value = ONodeUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
