﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SimplifiedArweaveSDK.ArweaveLocalHelper;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.RSACredentialsHelper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using SPKITL_ServerApp_CApp.SPKIDataModel;
using System.Runtime.InteropServices;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeSignSNodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        //Proceed either when payment was made
        //Or proceed when the existing Arweave Wallet still have funds..
        //Postpone the first for now..
        public static async void SignAllSNodeUsers()
        {
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            int Loop2 = 0;
            String[] EncryptedNodeUsersSignaturePrivateKeyPath = NCOperations.GetEncryptedUserPrivateKeysPath();
            String NodeUsersSignaturePrivateKeyRootDirectory = "/Project/SPKITL/User_SignaturePrivateKeys/";
            String[] NodeUsersIDs = new String[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean[] IsNodeUsersPublicKeyMatched = new Boolean[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean IsSigned = true;
            String NodeUserSignaturePublicKeyString = "";
            Byte[] NodeUserSignaturePrivateKeyBytes = new Byte[] { };
            Byte[] NodeUserSignaturePublicKeyBytes = new Byte[] { };
            List<String> SNodeUserIDs = new List<String>();
            List<String> SNodeIPAddresses = new List<String>();
            List<String> SNodeUserSignPKsString = new List<String>();
            List<String> SNodeUserAuthPKsString = new List<String>();
            List<int> ValidDays = new List<int>();
            List<int> ValidMonths = new List<int>();
            List<int> ValidYears = new List<int>();
            Byte[] SNodeUserPKBytes = new Byte[] { };
            Byte[] SignedSNodeUserPKBytes = new Byte[] { };
            String SignedSNodeUserSignPKString = "";
            String SignedSNodeUserAuthPKString = "";
            Boolean IsZero = true;
            IntPtr NodeUserSignaturePrivateKeyIntPtr = new IntPtr();
            List<String> AUUserIDs = new List<String>();
            List<String> Signed_Auth_PKs = new List<string>();
            List<String> Signed_Sign_PKs = new List<string>();
            List<int> SignDate_Days = new List<int>();
            List<int> SignDate_Months = new List<int>();
            List<int> SignDate_Years = new List<int>();
            List<int> ValidDate_Days = new List<int>();
            List<int> ValidDate_Months = new List<int>();
            List<int> ValidDate_Years = new List<int>();
            String AUInfoArweaveIDs = "";
            List<MLPNSignedCredentialsModel> SignedCredentials = new List<MLPNSignedCredentialsModel>();
            MLAUCertModel MLAUCert = new MLAUCertModel();
            String MLAUCertJSONString = "";
            while (Loop < NodeUsersIDs.Length)
            {
                NodeUsersIDs[Loop] = EncryptedNodeUsersSignaturePrivateKeyPath[Loop].Remove(0, NodeUsersSignaturePrivateKeyRootDirectory.Length);
                NodeUsersIDs[Loop] = NodeUsersIDs[Loop].Remove(32, 15);
                Loop += 1;
            }
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `SNode_Users`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read())
            {
                SNodeUserIDs.Add(DataReader.GetString("User_ID"));
                SNodeIPAddresses.Add(DataReader.GetString("IP_Address"));
                SNodeUserSignPKsString.Add(DataReader.GetString("Sign_PK"));
                SNodeUserAuthPKsString.Add(DataReader.GetString("Auth_PK"));
                ValidDays.Add(DataReader.GetInt16("Valid_Day"));
                ValidMonths.Add(DataReader.GetInt16("Valid_Month"));
                ValidYears.Add(DataReader.GetInt16("Valid_Year"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            Loop = 0;
            while (Loop < NodeUsersIDs.Length)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0) 
                {
                    NodeUserSignaturePrivateKeyBytes = CCOperations.DecryptUserSignaturePrivateKey(EncryptedNodeUsersSignaturePrivateKeyPath[Loop]);
                    if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                    {
                        NodeUserSignaturePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, NodeUserSignaturePrivateKeyBytes.Length);
                        Marshal.Copy(NodeUserSignaturePrivateKeyBytes, 0, NodeUserSignaturePrivateKeyIntPtr, NodeUserSignaturePrivateKeyBytes.Length);
                        SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(NodeUserSignaturePrivateKeyIntPtr);
                        NodeUserSignaturePublicKeyBytes = SodiumPublicKeyAuth.GeneratePublicKey(NodeUserSignaturePrivateKeyIntPtr);
                    }
                    else
                    {
                        NodeUserSignaturePublicKeyBytes = SecureED448.GeneratePublicKey(NodeUserSignaturePrivateKeyBytes);
                    }
                    NodeUserSignaturePublicKeyString = Convert.ToBase64String(NodeUserSignaturePublicKeyBytes);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID AND `Sign_PK`=@Sign_PK";
                    MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = NodeUserSignaturePublicKeyString;
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count > 0)
                    {
                        while (Loop2 < SNodeUserIDs.Count)
                        {
                            if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                            {
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserSignPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SodiumPublicKeyAuth.Sign(SNodeUserPKBytes, NodeUserSignaturePrivateKeyIntPtr);
                                SignedSNodeUserSignPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserAuthPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SodiumPublicKeyAuth.Sign(SNodeUserPKBytes, NodeUserSignaturePrivateKeyIntPtr);
                                SignedSNodeUserAuthPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                            }
                            else
                            {
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserSignPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, SNodeUserPKBytes, new Byte[] { });
                                SignedSNodeUserSignPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserAuthPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, SNodeUserPKBytes, new Byte[] { });
                                SignedSNodeUserAuthPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = SNodeIPAddresses[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 0)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "INSERT INTO `SNode_Users_SBPNU_Log`(`SNode_IP_Address`, `SNode_User_ID`, `User_ID`, `Signed_Auth_PK`, `Signed_Sign_PK`, `Sign_Day`,`Sign_Month`,`Sign_Year`,`Valid_Day`,`Valid_Month`,`Valid_Year`) VALUES (@SNode_IP_Address, @SNode_User_ID, @User_ID, @Signed_Auth_PK, @Signed_Sign_PK, @Sign_Day, @Sign_Month, @Sign_Year, @Valid_Day, @Valid_Month, @Valid_Year)";
                                MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = SNodeIPAddresses[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                MySQLGeneralQuery.Parameters.Add("@Sign_Day", MySqlDbType.Int16).Value = CurrentDateTime.Day;
                                MySQLGeneralQuery.Parameters.Add("@Sign_Month", MySqlDbType.Int16).Value = CurrentDateTime.Month;
                                MySQLGeneralQuery.Parameters.Add("@Sign_Year", MySqlDbType.Int16).Value = CurrentDateTime.Year;
                                MySQLGeneralQuery.Parameters.Add("@Valid_Day", MySqlDbType.Int16).Value = ValidDays[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@Valid_Month", MySqlDbType.Int16).Value = ValidMonths[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@Valid_Year", MySqlDbType.Int16).Value = ValidYears[Loop2];
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                            }
                            Loop2 += 1;
                        }
                        IsNodeUsersPublicKeyMatched[Loop] = true;
                    }
                    else
                    {
                        IsNodeUsersPublicKeyMatched[Loop] = false;
                    }
                }
                else 
                {
                    IsSigned = false;
                    IsNodeUsersPublicKeyMatched[Loop] = false;
                }
                if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                {
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(NodeUserSignaturePrivateKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(NodeUserSignaturePrivateKeyIntPtr);
                }
                else
                {
                    SodiumSecureMemory.SecureClearBytes(NodeUserSignaturePrivateKeyBytes);
                }
                Loop2 = 0;
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            Loop = 0;
            while (Loop < IsNodeUsersPublicKeyMatched.Length)
            {
                if (IsNodeUsersPublicKeyMatched[Loop] == false && IsSigned==true)
                {
                    throw new Exception("Error: Unable to proceed signing due to public keys mismatched.. or specified node user doesn't get signed by other nodes");
                }
                Loop += 1;
            }
            Loop = 0;
            while(Loop < SNodeUserIDs.Count) 
            {
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT * FROM `SNode_Users_SBPNU_Log` WHERE `SNode_User_ID`=@SNode_User_ID";
                MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read()) 
                {
                    Signed_Auth_PKs.Add(DataReader.GetString("Signed_Auth_PK"));
                    Signed_Sign_PKs.Add(DataReader.GetString("Signed_Sign_PK"));
                    SignDate_Days.Add(DataReader.GetInt16("Sign_Day"));
                    SignDate_Months.Add(DataReader.GetInt16("Sign_Month"));
                    SignDate_Years.Add(DataReader.GetInt16("Sign_Year"));
                    ValidDate_Days.Add(DataReader.GetInt16("Valid_Day"));
                    ValidDate_Days.Add(DataReader.GetInt16("Valid_Month"));
                    ValidDate_Days.Add(DataReader.GetInt16("Valid_Year"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `SNode_Users_SBPNU_Log` WHERE `SNode_User_ID`=@SNode_User_ID";
                MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    AUUserIDs.Add(DataReader.GetString("User_ID"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                Loop2 = 0;
                while (Loop2 < AUUserIDs.Count) 
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = AUUserIDs[Loop2];
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    if (Loop2 + 1 == AUUserIDs.Count) 
                    {
                        AUInfoArweaveIDs += MySQLGeneralQuery.ExecuteScalar().ToString();
                    }
                    else 
                    {
                        AUInfoArweaveIDs += MySQLGeneralQuery.ExecuteScalar().ToString()+";";
                    }
                    Loop2 += 1;
                }
                Loop2 = 0;
                while (Loop2 < Signed_Auth_PKs.Count) 
                {
                    MLPNSignedCredentialsModel MyModel = new MLPNSignedCredentialsModel();
                    MyModel.Signed_Auth_PK = Signed_Auth_PKs[Loop2];
                    MyModel.Signed_Sign_PK = Signed_Sign_PKs[Loop2];
                    MyModel.SignDate_Day = SignDate_Days[Loop2];
                    MyModel.SignDate_Month = SignDate_Days[Loop2];
                    MyModel.SignDate_Year = SignDate_Days[Loop2];
                    MyModel.ValidDate_Day = ValidDate_Days[Loop2];
                    MyModel.ValidDate_Month = ValidDate_Days[Loop2];
                    MyModel.ValidDate_Year = ValidDate_Days[Loop2];
                    SignedCredentials.Add(MyModel);
                    Loop2 += 1;
                }
                MLAUCert.User_ID = SNodeUserIDs[Loop];
                MLAUCert.SignedCredentials = SignedCredentials.ToArray();
                MLAUCertJSONString = JsonConvert.SerializeObject(MLAUCert);
                RSAHelper.SetRSACredentials();
                (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(MLAUCertJSONString, "gtkTFlA1yXTFl_k-OjjltMn5IEqA-YpcD6SuYRksNhVKj8eP3IZ0zREbhQpI2P9aIdEaXxzRhCum89Xe-xEnnHKsmB1CcLMuVSXOtuUz9xQ0XCX3L2hxoytWqviGkn16Cx8_YeOGuHWdJVqjF-oZVY2-Q32kHBbT79AniJHCFxTFuYYIo2YXPD24yVxFgjuySg2LtLo5ImYBkPjs-fnrKW8jAPMr-gmPSgaq7dLf95GBYKIQLjY13ABUaSvODbjBgKHXhB3N6ZALfrPzMLe6pl-_onAvNGzXZXeKyHnY-ar1wnPpGEo8QUXjkQrimBjYJhlE1DxC9J5K7KJgQ2xkLbTPpgfNwQxVUwN5b1CBokxBLUJtCzqxC0ZZC3WEA7ZEqpb0IEeAY7g20O3dN9aJw9VpYaoKjYOVRqmUMmE_XgDtglAVtV1X03-OyYZS3Ss_tz3bUWlv1XvxiW3sDFLLYs9nRkPvEklqT4280uRJbfMkLcgW9wlfzJwPgFJ5MTm9fD5PKGRDOCcNLrXVlacdnLQ_9YlWV9UFgu6CSZsH7v1_frA5VGitK3mfrhvuKJN1ZxszolcwJJAbbw1P-0DbrGF5B6KRE01-f_5v35sBgEm6K4umYbaJ5LFdkpHOn1uPP0H8XSeT_TfG69F7lLHG_YCWXiQzYBeWKK2xyJhjMjU",
                    RSAHelper.RSAModulus, RSAHelper.RSAExponent, RSAHelper.RSAD, RSAHelper.RSAP, RSAHelper.RSAQ, RSAHelper.RSADP, RSAHelper.RSADQ, RSAHelper.RSAInverseQ);
                //Need to modify slightly on the SimplifiedArweaveSDK..
                if (MyResults.Status.CompareTo("OK") == 0) 
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "INSERT INTO `SNode_Users_Cert_Info`(`SNode_User_ID`, `Arweave_ID`, `Signer_Arweave_IDs`) VALUES (@SNode_User_ID,@Arweave_ID,@Signer_Arweave_IDs)";
                    MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop];
                    MySQLGeneralQuery.Parameters.Add("@Arweave_ID", MySqlDbType.Text).Value = MyResults.TransactionID;
                    MySQLGeneralQuery.Parameters.Add("@Signer_Arweave_IDs", MySqlDbType.Text).Value = AUInfoArweaveIDs;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                }
                AUUserIDs.Clear();
                Signed_Auth_PKs.Clear();
                Signed_Sign_PKs.Clear();
                SignDate_Days.Clear();
                SignDate_Months.Clear();
                SignDate_Years.Clear();
                ValidDate_Days.Clear();
                ValidDate_Days.Clear();
                ValidDate_Days.Clear();
                AUInfoArweaveIDs = "";
                MLAUCert = new MLAUCertModel();
                SignedCredentials.Clear();
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
