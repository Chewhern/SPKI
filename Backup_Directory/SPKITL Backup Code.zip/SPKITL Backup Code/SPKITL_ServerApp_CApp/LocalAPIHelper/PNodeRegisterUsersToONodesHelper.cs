﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.LocalAPISubHelper;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeRegisterUsersToONodesHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void RegisterNodeUsersToONodes() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            List<String> API_IP_Addresses = new List<String>();
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                API_IP_Addresses.Add(MyReader.GetString("API_IP_Address"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            while (Loop < API_IP_Addresses.Count) 
            {
                PNodeRegisterUsersToONodeHelper.RegisterNodeUsersToONode(API_IP_Addresses[Loop]);
                Loop += 1;
            }
        }
    }
}
