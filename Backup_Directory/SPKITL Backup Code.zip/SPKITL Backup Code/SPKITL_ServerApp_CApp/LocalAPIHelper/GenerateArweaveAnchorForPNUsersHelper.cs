﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SimplifiedArweaveSDK.ArweaveLocalHelper;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.RSACredentialsHelper;
using SPKITL_ServerApp_CApp.SPKIDataModel;
using SPKITL_ServerApp_CApp.UtilityHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class GenerateArweaveAnchorForPNUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static async void GenerateAnchorsForPNUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            List<String> User_IDs = new List<String>();
            List<String> Public_Contacts = new List<String>();
            List<String> Private_Contacts = new List<String>();
            List<String> Auth_PKs = new List<String>();
            List<String> Sign_PKs = new List<String>();
            List<String> OOB_PKs = new List<String>();
            List<int> ASPK_ValidDays = new List<int>();
            List<int> ASPK_ValidMonths = new List<int>();
            List<int> ASPK_ValidYears = new List<int>();
            List<String> Arweave_IDs = new List<String>();
            int ColumnIndex = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users` WHERE DATEDIFF( CURDATE(), STR_TO_DATE( CONCAT(ASPK_ValidYear, '-', ASPK_ValidMonth, '-', ASPK_ValidDay), '%Y-%m-%d' ) ) <= 0 AND `Arweave_ID` IS NULL";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                User_IDs.Add(MyReader.GetString("User_ID"));
                Public_Contacts.Add(MyReader.GetString("Pub_Contact"));
                ColumnIndex = MyReader.GetOrdinal("Priv_Contact");
                if (MyReader.IsDBNull(ColumnIndex))
                {
                    Private_Contacts.Add("");
                }
                else
                {
                    Private_Contacts.Add(MyReader.GetString("Priv_Contact"));
                }
                Auth_PKs.Add(MyReader.GetString("Auth_PK"));
                Sign_PKs.Add(MyReader.GetString("Sign_PK"));
                OOB_PKs.Add(MyReader.GetString("OOB_PK"));
                ASPK_ValidDays.Add(MyReader.GetInt16("ASPK_ValidDay"));
                ASPK_ValidMonths.Add(MyReader.GetInt16("ASPK_ValidMonth"));
                ASPK_ValidYears.Add(MyReader.GetInt16("ASPK_ValidYear"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            int Loop = 0;
            while (Loop < User_IDs.Count) 
            {
                TLAUInfoModel MyModel = new TLAUInfoModel();
                MyModel.User_ID = User_IDs[Loop];
                MyModel.Public_Contact = Public_Contacts[Loop];
                MyModel.Private_Contact = Private_Contacts[Loop];
                MyModel.Auth_PK = Auth_PKs[Loop];
                MyModel.Sign_PK = Sign_PKs[Loop];
                MyModel.OOB_PK = OOB_PKs[Loop];
                MyModel.ValidDate_Day = ASPK_ValidDays[Loop];
                MyModel.ValidDate_Month = ASPK_ValidMonths[Loop];
                MyModel.ValidDate_Year = ASPK_ValidYears[Loop];
                String TLAUInfoModelJSONString = JsonConvert.SerializeObject(MyModel);
                RSAHelper.SetRSACredentials();
                (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(TLAUInfoModelJSONString, "gtkTFlA1yXTFl_k-OjjltMn5IEqA-YpcD6SuYRksNhVKj8eP3IZ0zREbhQpI2P9aIdEaXxzRhCum89Xe-xEnnHKsmB1CcLMuVSXOtuUz9xQ0XCX3L2hxoytWqviGkn16Cx8_YeOGuHWdJVqjF-oZVY2-Q32kHBbT79AniJHCFxTFuYYIo2YXPD24yVxFgjuySg2LtLo5ImYBkPjs-fnrKW8jAPMr-gmPSgaq7dLf95GBYKIQLjY13ABUaSvODbjBgKHXhB3N6ZALfrPzMLe6pl-_onAvNGzXZXeKyHnY-ar1wnPpGEo8QUXjkQrimBjYJhlE1DxC9J5K7KJgQ2xkLbTPpgfNwQxVUwN5b1CBokxBLUJtCzqxC0ZZC3WEA7ZEqpb0IEeAY7g20O3dN9aJw9VpYaoKjYOVRqmUMmE_XgDtglAVtV1X03-OyYZS3Ss_tz3bUWlv1XvxiW3sDFLLYs9nRkPvEklqT4280uRJbfMkLcgW9wlfzJwPgFJ5MTm9fD5PKGRDOCcNLrXVlacdnLQ_9YlWV9UFgu6CSZsH7v1_frA5VGitK3mfrhvuKJN1ZxszolcwJJAbbw1P-0DbrGF5B6KRE01-f_5v35sBgEm6K4umYbaJ5LFdkpHOn1uPP0H8XSeT_TfG69F7lLHG_YCWXiQzYBeWKK2xyJhjMjU",
                    RSAHelper.RSAModulus, RSAHelper.RSAExponent, RSAHelper.RSAD, RSAHelper.RSAP, RSAHelper.RSAQ, RSAHelper.RSADP, RSAHelper.RSADQ, RSAHelper.RSAInverseQ);
                //Need to modify slightly on the SimplifiedArweaveSDK..
                if (MyResults.Status.CompareTo("OK") == 0)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "UPDATE `Node_Users` SET `Arweave_ID`=@Arweave_ID WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_IDs[Loop];
                    MySQLGeneralQuery.Parameters.Add("@Arweave_ID", MySqlDbType.Text).Value = MyResults.TransactionID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                }
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
