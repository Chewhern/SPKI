﻿using SPKITL_ServerApp_CApp.LocalAPIHelper;
using SPKITL_ServerApp_CApp.RepetitiveOperationsHelper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;

namespace SPKITL_ServerApp_CApp.StartupHelper
{
    public static class StartupOrBackgroundOpsHelper
    {
        public static void StartupFunction() 
        {
            UsersRemovalHelper.RemoveUsers();
            GenerateArweaveAnchorForPNUsersHelper.GenerateAnchorsForPNUsers();
            SigningOperationsHelper.GeneratePCOTForUsers();
            ArweaveCertificateOpsHelper.PerformCOTOperations();
            UpdateNodePKHelper.UpdatePK();
            //Do something.. to make it detects.. whether run at least 1 time..
            if (File.Exists("/Project/SPKITL/Node/HasRunFirstTime.txt") == false) 
            {
                File.WriteAllText("/Project/SPKITL/Node/HasRunFirstTime.txt", "Yes");
            }
        }

        public static Boolean HasStartedUp() 
        {
            Boolean HasStarted = false;
            if (File.Exists("/Project/SPKITL/Node/HasRunFirstTime.txt") == true)
            {
                String TestString = File.ReadAllText("/Project/SPKITL/Node/HasRunFirstTime.txt");
                if(TestString!=null && TestString.CompareTo("Yes") == 0) 
                {
                    HasStarted = true;
                }
            }
            return HasStarted;
        }


        public static void BackgroundOperationsFunction() 
        {
            UsersRemovalHelper.RemoveUsers();
            GenerateArweaveAnchorForPNUsersHelper.GenerateAnchorsForPNUsers();
            SigningOperationsHelper.GeneratePCOTForUsers();
            ArweaveCertificateOpsHelper.PerformCOTOperations();
            UpdateNodePKHelper.UpdatePK();
        }
    }
}
