﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;
using Newtonsoft.Json;
using SPKITL_ServerApp_CApp.Helper;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace SPKITL_ServerApp_CApp.UtilityHelper
{
    public static class SingleONodeCheck
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static int CheckParentNodeExistence(String ONode_API_IP_Address)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            int Count = 0;
            MySqlDataReader MyReader;
            String IP_Address = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                IP_Address = MyReader.GetString("IP_Address");
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(500);
                client.BaseAddress = new Uri(ONode_API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ONode_Registration/CheckExist?IP_Address="+IP_Address);
                response.Wait();
                var result = response.Result;

                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    if (Result.Contains("Error") == true)
                    {
                        throw new Exception("Error:" + Result);
                    }
                    else 
                    {
                        Count = int.Parse(Result);
                    }
                }
                else
                {
                    throw new Exception("Error: Other Node encounter some issues");
                }
            }
            return Count;
        }
    }
}
