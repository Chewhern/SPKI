﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_ServerApp_CApp.SPKIDataModel
{
    public class TLAUCertModel
    {
        public String User_ID { get; set; }

        public TLONSignedCredentialsModel[] SignedCredentials { get; set; }
    }
}
