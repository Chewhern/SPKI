﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.UtilityHelper;

namespace SPKITL_ServerApp_CApp.APIHelper
{
    public static class UpdatePNodePKOnONodes
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void ParentNodeUpdatePKsOnONodes(String New_Auth_PK) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyReader;
            String ExceptionString = "";
            String ONode_API_IP_Address = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read()) 
            {
                ONode_API_IP_Address = MyReader.GetString("API_IP_Address");
                SingleONodePKUpdate.UpdateParentNodePKOnOneONode(ONode_API_IP_Address,New_Auth_PK);
                ONode_API_IP_Address = "";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            UpdateLocalNodeAuthPK.UpdateNodeAuthPK(New_Auth_PK);
        }
    }
}
