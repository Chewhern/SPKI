﻿using ASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKITL_ServerApp_CApp.Helper;
using System.Net.Http.Headers;

namespace SPKITL_ServerApp_CApp.APIHelper
{
    public static class VerifyONodePK
    {
        public static Boolean IsONodePKChanged(String ONode_Auth_PK,String IP_Address,String[] API_IP_Addresses) 
        {
            Boolean PKNotChanged = true;
            int Loop = 0;
            while (Loop < API_IP_Addresses.Length) 
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(API_IP_Addresses[Loop]);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.GetAsync("GetONodePK?IP_Address=" + IP_Address);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        if (Result.Contains("Error") == false) 
                        {
                            String TrimmedResult = Result.Substring(1, Result.Length - 2);
                            if (ONode_Auth_PK.CompareTo(TrimmedResult) != 0) 
                            {
                                PKNotChanged = false;
                                break;
                            }
                        }
                        else 
                        {
                            PKNotChanged = false;
                            break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Other Node encounter some issues");
                    }
                }
                Loop += 1;
            }
            return PKNotChanged;
        }
    }
}
