﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.LocalAPISubHelper;

namespace SPKITL_ServerApp_CApp.APIHelper
{
    public static class RegisterPNodeToONodes
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void RegisteringParentNode() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyReader;
            String ExceptionString = "";
            List<String> ONode_API_IP_Addresses_List = new List<String>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                ONode_API_IP_Addresses_List.Add(MyReader.GetString("API_IP_Address"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            if (File.Exists("/Project/SPKITL/Node/ONodeInformation.txt")==true) 
            {
                String[] ONode_API_IP_Addresses = File.ReadAllLines("/Project/SPKITL/Node/ONodeInformation.txt");
                int Loop = 0;
                if (ONode_API_IP_Addresses.Length > 0)
                {
                    while (Loop < ONode_API_IP_Addresses.Length)
                    {
                        SingleONodeRegistration.RegisterPNodeInformationOnSONode(ONode_API_IP_Addresses[Loop]);
                        Loop += 1;
                    }
                    File.WriteAllText("/Project/SPKITL/Node/ONodeInformation.txt","");
                }
                else
                {
                    while (Loop < ONode_API_IP_Addresses_List.Count)
                    {
                        SingleONodeRegistration.RegisterPNodeInformationOnSONode(ONode_API_IP_Addresses_List[Loop]);
                        Loop += 1;
                    }
                }
            }
        }
    }
}
