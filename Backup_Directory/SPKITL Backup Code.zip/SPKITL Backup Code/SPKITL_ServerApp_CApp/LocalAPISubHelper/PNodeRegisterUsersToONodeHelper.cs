﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.APIHelper;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using SPKITL_ServerApp_CApp.UtilityHelper;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Web;

namespace SPKITL_ServerApp_CApp.LocalAPISubHelper
{
    public static class PNodeRegisterUsersToONodeHelper
    {
        //In most cases, only public contacts will be used
        //private contacts on the other hand might only exist
        //in a slightly more confidential manner
        //.. will explain in documentation if required..
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void RegisterNodeUsersToONode(String ONode_API_IP_Address) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            List<String> User_IDs = new List<String>();
            List<String> Auth_PKs = new List<String>();
            List<String> Sign_PKs = new List<String>();
            List<int> ASPK_ValidDays = new List<int>();
            List<int> ASPK_ValidMonths = new List<int>();
            List<int> ASPK_ValidYears = new List<int>();
            List<String> Arweave_IDs = new List<String>();
            Byte[] Challenge = new Byte[] { };
            Byte[] DecryptedNodePrivateKey = new Byte[] { };
            Byte[] SignedChallenge = new Byte[] { };
            String SignedChallengeString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                IP_Address = MyReader.GetString("IP_Address");
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users` WHERE DATEDIFF( CURDATE(), STR_TO_DATE( CONCAT(ASPK_ValidYear, '-', ASPK_ValidMonth, '-', ASPK_ValidDay), '%Y-%m-%d' ) ) <= 0";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read()) 
            {
                User_IDs.Add(MyReader.GetString("User_ID"));
                Auth_PKs.Add(MyReader.GetString("Auth_PK"));
                Sign_PKs.Add(MyReader.GetString("Sign_PK"));
                ASPK_ValidDays.Add(MyReader.GetInt16("ASPK_ValidDay"));
                ASPK_ValidMonths.Add(MyReader.GetInt16("ASPK_ValidMonth"));
                ASPK_ValidYears.Add(MyReader.GetInt16("ASPK_ValidYear"));
                Arweave_IDs.Add(MyReader.GetString("Arweave_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            int Count = SingleONodeCheck.CheckParentNodeExistence(ONode_API_IP_Address);
            int Loop = 0;
            if (Count == 1)
            {
                while (Loop < User_IDs.Count) 
                {
                    Challenge = GetONodeChallenge.GetChallenge(ONode_API_IP_Address);
                    if (Challenge.Length != 0) 
                    {
                        DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                        SignedChallenge = new Byte[] { };
                        if (DecryptedNodePrivateKey.Length == 64)
                        {
                            Boolean IsZero = true;
                            IntPtr DecryptedNodePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, DecryptedNodePrivateKey.Length);
                            Marshal.Copy(DecryptedNodePrivateKey, 0, DecryptedNodePrivateKeyIntPtr, DecryptedNodePrivateKey.Length);
                            SodiumSecureMemory.SecureClearBytes(DecryptedNodePrivateKey);
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKeyIntPtr, true);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SignedChallengeString = Convert.ToBase64String(SignedChallenge);
                        using (var client = new HttpClient())
                        {
                            client.BaseAddress = new Uri(ONode_API_IP_Address);
                            client.DefaultRequestHeaders.Accept.Clear();
                            client.DefaultRequestHeaders.Accept.Add(
                                new MediaTypeWithQualityHeaderValue("application/json"));
                            var response = client.GetAsync("ONode_Users_Registration?IP_Address=" + HttpUtility.UrlEncode(IP_Address) + "&SignedChallenge=" + HttpUtility.UrlEncode(SignedChallengeString) + "&User_ID=" + HttpUtility.UrlEncode(User_IDs[Loop]) + "&Auth_PK=" + HttpUtility.UrlEncode(Auth_PKs[Loop]) + "&Sign_PK=" + HttpUtility.UrlEncode(Sign_PKs[Loop]) + "&Valid_DayString=" + ASPK_ValidDays[Loop] + "&Valid_MonthString=" + ASPK_ValidMonths[Loop] + "&Valid_YearString=" + ASPK_ValidYears[Loop] + "&Arweave_IDString=" + HttpUtility.UrlEncode(Arweave_IDs[Loop]));
                            response.Wait();
                            var result = response.Result;
                            if (result.IsSuccessStatusCode)
                            {
                                var readTask = result.Content.ReadAsStringAsync();
                                readTask.Wait();

                                var Result = readTask.Result;

                                if (Result.Contains("Error") == true)
                                {
                                    if (Result.Contains("Error: ONode user existed aborting insertion..") != true)
                                    {
                                        throw new Exception("Error:" + Result.Substring(1, Result.Length - 2));
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Error: Other Node encounter some issues");
                            }
                        }
                    }
                    Loop += 1;
                }
            }
        }
    }
}
