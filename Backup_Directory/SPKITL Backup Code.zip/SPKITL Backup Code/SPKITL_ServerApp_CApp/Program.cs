﻿// See https://aka.ms/new-console-template for more information

using ASodium;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using SPKITL_ServerApp_CApp.StartupHelper;

Boolean HasStarted = StartupOrBackgroundOpsHelper.HasStartedUp();

SodiumInit.Init();
InitializationHelper.Initialize();
if (InitializationHelper.IsAllInitialized() == true)
{
    if (HasStarted == false)
    {
        StartupOrBackgroundOpsHelper.StartupFunction();
    }
    else 
    {
        StartupOrBackgroundOpsHelper.BackgroundOperationsFunction();
    }
}
CCOperations.ClearKeys();