﻿using ASodium;
using BCASodium;
using SPKITL_ServerApp_CApp.APIHelper;
using System.Runtime.InteropServices;

namespace SPKITL_ServerApp_CApp.SimpleSoftHSM
{
    public static class CCOperations
    {
        private static IntPtr TempMasterMACKeyIntPtr;
        private static IntPtr TempMasterEncryptionKeyIntPtr;
        private static Byte[] Nonce1 = SodiumHelper.HexToBinary("352b66077513f1abe7da139522739e16244d0f2f044e6524");
        private static Byte[] Nonce2 = SodiumHelper.HexToBinary("924400f379fbd71f6d9f66b436159078715548e1282600e1");
        // /Project/SPKITL/Node
        // /Project/SPKITL/User_PublicKeys
        // /Project/SPKITL/User_SignaturePrivateKeys
        // /Project/SPKITL/Node/Exported

        public static void InitializeOperations() 
        {
            InitializeIntPtrs();
            CreateMasterKeys_Version2();
        }

        private static void InitializeIntPtrs() 
        {
            Boolean IsZeroPtr1 = true;
            Boolean IsZeroPtr2 = true;
            while(IsZeroPtr1 == true || IsZeroPtr2 == true) 
            {
                TempMasterMACKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZeroPtr1, 32);
                TempMasterEncryptionKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZeroPtr2, 32);
            }
        }


        private static void CreateMasterKeys_Version2() 
        {
            //Input your seedsources here, you can use libsodium's binary to hex converter to replace the 00
            Byte[] SeedSource1 = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00 };
            Byte[] SeedSource2 = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00 };
            Byte[] EncryptedMACKeyWithMAC = File.ReadAllBytes("/Project/SPKITL/Node/MACSecretKey.txt");
            Byte[] EncryptedEncryptionKeyWithMAC = File.ReadAllBytes("/Project/SPKITL/Node/EncryptionSecretKey.txt");
            Byte[] PreGeneratedMACKey = SodiumRNG.GetSeededRandomBytes(32, SeedSource1, true);
            Byte[] PreGeneratedEncryptionKey = SodiumRNG.GetSeededRandomBytes(32, SeedSource2, true);
            Boolean IsZero1 = false;
            Boolean IsZero2 = false;
            IntPtr PreGeneratedMACKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero1, 32);
            IntPtr PreGeneratedEncryptionKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero2, 32);
            Marshal.Copy(PreGeneratedMACKey, 0, PreGeneratedMACKeyIntPtr, 32);
            Marshal.Copy(PreGeneratedEncryptionKey, 0, PreGeneratedEncryptionKeyIntPtr, 32);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(PreGeneratedMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(PreGeneratedEncryptionKeyIntPtr);
            SodiumSecureMemory.SecureClearBytes(PreGeneratedMACKey);
            SodiumSecureMemory.SecureClearBytes(PreGeneratedEncryptionKey);
            if (EncryptedMACKeyWithMAC.Length == EncryptedEncryptionKeyWithMAC.Length) 
            {
                Byte[] EncryptedMACKeyMAC = new Byte[64];
                Byte[] EncryptedEncryptionKeyMAC = new Byte[64];
                Byte[] EncryptedMACKey = new Byte[EncryptedMACKeyWithMAC.Length - EncryptedMACKeyMAC.Length];
                Byte[] EncryptedEncryptionKey = new Byte[EncryptedEncryptionKeyWithMAC.Length - EncryptedEncryptionKeyMAC.Length];
                Buffer.BlockCopy(EncryptedMACKeyWithMAC,0,EncryptedMACKeyMAC,0,EncryptedEncryptionKeyMAC.Length);
                Buffer.BlockCopy(EncryptedMACKeyWithMAC, EncryptedEncryptionKeyMAC.Length, EncryptedMACKey, 0, EncryptedMACKey.Length);
                Buffer.BlockCopy(EncryptedEncryptionKeyWithMAC, 0, EncryptedEncryptionKeyMAC, 0, EncryptedEncryptionKeyMAC.Length);
                Buffer.BlockCopy(EncryptedEncryptionKeyWithMAC, EncryptedEncryptionKeyMAC.Length, EncryptedEncryptionKey, 0, EncryptedEncryptionKey.Length);
                Boolean AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(EncryptedMACKeyMAC, EncryptedMACKey, PreGeneratedMACKeyIntPtr);
                Boolean AbleToVerifyHMAC2 = SodiumHMACSHA512.VerifyMAC(EncryptedEncryptionKeyMAC, EncryptedEncryptionKey, PreGeneratedMACKeyIntPtr);
                if(AbleToVerifyHMAC==true && AbleToVerifyHMAC2 == true) 
                {
                    Byte[] DecryptedMACKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedMACKey, Nonce1, PreGeneratedEncryptionKeyIntPtr);
                    Byte[] DecryptedEncryptionKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedEncryptionKey, Nonce2, PreGeneratedEncryptionKeyIntPtr);
                    Marshal.Copy(DecryptedMACKey, 0, TempMasterMACKeyIntPtr, 32);
                    Marshal.Copy(DecryptedEncryptionKey, 0, TempMasterEncryptionKeyIntPtr, 32);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
                    SodiumSecureMemory.SecureClearBytes(DecryptedMACKey);
                    SodiumSecureMemory.SecureClearBytes(DecryptedEncryptionKey);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(PreGeneratedMACKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(PreGeneratedMACKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(PreGeneratedEncryptionKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(PreGeneratedEncryptionKeyIntPtr);
                }
                else 
                {
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(PreGeneratedMACKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(PreGeneratedMACKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(PreGeneratedEncryptionKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(PreGeneratedEncryptionKeyIntPtr);
                    throw new Exception("Error: Unable to verify HMAC");
                }
            }
            else 
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(PreGeneratedMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(PreGeneratedMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(PreGeneratedEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(PreGeneratedEncryptionKeyIntPtr);
                throw new Exception("Error: These two private keys length must be the same");
            }
        }

        public static void GenerateAndEncryptSignaturePrivateKey(Boolean IsED25519=true) 
        {
            Boolean DoesNodeSignatureKeyPairExist = File.Exists("/Project/SPKITL/Node/SPrivateKey.txt");
            if (DoesNodeSignatureKeyPairExist == true)
            {
                String NodeSignatureKPPKB64 = "";
                Byte[] EncryptedNodeSPrivateKey = new Byte[] { };
                Byte[] NodeSPublicKey = new Byte[] { };
                if (IsED25519)
                {
                    RevampedKeyPair NodeED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    EncryptedNodeSPrivateKey = EncryptNodeSignaturePrivateKey(NodeED25519KeyPair.PrivateKey);
                    NodeSPublicKey = NodeED25519KeyPair.PublicKey;
                    NodeSignatureKPPKB64 = Convert.ToBase64String(NodeSPublicKey);
                    NodeED25519KeyPair.Clear();
                }
                else
                {
                    ED448RevampedKeyPair NodeED448KeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    EncryptedNodeSPrivateKey = EncryptNodeSignaturePrivateKey(NodeED448KeyPair.PrivateKey);
                    NodeSPublicKey = NodeED448KeyPair.PublicKey;
                    NodeSignatureKPPKB64 = Convert.ToBase64String(NodeSPublicKey);
                    NodeED448KeyPair.Clear();
                }
                NodeSPublicKey = Convert.FromBase64String(NodeSignatureKPPKB64);
                UpdatePNodePKOnONodes.ParentNodeUpdatePKsOnONodes(NodeSignatureKPPKB64);
                ExportNodeSignaturePrivateKey();
                File.WriteAllBytes("/Project/SPKITL/Node/SPrivateKey.txt", EncryptedNodeSPrivateKey);
                File.WriteAllBytes("/Project/SPKITL/Node/SPublicKey.txt", NodeSPublicKey);
            }
        }

        private static Byte[] EncryptNodeSignaturePrivateKey(Byte[] PrivateKey,Boolean ClearKey=false) 
        {
            Byte[] EncryptedPrivateKeyWithMAC = new Byte[] { };
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterEncryptionKeyIntPtr);
            Byte[] MAC = new Byte[64];
            Byte[] EncryptedNodeSignaturePrivateKey = new Byte[PrivateKey.Length];
            Byte[] CipherTextWithMAC = new Byte[MAC.Length + EncryptedNodeSignaturePrivateKey.Length];
            Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
            TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
            EncryptedNodeSignaturePrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(PrivateKey, TempNonce, TempMasterEncryptionKeyIntPtr);
            MAC = SodiumHMACSHA512.ComputeMAC(EncryptedNodeSignaturePrivateKey, TempMasterMACKeyIntPtr);
            CipherTextWithMAC = MAC.Concat(EncryptedNodeSignaturePrivateKey).ToArray();
            EncryptedPrivateKeyWithMAC = CipherTextWithMAC;
            if (ClearKey == true) 
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
            return EncryptedPrivateKeyWithMAC;
        }

        public static Byte[] DecryptNodeSignaturePrivateKey(Boolean ClearKey = false) 
        {
            Byte[] EncryptedPrivateKeyWithMAC = File.ReadAllBytes("/Project/SPKITL/Node/SPrivateKey.txt");
            Byte[] EncryptedPrivateKeyMAC = new Byte[64];
            Byte[] EncryptedPrivateKey = new Byte[EncryptedPrivateKeyWithMAC.Length - EncryptedPrivateKeyMAC.Length];
            Byte[] DecryptedPrivateKey = new Byte[EncryptedPrivateKey.Length];
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterEncryptionKeyIntPtr);
            Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
            TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
            Array.Copy(EncryptedPrivateKeyWithMAC, 0, EncryptedPrivateKeyMAC, 0, EncryptedPrivateKeyMAC.Length);
            Array.Copy(EncryptedPrivateKeyWithMAC, EncryptedPrivateKeyMAC.Length, EncryptedPrivateKey, 0, EncryptedPrivateKey.Length);
            Boolean AbleToVerify = SodiumHMACSHA512.VerifyMAC(EncryptedPrivateKeyMAC, EncryptedPrivateKey, TempMasterMACKeyIntPtr);
            if (AbleToVerify == true)
            {
                DecryptedPrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedPrivateKey, TempNonce, TempMasterEncryptionKeyIntPtr);
            }
            else
            {
                throw new Exception("Error: Unable to verify MAC on encrypted node signature private key");
            }
            if (ClearKey == true)
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
            return DecryptedPrivateKey;
        }

        private static void ExportNodeSignaturePrivateKey(Boolean ClearKey=false) 
        {
            Byte[] DecryptedNodeSignaturePrivateKey = DecryptNodeSignaturePrivateKey();
            //Add public key here on StringB64..
            String X25519OrX448MACPublicKeyStringB64 = "BxkDAmll3waGHGNDEk/HIT2sN74DAaUC89uHt/a8OjImJwh+g5XjC5iKs3ofL6oO6vLVd8t8dkw=";
            Byte[] X25519OrX448MACPublicKey = Convert.FromBase64String(X25519OrX448MACPublicKeyStringB64);
            String X25519OrX448EncryptionPublicKeyStringB64 = "g8XHEzauiGuKJLG1vbqJubEppzA14aCgpHkWagS+2hvA/jerqLFRVEBdAgZ4aqHByQ1i47G4AfM=";
            Byte[] X25519OrX448EncryptionPublicKey = Convert.FromBase64String(X25519OrX448EncryptionPublicKeyStringB64);
            Boolean IsZero1 = false;
            Boolean IsZero2 = false;
            IntPtr MACSharedSecretIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero1, 32);
            IntPtr EncryptionSharedSecretIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero2, 32);
            Byte[] MACSharedSecret = new Byte[] { };
            Byte[] EncryptionSharedSecret = new Byte[] { };
            Byte[] ActualMACSharedSecret = new Byte[] { };
            Byte[] ActualEncryptionSharedSecret = new Byte[] { };
            Byte[] ServerEphemeralX25519OrX448PublicKeys = new Byte[] { };
            Byte[] TempNonce = new Byte[] { };
            Byte[] EncryptedNodeSignaturePrivateKey = new Byte[] { };
            Byte[] MACOfEncryptedNodeSignaturePrivateKey = new Byte[] { };
            Byte[] MACWithEncryptedNodeSignaturePrivateKey = new Byte[] { };
            Byte[] ActualEncryptedNodeSignaturePrivateKey = new Byte[] { };
            if(X25519OrX448MACPublicKey.Length==0 || X25519OrX448EncryptionPublicKey.Length == 0) 
            {
                throw new Exception("Error: Either one of the key exchange public keys was empty");
            }
            if(X25519OrX448MACPublicKey.Length != X25519OrX448EncryptionPublicKey.Length) 
            {
                throw new Exception("Error: Both key exchange public keys must have equal legnth");
            }
            if (X25519OrX448MACPublicKey.Length == 32) 
            {
                KeyPair ServerEphemeralX25519MACKeyPair = SodiumPublicKeyBox.GenerateKeyPair();
                KeyPair ServerEphemeralX25519EncryptionKeyPair = SodiumPublicKeyBox.GenerateKeyPair();
                MACSharedSecretIntPtr = SodiumPublicKeyBox.GenerateSharedSecretIntPtr(ServerEphemeralX25519MACKeyPair.GetPrivateKey(), X25519OrX448MACPublicKey, true);
                EncryptionSharedSecretIntPtr = SodiumPublicKeyBox.GenerateSharedSecretIntPtr(ServerEphemeralX25519EncryptionKeyPair.GetPrivateKey(), X25519OrX448EncryptionPublicKey, true);
                ServerEphemeralX25519OrX448PublicKeys = ServerEphemeralX25519MACKeyPair.GetPublicKey().Concat(ServerEphemeralX25519EncryptionKeyPair.GetPublicKey()).ToArray();
                TempNonce = X25519OrX448MACPublicKey.Concat(X25519OrX448EncryptionPublicKey).Concat(ServerEphemeralX25519OrX448PublicKeys).ToArray();
                TempNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), TempNonce);
                EncryptedNodeSignaturePrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DecryptedNodeSignaturePrivateKey, TempNonce, EncryptionSharedSecretIntPtr, true);
                MACOfEncryptedNodeSignaturePrivateKey = SodiumHMACSHA512.ComputeMAC(EncryptedNodeSignaturePrivateKey, MACSharedSecretIntPtr, true);
                ServerEphemeralX25519MACKeyPair.Clear();
                ServerEphemeralX25519EncryptionKeyPair.Clear();
            }
            else 
            {
                X448RevampedKeyPair ServerEphemeralX448MACKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                X448RevampedKeyPair ServerEphemeralX448EncryptionKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                MACSharedSecret = SecureX448.CalculateSecret(X25519OrX448MACPublicKey, ServerEphemeralX448MACKeyPair.PrivateKey, true);
                EncryptionSharedSecret = SecureX448.CalculateSecret(X25519OrX448EncryptionPublicKey, ServerEphemeralX448EncryptionKeyPair.PrivateKey, true);
                ActualMACSharedSecret = SodiumKDF.KDFFunction(32, 1, "MAC'sKDF", MACSharedSecret,true);
                ActualEncryptionSharedSecret = SodiumKDF.KDFFunction(32, 1, "ENC'sKDF", EncryptionSharedSecret,true);
                ServerEphemeralX25519OrX448PublicKeys = ServerEphemeralX448MACKeyPair.PublicKey.Concat(ServerEphemeralX448EncryptionKeyPair.PublicKey).ToArray();
                TempNonce = X25519OrX448MACPublicKey.Concat(X25519OrX448EncryptionPublicKey).Concat(ServerEphemeralX25519OrX448PublicKeys).ToArray();
                TempNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), TempNonce);
                EncryptedNodeSignaturePrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DecryptedNodeSignaturePrivateKey, TempNonce, ActualEncryptionSharedSecret, true);
                MACOfEncryptedNodeSignaturePrivateKey = SodiumHMACSHA512.ComputeMAC(EncryptedNodeSignaturePrivateKey, ActualMACSharedSecret, true);
                ServerEphemeralX448MACKeyPair.Clear();
                ServerEphemeralX448EncryptionKeyPair.Clear();
            }
            MACWithEncryptedNodeSignaturePrivateKey = MACOfEncryptedNodeSignaturePrivateKey.Concat(EncryptedNodeSignaturePrivateKey).ToArray();
            ActualEncryptedNodeSignaturePrivateKey = ServerEphemeralX25519OrX448PublicKeys.Concat(MACWithEncryptedNodeSignaturePrivateKey).ToArray();
            File.WriteAllBytes("/Project/SPKITL/Node/Exported/EncryptedNodeSPrivateKey.txt", ActualEncryptedNodeSignaturePrivateKey);
            SodiumSecureMemory.SecureClearBytes(DecryptedNodeSignaturePrivateKey);
            if (ClearKey == true)
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
        }

        public static Byte[] DecryptUserSignaturePrivateKey(String PrivateKeyPath,Boolean ClearKey=false) 
        {
            Byte[] EncryptedUserPrivateKeyWithMAC = File.ReadAllBytes(PrivateKeyPath);
            Byte[] EncryptedUserPrivateKeyMAC = new Byte[64];
            Byte[] EncryptedUserPrivateKey = new Byte[EncryptedUserPrivateKeyWithMAC.Length - EncryptedUserPrivateKeyMAC.Length];
            Byte[] DecryptedUserPrivateKey = new Byte[EncryptedUserPrivateKey.Length];
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterEncryptionKeyIntPtr);
            Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
            TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
            Array.Copy(EncryptedUserPrivateKeyWithMAC, 0, EncryptedUserPrivateKeyMAC, 0, EncryptedUserPrivateKeyMAC.Length);
            Array.Copy(EncryptedUserPrivateKeyWithMAC, EncryptedUserPrivateKeyMAC.Length, EncryptedUserPrivateKey, 0, EncryptedUserPrivateKey.Length);
            Boolean AbleToVerify = SodiumHMACSHA512.VerifyMAC(EncryptedUserPrivateKeyMAC, EncryptedUserPrivateKey, TempMasterMACKeyIntPtr);
            if (AbleToVerify == true)
            {
                DecryptedUserPrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedUserPrivateKey, TempNonce, TempMasterEncryptionKeyIntPtr);
            }
            else
            {
                throw new Exception("Error: Unable to verify MAC on encrypted node signature private key");
            }
            if (ClearKey == true)
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
            return DecryptedUserPrivateKey;
        }

        public static void ClearKeys() 
        {
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
        }
    }
}
