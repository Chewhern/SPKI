﻿using SPKITL_ServerApp_CApp.APIHelper;
using SPKITL_ServerApp_CApp.StartupHelper;

namespace SPKITL_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class ArweaveCertificateOpsHelper
    {
        private static void FetchCOTForNodeUsers() 
        {
            if (InitializationHelper.IsAllInitialized() == true) 
            {
                ParentNodeFetchONodeArweaveCertificates.CreateArweaveCertificatesForAllPNodeUsers();
            }
        }

        public static void PerformCOTOperations() 
        {
            FetchCOTForNodeUsers();
        }
    }
}
