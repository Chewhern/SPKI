﻿using SPKITL_ServerApp_CApp.LocalAPIHelper;

namespace SPKITL_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class SigningOperationsHelper
    {
        private static void SigningUsers() 
        {
            PNodeSignONodeUsersHelper.SignAllONodeUsers();
            PNodeSignSNodeUsersHelper.SignAllSNodeUsers();
        }

        public static void GeneratePCOTForUsers() 
        {
            SigningUsers();
        }
    }
}
