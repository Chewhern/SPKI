﻿using SPKITL_ServerApp_CApp.LocalAPIHelper;

namespace SPKITL_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class UsersRemovalHelper
    {
        private static void RemovingUsers() 
        {
            PNodeLocalDeleteSNodeUsersHelper.DeleteSNodeUsers();
            PNodeLocalDeleteONodeUsersHelper.DeleteONodeUsers();
            PNodeLocalDeleteNodeUsersHelper.DeleteNodeUsers();
        }

        public static void RemoveUsers() 
        {
            RemovingUsers();
        }
    }
}
