﻿using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using SPKITL_ServerApp_CApp.StartupHelper;

namespace SPKITL_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class UpdateNodePKHelper
    {
        private static Boolean HasNodeBeenInitialized = InitializationHelper.IsAllInitialized();
        //Postpone for now..

        private static void UpdateNodePK() 
        {
            if(HasNodeBeenInitialized == true) 
            {
                CCOperations.GenerateAndEncryptSignaturePrivateKey();
            }
        }

        public static void UpdatePK() 
        {
            UpdateNodePK();
        }
    }
}
