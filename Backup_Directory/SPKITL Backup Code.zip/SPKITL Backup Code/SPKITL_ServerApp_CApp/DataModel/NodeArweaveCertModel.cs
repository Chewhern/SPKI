﻿namespace SPKITL_ServerApp_CApp.DataModel
{
    public class NodeArweaveCertModel
    {
        public String NodeAUInfoArweaveID { get; set; }

        public String NodeAUCertInfoArweaveID { get; set; }

        public String[] ONodeAUInfoArweaveIDs { get; set; }

        public String Status { get; set; }
    }
}
