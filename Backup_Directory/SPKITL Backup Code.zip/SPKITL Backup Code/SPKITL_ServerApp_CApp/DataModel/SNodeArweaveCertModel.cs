﻿namespace SPKITL_ServerApp_CApp.DataModel
{
    public class SNodeArweaveCertModel
    {
        public String SNodeAUCertInfoArweaveID { get; set; }

        public String[] NodeAUCertInfoArweaveIDs { get; set; }

        public String[] NodeAUInfoArweaveIDs { get; set; }

        public String[] ONodeAUInfoArweaveIDs { get; set; }

        public String Status { get; set; }
    }
}
