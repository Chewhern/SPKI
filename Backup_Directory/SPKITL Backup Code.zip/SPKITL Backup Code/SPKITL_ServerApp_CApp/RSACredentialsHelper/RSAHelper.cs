﻿using ASodium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_ServerApp_CApp.RSACredentialsHelper
{
    public static class RSAHelper
    {
        //In future might need to make RSA and ED448 safer
        //in a security engineering manner (leaning towards software based side-channel attacks)..
        //due to such a consideration, the whole suite might be better
        //off staying as a Linux application
        //instead of able to support Windows due to certain limitations on Windows
        public static Byte[] RSAModulus = new Byte[] { };
        public static Byte[] RSAExponent = new Byte[] { };
        public static Byte[] RSAD = new Byte[] { };
        public static Byte[] RSAP = new Byte[] { };
        public static Byte[] RSAQ = new Byte[] { };
        public static Byte[] RSADP = new Byte[] { };
        public static Byte[] RSADQ = new Byte[] { };
        public static Byte[] RSAInverseQ = new Byte[] { };

        public static void SetRSACredentials() 
        {
            //Change accordingly during build/compilation..
            RSAModulus = new Byte[] { 0x00, 0x00, 0x00};
            RSAExponent = new Byte[] { 0x00, 0x00, 0x00 };
            RSAD = new Byte[] { 0x00, 0x00, 0x00 };
            RSAP = new Byte[] { 0x00, 0x00, 0x00 };
            RSAQ = new Byte[] { 0x00, 0x00, 0x00 };
            RSADP = new Byte[] { 0x00, 0x00, 0x00 };
            RSADQ = new Byte[] { 0x00, 0x00, 0x00 };
            RSAInverseQ = new Byte[] { 0x00, 0x00, 0x00 };
        }
    }
}
