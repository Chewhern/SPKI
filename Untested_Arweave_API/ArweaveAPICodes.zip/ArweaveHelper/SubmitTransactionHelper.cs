﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestApplication.ArweaveModel;

namespace TestApplication.ArweaveHelper
{
    public static class SubmitTransactionHelper
    {
        //Need to test..
        //12MB Max.
        public static String SubmitTransaction(TransactionModel MyModel) 
        {
            String SubmitStatus = "";
            String JSONBodyString = "";
            StringContent PostRequestData = new StringContent("");
            JSONBodyString = JsonConvert.SerializeObject(MyModel);
            PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://arweave.net/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.PostAsync("tx", PostRequestData);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    SubmitStatus = "OK";
                }
                else
                {
                    if (result.StatusCode == System.Net.HttpStatusCode.AlreadyReported)
                    {
                        SubmitStatus = "Transaction already processed.";
                    }
                    else if (result.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        SubmitStatus = "Transaction verification failed.";
                    }
                    else if (result.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        SubmitStatus = "Too Many Requests";
                    }
                    else if (result.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable) 
                    {
                        SubmitStatus = "Transaction verification failed.";
                    }
                }
            }
            return SubmitStatus;
        }
    }
}
