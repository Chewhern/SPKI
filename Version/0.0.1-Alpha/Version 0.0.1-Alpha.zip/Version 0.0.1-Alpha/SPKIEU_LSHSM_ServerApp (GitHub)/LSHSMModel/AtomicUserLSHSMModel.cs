﻿namespace SPKIEU_LSHSM_ServerApp.LSHSMModel
{
    public class AtomicUserLSHSMModel
    {
        public String EndUserID { get; set; }

        public IntPtr MACSecretKeyIntPtr { get; set; }

        public int MACSecretKeyIntPtrPermissionStatus { get; set; }

        public IntPtr EncryptionSecretKeyIntPtr { get; set; }

        public int EncryptionSecretKeyIntPtrPermissionStatus { get; set; }

        public DateTime ValidDuration { get; set; }

        public String Status { get; set; }
    }
}
