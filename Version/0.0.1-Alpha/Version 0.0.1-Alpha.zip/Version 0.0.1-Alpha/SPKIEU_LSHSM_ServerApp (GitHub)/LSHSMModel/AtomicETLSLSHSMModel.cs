﻿namespace SPKIEU_LSHSM_ServerApp.LSHSMModel
{
    public class AtomicETLSLSHSMModel
    {
        public Byte[] MACKXDSAPublicKeyBytes { get; set; }

        public Byte[] EncryptionKXDSAPublicKeyBytes { get; set; }

        public IntPtr MACKXPrivateKeyIntPtr { get; set; }

        public int MACKXPrivateKeyIntPtrPermissionStatus { get; set; }

        public Byte[] MACKXPublicKeyBytes { get; set; }

        public Byte[] EUMACKXPublicKeyBytes { get; set; }

        public IntPtr EncryptionKXPrivateKeyIntPtr { get; set; }

        public int EncryptionKXPrivateKeyIntPtrPermissionStatus { get; set; }

        public Byte[] EncryptionKXPublicKeyBytes { get; set; }

        public Byte[] EUEncryptionKXPublicKeyBytes { get; set; }

        public String EndUserID { get; set; }

        public IntPtr MACSecretKeyIntPtr { get; set; }

        public int MACSecretKeyIntPtrPermissionStatus { get; set; }

        public IntPtr EncryptionSecretKeyIntPtr { get; set; }

        public int EncryptionSecretKeyIntPtrPermissionStatus { get; set; }

        public String ETLSStatus { get; set; }
    }
}
