﻿using Newtonsoft.Json;
using SPKIEU_LSHSM_ServerApp.PostDataModel;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SPKIEU_LSHSM_ServerApp.APIMethodHelper
{
    public static class VerifyNodeUserCertificate
    {
        public static String StatusString="";

        public static void AbleToVerifyNodeUserCertificate(String Path) 
        {
            String[] FileContents = File.ReadAllLines(Path);
            String[] RowContents = new String[] { };
            DateTime[] SignedDateTimes = new DateTime[] { };
            String[] SNodeIPAddresses = new String[] { };
            String[] Signed_TNode_User_Auth_PKs = new String[] { };
            String[] Signed_TNode_User_Sign_PKs = new String[] { };
            String[] SNode_User_IDs = new String[] { };
            int Loop = 0;
            int Loop2 = 0;
            VerifyAuthorizedUserPartialCertificateModel MyModel = new VerifyAuthorizedUserPartialCertificateModel();
            if (FileContents.Length > 2) 
            {
                SignedDateTimes = new DateTime[FileContents.Length - 2];
                SNodeIPAddresses = new String[SignedDateTimes.Length - 2];
                Signed_TNode_User_Auth_PKs = new String[SignedDateTimes.Length];
                Signed_TNode_User_Sign_PKs = new String[SignedDateTimes.Length];
                SNode_User_IDs = new String[SignedDateTimes.Length];
                while (Loop < FileContents.Length) 
                {
                    if (Loop == 0) 
                    {
                        MyModel.TNode_IP_Address = FileContents[Loop];
                    }
                    else if(Loop == 1) 
                    {
                        MyModel.TNode_User_ID = FileContents[Loop];
                    }
                    else 
                    {
                        RowContents = FileContents[Loop].Split(";");

                        SNode_User_IDs[Loop2] = RowContents[0];
                        Signed_TNode_User_Auth_PKs[Loop2] = RowContents[1];
                        Signed_TNode_User_Sign_PKs[Loop2] = RowContents[2];
                        //DateTime Parse has accuracy related issues.. Not sure how to properly fix as of now
                        //will postpone when updating/maintaining the CA infrastructure. 
                        SignedDateTimes[Loop2] = DateTime.ParseExact(RowContents[3], "dd/M/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                        Loop2 += 1;
                    }
                    Loop += 1;
                }
                MyModel.SignedChallenge = "";
                MyModel.RNode_IP_Address = "";
                MyModel.SNode_User_IDs = SNode_User_IDs;
                MyModel.Signed_TNode_User_Auth_PKs = Signed_TNode_User_Auth_PKs;
                MyModel.Signed_TNode_User_Sign_PKs = Signed_TNode_User_Sign_PKs;
                MyModel.SignedDateTimes = SignedDateTimes;
                String JSONBodyString = "";
                StringContent PostRequestData = new StringContent("");
                JSONBodyString = JsonConvert.SerializeObject(MyModel);
                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://"+MyModel.TNode_IP_Address+":1001/api/");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.PostAsync("NodeCertificateOps/", PostRequestData);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        StatusString = Result.Substring(1,Result.Length-2);
                    }
                    else
                    {
                        StatusString = "Error: Middle node encounter some issues";
                    }
                }
            }
        }
    }
}
