﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKIEU_LSHSM_ServerApp.Helper;
using SPKIEU_LSHSM_ServerApp.LocalAPIHelper;
using SPKIEU_LSHSM_ServerApp.LSHSMModel;
using SPKIEU_LSHSM_ServerApp.Model;
using System.Runtime.InteropServices;

namespace SPKIEU_LSHSM_ServerApp.System_LSHSM
{
    //Project/LSHSM/EU/

    //Potential ETLSLSHSM issue: Concurrent deletion..
    //Need to revisit back in future to make the code more organized/less repetitive
    public static class ETLSLSHSM
    {
        private static List<AtomicETLSLSHSMModel> UsersETLSSessions = new List<AtomicETLSLSHSMModel> ();
        private static Boolean HasDeletionTriggered = false;
        private static DateTime DeletionDateTime = DateTime.MinValue;

        public static int FindETLSForUser(String EndUserID) 
        {
            int Result = -1;
            int Loop = 0;
            if (EndUserID!=null && EndUserID.CompareTo("") != 0) 
            {
                while (Loop < UsersETLSSessions.Count)
                {
                    if (EndUserID.CompareTo(UsersETLSSessions[Loop].EndUserID) == 0)
                    {
                        Result = Loop;
                        break;
                    }
                    Loop += 1;
                }
            }
            return Result;
        }

        public static void InitializeETLSForUser(int EndUserIDIndex,AtomicETLSLSHSMModel MyModel) 
        {
            if (EndUserIDIndex == -1) 
            {
                UsersETLSSessions.Add(MyModel);
            }
        }

        public static void FinalizeETLSForUser(int EndUserIDIndex, Byte[] SignedMACKXPublicKey, Byte[] SignedEncryptionKXPublicKey) 
        {
            if (EndUserIDIndex != -1) 
            {
                Byte[] MACKXPublicKey = new Byte[] { };
                Byte[] EncryptionKXPublicKey = new Byte[] { };
                Byte[] TNode_User_Sign_PKBytes = new Byte[] { };
                Byte[] ServerEphemeralMACKXPrivateKey = new Byte[UsersETLSSessions[EndUserIDIndex].MACKXPublicKeyBytes.Length];
                Byte[] ServerEphemeralEncryptionKXPrivateKey = new Byte[UsersETLSSessions[EndUserIDIndex].EncryptionKXPublicKeyBytes.Length];
                Byte[] TemporaryMACSharedSecret = new Byte[] { };
                Byte[] TemporaryEncryptionSharedSecret = new Byte[] { };
                Byte[] MACSharedSecret = new Byte[32];
                Byte[] EncryptionSharedSecret = new Byte[32];
                Boolean IsMACSecretKeyIntPtrZero = true;
                Boolean IsEncryptionSecretKeyIntPtrZero = true;
                IntPtr MACSecretKeyIntPtr = new IntPtr();
                IntPtr EncryptionSecretKeyIntPtr = new IntPtr();
                String ResultString = LSHSM_MethodsHelper.VerifyPublicKeys(UsersETLSSessions[EndUserIDIndex].EndUserID,ref TNode_User_Sign_PKBytes);
                if (ResultString.Contains("Error") == false) 
                {
                    if (TNode_User_Sign_PKBytes.Length == 32)
                    {
                        MACKXPublicKey = SodiumPublicKeyAuth.Verify(SignedMACKXPublicKey, TNode_User_Sign_PKBytes);
                        EncryptionKXPublicKey = SodiumPublicKeyAuth.Verify(SignedEncryptionKXPublicKey, TNode_User_Sign_PKBytes);
                    }
                    else
                    {
                        MACKXPublicKey = SecureED448.GetMessageFromSignatureMessage(TNode_User_Sign_PKBytes, SignedMACKXPublicKey, new Byte[] { });
                        EncryptionKXPublicKey = SecureED448.GetMessageFromSignatureMessage(TNode_User_Sign_PKBytes, SignedEncryptionKXPublicKey, new Byte[] { });
                    }
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtr);
                    Marshal.Copy(UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtr, ServerEphemeralMACKXPrivateKey, 0, ServerEphemeralMACKXPrivateKey.Length);
                    Marshal.Copy(UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtr, ServerEphemeralEncryptionKXPrivateKey, 0, ServerEphemeralEncryptionKXPrivateKey.Length);
                    UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtrPermissionStatus = 1;
                    UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtrPermissionStatus = 1;
                    if (ServerEphemeralMACKXPrivateKey.Length == 32)
                    {
                        MACSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(ServerEphemeralMACKXPrivateKey, MACKXPublicKey,true);
                    }
                    else
                    {
                        TemporaryMACSharedSecret = SecureX448.CalculateSecret(MACKXPublicKey, ServerEphemeralMACKXPrivateKey, true);
                        MACSharedSecret = SodiumKDF.KDFFunction(32, 1, "FX448KDF", TemporaryMACSharedSecret, true);
                    }
                    if (ServerEphemeralEncryptionKXPrivateKey.Length == 32)
                    {
                        EncryptionSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(ServerEphemeralEncryptionKXPrivateKey, EncryptionKXPublicKey, true);
                    }
                    else
                    {
                        TemporaryEncryptionSharedSecret = SecureX448.CalculateSecret(EncryptionKXPublicKey, ServerEphemeralEncryptionKXPrivateKey, true);
                        EncryptionSharedSecret = SodiumKDF.KDFFunction(32, 1, "FX448KDF", TemporaryEncryptionSharedSecret, true);
                    }
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtr);
                    UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtrPermissionStatus = 0;
                    UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtrPermissionStatus = 0;
                    UsersETLSSessions[EndUserIDIndex].EUMACKXPublicKeyBytes = MACKXPublicKey;
                    UsersETLSSessions[EndUserIDIndex].EUEncryptionKXPublicKeyBytes = EncryptionKXPublicKey;
                    while (IsMACSecretKeyIntPtrZero == true || IsEncryptionSecretKeyIntPtrZero == true)
                    {
                        MACSecretKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsMACSecretKeyIntPtrZero, 32);
                        EncryptionSecretKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsEncryptionSecretKeyIntPtrZero, 32);
                    }
                    Marshal.Copy(MACSharedSecret, 0, MACSecretKeyIntPtr, 32);
                    Marshal.Copy(EncryptionSharedSecret, 0, EncryptionSecretKeyIntPtr, 32);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(MACSecretKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(EncryptionSecretKeyIntPtr);
                    UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtr = MACSecretKeyIntPtr;
                    UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtr = EncryptionSecretKeyIntPtr;
                    UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 0;
                    UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 0;
                    UsersETLSSessions[EndUserIDIndex].ETLSStatus = "Success: Created ETLS Session";
                }
                else 
                {
                    UsersETLSSessions[EndUserIDIndex].ETLSStatus = ResultString;
                }
            }
        }

        public static void RemoveETLSForUser(int EndUserIDIndex, Byte[] SignedChallenge) 
        {
            if (EndUserIDIndex != -1) 
            {
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(UsersETLSSessions[EndUserIDIndex].EndUserID, SignedChallenge, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                if (AbleToVerify)
                {
                    Boolean IsAbleToDelete = true;
                    IsAbleToDelete = IsDeletionCleared();
                    if (IsAbleToDelete) 
                    {
                        SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtr);
                        SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtr);
                        SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtr);
                        SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                        UsersETLSSessions.RemoveAt(EndUserIDIndex);
                        HasDeletionTriggered = true;
                        DeletionDateTime = DateTime.UtcNow.AddHours(8);
                    }
                    else 
                    {
                        UsersETLSSessions[EndUserIDIndex].ETLSStatus = "Error: Unable to delete ETLS.";
                    }
                }
                else
                {
                    UsersETLSSessions[EndUserIDIndex].ETLSStatus = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                }
            }
        }

        //Once decrypt data, immediately remove the ETLS
        public static void DecryptData(int EndUserIDIndex, Byte[] SignedChallenge, Byte[] EncryptedMACSecretKeyBytes, Byte[] EncryptedEncryptionSecretKeyBytes) 
        {
            if (EndUserIDIndex != -1) 
            {
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(UsersETLSSessions[EndUserIDIndex].EndUserID, SignedChallenge, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                Byte[] MACSecretKeyBytesNonce = new Byte[] { };
                Byte[] EncryptionSecretKeyBytesNonce = new Byte[] { };
                Byte[] MACInEncryptedMACSecretKeyBytes = new Byte[64];
                Byte[] MACInEncryptedEncryptionSecretKeyBytes = new Byte[64];
                Byte[] PureEncryptedMACSecretKeyBytes = new Byte[32];
                Byte[] PureEncryptedEncryptionSecretKeyBytes = new Byte[32];
                Byte[] MACSecretKeyBytes = new Byte[32];
                Byte[] EncryptionSecretKeyBytes = new Byte[32];
                Byte[] ETLSMACSecretKeyBytes = new Byte[32];
                Byte[] ETLSEncryptionSecretKeyBytes = new Byte[32];
                Boolean AbleToVerifyFirstMAC = true;
                Boolean AbleToVerifySecondMAC = true;
                int LSHSMEndUserIDIndex = 0;
                Boolean IsMACSecretKeyIntPtrZero = true;
                Boolean IsEncryptionSecretKeyIntPtrZero = true;
                IntPtr MACSecretKeyIntPtr = new IntPtr();
                IntPtr EncryptionSecretKeyIntPtr = new IntPtr();
                if (AbleToVerify)
                {
                    MACSecretKeyBytesNonce = UsersETLSSessions[EndUserIDIndex].MACKXPublicKeyBytes.Concat(UsersETLSSessions[EndUserIDIndex].EUMACKXPublicKeyBytes).ToArray();
                    MACSecretKeyBytesNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), MACSecretKeyBytesNonce);
                    EncryptionSecretKeyBytesNonce = UsersETLSSessions[EndUserIDIndex].EncryptionKXPublicKeyBytes.Concat(UsersETLSSessions[EndUserIDIndex].EUEncryptionKXPublicKeyBytes).ToArray();
                    EncryptionSecretKeyBytesNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), EncryptionSecretKeyBytesNonce);
                    Buffer.BlockCopy(EncryptedMACSecretKeyBytes, 0, MACInEncryptedMACSecretKeyBytes, 0, MACInEncryptedMACSecretKeyBytes.Length);
                    Buffer.BlockCopy(EncryptedMACSecretKeyBytes, MACInEncryptedMACSecretKeyBytes.Length, PureEncryptedMACSecretKeyBytes, 0, PureEncryptedMACSecretKeyBytes.Length);
                    Buffer.BlockCopy(EncryptedEncryptionSecretKeyBytes, 0, MACInEncryptedEncryptionSecretKeyBytes, 0, MACInEncryptedEncryptionSecretKeyBytes.Length);
                    Buffer.BlockCopy(EncryptedEncryptionSecretKeyBytes, MACInEncryptedEncryptionSecretKeyBytes.Length, PureEncryptedEncryptionSecretKeyBytes, 0, PureEncryptedEncryptionSecretKeyBytes.Length);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                    Marshal.Copy(UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtr, ETLSMACSecretKeyBytes, 0, ETLSMACSecretKeyBytes.Length);
                    Marshal.Copy(UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtr, ETLSEncryptionSecretKeyBytes, 0, ETLSEncryptionSecretKeyBytes.Length);
                    UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 1;
                    UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 1;
                    AbleToVerifyFirstMAC = SodiumHMACSHA512.VerifyMAC(MACInEncryptedMACSecretKeyBytes, PureEncryptedMACSecretKeyBytes, ETLSMACSecretKeyBytes);
                    AbleToVerifySecondMAC = SodiumHMACSHA512.VerifyMAC(MACInEncryptedEncryptionSecretKeyBytes, PureEncryptedEncryptionSecretKeyBytes, ETLSMACSecretKeyBytes, true);
                    if (AbleToVerifyFirstMAC == true && AbleToVerifySecondMAC == true)
                    {
                        MACSecretKeyBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(PureEncryptedMACSecretKeyBytes, MACSecretKeyBytesNonce, ETLSEncryptionSecretKeyBytes);
                        EncryptionSecretKeyBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(PureEncryptedEncryptionSecretKeyBytes, EncryptionSecretKeyBytesNonce, ETLSEncryptionSecretKeyBytes, true);
                        LSHSMEndUserIDIndex = Users_LSHSM.FindLHSMForUser(UsersETLSSessions[EndUserIDIndex].EndUserID);
                        if (LSHSMEndUserIDIndex == -1)
                        {
                            AtomicUserLSHSMModel MyModel = new AtomicUserLSHSMModel();
                            while (IsMACSecretKeyIntPtrZero == true || IsEncryptionSecretKeyIntPtrZero == true)
                            {
                                MACSecretKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsMACSecretKeyIntPtrZero, 32);
                                EncryptionSecretKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsEncryptionSecretKeyIntPtrZero, 32);
                            }
                            Marshal.Copy(MACSecretKeyBytes, 0, MACSecretKeyIntPtr, 32);
                            Marshal.Copy(EncryptionSecretKeyBytes, 0, EncryptionSecretKeyIntPtr, 32);
                            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(MACSecretKeyIntPtr);
                            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(EncryptionSecretKeyIntPtr);
                            MyModel.EndUserID = UsersETLSSessions[EndUserIDIndex].EndUserID;
                            MyModel.MACSecretKeyIntPtr = MACSecretKeyIntPtr;
                            MyModel.MACSecretKeyIntPtrPermissionStatus = 0;
                            MyModel.EncryptionSecretKeyIntPtr = EncryptionSecretKeyIntPtr;
                            MyModel.EncryptionSecretKeyIntPtrPermissionStatus = 0;
                            MyModel.ValidDuration = DateTime.UtcNow.AddHours(8).AddHours(12);
                            MyModel.Status = "";
                            Users_LSHSM.AddLHSMForUser(LSHSMEndUserIDIndex, MyModel);
                            HasDeletionTriggered = true;
                            DeletionDateTime = DateTime.UtcNow.AddHours(8);
                            SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].MACKXPrivateKeyIntPtr);
                            SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtr);
                            SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].EncryptionKXPrivateKeyIntPtr);
                            SodiumGuardedHeapAllocation.Sodium_Free(UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                            UsersETLSSessions[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = -1;
                            UsersETLSSessions[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = -1;
                            UsersETLSSessions.RemoveAt(EndUserIDIndex);
                        }
                        SodiumSecureMemory.SecureClearBytes(MACSecretKeyBytes);
                        SodiumSecureMemory.SecureClearBytes(EncryptionSecretKeyBytes);
                    }
                }
                else
                {
                    UsersETLSSessions[EndUserIDIndex].ETLSStatus = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                }
            }
        }

        public static String GetETLSStatus(int EndUserIDIndex) 
        {
            if (EndUserIDIndex != -1) 
            {
                return UsersETLSSessions[EndUserIDIndex].ETLSStatus;
            }
            else 
            {
                return "";
            }
        }

        public static Boolean IsDeletionCleared() 
        {
            if(HasDeletionTriggered==false && DeletionDateTime.CompareTo(DateTime.MinValue) == 0) 
            {
                return true;
            }
            else 
            {
                TimeSpan MyTimeSpan = DateTime.UtcNow.AddHours(8).Subtract(DeletionDateTime);
                if (MyTimeSpan.TotalMinutes <= 8) 
                {
                    return false;
                }
                else 
                {
                    HasDeletionTriggered = false;
                    DeletionDateTime = DateTime.MinValue;
                    return true;
                }
            }
        }
    }
}
