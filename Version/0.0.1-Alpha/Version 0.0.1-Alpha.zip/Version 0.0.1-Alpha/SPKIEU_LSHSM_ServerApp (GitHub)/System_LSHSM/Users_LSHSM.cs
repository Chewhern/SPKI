﻿using ASodium;
using BCASodium;
using SPKIEU_LSHSM_ServerApp.LocalAPIHelper;
using SPKIEU_LSHSM_ServerApp.LSHSMModel;
using System.Runtime.InteropServices;

namespace SPKIEU_LSHSM_ServerApp.System_LSHSM
{
    //Project/LSHSM/EU/{UserID}/OriginalFiles
    //Project/LSHSM/EU/{UserID}/EncryptedFiles
    //Project/LSHSM/EU/{UserID}/DecryptedFiles

    //Potential LSHSM issue: Concurrent deletion..
    //LSHSM Deletion..

    //Need to revisit back in future to make the code more organized/less repetitive
    public static class Users_LSHSM
    {
        private static List<AtomicUserLSHSMModel> UsersEmulatedLSHSM = new List<AtomicUserLSHSMModel>();
        private static Boolean HasDeletionTriggered = false;
        private static DateTime DeletionDateTime = DateTime.MinValue;
        private static Byte[] InternalChallenge = new Byte[] { };
        private static Byte[] InternalDSAPublicKeyBytes = new Byte[] { };
        private static Boolean HasInitializationTriggered = false;
        private static DateTime InitializationDateTime = DateTime.MinValue;

        public static int FindLHSMForUser(String EndUserID)
        {
            int Result = -1;
            int Loop = 0;
            while (Loop < UsersEmulatedLSHSM.Count)
            {
                if (EndUserID.CompareTo(UsersEmulatedLSHSM[Loop].EndUserID) == 0)
                {
                    Result = Loop;
                    break;
                }
                Loop += 1;
            }
            return Result;
        }

        public static void AddLHSMForUser(int EndUserIDIndex, AtomicUserLSHSMModel MyModel) 
        {
            if (EndUserIDIndex == -1) 
            {
                UsersEmulatedLSHSM.Add(MyModel);
            }
        }

        public static Byte[] GenerateInternalChallenge()
        {
            InternalChallenge = SodiumRNG.GetRandomBytes(128);
            return InternalChallenge;
        }

        public static void SetInternalPublicKey(Byte[] DSAPublicKeyBytes) 
        {
            if (HasSystemInitialized() == false) 
            {
                InternalDSAPublicKeyBytes = DSAPublicKeyBytes;
                HasInitializationTriggered = true;
                InitializationDateTime = DateTime.UtcNow.AddHours(8);
            }
        }

        public static Boolean DeleteLSHSMs(Byte[] SignedChallenge) 
        {
            if (HasInitializationTriggered == true) 
            {
                Boolean AbleToVerify = true;
                Boolean SameAsInternalChallenge = true;
                Byte[] TempChallenge = new Byte[] { };
                int Loop = 0;
                DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
                TimeSpan MyTimeSpan = new TimeSpan();
                if (InternalDSAPublicKeyBytes.Length == 32) 
                {
                    try 
                    {
                        TempChallenge = SodiumPublicKeyAuth.Verify(SignedChallenge, InternalDSAPublicKeyBytes);
                    }
                    catch 
                    {
                        AbleToVerify = false;
                    }
                }
                else 
                {
                    try
                    {
                        TempChallenge = SecureED448.GetMessageFromSignatureMessage(InternalDSAPublicKeyBytes,SignedChallenge,new Byte[] { });
                    }
                    catch
                    {
                        AbleToVerify = false;
                    }
                }
                try 
                {
                    SodiumHelper.Sodium_Memory_Compare(InternalChallenge, TempChallenge);
                }
                catch 
                {
                    SameAsInternalChallenge = false;
                }
                if(AbleToVerify==true && SameAsInternalChallenge == true) 
                {
                    while (Loop < UsersEmulatedLSHSM.Count) 
                    {
                        MyTimeSpan = CurrentDateTime.Subtract(UsersEmulatedLSHSM[Loop].ValidDuration);
                        if (MyTimeSpan.TotalMinutes >= 0) 
                        {
                            UsersEmulatedLSHSM.RemoveAt(Loop);
                        }
                        Loop += 1;
                    }
                }
                return (AbleToVerify == true && SameAsInternalChallenge == true);
            }
            else 
            {
                return false;
            }
        }

        public static void ChangeUserLSHSMDuration(int EndUserIDIndex, Byte[] SignedChallenge, DateTime MyDT) 
        {
            if (EndUserIDIndex != -1)
            {
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(UsersEmulatedLSHSM[EndUserIDIndex].EndUserID, SignedChallenge, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                if (AbleToVerify)
                {
                    UsersEmulatedLSHSM[EndUserIDIndex].ValidDuration = MyDT;
                    UsersEmulatedLSHSM[EndUserIDIndex].Status = "Success: The light software emulated HSM valid duration had been updated..";
                }
                else
                {
                    UsersEmulatedLSHSM[EndUserIDIndex].Status = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                }
            }
        }

        public static void EncryptFiles(int EndUserIDIndex, Byte[] SignedChallenge) 
        {
            if (EndUserIDIndex != -1)
            {
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(UsersEmulatedLSHSM[EndUserIDIndex].EndUserID, SignedChallenge, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                if (AbleToVerify)
                {
                    Byte[] MACSecretKey = new Byte[32];
                    Byte[] EncryptionSecretKey = new Byte[32];
                    Byte[] Nonce = new Byte[] { };
                    Byte[] MAC = new Byte[] { };
                    Byte[] CipherText = new Byte[] { };
                    Byte[] FileContentBytes = new Byte[] { };
                    Byte[] EncryptedFileContentBytes = new Byte[] { };
                    int FilesLoop = 0;
                    String OriginalFilePathDirectory = "/Project/LSHSM/EU/" + UsersEmulatedLSHSM[EndUserIDIndex].EndUserID + "/OriginalFiles/";
                    String EncryptedFilePathDirectory = "/Project/LSHSM/EU/" + UsersEmulatedLSHSM[EndUserIDIndex].EndUserID + "/EncryptedFiles/";
                    String[] FilesWithPaths = Directory.GetFiles(OriginalFilePathDirectory);
                    String[] TrimmedFilesWithPaths = new String[FilesWithPaths.Length];
                    String[] EncryptedFilesWithPaths = new String[FilesWithPaths.Length];
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                    UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 1;
                    UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 1;
                    Marshal.Copy(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr, MACSecretKey, 0, MACSecretKey.Length);
                    Marshal.Copy(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr, EncryptionSecretKey, 0, EncryptionSecretKey.Length);
                    while (FilesLoop < FilesWithPaths.Length)
                    {
                        FileContentBytes = File.ReadAllBytes(FilesWithPaths[FilesLoop]);
                        Nonce = SodiumStreamCipherXChaCha20.GenerateXChaCha20Nonce();
                        CipherText = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(FileContentBytes, Nonce, EncryptionSecretKey);
                        MAC = SodiumHMACSHA512.ComputeMAC(CipherText, MACSecretKey);
                        EncryptedFileContentBytes = Nonce.Concat(MAC).Concat(CipherText).ToArray();
                        TrimmedFilesWithPaths[FilesLoop] = FilesWithPaths[FilesLoop].Remove(0, OriginalFilePathDirectory.Length);
                        EncryptedFilesWithPaths[FilesLoop] = EncryptedFilePathDirectory + TrimmedFilesWithPaths[FilesLoop];
                        File.WriteAllBytes(EncryptedFilesWithPaths[FilesLoop] + ".encrypted", EncryptedFileContentBytes);
                        File.Delete(FilesWithPaths[FilesLoop]);
                        FilesLoop += 1;
                    }
                    SodiumSecureMemory.SecureClearBytes(MACSecretKey);
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                    UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 0;
                    UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 0;
                    UsersEmulatedLSHSM[EndUserIDIndex].Status = "Success: Plaintext files encrypted, Non-encrypted plaintext files removed.";
                }
                else
                {
                    UsersEmulatedLSHSM[EndUserIDIndex].Status = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                }
            }
        }

        public static void DecryptFiles(int EndUserIDIndex, Byte[] SignedChallenge) 
        {
            if (EndUserIDIndex != -1)
            {
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(UsersEmulatedLSHSM[EndUserIDIndex].EndUserID, SignedChallenge, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                if (AbleToVerify)
                {
                    Byte[] MACSecretKey = new Byte[32];
                    Byte[] EncryptionSecretKey = new Byte[32];
                    Byte[] Nonce = new Byte[SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength()];
                    Byte[] MAC = new Byte[64];
                    Byte[] CipherText = new Byte[] { };
                    Byte[] EncryptedFileContentBytes = new Byte[] { };
                    Byte[] DecryptedFileContentBytes = new Byte[] { };
                    int FilesLoop = 0;
                    String EncryptedFilePathDirectory = "/Project/LSHSM/EU/" + UsersEmulatedLSHSM[EndUserIDIndex].EndUserID + "/EncryptedFiles/";
                    String DecryptedFilePathDirectory = "/Project/LSHSM/EU/" + UsersEmulatedLSHSM[EndUserIDIndex].EndUserID + "/DecryptedFiles/";
                    String[] FilesWithPaths = Directory.GetFiles(EncryptedFilePathDirectory);
                    String[] TrimmedFilesWithPaths = new String[FilesWithPaths.Length];
                    String[] DecryptedFilesWithPaths = new String[FilesWithPaths.Length];
                    Boolean AbleToVerifyMAC = true;
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                    UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 1;
                    UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 1;
                    Marshal.Copy(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr, MACSecretKey, 0, MACSecretKey.Length);
                    Marshal.Copy(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr, EncryptionSecretKey, 0, EncryptionSecretKey.Length);
                    while (FilesLoop < FilesWithPaths.Length)
                    {
                        EncryptedFileContentBytes = File.ReadAllBytes(FilesWithPaths[FilesLoop]);
                        Buffer.BlockCopy(EncryptedFileContentBytes, 0, Nonce, 0, Nonce.Length);
                        Buffer.BlockCopy(EncryptedFileContentBytes, Nonce.Length, MAC, 0, MAC.Length);
                        CipherText = new Byte[EncryptedFileContentBytes.Length - Nonce.Length - MAC.Length];
                        Buffer.BlockCopy(EncryptedFileContentBytes, Nonce.Length + MAC.Length, CipherText, 0, CipherText.Length);
                        AbleToVerifyMAC = SodiumHMACSHA512.VerifyMAC(MAC, CipherText, MACSecretKey);
                        if (AbleToVerifyMAC == true)
                        {
                            DecryptedFileContentBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(CipherText, Nonce, EncryptionSecretKey);
                        }
                        else
                        {
                            UsersEmulatedLSHSM[EndUserIDIndex].Status = "Error: Unable to verify HMAC";
                            break;
                        }
                        TrimmedFilesWithPaths[FilesLoop] = FilesWithPaths[FilesLoop].Remove(0, EncryptedFilePathDirectory.Length);
                        TrimmedFilesWithPaths[FilesLoop] = TrimmedFilesWithPaths[FilesLoop].Substring(0, TrimmedFilesWithPaths[FilesLoop].Length - 10);
                        DecryptedFilesWithPaths[FilesLoop] = DecryptedFilePathDirectory + TrimmedFilesWithPaths[FilesLoop];
                        File.WriteAllBytes(DecryptedFilesWithPaths[FilesLoop], DecryptedFileContentBytes);
                        FilesLoop += 1;
                    }
                    SodiumSecureMemory.SecureClearBytes(MACSecretKey);
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                    UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 0;
                    UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 0;
                    if (UsersEmulatedLSHSM[EndUserIDIndex].Status.Contains("Error") == true)
                    {
                        UsersEmulatedLSHSM[EndUserIDIndex].Status = "Error: Unable to decrypt certain files";
                    }
                    else 
                    {
                        UsersEmulatedLSHSM[EndUserIDIndex].Status = "Success: All files able to decrypt.";
                    }
                }
                else
                {
                    UsersEmulatedLSHSM[EndUserIDIndex].Status = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                }
            }
        }

        //Check again..
        public static void DeleteLSHSM(int EndUserIDIndex, Byte[] SignedChallenge) 
        {
            if (EndUserIDIndex != -1)
            {
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(UsersEmulatedLSHSM[EndUserIDIndex].EndUserID, SignedChallenge, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                if (AbleToVerify)
                {
                    Boolean IsAbleToDelete = true;
                    IsAbleToDelete = IsDeletionCleared();
                    if (IsAbleToDelete) 
                    {
                        SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr);
                        SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                        SodiumSecureMemory.MemZero(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr, 32);
                        SodiumSecureMemory.MemZero(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr, 32);
                        SodiumGuardedHeapAllocation.Sodium_Free(UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtr);
                        SodiumGuardedHeapAllocation.Sodium_Free(UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtr);
                        UsersEmulatedLSHSM[EndUserIDIndex].EncryptionSecretKeyIntPtrPermissionStatus = 0;
                        UsersEmulatedLSHSM[EndUserIDIndex].MACSecretKeyIntPtrPermissionStatus = 0;
                        UsersEmulatedLSHSM.RemoveAt(EndUserIDIndex);
                        HasDeletionTriggered = true;
                        DeletionDateTime = DateTime.UtcNow.AddHours(8);
                    }
                    else 
                    {
                        UsersEmulatedLSHSM[EndUserIDIndex].Status += "Error: Unable to delete LSHSM for this end user as other end user just deleted his/her LSHSM";
                    }
                }
                else
                {
                    UsersEmulatedLSHSM[EndUserIDIndex].Status = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                    UsersEmulatedLSHSM[EndUserIDIndex].Status += ";Error: Unable to delete LSHSM for this end user";
                }
            }
        }

        public static String GetStatus(int EndUserIDIndex) 
        {
            if (EndUserIDIndex != -1) 
            {
                return UsersEmulatedLSHSM[EndUserIDIndex].Status;
            }
            else 
            {
                return "Error: Unable to find status";
            }
        }

        public static Boolean IsDeletionCleared()
        {
            if (HasDeletionTriggered == false && DeletionDateTime.CompareTo(DateTime.MinValue) == 0)
            {
                return true;
            }
            else
            {
                TimeSpan MyTimeSpan = DateTime.UtcNow.AddHours(8).Subtract(DeletionDateTime);
                if (MyTimeSpan.TotalMinutes <= 8)
                {
                    return false;
                }
                else
                {
                    HasDeletionTriggered = false;
                    DeletionDateTime = DateTime.MinValue;
                    return true;
                }
            }
        }

        private static Boolean HasSystemInitialized()
        {
            if (HasInitializationTriggered == false && InitializationDateTime.CompareTo(DateTime.MinValue) == 0)
            {
                return false;
            }
            else
            {
                TimeSpan MyTimeSpan = DateTime.UtcNow.AddHours(8).Subtract(InitializationDateTime);
                if (MyTimeSpan.TotalMinutes <= 8)
                {
                    return true;
                }
                else
                {
                    HasInitializationTriggered = false;
                    InitializationDateTime = DateTime.MinValue;
                    return false;
                }
            }
        }

        public static int GetCurrentLSHSMCount()
        {
            return UsersEmulatedLSHSM.Count;
        }
    }
}
