﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SPKIEU_LSHSM_ServerApp.APIMethodHelper;
using SPKIEU_LSHSM_ServerApp.Helper;
using SPKIEU_LSHSM_ServerApp.LocalAPIHelper;
using SPKIEU_LSHSM_ServerApp.System_LSHSM;

namespace SPKIEU_LSHSM_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EncryptionOps : ControllerBase
    {
        //Need to revisit back in future to add challenge to upload file
        [HttpPost]
        public async Task<IActionResult> UploadFile([FromQuery] String EndUserID, [FromQuery] String FileName, [FromQuery] String SignedChallenge)
        {
            if (String.IsNullOrEmpty(FileName))
                return BadRequest("Missing filename.");

            if (Directory.Exists("/Project/LSHSM/EU/" + EndUserID + "/OriginalFiles/") == true) 
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(EndUserID, SignedChallengeBytes, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                    if (AbleToVerify) 
                    {
                        var filePath = Path.Combine("/Project/LSHSM/EU/" + EndUserID + "/OriginalFiles/", FileName);

                        if (Directory.Exists("/Project/LSHSM/EU/" + EndUserID + "/OriginalFiles/") == false)
                        {
                            Directory.CreateDirectory("/Project/LSHSM/EU/" + EndUserID + "/OriginalFiles/");
                        }

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await Request.Body.CopyToAsync(stream);
                        }

                        return Ok(new { FileName, Message = "Success: File had been uploaded." });
                    }
                    else 
                    {
                        return Problem(
                        detail: InternalVerificationResultString+";"+DatabaseVerificationResultString,
                        statusCode: 400,
                        title: "Verification error"
                        );
                    }
                }
                else
                {
                    return Problem(
                    detail: "Unable to parse or it's invalid",
                    statusCode: 400,
                    title: "Invalid data"
                    );
                }
            }
            else 
            {
                return Problem(
                    detail: "Unable to verify certificate",
                    statusCode: 400,
                    title: "Certificate verification failed"
                );
            }
        }

        [HttpGet("Encrypt")]
        public String EncryptFiles(String EndUserID,String SignedChallenge)
        {
            String ResultString = "";
            if(EndUserID!=null && SignedChallenge != null) 
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                try 
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch 
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    Users_LSHSM.EncryptFiles(EUIDIndex, SignedChallengeBytes);
                    ResultString = Users_LSHSM.GetStatus(EUIDIndex);
                }
                else 
                {
                    ResultString = "Error: EndUserID must be valid and SignedChallenge must encode in base64";
                }
            }
            else 
            {
                ResultString = "Error: EndUserID and SignedChallenge must not be empty";
            }
            return ResultString;
        }

        [HttpGet("Decrypt")]
        public String DecryptFiles(String EndUserID, String SignedChallenge)
        {
            String ResultString = "";
            if (EndUserID != null && SignedChallenge != null)
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    Users_LSHSM.DecryptFiles(EUIDIndex, SignedChallengeBytes);
                    ResultString = Users_LSHSM.GetStatus(EUIDIndex);
                }
                else
                {
                    ResultString = "Error: EndUserID must be valid and SignedChallenge must encode in base64";
                }
            }
            else
            {
                ResultString = "Error: EndUserID and SignedChallenge must not be empty";
            }
            return ResultString;
        }
    }
}
