﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SPKIEU_LSHSM_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServerStatus : ControllerBase
    {
        [HttpGet]
        public void CheckConnection() 
        {
            return;
        }
    }
}
