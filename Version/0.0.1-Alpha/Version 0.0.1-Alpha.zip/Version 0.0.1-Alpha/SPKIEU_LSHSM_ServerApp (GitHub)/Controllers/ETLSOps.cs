﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SPKIEU_LSHSM_ServerApp.Helper;
using SPKIEU_LSHSM_ServerApp.LSHSMModel;
using SPKIEU_LSHSM_ServerApp.System_LSHSM;
using System.Runtime.InteropServices;

namespace SPKIEU_LSHSM_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ETLSOps : ControllerBase
    {

        //Use Models in future..
        [HttpGet]
        public String InitializeETLS(String EndUserID, Boolean UseDefault=true) 
        {
            String ResultString = "";
            if(EndUserID!=null && EndUserID.CompareTo("") != 0) 
            {
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID) == true) 
                {
                    int Check = ETLSLSHSM.FindETLSForUser(EndUserID);
                    if (Check == -1) 
                    {
                        AtomicETLSLSHSMModel MyModel = new AtomicETLSLSHSMModel();
                        Byte[] SignedEphemeralMACKXPublicKeyBytes = new Byte[] { };
                        Byte[] SignedEphemeralEncryptionKXPublicKeyBytes = new Byte[] { };
                        IntPtr ServerEphemeralMACKXPrivateKeyIntPtr = new IntPtr();
                        IntPtr ServerEphemeralEncryptionKXPrivateKeyIntPtr = new IntPtr();
                        Boolean IsServerEphemeralMACKXPrivateKeyIntPtrZero = true;
                        Boolean IsServerEphemeralEncryptionKXPrivateKeyIntPtrZero = true;
                        String EphemeralMACDSAPublicKeyString = "";
                        String EphemeralEncryptionDSAPublicKeyString = "";
                        String EphemeralMACKXPublicKeyString = "";
                        String EphemeralEncryptionKXPublicKeyString = "";
                        if (UseDefault) 
                        {
                            RevampedKeyPair ServerEphemeralMACDSAKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                            RevampedKeyPair ServerEphemeralEncryptionDSAKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                            RevampedKeyPair ServerEphemeralMACKXKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                            RevampedKeyPair ServerEphemeralEncryptionKXKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                            SignedEphemeralMACKXPublicKeyBytes = SodiumPublicKeyAuth.Sign(ServerEphemeralMACKXKeyPair.PublicKey, ServerEphemeralMACDSAKeyPair.PrivateKey);
                            SignedEphemeralEncryptionKXPublicKeyBytes = SodiumPublicKeyAuth.Sign(ServerEphemeralEncryptionKXKeyPair.PublicKey, ServerEphemeralEncryptionDSAKeyPair.PrivateKey);
                            while(IsServerEphemeralMACKXPrivateKeyIntPtrZero == true || IsServerEphemeralEncryptionKXPrivateKeyIntPtrZero == true) 
                            {
                                ServerEphemeralMACKXPrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsServerEphemeralMACKXPrivateKeyIntPtrZero, 32);
                                ServerEphemeralEncryptionKXPrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsServerEphemeralEncryptionKXPrivateKeyIntPtrZero, 32);
                            }
                            Marshal.Copy(ServerEphemeralMACKXKeyPair.PrivateKey, 0, ServerEphemeralMACKXPrivateKeyIntPtr, 32);
                            Marshal.Copy(ServerEphemeralEncryptionKXKeyPair.PrivateKey, 0, ServerEphemeralEncryptionKXPrivateKeyIntPtr, 32);
                            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(ServerEphemeralMACKXPrivateKeyIntPtr);
                            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(ServerEphemeralEncryptionKXPrivateKeyIntPtr);
                            EphemeralMACDSAPublicKeyString = Convert.ToBase64String(ServerEphemeralMACDSAKeyPair.PublicKey);
                            EphemeralEncryptionDSAPublicKeyString = Convert.ToBase64String(ServerEphemeralEncryptionDSAKeyPair.PublicKey);
                            EphemeralMACKXPublicKeyString = Convert.ToBase64String(ServerEphemeralMACKXKeyPair.PublicKey);
                            EphemeralEncryptionKXPublicKeyString = Convert.ToBase64String(ServerEphemeralEncryptionKXKeyPair.PublicKey);
                            ServerEphemeralMACDSAKeyPair.Clear();
                            ServerEphemeralEncryptionDSAKeyPair.Clear();
                            ServerEphemeralMACKXKeyPair.Clear();
                            ServerEphemeralEncryptionKXKeyPair.Clear();
                        }
                        else 
                        {
                            ED448RevampedKeyPair ServerEphemeralMACDSAKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                            ED448RevampedKeyPair ServerEphemeralEncryptionDSAKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                            X448RevampedKeyPair ServerEphemeralMACKXKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                            X448RevampedKeyPair ServerEphemeralEncryptionKXKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                            SignedEphemeralMACKXPublicKeyBytes = SecureED448.GenerateSignatureMessage(ServerEphemeralMACDSAKeyPair.PrivateKey, ServerEphemeralMACKXKeyPair.PublicKey, new Byte[] { });
                            SignedEphemeralEncryptionKXPublicKeyBytes = SecureED448.GenerateSignatureMessage(ServerEphemeralEncryptionDSAKeyPair.PrivateKey, ServerEphemeralEncryptionKXKeyPair.PublicKey, new Byte[] { });
                            while (IsServerEphemeralMACKXPrivateKeyIntPtrZero == true || IsServerEphemeralEncryptionKXPrivateKeyIntPtrZero == true)
                            {
                                ServerEphemeralMACKXPrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsServerEphemeralMACKXPrivateKeyIntPtrZero, 32);
                                ServerEphemeralEncryptionKXPrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsServerEphemeralEncryptionKXPrivateKeyIntPtrZero, 32);
                            }
                            Marshal.Copy(ServerEphemeralMACKXKeyPair.PrivateKey, 0, ServerEphemeralMACKXPrivateKeyIntPtr, 32);
                            Marshal.Copy(ServerEphemeralEncryptionKXKeyPair.PrivateKey, 0, ServerEphemeralEncryptionKXPrivateKeyIntPtr, 32);
                            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(ServerEphemeralMACKXPrivateKeyIntPtr);
                            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(ServerEphemeralEncryptionKXPrivateKeyIntPtr);
                            EphemeralMACDSAPublicKeyString = Convert.ToBase64String(ServerEphemeralMACDSAKeyPair.PublicKey);
                            EphemeralEncryptionDSAPublicKeyString = Convert.ToBase64String(ServerEphemeralEncryptionDSAKeyPair.PublicKey);
                            EphemeralMACKXPublicKeyString = Convert.ToBase64String(ServerEphemeralMACKXKeyPair.PublicKey);
                            EphemeralEncryptionKXPublicKeyString = Convert.ToBase64String(ServerEphemeralEncryptionKXKeyPair.PublicKey);
                            ServerEphemeralMACDSAKeyPair.Clear();
                            ServerEphemeralEncryptionDSAKeyPair.Clear();
                            ServerEphemeralMACKXKeyPair.Clear();
                            ServerEphemeralEncryptionKXKeyPair.Clear();
                        }
                        MyModel.MACKXDSAPublicKeyBytes = Convert.FromBase64String(EphemeralMACDSAPublicKeyString);
                        MyModel.EncryptionKXDSAPublicKeyBytes = Convert.FromBase64String(EphemeralEncryptionDSAPublicKeyString);
                        MyModel.MACKXPrivateKeyIntPtr = ServerEphemeralMACKXPrivateKeyIntPtr;
                        MyModel.MACKXPrivateKeyIntPtrPermissionStatus = 0;
                        MyModel.MACKXPublicKeyBytes = Convert.FromBase64String(EphemeralMACKXPublicKeyString);
                        MyModel.EncryptionKXPrivateKeyIntPtr = ServerEphemeralEncryptionKXPrivateKeyIntPtr;
                        MyModel.EncryptionKXPrivateKeyIntPtrPermissionStatus = 0;
                        MyModel.EncryptionKXPublicKeyBytes = Convert.FromBase64String(EphemeralEncryptionKXPublicKeyString);
                        MyModel.EndUserID = EndUserID;
                        ETLSLSHSM.InitializeETLSForUser(Check, MyModel);
                        ResultString = Convert.ToBase64String(SignedEphemeralMACKXPublicKeyBytes) + ";" + EphemeralMACDSAPublicKeyString + ";"
                            + Convert.ToBase64String(SignedEphemeralEncryptionKXPublicKeyBytes) + ";" + EphemeralEncryptionDSAPublicKeyString;
                    }
                    else 
                    {
                        ResultString = "Error: ETLS already exist for this user";
                    }
                }
                else 
                {
                    ResultString = "Error: This user does not have a valid certificate";
                }
            }
            else 
            {
                ResultString = "Error: EndUserID must not be empty";
            }
            return ResultString;
        }

        [HttpGet("AgreeKeys")]
        public String FinalizeETLS(String EndUserID, String SignedMACKXPublicKey, String SignedEncryptionKXPublicKey) 
        {
            String ResultString = "";
            if (EndUserID != null && EndUserID.CompareTo("") != 0 && SignedMACKXPublicKey!=null && SignedMACKXPublicKey.CompareTo("")!=0
                && SignedEncryptionKXPublicKey!=null && SignedEncryptionKXPublicKey.CompareTo("")!=0) 
            {
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID) == true) 
                {
                    int Check = ETLSLSHSM.FindETLSForUser(EndUserID);
                    if (Check != -1) 
                    {
                        Byte[] SignedMACKXPublicKeyBytes = new Byte[] { };
                        Byte[] SignedEncryptionKXPublicKeyBytes = new Byte[] { };
                        Boolean AbleToParse = true;
                        try 
                        {
                            SignedMACKXPublicKeyBytes = Convert.FromBase64String(SignedMACKXPublicKey);
                            SignedEncryptionKXPublicKeyBytes = Convert.FromBase64String(SignedEncryptionKXPublicKey);
                        }
                        catch 
                        {
                            AbleToParse = false;
                        }
                        if (AbleToParse) 
                        {
                            ETLSLSHSM.FinalizeETLSForUser(Check, SignedMACKXPublicKeyBytes, SignedEncryptionKXPublicKeyBytes);
                            ResultString = ETLSLSHSM.GetETLSStatus(Check);
                        }
                        else 
                        {
                            ResultString = "Error: The public keys must encode in base64";
                        }
                    }
                    else 
                    {
                        ResultString = "Error: This user does not have ETLS initiated";
                    }
                }
                else 
                {
                    ResultString = "Error: This user does not have a valid certificate";
                }
            }
            else 
            {
                ResultString = "Error: EndUserID and signed public keys must not be empty";
            }
            return ResultString;
        }

        [HttpGet("DeleteETLS")]
        public String RemoveETLS(String EndUserID, String SignedChallenge) 
        {
            String ResultString = "";
            if (EndUserID != null && EndUserID.CompareTo("") != 0 && SignedChallenge != null && SignedChallenge.CompareTo("") != 0)
            {
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID) == true)
                {
                    int Check = ETLSLSHSM.FindETLSForUser(EndUserID);
                    if (Check != -1)
                    {
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        Boolean AbleToParse = true;
                        try
                        {
                            SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                        }
                        catch
                        {
                            AbleToParse = false;
                        }
                        if (AbleToParse)
                        {
                            ETLSLSHSM.RemoveETLSForUser(Check, SignedChallengeBytes);
                            Check = ETLSLSHSM.FindETLSForUser(EndUserID);
                            if (Check == -1) 
                            {
                                ResultString = "Success: ETLS removed for this user";
                            }
                            else 
                            {
                                ResultString = ETLSLSHSM.GetETLSStatus(Check);
                            }
                        }
                        else
                        {
                            ResultString = "Error: The signed challenge must encode in base64";
                        }
                    }
                    else
                    {
                        ResultString = "Error: This user does not have ETLS initiated";
                    }
                }
                else
                {
                    ResultString = "Error: This user does not have a valid certificate";
                }
            }
            else
            {
                ResultString = "Error: EndUserID and signed challenge must not be empty";
            }
            return ResultString;
        }

        [HttpGet("StartLSHSM")]
        public String DecryptData(String EndUserID, String SignedChallenge, String EncryptedMACSecretKey, String EncryptedEncryptionSecretKey) 
        {
            String ResultString = "";
            if (EndUserID != null && EndUserID.CompareTo("") != 0 && SignedChallenge != null && SignedChallenge.CompareTo("") != 0
                && EncryptedMACSecretKey!=null && EncryptedMACSecretKey.CompareTo("")!=0 &&
                EncryptedEncryptionSecretKey!=null && EncryptedEncryptionSecretKey.CompareTo("")!=0)
            {
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID) == true)
                {
                    int Check = ETLSLSHSM.FindETLSForUser(EndUserID);
                    if (Check != -1)
                    {
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        Byte[] EncryptedMACSecretKeyBytes = new Byte[] { };
                        Byte[] EncryptedEncryptionSecretKeyBytes = new Byte[] { };
                        Boolean AbleToParse = true;
                        try
                        {
                            SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                            EncryptedMACSecretKeyBytes = Convert.FromBase64String(EncryptedMACSecretKey);
                            EncryptedEncryptionSecretKeyBytes = Convert.FromBase64String(EncryptedEncryptionSecretKey);
                        }
                        catch
                        {
                            AbleToParse = false;
                        }
                        if (AbleToParse)
                        {
                            ETLSLSHSM.DecryptData(Check, SignedChallengeBytes,EncryptedMACSecretKeyBytes,EncryptedEncryptionSecretKeyBytes);
                            Check = ETLSLSHSM.FindETLSForUser(EndUserID);
                            if (Check == -1)
                            {
                                ResultString = "Success: Secret keys decrypted and actual LSHSM for user initiated";
                            }
                            else
                            {
                                ResultString = ETLSLSHSM.GetETLSStatus(Check);
                            }
                        }
                        else
                        {
                            ResultString = "Error: The signed challenge and encrypted secret keys must encode in base64";
                        }
                    }
                    else
                    {
                        ResultString = "Error: This user does not have ETLS initiated";
                    }
                }
                else
                {
                    ResultString = "Error: This user does not have a valid certificate";
                }
            }
            else
            {
                ResultString = "Error: EndUserID, signed challenge and encrypted secret keys must not be empty";
            }
            return ResultString;
        }
    }
}
