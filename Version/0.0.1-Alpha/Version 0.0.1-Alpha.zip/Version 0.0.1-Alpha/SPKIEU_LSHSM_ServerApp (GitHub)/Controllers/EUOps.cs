﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKIEU_LSHSM_ServerApp.APIMethodHelper;
using SPKIEU_LSHSM_ServerApp.Helper;
using SPKIEU_LSHSM_ServerApp.LocalAPIHelper;
using SPKIEU_LSHSM_ServerApp.Model;
using SPKIEU_LSHSM_ServerApp.PostDataModel;
using SPKIEU_LSHSM_ServerApp.System_LSHSM;
using System.Globalization;
using System.IO.Compression;
using System.Net.Http.Headers;
using System.Text;

namespace SPKIEU_LSHSM_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EUOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpPost]
        public async Task<IActionResult> UploadAndVerifyCertificate([FromQuery] String FileName)
        {
            if (String.IsNullOrEmpty(FileName))
                return BadRequest("Missing filename.");

            var filePath = Path.Combine("/Project/LSHSM/EU/Unfiltered/", FileName);

            if (Directory.Exists("/Project/LSHSM/EU/Unfiltered/") == false) 
            {
                Directory.CreateDirectory("/Project/LSHSM/EU/Unfiltered/");
            }
            
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await Request.Body.CopyToAsync(stream);
            }

            VerifyNodeUserCertificate.AbleToVerifyNodeUserCertificate(filePath);

            if (VerifyNodeUserCertificate.StatusString.Contains("Success")) 
            {
                String[] FileContents = System.IO.File.ReadAllLines(filePath);
                String EndUserID = "";
                int Loop = 0;
                if (FileContents.Length > 2)
                {
                    while (Loop < FileContents.Length)
                    {
                        if (Loop == 1)
                        {
                            EndUserID = FileContents[Loop];
                            break;
                        }
                        Loop += 1;
                    }
                }

                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID) == false)
                {
                    System.IO.Directory.CreateDirectory("/Project/LSHSM/EU/" + EndUserID);
                }
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID + "/OriginalFiles") == false)
                {
                    System.IO.Directory.CreateDirectory("/Project/LSHSM/EU/" + EndUserID + "/OriginalFiles");
                }
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID + "/EncryptedFiles") == false)
                {
                    System.IO.Directory.CreateDirectory("/Project/LSHSM/EU/" + EndUserID + "/EncryptedFiles");
                }
                if (System.IO.Directory.Exists("/Project/LSHSM/EU/" + EndUserID + "/DecryptedFiles") == false)
                {
                    System.IO.Directory.CreateDirectory("/Project/LSHSM/EU/" + EndUserID + "/DecryptedFiles");
                }

                Byte[] FileContentBytes = System.IO.File.ReadAllBytes(filePath);
                System.IO.File.WriteAllBytes("/Project/LSHSM/EU/" + EndUserID + "/" +FileName,FileContentBytes);
                System.IO.File.Delete(filePath);

                return Ok(new { FileName, Message = "End user certificate uploaded successfully." });
            }
            else 
            {
                return Problem(
                    detail: "Unable to verify certificate",
                    statusCode: 400,
                    title: "Certificate verification failed"
                );
            }
        }

        [HttpGet]
        public String ChangeLSHSMDuration(String EndUserID, String SignedChallenge, String DurationString) 
        {
            String ResultString = "";
            if (EndUserID != null && SignedChallenge != null)
            {
                int EUIDIndex = System_LSHSM.Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                DateTime MyDT = DateTime.UtcNow.AddHours(8).AddSeconds(Double.Parse(DurationString));
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    Users_LSHSM.ChangeUserLSHSMDuration(EUIDIndex, SignedChallengeBytes,MyDT);
                    ResultString = Users_LSHSM.GetStatus(EUIDIndex);
                }
                else
                {
                    ResultString = "Error: EndUserID must be valid, SignedChallenge must encode in base64";
                }
            }
            else
            {
                ResultString = "Error: EndUserID and SignedChallenge must not be empty";
            }
            return ResultString;
        }

        [HttpGet("Delete")]
        public String DeleteLSHSM(String EndUserID, String SignedChallenge) 
        {
            String ResultString = "";
            if (EndUserID != null && SignedChallenge != null)
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    Users_LSHSM.DeleteLSHSM(EUIDIndex, SignedChallengeBytes);
                    EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                    if (EUIDIndex == -1) 
                    {
                        ResultString = "Success: The LSHSM for this end user had been deleted";
                    }
                    else 
                    {
                        ResultString = Users_LSHSM.GetStatus(EUIDIndex);
                    }
                }
                else
                {
                    ResultString = "Error: EndUserID must be valid, SignedChallenge must encode in base64 and specified format's datetime string was required";
                }
            }
            else
            {
                ResultString = "Error: EndUserID and SignedChallenge must not be empty";
            }
            return ResultString;
        }

        [HttpGet("DownloadDecryptedFiles")]
        public async Task<IActionResult> DownloadFiles(String EndUserID, String SignedChallenge) 
        {
            if(EndUserID!=null && SignedChallenge!=null && EndUserID.CompareTo("")!=0 && SignedChallenge.CompareTo("") != 0) 
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(EndUserID, SignedChallengeBytes, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                    if (AbleToVerify)
                    {
                        var memoryStream = new MemoryStream();

                        using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, leaveOpen: true))
                        {
                            var files = Directory.GetFiles($"/Project/LSHSM/EU/{EndUserID}/DecryptedFiles");

                            foreach (var filePath in files)
                            {
                                var entryName = Path.GetFileName(filePath);
                                var entry = archive.CreateEntry(entryName);

                                using var entryStream = entry.Open();
                                using var fileStream = System.IO.File.OpenRead(filePath);
                                await fileStream.CopyToAsync(entryStream);
                            }
                        }

                        memoryStream.Seek(0, SeekOrigin.Begin);

                        var zipFileName = "DecryptedFiles.zip";
                        return File(memoryStream, "application/zip", zipFileName);
                    }
                    else
                    {
                        return Problem(
                        detail: InternalVerificationResultString + ";" + DatabaseVerificationResultString,
                        statusCode: 400,
                        title: "Verification error"
                        );
                    }
                }
                else
                {
                    return Problem(
                    detail: "Unable to parse or it's invalid",
                    statusCode: 400,
                    title: "Invalid data"
                    );
                }
            }
            else 
            {
                return Problem(
                detail: "Error: EndUserID or SignedChallenge are empty",
                statusCode: 400,
                title: "Verification error"
                );
            }
        }

        //Request access only able to download decrypted files
        [HttpGet("RequestPerm")]
        public String RequestAccess(String AdminEndUserID, String NormalEndUserID, String SignedChallenge)
        {
            String StatusString = "";
            if (AdminEndUserID != null && SignedChallenge != null &&
                AdminEndUserID.CompareTo("") != 0 && SignedChallenge.CompareTo("") != 0
                && NormalEndUserID!=null && NormalEndUserID.CompareTo("")!=0) 
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(NormalEndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true) 
                {
                    AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(NormalEndUserID, SignedChallengeBytes, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                    if (AbleToVerify) 
                    {
                        //Do something..
                        MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                        String ExceptionString = "";
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        MySQLGeneralQuery.CommandText = "INSERT INTO `Current_EU_Perm_Access`(`Root_End_User_ID`, `Normal_End_User_ID`, `Request_Access_DT`) VALUES (@Root_End_User_ID,@Normal_End_User_ID,@Request_Access_DT)";
                        MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                        MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = NormalEndUserID;
                        MySQLGeneralQuery.Parameters.Add("@Request_Access_DT", MySqlDbType.DateTime).Value = DateTime.UtcNow.AddHours(8);
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        myMyOwnMySQLConnection.ClearConnectionString();
                        StatusString = "Success: Requesting permission from admin user.";
                    }
                    else 
                    {
                        StatusString = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                    }
                }
                else 
                {
                    StatusString = "Error: Unable to parse or it's invalid";
                }
            }
            else 
            {
                StatusString = "Error: User IDs and signed challenge must not be empty";
            }
            return StatusString;
        }

        [HttpGet("GrantPerm")]
        public String GrantAccess(String AdminEndUserID, String NormalEndUserID, String SignedChallenge) 
        {
            String StatusString = "";
            if (AdminEndUserID != null && SignedChallenge != null &&
                AdminEndUserID.CompareTo("") != 0 && SignedChallenge.CompareTo("") != 0
                && NormalEndUserID != null && NormalEndUserID.CompareTo("") != 0)
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(AdminEndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(AdminEndUserID, SignedChallengeBytes, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                    if (AbleToVerify)
                    {
                        //Do something..
                        MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                        String ExceptionString = "";
                        int Count = 0;
                        DateTime DatabaseDateTime = new DateTime();
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Current_EU_Perm_Access` WHERE `Root_End_User_ID`=@Root_End_User_ID AND `Normal_End_User_ID`=@Normal_End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                        MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = NormalEndUserID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count == 1) 
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `Request_Access_DT` FROM `Current_EU_Perm_Access` WHERE `Root_End_User_ID`=@Root_End_User_ID AND `Normal_End_User_ID`=@Normal_End_User_ID";
                            MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                            MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = NormalEndUserID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `Current_EU_Perm_Access` WHERE `Root_End_User_ID`=@Root_End_User_ID AND `Normal_End_User_ID`=@Normal_End_User_ID";
                            MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                            MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = NormalEndUserID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "INSERT INTO `EU_Perm_Access_Log`(`Root_End_User_ID`, `Normal_End_User_ID`, `Request_Access_DT`) VALUES (@Root_End_User_ID,@Normal_End_User_ID,@Request_Access_DT)";
                            MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                            MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = NormalEndUserID;
                            MySQLGeneralQuery.Parameters.Add("@Request_Access_DT", MySqlDbType.DateTime).Value = DatabaseDateTime;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            StatusString = "Success: Access granted to the user.";
                        }
                        else 
                        {
                            StatusString = "Error: Either the record didn't exist or more than 1 record exist";
                        }
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        myMyOwnMySQLConnection.ClearConnectionString();
                    }
                    else
                    {
                        StatusString = InternalVerificationResultString + ";" + DatabaseVerificationResultString;
                    }
                }
                else
                {
                    StatusString = "Error: Unable to parse or it's invalid";
                }
            }
            else
            {
                StatusString = "Error: User IDs and signed challenge must not be empty";
            }
            return StatusString;
        }

        [HttpGet("RetrivePermList")]
        public String RetrieveAccessList(String EndUserID, String SignedChallenge) 
        {
            String StatusString = "";
            if (EndUserID != null && SignedChallenge != null && EndUserID.CompareTo("") != 0 && SignedChallenge.CompareTo("") != 0) 
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                    String ExceptionString = "";
                    MySqlDataReader MyReader;
                    int Count = 0;
                    int Loop = 0;
                    List<String> ResultsData = new List<String>();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_Perm_Access_Log` WHERE `Root_End_User_ID`=@Root_End_User_ID";
                    MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = EndUserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count > 0) 
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Normal_End_User_ID`, `Request_Access_DT` FROM `EU_Perm_Access_Log` WHERE `Root_End_User_ID`=@Root_End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = EndUserID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MyReader = MySQLGeneralQuery.ExecuteReader();
                        while (MyReader.Read()) 
                        {
                            ResultsData.Add(MyReader.GetString("Normal_End_User_ID"));
                            ResultsData.Add(MyReader.GetDateTime("Request_Access_DT").ToString());
                        }
                        while (Loop < ResultsData.Count) 
                        {
                            if ((Loop + 1) % 2 == 0) 
                            {
                                StatusString += "," + ResultsData[Loop];
                                StatusString += ";";
                            }
                            else 
                            {
                                StatusString += ResultsData[Loop];
                            }
                            Loop += 1;
                        }
                    }
                    else 
                    {
                        StatusString = "Error: There's no permission access log for this end user";
                    }
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                }
                else
                {
                    StatusString = "Error: EndUserID must be valid, SignedChallenge must encode in base64 and specified format's datetime string was required";
                }
            }
            else 
            {
                StatusString = "Error: EndUserID and SignedChallenge must not be empty";
            }
            return StatusString;
        }

        [HttpGet("NormalUserDownloadFiles")]
        public async Task<IActionResult> NormalUserDownloadFiles(String EndUserID, String SignedChallenge, String AdminEndUserID)
        {
            if (EndUserID != null && SignedChallenge != null && EndUserID.CompareTo("") != 0 && SignedChallenge.CompareTo("") != 0
                && AdminEndUserID!=null && AdminEndUserID.CompareTo("")!=0)
            {
                int EUIDIndex = Users_LSHSM.FindLHSMForUser(EndUserID);
                Byte[] SignedChallengeBytes = new Byte[] { };
                Boolean AbleToParse = true;
                Boolean IsValid = true;
                String InternalVerificationResultString = "";
                String DatabaseVerificationResultString = "";
                Boolean AbleToVerify = true;
                try
                {
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (EUIDIndex == -1)
                {
                    IsValid = false;
                }
                if (AbleToParse == true && IsValid == true)
                {
                    AbleToVerify = LSHSM_MethodsHelper.VerifyingSignedChallenge(EndUserID, SignedChallengeBytes, ref InternalVerificationResultString, ref DatabaseVerificationResultString);
                    if (AbleToVerify)
                    {
                        //Do something on database..
                        MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                        String ExceptionString = "";
                        int Count = 0;
                        DateTime DatabaseDateTime = new DateTime();
                        DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
                        TimeSpan MyTimeSpan = new TimeSpan();
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_Perm_Access_Log` WHERE `Root_End_User_ID`=@Root_End_User_ID AND `Normal_End_User_ID`=@Normal_End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                        MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = EndUserID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count > 0) 
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `Request_Access_DT` FROM `EU_Perm_Access_Log` WHERE `Root_End_User_ID`=@Root_End_User_ID AND `Normal_End_User_ID`=@Normal_End_User_ID ORDER BY `EUPAL_ID` DESC LIMIT 1";
                            MySQLGeneralQuery.Parameters.Add("@Root_End_User_ID", MySqlDbType.Text).Value = AdminEndUserID;
                            MySQLGeneralQuery.Parameters.Add("@Normal_End_User_ID", MySqlDbType.Text).Value = EndUserID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                            if (MyTimeSpan.TotalHours <= 12) 
                            {
                                var memoryStream = new MemoryStream();

                                using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, leaveOpen: true))
                                {
                                    var files = Directory.GetFiles($"/Project/LSHSM/EU/{AdminEndUserID}/DecryptedFiles");

                                    foreach (var filePath in files)
                                    {
                                        var entryName = Path.GetFileName(filePath);
                                        var entry = archive.CreateEntry(entryName);

                                        using var entryStream = entry.Open();
                                        using var fileStream = System.IO.File.OpenRead(filePath);
                                        await fileStream.CopyToAsync(entryStream);
                                    }
                                }

                                memoryStream.Seek(0, SeekOrigin.Begin);

                                var zipFileName = "DecryptedFiles.zip";
                                return File(memoryStream, "application/zip", zipFileName);
                            }
                            else 
                            {
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                return Problem(
                                detail: "Error: Access expired. Kindly request from the admin again.",
                                statusCode: 400,
                                title: "Access Error"
                                );
                            }
                        }
                        else 
                        {
                            myMyOwnMySQLConnection.MyMySQLConnection.Close();
                            myMyOwnMySQLConnection.ClearConnectionString();
                            return Problem(
                            detail: "Error: Unable to find any permission records",
                            statusCode: 400,
                            title: "Records Error"
                            );
                        }
                    }
                    else
                    {
                        return Problem(
                        detail: InternalVerificationResultString + ";" + DatabaseVerificationResultString,
                        statusCode: 400,
                        title: "Verification error"
                        );
                    }
                }
                else
                {
                    return Problem(
                    detail: "Unable to parse or it's invalid",
                    statusCode: 400,
                    title: "Invalid data"
                    );
                }
            }
            else
            {
                return Problem(
                detail: "Error: EndUserIDs or SignedChallenge are empty",
                statusCode: 400,
                title: "Verification error"
                );
            }
        }
    }
}
