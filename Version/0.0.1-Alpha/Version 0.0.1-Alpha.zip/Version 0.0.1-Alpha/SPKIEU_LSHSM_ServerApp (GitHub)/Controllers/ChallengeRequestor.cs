﻿using ASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKIEU_LSHSM_ServerApp.Helper;
using System;

namespace SPKIEU_LSHSM_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChallengeRequestor : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String GenerateOrFetchChallenge(String End_User_ID,String Type,String Remarks) 
        {
            Boolean IsEUExist = System.IO.Directory.Exists("/Project/LSHSM/EU/" + End_User_ID +"/");
            if (IsEUExist) 
            {
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                String ExceptionString = "";
                int Count = 0;
                String ResultString = "";
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = End_User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 0)
                {
                    Byte[] Challenge = new Byte[] { };
                    Challenge = SodiumRNG.GetRandomBytes(128);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "INSERT INTO `System_Challenge`(`EU_ID`, `Challenge`, `Request_Time`, `Type`, `Remarks`) VALUES (@EU_ID, @Challenge, @Request_Time, @Type, @Remarks)";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = End_User_ID;
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Parameters.Add("@Request_Time", MySqlDbType.DateTime).Value = DateTime.UtcNow.AddHours(8);
                    MySQLGeneralQuery.Parameters.Add("@Type", MySqlDbType.Text).Value = Type;
                    MySQLGeneralQuery.Parameters.Add("@Remarks", MySqlDbType.Text).Value = Remarks;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    ResultString = Convert.ToBase64String(Challenge);
                }
                else
                {
                    DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
                    DateTime DatabaseDateTime = new DateTime();
                    TimeSpan MyTimeSpan = new TimeSpan();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Request_Time` FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = End_User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                    if (MyTimeSpan.TotalMinutes <= 8)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Challenge` FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                        MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = End_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        ResultString = MySQLGeneralQuery.ExecuteScalar().ToString();
                    }
                    else
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                        MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = End_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        ResultString = "Error: This specified user had exceeded the valid duration.. Deleting the generated challenge";
                    }
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                return ResultString;
            }
            else 
            {
                return "Error: This end user does not have a valid certificate";
            }
        }
    }
}
