﻿using SPKIEU_LSHSM_ServerApp.LocalAPIHelper;
using SPKIEU_LSHSM_ServerApp.System_LSHSM;

namespace SPKIEU_LSHSM_ServerApp
{
    //
    public class RemoveUsersLSHSMSchedulerHelper : BackgroundService
    {
        private readonly ILogger<RemoveUsersLSHSMSchedulerHelper> _logger;
        private readonly TimeSpan _interval = TimeSpan.FromMinutes(5); // ⏱ change as needed
        private static Boolean IsReady = false;

        public RemoveUsersLSHSMSchedulerHelper(ILogger<RemoveUsersLSHSMSchedulerHelper> logger)
        {
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("ScheduledTaskService started.");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    // 👉 Your scheduled task logic here
                    _logger.LogInformation("Running scheduled task at: {time}", DateTimeOffset.Now);

                    if (IsReady) 
                    {
                        ServerRemoveLSHSMsHelper.RemoveLSHSMs();
                        Console.WriteLine(Users_LSHSM.GetCurrentLSHSMCount());
                    }
                    else 
                    {
                        IsReady = true;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "An error occurred while executing scheduled task.");
                }

                // Wait for next interval or until cancellation
                await Task.Delay(_interval, stoppingToken);
            }

            _logger.LogInformation("ScheduledTaskService is stopping.");
        }
    }
}
