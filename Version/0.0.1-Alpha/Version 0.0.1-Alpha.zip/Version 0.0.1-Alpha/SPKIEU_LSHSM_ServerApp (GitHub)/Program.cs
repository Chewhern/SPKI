using ASodium;
using SPKIEU_LSHSM_ServerApp;
using SPKIEU_LSHSM_ServerApp.Helper;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//Need to also add backgroundworker to remove the LSHSM

builder.Services.AddControllers();

builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.Listen(System.Net.IPAddress.Parse("0.0.0.0"), 5001);
}
);

builder.Services.AddHostedService<RemoveUsersLSHSMSchedulerHelper>();

var app = builder.Build();

app.Lifetime.ApplicationStarted.Register(() =>
{
    SodiumInit.Init();
    DirectoriesCreationHelper.CreateDirectories();
});

// Configure the HTTP request pipeline.

//app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
