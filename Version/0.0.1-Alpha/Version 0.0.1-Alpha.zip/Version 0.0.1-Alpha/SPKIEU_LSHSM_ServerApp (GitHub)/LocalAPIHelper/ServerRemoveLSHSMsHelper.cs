﻿using ASodium;
using BCASodium;
using SPKIEU_LSHSM_ServerApp.System_LSHSM;

namespace SPKIEU_LSHSM_ServerApp.LocalAPIHelper
{
    public static class ServerRemoveLSHSMsHelper
    {
        public static void RemoveLSHSMs(Boolean UseDefault=true) 
        {
            if (UseDefault) 
            {
                RevampedKeyPair MyED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                Byte[] Challenge = Users_LSHSM.GenerateInternalChallenge();
                Users_LSHSM.SetInternalPublicKey(MyED25519KeyPair.PublicKey);
                Byte[] SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, MyED25519KeyPair.PrivateKey);
                Users_LSHSM.DeleteLSHSMs(SignedChallenge);
                MyED25519KeyPair.Clear();
            }
            else 
            {
                ED448RevampedKeyPair MyED448KeyPair = SecureED448.GenerateED448RevampedKeyPair();
                Byte[] Challenge = Users_LSHSM.GenerateInternalChallenge();
                Users_LSHSM.SetInternalPublicKey(MyED448KeyPair.PublicKey);
                Byte[] SignedChallenge = SecureED448.GenerateSignatureMessage(MyED448KeyPair.PrivateKey, Challenge, new Byte[] { }, true);
                Console.WriteLine(Users_LSHSM.DeleteLSHSMs(SignedChallenge));
                MyED448KeyPair.Clear();
            }
        }
    }
}
