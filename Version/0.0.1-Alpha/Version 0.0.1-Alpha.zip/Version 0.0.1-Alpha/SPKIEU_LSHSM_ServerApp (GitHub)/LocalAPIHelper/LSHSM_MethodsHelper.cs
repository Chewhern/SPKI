﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKIEU_LSHSM_ServerApp.Helper;
using SPKIEU_LSHSM_ServerApp.Model;

namespace SPKIEU_LSHSM_ServerApp.LocalAPIHelper
{
    public static class LSHSM_MethodsHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static Boolean VerifyingSignedChallenge(String EndUserID, Byte[] SignedChallenge,ref String InternalVerificationResultString, ref String DatabaseVerificationResultString) 
        {
            Boolean AbleToVerify = true;
            Byte[] Challenge = new Byte[] { };
            InternalVerificationResultString = VerifySignedChallenge(EndUserID,SignedChallenge,ref Challenge);
            DatabaseVerificationResultString = VerifyChallengeWithDatabase(InternalVerificationResultString,EndUserID,Challenge);
            if(InternalVerificationResultString.Contains("Error")==false && DatabaseVerificationResultString.Contains("Error") == false) 
            {
                AbleToVerify = true;
            }
            else 
            {
                AbleToVerify = false;
            }
            return AbleToVerify;
        }
        
        public static String VerifySignedChallenge(String EndUserID, Byte[] SignedChallenge, ref Byte[] Challenge)
        {
            String ResultString = "";
            if (File.Exists("/Project/LSHSM/EU/" + EndUserID + "/BasicTLCert.txt")==true) 
            {
                String[] FileContents = File.ReadAllLines("/Project/LSHSM/EU/" + EndUserID + "/BasicTLCert.txt");
                String[] RowContents = new String[] { };
                String SignerPublicKeyB64String = "";
                Byte[] SignerPublicKeyBytes = new Byte[] { };
                String[] Signed_TNode_User_Auth_PKs = new String[] { };
                Byte[] Signed_TNode_User_Auth_PKBytes = new Byte[] { };
                Byte[] TNode_User_Auth_PKBytes = new Byte[] { };
                int Loop = 0;
                int Loop2 = 0;
                if (FileContents.Length > 2)
                {
                    Signed_TNode_User_Auth_PKs = new String[FileContents.Length - 2];
                    while (Loop < FileContents.Length)
                    {
                        if (Loop >= 2)
                        {
                            RowContents = FileContents[Loop].Split(";");
                            Signed_TNode_User_Auth_PKs[Loop2] = RowContents[1];
                            SignerPublicKeyB64String = RowContents[4];
                            SignerPublicKeyBytes = Convert.FromBase64String(SignerPublicKeyB64String);
                            Signed_TNode_User_Auth_PKBytes = Convert.FromBase64String(Signed_TNode_User_Auth_PKs[Loop2]);
                            try 
                            {
                                if (SignerPublicKeyBytes.Length == 32)
                                {
                                    TNode_User_Auth_PKBytes = SodiumPublicKeyAuth.Verify(Signed_TNode_User_Auth_PKBytes, SignerPublicKeyBytes);
                                }
                                else
                                {
                                    TNode_User_Auth_PKBytes = SecureED448.GetMessageFromSignatureMessage(SignerPublicKeyBytes, Signed_TNode_User_Auth_PKBytes, new Byte[] { });
                                }
                            }
                            catch 
                            {
                                ResultString = "Error: Unable to verify certain signed authentication public keys";
                                break;
                            }
                            Loop2 += 1;
                        }
                        Loop += 1;
                    }
                    if (ResultString.CompareTo("") == 0) 
                    {
                        if (TNode_User_Auth_PKBytes.Length == 32)
                        {
                            try
                            {
                                Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, TNode_User_Auth_PKBytes);
                            }
                            catch
                            {
                                ResultString = "Error: Unable to verify challenge";
                            }
                        }
                        else
                        {
                            try
                            {
                                Challenge = SecureED448.GetMessageFromSignatureMessage(TNode_User_Auth_PKBytes, SignedChallenge, new Byte[] { });
                            }
                            catch
                            {
                                ResultString = "Error: Unable to verify challenge";
                            }
                        }
                        if (ResultString.CompareTo("") == 0)
                        {
                            ResultString = "Success: The signed challenge had been verified";
                        }
                    }
                }
                else 
                {
                    ResultString = "Error: This certificate file is not valid.";
                }
            }
            else 
            {
                ResultString = "Error: This EndUserID does not exist";
            }
            return ResultString;
        }

        private static String VerifyChallengeWithDatabase(String StatusString, String EndUserID, Byte[] Challenge) 
        {
            String ResultString = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            int Count = 0;
            InternalChallengeModel InternalModel = new InternalChallengeModel();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            if (StatusString != null && StatusString.Contains("Error") == false)
            {
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `System_Challenge` WHERE `EU_ID`=@EU_ID AND `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = EndUserID;
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    InternalModel.EU_ID = EndUserID;
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Challenge` FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = EndUserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    InternalModel.Challenge = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Request_Time` FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = EndUserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    InternalModel.Request_Time = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    InternalModel.Removal_Time = DateTime.UtcNow.AddHours(8);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Type` FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = EndUserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    InternalModel.Type = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Remarks` FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = EndUserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    InternalModel.Remarks = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "INSERT INTO `System_Challenge_Log`(`EU_ID`, `Challenge`, `Request_Time`, `Removal_Time`, `Type`, `Remarks`) VALUES (@EU_ID, @Challenge, @Request_Time, @Removal_Time, @Type, @Remarks)";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = InternalModel.EU_ID;
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = InternalModel.Challenge;
                    MySQLGeneralQuery.Parameters.Add("@Request_Time", MySqlDbType.DateTime).Value = InternalModel.Request_Time;
                    MySQLGeneralQuery.Parameters.Add("@Removal_Time", MySqlDbType.DateTime).Value = InternalModel.Removal_Time;
                    MySQLGeneralQuery.Parameters.Add("@Type", MySqlDbType.Text).Value = InternalModel.Type;
                    MySQLGeneralQuery.Parameters.Add("@Remarks", MySqlDbType.Text).Value = InternalModel.Remarks;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `System_Challenge` WHERE `EU_ID`=@EU_ID";
                    MySQLGeneralQuery.Parameters.Add("@EU_ID", MySqlDbType.Text).Value = EndUserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    ResultString = "Success: This verified challenge able to verify with database";
                }
                else 
                {
                    ResultString = "Error: This verified challenge unable to verify with database";
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        public static String VerifyPublicKeys(String EndUserID,ref Byte[] TNode_User_Sign_PKBytes) 
        {
            String ResultString = "";
            if (File.Exists("/Project/LSHSM/EU/" + EndUserID + "/BasicTLCert.txt") == true) 
            {
                String[] FileContents = File.ReadAllLines("/Project/LSHSM/EU/" + EndUserID + "/BasicTLCert.txt");
                String[] RowContents = new String[] { };
                String SignerPublicKeyB64String = "";
                Byte[] SignerPublicKeyBytes = new Byte[] { };
                String[] Signed_TNode_User_Sign_PKs = new String[] { };
                Byte[] Signed_TNode_User_Sign_PKBytes = new Byte[] { };
                int Loop = 0;
                int Loop2 = 0;
                Signed_TNode_User_Sign_PKs = new String[FileContents.Length - 2];
                Boolean AbleToVerifyAll = true;
                if (FileContents.Length > 2) 
                {
                    while (Loop < FileContents.Length)
                    {
                        if (Loop >= 2)
                        {
                            RowContents = FileContents[Loop].Split(";");
                            Signed_TNode_User_Sign_PKs[Loop2] = RowContents[2];
                            SignerPublicKeyB64String = RowContents[4];
                            SignerPublicKeyBytes = Convert.FromBase64String(SignerPublicKeyB64String);
                            Signed_TNode_User_Sign_PKBytes = Convert.FromBase64String(Signed_TNode_User_Sign_PKs[Loop2]);
                            try
                            {
                                if (SignerPublicKeyBytes.Length == 32)
                                {
                                    TNode_User_Sign_PKBytes = SodiumPublicKeyAuth.Verify(Signed_TNode_User_Sign_PKBytes, SignerPublicKeyBytes);
                                }
                                else
                                {
                                    TNode_User_Sign_PKBytes = SecureED448.GetMessageFromSignatureMessage(SignerPublicKeyBytes, Signed_TNode_User_Sign_PKBytes, new Byte[] { });
                                }
                            }
                            catch
                            {
                                AbleToVerifyAll = false;
                                break;
                            }
                            Loop2 += 1;
                        }
                        Loop += 1;
                    }
                    if (AbleToVerifyAll) 
                    {
                        ResultString = "Success: Successfully verify all signed public keys";
                    }
                    else 
                    {
                        ResultString = "Error: Unable to verify certain signed public keys for this end user";
                    }
                }
                else 
                {
                    ResultString = "Error: This certificate file is not valid";
                }
            }
            else 
            {
                ResultString = "Error: Unable to find certificate for this user";
            }
            return ResultString;
        }
    }
}
