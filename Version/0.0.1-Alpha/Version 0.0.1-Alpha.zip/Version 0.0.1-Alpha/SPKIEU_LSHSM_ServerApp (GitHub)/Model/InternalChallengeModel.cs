﻿namespace SPKIEU_LSHSM_ServerApp.Model
{
    public class InternalChallengeModel
    {
        public String EU_ID { get; set; }

        public String Challenge { get; set; }

        public DateTime Request_Time { get; set; }

        public DateTime Removal_Time { get; set; }

        public String Type { get; set; }

        public String Remarks { get; set; }
    }
}
