﻿namespace SPKIEU_LSHSM_ServerApp.Helper
{
    public static class DirectoriesCreationHelper
    {
        public static void CreateDirectories() 
        {
            if (Directory.Exists("/Project/") == false) 
            {
                Directory.CreateDirectory("/Project/");
            }
            if (Directory.Exists("/Project/LSHSM/") == false) 
            {
                Directory.CreateDirectory("/Project/LSHSM/");
            }
            if (Directory.Exists("/Project/LSHSM/db/") == false) 
            {
                Directory.CreateDirectory("/Project/LSHSM/db/");
            }
            if (Directory.Exists("/Project/LSHSM/EU/") == false) 
            {
                Directory.CreateDirectory("/Project/LSHSM/EU/");
            }
        }
    }
}
