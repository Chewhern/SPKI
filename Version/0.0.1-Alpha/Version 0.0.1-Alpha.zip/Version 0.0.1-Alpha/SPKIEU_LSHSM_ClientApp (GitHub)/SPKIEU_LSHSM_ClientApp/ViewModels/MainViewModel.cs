﻿namespace SPKIEU_LSHSM_ClientApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}
