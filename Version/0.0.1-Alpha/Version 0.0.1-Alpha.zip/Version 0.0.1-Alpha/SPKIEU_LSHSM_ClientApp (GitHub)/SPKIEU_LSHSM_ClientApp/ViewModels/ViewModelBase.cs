﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKIEU_LSHSM_ClientApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
