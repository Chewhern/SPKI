﻿using SPKIEU_LSHSM_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIEU_LSHSM_ClientApp.EUMethodHelper
{
    public static class DownloadZipHelper
    {
        public static async Task<string> AdminDownloadZip(string EndUserID,string SignedChallenge) 
        {
            string StatusString = "";
            string directory = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
            {
                directory = AppContext.BaseDirectory + "\\Encryption\\Decrypted_Data\\";
            }
            else 
            {
                directory = AppContext.BaseDirectory + "/Encryption/Decrypted_Data/";
            }
            string downloadUrl = APIIPAddressHelper.IPAddress + $"EUOps/DownloadDecryptedFiles?EndUserID={EndUserID}" + $"&SignedChallenge={HttpUtility.UrlEncode(SignedChallenge)}";
            var zipSavePath = directory + "DecryptedFiles.zip";

            using var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(downloadUrl);

            if (response.IsSuccessStatusCode)
            {
                await using var stream = await response.Content.ReadAsStreamAsync();
                await using var fileStream = File.Create(zipSavePath);
                await stream.CopyToAsync(fileStream);
                StatusString = $"ZIP saved to: {zipSavePath}";
            }
            else
            {
                StatusString = "Download failed: " + await response.Content.ReadAsStringAsync();
            }

            return StatusString;
        }

        public static async Task<string> NormalUsersDownloadZip(string EndUserID, string SignedChallenge, string AdminEndUserID)
        {
            string StatusString = "";
            string directory = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                directory = AppContext.BaseDirectory + "\\Encryption\\Decrypted_Data\\";
            }
            else
            {
                directory = AppContext.BaseDirectory + "/Encryption/Decrypted_Data/";
            }
            string downloadUrl = APIIPAddressHelper.IPAddress + $"EUOps/NormalUserDownloadFiles?EndUserID={EndUserID}" + $"&SignedChallenge={HttpUtility.UrlEncode(SignedChallenge)}" + $"&AdminEndUserID={AdminEndUserID}";
            var zipSavePath = directory + "DecryptedFiles.zip";

            using var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(downloadUrl);

            if (response.IsSuccessStatusCode)
            {
                await using var stream = await response.Content.ReadAsStreamAsync();
                await using var fileStream = File.Create(zipSavePath);
                await stream.CopyToAsync(fileStream);
                StatusString = $"ZIP saved to: {zipSavePath}";
            }
            else
            {
                StatusString = "Download failed: " + await response.Content.ReadAsStringAsync();
            }

            return StatusString;
        }
    }
}
