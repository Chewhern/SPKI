﻿using SPKIEU_LSHSM_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIEU_LSHSM_ClientApp.EUMethodHelper
{
    public static class RetrieveAccessListHelper
    {
        public static string RetrieveAccessList(string EndUserID, string SignedChallenge) 
        {
            string ResultString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync($"EUOps/RetrivePermList?EndUserID={EndUserID}&SignedChallenge={HttpUtility.UrlEncode(SignedChallenge)}");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    ResultString = Result;

                    if (ResultString.Contains("Error") == false) 
                    {
                        string[] ResultArray = ResultString.Split(";");
                        string TempResult = "";
                        int Loop = 0;
                        string TempPath = "";
                        while (Loop < ResultArray.Length) 
                        {
                            if (Loop + 1 == ResultArray.Length) 
                            {
                                TempResult += ResultArray[Loop];
                            }
                            else 
                            {
                                TempResult += ResultArray[Loop] + Environment.NewLine;
                            }
                            Loop += 1;
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                        {
                            TempPath = AppContext.BaseDirectory + "\\Access_List\\";
                        }
                        else 
                        {
                            TempPath = AppContext.BaseDirectory + "/Access_List/";
                        }
                        File.WriteAllText(TempPath + "List.txt", TempResult);
                    }
                }
                else
                {
                    ResultString = "Error: Server encounter issues";
                }
            }
            return ResultString;
        }
    }
}
