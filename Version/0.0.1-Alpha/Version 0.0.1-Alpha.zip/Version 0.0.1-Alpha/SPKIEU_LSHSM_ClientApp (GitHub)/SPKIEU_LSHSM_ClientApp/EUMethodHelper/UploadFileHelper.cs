﻿using SPKIEU_LSHSM_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIEU_LSHSM_ClientApp.EUMethodHelper
{
    public static class UploadFileHelper
    {
        public static async Task<string> UploadCert(string Path) 
        {
            string StatusString = "";

            var httpClient = new HttpClient();
            var fileBytes = File.ReadAllBytes(Path);
            var content = new ByteArrayContent(fileBytes);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            var response = await httpClient.PostAsync(APIIPAddressHelper.IPAddress+"EUOps?fileName=BasicTLCert.txt", content);

            StatusString = await response.Content.ReadAsStringAsync();

            return StatusString;
        }

        public static async Task<string> UploadFile(string Path, string EndUserID, string FileName, string SignedChallenge)
        {
            string StatusString = "";

            var httpClient = new HttpClient();
            var fileBytes = File.ReadAllBytes(Path);
            var content = new ByteArrayContent(fileBytes);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            var response = await httpClient.PostAsync(APIIPAddressHelper.IPAddress + $"EncryptionOps?EndUserID={EndUserID}&FileName={FileName}&SignedChallenge={HttpUtility.UrlEncode(SignedChallenge)}", content);

            StatusString = await response.Content.ReadAsStringAsync();

            return StatusString;
        }
    }
}
