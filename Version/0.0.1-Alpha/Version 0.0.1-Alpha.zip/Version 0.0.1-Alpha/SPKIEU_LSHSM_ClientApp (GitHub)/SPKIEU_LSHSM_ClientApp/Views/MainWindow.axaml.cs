﻿using Avalonia.Controls;

namespace SPKIEU_LSHSM_ClientApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
