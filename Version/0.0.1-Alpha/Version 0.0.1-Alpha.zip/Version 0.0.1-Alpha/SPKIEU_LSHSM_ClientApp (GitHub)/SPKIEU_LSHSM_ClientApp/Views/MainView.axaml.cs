﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using SPKIEU_LSHSM_ClientApp.APIHelper;
using SPKIEU_LSHSM_ClientApp.APIMethodHelper;
using SPKIEU_LSHSM_ClientApp.EncryptionMethodHelper;
using SPKIEU_LSHSM_ClientApp.ETLSMethodHelper;
using SPKIEU_LSHSM_ClientApp.EUMethodHelper;
using SPKIEU_LSHSM_ClientApp.LSHSMMethodHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace SPKIEU_LSHSM_ClientApp.Views;

public partial class MainView : UserControl
{
    private static int IPOpsAppUIChooser = 0;
    private static int EUOpsAppUIChooser = 0;
    private static int ETLSOpsAppUIChooser = 0;
    private static int EncryptionOpsAppUIChooser = 0;
    private static int LSHSMAppUIChooser = 0;
    //...
    private static TextBlock[] FirstIPOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstIPOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstIPOpsAppButtonArray = new Button[] { };
    //...
    private static TextBlock[] FirstEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstEUOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondEUOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdEUOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FourthEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FourthEUOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FourthEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FifthEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FifthEUOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FifthEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SixthEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SixthEUOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SixthEUOpsAppButtonArray = new Button[] { };
    //...
    private static TextBlock[] FirstETLSOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstETLSOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstETLSOpsAppButtonArray = new Button[] { };
    //...
    private static TextBlock[] FirstEncryptionOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstEncryptionOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstEncryptionOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondEncryptionOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondEncryptionOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondEncryptionOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdEncryptionOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdEncryptionOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdEncryptionOpsAppButtonArray = new Button[] { };
    //...
    private static TextBlock[] FirstLSHSMTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstLSHSMTextBoxArray = new TextBox[] { };
    private static Button[] FirstLSHSMButtonArray = new Button[] { };
    private static TextBlock[] SecondLSHSMTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondLSHSMTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondLSHSMComboBoxArray = new ComboBox[] { };
    private static Button[] SecondLSHSMButtonArray = new Button[] { };
    private static TextBlock[] ThirdLSHSMTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdLSHSMTextBoxArray = new TextBox[] { };
    private static Button[] ThirdLSHSMButtonArray = new Button[] { };
    //Add the root directories..
    //..TBC
    private static String ServerFolder = "";
    private static String CertFolder = "";
    private static String ETLSOpsAppFolder = "";
    private static String EncryptionOpsAppMainFolder = "";
    private static String EncryptionOpsAppDataSourceFolder = "";
    private static String EncryptionOpsAppDecryptedFolder = "";
    private static String PermissionsListFolder = "";
    //..

    private static Boolean HasIPOpsAppUIRendered = false;
    private static Boolean HasEUOpsAppUIRendered = false;
    private static Boolean HasETLSOpsAppUIRendered = false;
    private static Boolean HasEncryptionOpsAppUIRendered = false;
    private static Boolean HasLSHSMAppUIRendered = false;

    public MainView()
    {
        InitializeComponent();
        IPOpsAppInitialization();
        EUOpsAppInitialization();
        ETLSOpsAppInitialization();
        EncryptionOpsAppInitialization();
        LSHSMAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
        {
            ServerFolder = AppContext.BaseDirectory + "\\Server\\";
            CertFolder = AppContext.BaseDirectory + "\\Cert\\";
            ETLSOpsAppFolder = AppContext.BaseDirectory + "\\ETLS\\";
            EncryptionOpsAppMainFolder = AppContext.BaseDirectory + "\\Encryption\\";
            EncryptionOpsAppDataSourceFolder = EncryptionOpsAppMainFolder + "Data\\";
            EncryptionOpsAppDecryptedFolder = EncryptionOpsAppMainFolder + "Decrypted_Data\\";
            PermissionsListFolder = AppContext.BaseDirectory + "\\Access_List\\";
        }
        else 
        {
            ServerFolder = AppContext.BaseDirectory + "/Server/";
            CertFolder = AppContext.BaseDirectory + "/Cert/";
            ETLSOpsAppFolder = AppContext.BaseDirectory + "/ETLS/";
            EncryptionOpsAppMainFolder = AppContext.BaseDirectory + "/Encryption/";
            EncryptionOpsAppDataSourceFolder = EncryptionOpsAppMainFolder + "Data/";
            EncryptionOpsAppDecryptedFolder = EncryptionOpsAppMainFolder + "Decrypted_Data/";
            PermissionsListFolder = AppContext.BaseDirectory + "/Access_List/";
        }
        if (Directory.Exists(ServerFolder)==false) 
        {
            Directory.CreateDirectory(ServerFolder);
        }
        if (Directory.Exists(CertFolder) == false) 
        {
            Directory.CreateDirectory(CertFolder);
        }
        if (Directory.Exists(ETLSOpsAppFolder) == false)
        {
            Directory.CreateDirectory(ETLSOpsAppFolder);
        }
        if (Directory.Exists(EncryptionOpsAppMainFolder) == false) 
        {
            Directory.CreateDirectory(EncryptionOpsAppMainFolder);
        }
        if (Directory.Exists(EncryptionOpsAppDataSourceFolder) == false)
        {
            Directory.CreateDirectory(EncryptionOpsAppDataSourceFolder);
        }
        if (Directory.Exists(EncryptionOpsAppDecryptedFolder) == false)
        {
            Directory.CreateDirectory(EncryptionOpsAppDecryptedFolder);
        }
        if (Directory.Exists(PermissionsListFolder) == false)
        {
            Directory.CreateDirectory(PermissionsListFolder);
        }
        StartUpFunction();
    }

    private void StartUpFunction() 
    {
        if (Directory.Exists(ServerFolder) == true)
        {
            if (File.Exists(ServerFolder + "IP.txt") == true)
            {
                EstablishConnectionHelper.CreateLinkWithServer();
            }
        }
    }

    private void IPOpsAppInitialization() 
    {
        IPOpsAppUIChooser = 0;
        IPOpsAppToggleBTN1.Click += IPOpsAppToggleBTNSFunction;
    }

    private void EUOpsAppInitialization() 
    {
        EUOpsAppUIChooser = 0;
        EUOpsAppToggleBTN1.Click += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN2.Click += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN3.Click += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN4.Click += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN5.Click += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN6.Click += EUOpsAppToggleBTNSFunction;
    }

    private void ETLSOpsAppInitialization() 
    {
        ETLSOpsAppUIChooser = 0;
        ETLSOpsAppToggleBTN1.Click += ETLSOpsAppToggleBTNSFunction;
    }

    private void EncryptionOpsAppInitialization() 
    {
        EncryptionOpsAppUIChooser = 0;
        EncryptionOpsAppToggleBTN1.Click += EncryptionOpsAppToggleBTNSFunction;
        EncryptionOpsAppToggleBTN2.Click += EncryptionOpsAppToggleBTNSFunction;
        EncryptionOpsAppToggleBTN3.Click += EncryptionOpsAppToggleBTNSFunction;
    }

    private void LSHSMAppInitialization() 
    {
        LSHSMAppUIChooser = 0;
        LSHSMOpsAppToggleBTN1.Click += LSHSMAppToggleBTNSFunction;
        LSHSMOpsAppToggleBTN2.Click += LSHSMAppToggleBTNSFunction;
        LSHSMOpsAppToggleBTN3.Click += LSHSMAppToggleBTNSFunction;
    }

    private void IPOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(IPOpsAppToggleBTN1.IsChecked == true) 
        {
            IPOpsAppUIChooser = 1;
        }
        else 
        {
            ResetIPOpsAppUI();
        }
        IPOpsAppDrawUI();
    }

    private void EUOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(EUOpsAppToggleBTN1.IsChecked == true) 
        {
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppToggleBTN4.IsChecked = false;
            EUOpsAppToggleBTN5.IsChecked = false;
            EUOpsAppToggleBTN6.IsChecked = false;
            EUOpsAppUIChooser = 1;
        }
        else if (EUOpsAppToggleBTN2.IsChecked == true)
        {
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppToggleBTN4.IsChecked = false;
            EUOpsAppToggleBTN5.IsChecked = false;
            EUOpsAppToggleBTN6.IsChecked = false;
            EUOpsAppUIChooser = 2;
        }
        else if (EUOpsAppToggleBTN3.IsChecked == true)
        {
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN4.IsChecked = false;
            EUOpsAppToggleBTN5.IsChecked = false;
            EUOpsAppToggleBTN6.IsChecked = false;
            EUOpsAppUIChooser = 3;
        }
        else if (EUOpsAppToggleBTN4.IsChecked == true)
        {
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppToggleBTN5.IsChecked = false;
            EUOpsAppToggleBTN6.IsChecked = false;
            EUOpsAppUIChooser = 4;
        }
        else if (EUOpsAppToggleBTN5.IsChecked == true)
        {
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppToggleBTN4.IsChecked = false;
            EUOpsAppToggleBTN6.IsChecked = false;
            EUOpsAppUIChooser = 5;
        }
        else if (EUOpsAppToggleBTN6.IsChecked == true)
        {
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppToggleBTN4.IsChecked = false;
            EUOpsAppToggleBTN5.IsChecked = false;
            EUOpsAppUIChooser = 6;
        }
        else 
        {
            ResetEUOpsAppUI();
        }
        EUOpsAppDrawUI();
    }

    private void ETLSOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(ETLSOpsAppToggleBTN1.IsChecked == true) 
        {
            ETLSOpsAppUIChooser = 1;
        }
        else 
        {
            ResetETLSOpsAppUI();
        }
        ETLSOpsAppDrawUI();
    }

    private void EncryptionOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (EncryptionOpsAppToggleBTN1.IsChecked == true) 
        {
            EncryptionOpsAppToggleBTN2.IsChecked = false;
            EncryptionOpsAppToggleBTN3.IsChecked = false;
            EncryptionOpsAppUIChooser = 1;
        }
        else if (EncryptionOpsAppToggleBTN2.IsChecked == true) 
        {
            EncryptionOpsAppToggleBTN1.IsChecked = false;
            EncryptionOpsAppToggleBTN3.IsChecked = false;
            EncryptionOpsAppUIChooser = 2;
        }
        else if (EncryptionOpsAppToggleBTN3.IsChecked == true)
        {
            EncryptionOpsAppToggleBTN1.IsChecked = false;
            EncryptionOpsAppToggleBTN2.IsChecked = false;
            EncryptionOpsAppUIChooser = 3;
        }
        else
        {
            ResetEncryptionOpsAppUI();
        }
        EncryptionOpsAppDrawUI();
    }

    private void LSHSMAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(LSHSMOpsAppToggleBTN1.IsChecked == true) 
        {
            LSHSMOpsAppToggleBTN2.IsChecked = false;
            LSHSMOpsAppToggleBTN3.IsChecked = false;
            LSHSMAppUIChooser = 1;
        }
        else if(LSHSMOpsAppToggleBTN2.IsChecked == true) 
        {
            LSHSMOpsAppToggleBTN1.IsChecked = false;
            LSHSMOpsAppToggleBTN3.IsChecked = false;
            LSHSMAppUIChooser = 2;
        }
        else if(LSHSMOpsAppToggleBTN3.IsChecked == true) 
        {
            LSHSMOpsAppToggleBTN1.IsChecked = false;
            LSHSMOpsAppToggleBTN2.IsChecked = false;
            LSHSMAppUIChooser = 3;
        }
        else 
        {
            ResetLSHSMAppUI();
        }
        LSHSMAppDrawUI();
    }

    private void IPOpsAppDrawUI()
    {
        if(IPOpsAppUIChooser == 1) 
        {
            if(HasIPOpsAppUIRendered == false) 
            {
                FirstIPOpsAppTextBlockArray = new TextBlock[2];
                FirstIPOpsAppTextBlockArray[0] = new TextBlock();
                FirstIPOpsAppTextBlockArray[1] = new TextBlock();
                FirstIPOpsAppTextBlockArray[0].Text = "Server API IP address of LSHSM?";
                FirstIPOpsAppTextBlockArray[1].Text = "Server IP address status (Read Only)";
                FirstIPOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstIPOpsAppTextBoxArray = new TextBox[2];
                FirstIPOpsAppTextBoxArray[0] = new TextBox();
                FirstIPOpsAppTextBoxArray[1] = new TextBox();
                FirstIPOpsAppTextBoxArray[0].Height = 125;
                FirstIPOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstIPOpsAppTextBoxArray[0].Width = 250;
                FirstIPOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstIPOpsAppTextBoxArray[1].Height = 125;
                FirstIPOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstIPOpsAppTextBoxArray[1].Width = 250;
                FirstIPOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstIPOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstIPOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstIPOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstIPOpsAppButtonArray = new Button[1];
                FirstIPOpsAppButtonArray[0] = new Button();
                FirstIPOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstIPOpsAppButtonArray[0].Content = "Add and establish a connection";
                FirstIPOpsAppButtonArray[0].Click += IPOpsAppBTN_Click;
                IPOpsAppLowerRightSP.Children.Add(FirstIPOpsAppTextBlockArray[0]);
                IPOpsAppLowerRightSP.Children.Add(FirstIPOpsAppTextBoxArray[0]);
                IPOpsAppLowerRightSP.Children.Add(FirstIPOpsAppTextBlockArray[1]);
                IPOpsAppLowerRightSP.Children.Add(FirstIPOpsAppTextBoxArray[1]);
                IPOpsAppLowerRightSP.Children.Add(FirstIPOpsAppButtonArray[0]);
                HasIPOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetIPOpsAppUI();
        }
    }

    private void EUOpsAppDrawUI()
    {
        if(EUOpsAppUIChooser == 1) 
        {
            if(HasEUOpsAppUIRendered == false) 
            {
                FirstEUOpsAppTextBlockArray = new TextBlock[1];
                FirstEUOpsAppTextBlockArray[0] = new TextBlock();
                FirstEUOpsAppTextBlockArray[0].Text = "Upload Cert Status";
                FirstEUOpsAppTextBoxArray = new TextBox[1];
                FirstEUOpsAppTextBoxArray[0] = new TextBox();
                FirstEUOpsAppTextBoxArray[0].Height = 125;
                FirstEUOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[0].Width = 250;
                FirstEUOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[0].IsReadOnly = true;
                FirstEUOpsAppButtonArray = new Button[1];
                FirstEUOpsAppButtonArray[0] = new Button();
                FirstEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppButtonArray[0].Content = "Upload Cert";
                FirstEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                EUOpsAppLowerRightSP.Children.Add(FirstEUOpsAppTextBlockArray[0]);
                EUOpsAppLowerRightSP.Children.Add(FirstEUOpsAppTextBoxArray[0]);
                EUOpsAppLowerRightSP.Children.Add(FirstEUOpsAppButtonArray[0]);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if(EUOpsAppUIChooser == 2) 
        {
            if (HasEUOpsAppUIRendered == false)
            {
                SecondEUOpsAppTextBlockArray = new TextBlock[1];
                SecondEUOpsAppTextBlockArray[0] = new TextBlock();
                SecondEUOpsAppTextBlockArray[0].Text = "Download File Status";
                SecondEUOpsAppTextBoxArray = new TextBox[1];
                SecondEUOpsAppTextBoxArray[0] = new TextBox();
                SecondEUOpsAppTextBoxArray[0].Height = 125;
                SecondEUOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondEUOpsAppTextBoxArray[0].Width = 250;
                SecondEUOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondEUOpsAppButtonArray = new Button[1];
                SecondEUOpsAppButtonArray[0] = new Button();
                SecondEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppButtonArray[0].Content = "Download my files";
                SecondEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                EUOpsAppLowerRightSP.Children.Add(SecondEUOpsAppTextBlockArray[0]);
                EUOpsAppLowerRightSP.Children.Add(SecondEUOpsAppTextBoxArray[0]);
                EUOpsAppLowerRightSP.Children.Add(SecondEUOpsAppButtonArray[0]);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if(EUOpsAppUIChooser == 3) 
        {
            if (HasEUOpsAppUIRendered == false)
            {
                ThirdEUOpsAppTextBlockArray = new TextBlock[2];
                ThirdEUOpsAppTextBlockArray[0] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[1] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[0].Text = "End User ID who request?";
                ThirdEUOpsAppTextBlockArray[1].Text = "Request Status";
                ThirdEUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBoxArray = new TextBox[2];
                ThirdEUOpsAppTextBoxArray[0] = new TextBox();
                ThirdEUOpsAppTextBoxArray[1] = new TextBox();
                ThirdEUOpsAppTextBoxArray[0].Height = 125;
                ThirdEUOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[0].Width = 250;
                ThirdEUOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[1].Height = 125;
                ThirdEUOpsAppTextBoxArray[1].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[1].Width = 250;
                ThirdEUOpsAppTextBoxArray[1].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[1].IsReadOnly = true;
                ThirdEUOpsAppButtonArray = new Button[1];
                ThirdEUOpsAppButtonArray[0] = new Button();
                ThirdEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppButtonArray[0].Content = "Request Permission";
                ThirdEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                EUOpsAppLowerRightSP.Children.Add(ThirdEUOpsAppTextBlockArray[0]);
                EUOpsAppLowerRightSP.Children.Add(ThirdEUOpsAppTextBoxArray[0]);
                EUOpsAppLowerRightSP.Children.Add(ThirdEUOpsAppTextBlockArray[1]);
                EUOpsAppLowerRightSP.Children.Add(ThirdEUOpsAppTextBoxArray[1]);
                EUOpsAppLowerRightSP.Children.Add(ThirdEUOpsAppButtonArray[0]);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if(EUOpsAppUIChooser == 4) 
        {
            if (HasEUOpsAppUIRendered == false)
            {
                FourthEUOpsAppTextBlockArray = new TextBlock[2];
                FourthEUOpsAppTextBlockArray[0] = new TextBlock();
                FourthEUOpsAppTextBlockArray[1] = new TextBlock();
                FourthEUOpsAppTextBlockArray[0].Text = "Grant access to end user id?";
                FourthEUOpsAppTextBlockArray[1].Text = "Grant Status";
                FourthEUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthEUOpsAppTextBoxArray = new TextBox[2];
                FourthEUOpsAppTextBoxArray[0] = new TextBox();
                FourthEUOpsAppTextBoxArray[1] = new TextBox();
                FourthEUOpsAppTextBoxArray[0].Height = 125;
                FourthEUOpsAppTextBoxArray[0].MaxHeight = 125;
                FourthEUOpsAppTextBoxArray[0].Width = 250;
                FourthEUOpsAppTextBoxArray[0].MaxWidth = 250;
                FourthEUOpsAppTextBoxArray[1].Height = 125;
                FourthEUOpsAppTextBoxArray[1].MaxHeight = 125;
                FourthEUOpsAppTextBoxArray[1].Width = 250;
                FourthEUOpsAppTextBoxArray[1].MaxWidth = 250;
                FourthEUOpsAppTextBoxArray[1].IsReadOnly = true;
                FourthEUOpsAppButtonArray = new Button[1];
                FourthEUOpsAppButtonArray[0] = new Button();
                FourthEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthEUOpsAppButtonArray[0].Content = "Grant Access";
                FourthEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                EUOpsAppLowerRightSP.Children.Add(FourthEUOpsAppTextBlockArray[0]);
                EUOpsAppLowerRightSP.Children.Add(FourthEUOpsAppTextBoxArray[0]);
                EUOpsAppLowerRightSP.Children.Add(FourthEUOpsAppTextBlockArray[1]);
                EUOpsAppLowerRightSP.Children.Add(FourthEUOpsAppTextBoxArray[1]);
                EUOpsAppLowerRightSP.Children.Add(FourthEUOpsAppButtonArray[0]);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if(EUOpsAppUIChooser == 5) 
        {
            if (HasEUOpsAppUIRendered == false)
            {
                FifthEUOpsAppTextBlockArray = new TextBlock[1];
                FifthEUOpsAppTextBlockArray[0] = new TextBlock();
                FifthEUOpsAppTextBlockArray[0].Text = "Retrieve Status";
                FifthEUOpsAppTextBoxArray = new TextBox[1];
                FifthEUOpsAppTextBoxArray[0] = new TextBox();
                FifthEUOpsAppTextBoxArray[0].Height = 125;
                FifthEUOpsAppTextBoxArray[0].MaxHeight = 125;
                FifthEUOpsAppTextBoxArray[0].Width = 250;
                FifthEUOpsAppTextBoxArray[0].MaxWidth = 250;
                FifthEUOpsAppTextBoxArray[0].IsReadOnly = true;
                FifthEUOpsAppButtonArray = new Button[1];
                FifthEUOpsAppButtonArray[0] = new Button();
                FifthEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthEUOpsAppButtonArray[0].Content = "Retrieve Access List";
                FifthEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                EUOpsAppLowerRightSP.Children.Add(FifthEUOpsAppTextBlockArray[0]);
                EUOpsAppLowerRightSP.Children.Add(FifthEUOpsAppTextBoxArray[0]);
                EUOpsAppLowerRightSP.Children.Add(FifthEUOpsAppButtonArray[0]);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if(EUOpsAppUIChooser == 6) 
        {
            if (HasEUOpsAppUIRendered == false)
            {
                SixthEUOpsAppTextBlockArray = new TextBlock[2];
                SixthEUOpsAppTextBlockArray[0] = new TextBlock();
                SixthEUOpsAppTextBlockArray[1] = new TextBlock();
                SixthEUOpsAppTextBlockArray[0].Text = "What's the admin user id?";
                SixthEUOpsAppTextBlockArray[1].Text = "Download File Status";
                SixthEUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthEUOpsAppTextBoxArray = new TextBox[2];
                SixthEUOpsAppTextBoxArray[0] = new TextBox();
                SixthEUOpsAppTextBoxArray[1] = new TextBox();
                SixthEUOpsAppTextBoxArray[0].Height = 125;
                SixthEUOpsAppTextBoxArray[0].MaxHeight = 125;
                SixthEUOpsAppTextBoxArray[0].Width = 250;
                SixthEUOpsAppTextBoxArray[0].MaxWidth = 250;
                SixthEUOpsAppTextBoxArray[1].Height = 125;
                SixthEUOpsAppTextBoxArray[1].MaxHeight = 125;
                SixthEUOpsAppTextBoxArray[1].Width = 250;
                SixthEUOpsAppTextBoxArray[1].MaxWidth = 250;
                SixthEUOpsAppTextBoxArray[1].IsReadOnly = true;
                SixthEUOpsAppButtonArray = new Button[1];
                SixthEUOpsAppButtonArray[0] = new Button();
                SixthEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthEUOpsAppButtonArray[0].Content = "Download others files";
                SixthEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                EUOpsAppLowerRightSP.Children.Add(SixthEUOpsAppTextBlockArray[0]);
                EUOpsAppLowerRightSP.Children.Add(SixthEUOpsAppTextBoxArray[0]);
                EUOpsAppLowerRightSP.Children.Add(SixthEUOpsAppTextBlockArray[1]);
                EUOpsAppLowerRightSP.Children.Add(SixthEUOpsAppTextBoxArray[1]);
                EUOpsAppLowerRightSP.Children.Add(SixthEUOpsAppButtonArray[0]);
                HasEUOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetEUOpsAppUI();
        }
    }

    private void ETLSOpsAppDrawUI()
    {
        if(ETLSOpsAppUIChooser == 1) 
        {
            if(HasETLSOpsAppUIRendered == false) 
            {
                FirstETLSOpsAppTextBlockArray = new TextBlock[1];
                FirstETLSOpsAppTextBlockArray[0] = new TextBlock();
                FirstETLSOpsAppTextBlockArray[0].Text = "ETLS Deletion Status (Read Only)";
                FirstETLSOpsAppTextBoxArray = new TextBox[1];
                FirstETLSOpsAppTextBoxArray[0] = new TextBox();
                FirstETLSOpsAppTextBoxArray[0].Height = 125;
                FirstETLSOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstETLSOpsAppTextBoxArray[0].Width = 250;
                FirstETLSOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstETLSOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstETLSOpsAppTextBoxArray[0].IsReadOnly = true;
                FirstETLSOpsAppButtonArray = new Button[1];
                FirstETLSOpsAppButtonArray[0] = new Button();
                FirstETLSOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstETLSOpsAppButtonArray[0].Content = "Delete ETLS";
                FirstETLSOpsAppButtonArray[0].Click += ETLSOpsAppBTN_Click;
                ETLSOpsAppLowerRightSP.Children.Add(FirstETLSOpsAppTextBlockArray[0]);
                ETLSOpsAppLowerRightSP.Children.Add(FirstETLSOpsAppTextBoxArray[0]);
                ETLSOpsAppLowerRightSP.Children.Add(FirstETLSOpsAppButtonArray[0]);
                HasETLSOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetETLSOpsAppUI();
        }
    }

    private void EncryptionOpsAppDrawUI()
    {
        if(EncryptionOpsAppUIChooser == 1) 
        {
            if(HasEncryptionOpsAppUIRendered == false) 
            {
                FirstEncryptionOpsAppTextBlockArray = new TextBlock[1];
                FirstEncryptionOpsAppTextBlockArray[0] = new TextBlock();
                FirstEncryptionOpsAppTextBlockArray[0].Text = "Upload File Status (Read Only)";
                FirstEncryptionOpsAppTextBoxArray = new TextBox[1];
                FirstEncryptionOpsAppTextBoxArray[0] = new TextBox();
                FirstEncryptionOpsAppTextBoxArray[0].Height = 125;
                FirstEncryptionOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstEncryptionOpsAppTextBoxArray[0].Width = 250;
                FirstEncryptionOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstEncryptionOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstEncryptionOpsAppTextBoxArray[0].IsReadOnly = true;
                FirstEncryptionOpsAppButtonArray = new Button[1];
                FirstEncryptionOpsAppButtonArray[0] = new Button();
                FirstEncryptionOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEncryptionOpsAppButtonArray[0].Content = "Upload File(s)";
                FirstEncryptionOpsAppButtonArray[0].Click += EncryptionOpsAppBTN_Click;
                EncryptionOpsAppLowerRightSP.Children.Add(FirstEncryptionOpsAppTextBlockArray[0]);
                EncryptionOpsAppLowerRightSP.Children.Add(FirstEncryptionOpsAppTextBoxArray[0]);
                EncryptionOpsAppLowerRightSP.Children.Add(FirstEncryptionOpsAppButtonArray[0]);
                HasEncryptionOpsAppUIRendered = true;
            }
        }
        else if(EncryptionOpsAppUIChooser == 2) 
        {
            if (HasEncryptionOpsAppUIRendered == false)
            {
                SecondEncryptionOpsAppTextBlockArray = new TextBlock[1];
                SecondEncryptionOpsAppTextBlockArray[0] = new TextBlock();
                SecondEncryptionOpsAppTextBlockArray[0].Text = "Encryption Status (Read Only)";
                SecondEncryptionOpsAppTextBoxArray = new TextBox[1];
                SecondEncryptionOpsAppTextBoxArray[0] = new TextBox();
                SecondEncryptionOpsAppTextBoxArray[0].Height = 125;
                SecondEncryptionOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondEncryptionOpsAppTextBoxArray[0].Width = 250;
                SecondEncryptionOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondEncryptionOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondEncryptionOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondEncryptionOpsAppButtonArray = new Button[1];
                SecondEncryptionOpsAppButtonArray[0] = new Button();
                SecondEncryptionOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEncryptionOpsAppButtonArray[0].Content = "Encrypt Files";
                SecondEncryptionOpsAppButtonArray[0].Click += EncryptionOpsAppBTN_Click;
                EncryptionOpsAppLowerRightSP.Children.Add(SecondEncryptionOpsAppTextBlockArray[0]);
                EncryptionOpsAppLowerRightSP.Children.Add(SecondEncryptionOpsAppTextBoxArray[0]);
                EncryptionOpsAppLowerRightSP.Children.Add(SecondEncryptionOpsAppButtonArray[0]);
                HasEncryptionOpsAppUIRendered = true;
            }
        }
        else if(EncryptionOpsAppUIChooser == 3) 
        {
            if (HasEncryptionOpsAppUIRendered == false)
            {
                ThirdEncryptionOpsAppTextBlockArray = new TextBlock[1];
                ThirdEncryptionOpsAppTextBlockArray[0] = new TextBlock();
                ThirdEncryptionOpsAppTextBlockArray[0].Text = "Decryption Status (Read Only)";
                ThirdEncryptionOpsAppTextBoxArray = new TextBox[1];
                ThirdEncryptionOpsAppTextBoxArray[0] = new TextBox();
                ThirdEncryptionOpsAppTextBoxArray[0].Height = 125;
                ThirdEncryptionOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdEncryptionOpsAppTextBoxArray[0].Width = 250;
                ThirdEncryptionOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdEncryptionOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdEncryptionOpsAppTextBoxArray[0].IsReadOnly = true;
                ThirdEncryptionOpsAppButtonArray = new Button[1];
                ThirdEncryptionOpsAppButtonArray[0] = new Button();
                ThirdEncryptionOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEncryptionOpsAppButtonArray[0].Content = "Decrypt Files";
                ThirdEncryptionOpsAppButtonArray[0].Click += EncryptionOpsAppBTN_Click;
                EncryptionOpsAppLowerRightSP.Children.Add(ThirdEncryptionOpsAppTextBlockArray[0]);
                EncryptionOpsAppLowerRightSP.Children.Add(ThirdEncryptionOpsAppTextBoxArray[0]);
                EncryptionOpsAppLowerRightSP.Children.Add(ThirdEncryptionOpsAppButtonArray[0]);
                HasEncryptionOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetEncryptionOpsAppUI();
        }
    }

    private void LSHSMAppDrawUI()
    {
        if(LSHSMAppUIChooser == 1) 
        {
            if(HasLSHSMAppUIRendered == false) 
            {
                FirstLSHSMTextBlockArray = new TextBlock[1];
                FirstLSHSMTextBlockArray[0] = new TextBlock();
                FirstLSHSMTextBlockArray[0].Text = "LSHSM Start Status (Read Only)";
                FirstLSHSMTextBoxArray = new TextBox[1];
                FirstLSHSMTextBoxArray[0] = new TextBox();
                FirstLSHSMTextBoxArray[0].Height = 125;
                FirstLSHSMTextBoxArray[0].MaxHeight = 125;
                FirstLSHSMTextBoxArray[0].Width = 250;
                FirstLSHSMTextBoxArray[0].MaxWidth = 250;
                FirstLSHSMTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstLSHSMTextBoxArray[0].IsReadOnly = true;
                FirstLSHSMButtonArray = new Button[1];
                FirstLSHSMButtonArray[0] = new Button();
                FirstLSHSMButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstLSHSMButtonArray[0].Content = "Start LSHSM";
                FirstLSHSMButtonArray[0].Click += LSHSMAppBTN_Click;
                LSHSMOpsAppLowerRightSP.Children.Add(FirstLSHSMTextBlockArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(FirstLSHSMTextBoxArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(FirstLSHSMButtonArray[0]);
                HasLSHSMAppUIRendered = true;
            }
        }
        else if(LSHSMAppUIChooser == 2) 
        {
            if (HasLSHSMAppUIRendered == false)
            {
                SecondLSHSMTextBlockArray = new TextBlock[3];
                SecondLSHSMTextBlockArray[0] = new TextBlock();
                SecondLSHSMTextBlockArray[1] = new TextBlock();
                SecondLSHSMTextBlockArray[2] = new TextBlock();
                SecondLSHSMTextBlockArray[0].Text = "Duration Unit";
                SecondLSHSMTextBlockArray[1].Text = "Duration Amount (<=12 Hours)";
                SecondLSHSMTextBlockArray[2].Text = "Status (Read Only)";
                SecondLSHSMTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLSHSMTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLSHSMTextBoxArray = new TextBox[2];
                SecondLSHSMTextBoxArray[0] = new TextBox();
                SecondLSHSMTextBoxArray[1] = new TextBox();
                SecondLSHSMTextBoxArray[1].IsReadOnly = true;
                SecondLSHSMTextBoxArray[0].Height = 125;
                SecondLSHSMTextBoxArray[0].MaxHeight = 125;
                SecondLSHSMTextBoxArray[0].Width = 250;
                SecondLSHSMTextBoxArray[0].MaxWidth = 250;
                SecondLSHSMTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondLSHSMTextBoxArray[1].Height = 125;
                SecondLSHSMTextBoxArray[1].MaxHeight = 125;
                SecondLSHSMTextBoxArray[1].Width = 250;
                SecondLSHSMTextBoxArray[1].MaxWidth = 250;
                SecondLSHSMTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondLSHSMComboBoxArray = new ComboBox[1];
                SecondLSHSMComboBoxArray[0] = new ComboBox();
                SecondLSHSMComboBoxArray[0].Items.Add("Seconds");
                SecondLSHSMComboBoxArray[0].Items.Add("Minutes");
                SecondLSHSMComboBoxArray[0].Items.Add("Hours");
                SecondLSHSMButtonArray = new Button[1];
                SecondLSHSMButtonArray[0] = new Button();
                SecondLSHSMButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLSHSMButtonArray[0].Content = "Change LSHSM Duration";
                SecondLSHSMButtonArray[0].Click += LSHSMAppBTN_Click;
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMTextBlockArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMComboBoxArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMTextBlockArray[1]);
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMTextBoxArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMTextBlockArray[2]);
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMTextBoxArray[1]);
                LSHSMOpsAppLowerRightSP.Children.Add(SecondLSHSMButtonArray[0]);
                HasLSHSMAppUIRendered = true;
            }
        }
        else if(LSHSMAppUIChooser == 3) 
        {
            if (HasLSHSMAppUIRendered == false)
            {
                ThirdLSHSMTextBlockArray = new TextBlock[1];
                ThirdLSHSMTextBlockArray[0] = new TextBlock();
                ThirdLSHSMTextBlockArray[0].Text = "LSHSM Deletion Status (Read Only)";
                ThirdLSHSMTextBoxArray = new TextBox[1];
                ThirdLSHSMTextBoxArray[0] = new TextBox();
                ThirdLSHSMTextBoxArray[0].Height = 125;
                ThirdLSHSMTextBoxArray[0].MaxHeight = 125;
                ThirdLSHSMTextBoxArray[0].Width = 250;
                ThirdLSHSMTextBoxArray[0].MaxWidth = 250;
                ThirdLSHSMTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdLSHSMTextBoxArray[0].IsReadOnly = true;
                ThirdLSHSMButtonArray = new Button[1];
                ThirdLSHSMButtonArray[0] = new Button();
                ThirdLSHSMButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdLSHSMButtonArray[0].Content = "Delete LSHSM";
                ThirdLSHSMButtonArray[0].Click += LSHSMAppBTN_Click;
                LSHSMOpsAppLowerRightSP.Children.Add(ThirdLSHSMTextBlockArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(ThirdLSHSMTextBoxArray[0]);
                LSHSMOpsAppLowerRightSP.Children.Add(ThirdLSHSMButtonArray[0]);
                HasLSHSMAppUIRendered = true;
            }
        }
        else 
        {
            ResetLSHSMAppUI();
        }
    }

    private void ResetIPOpsAppUI()
    {
        IPOpsAppUIChooser = 0;
        FirstIPOpsAppTextBlockArray = new TextBlock[] { };
        FirstIPOpsAppTextBoxArray = new TextBox[] { };
        FirstIPOpsAppButtonArray = new Button[] { };
        IPOpsAppLowerRightSP.Children.Clear();
        HasIPOpsAppUIRendered = false;
    }

    private void ResetEUOpsAppUI()
    {
        EUOpsAppUIChooser = 0;
        FirstEUOpsAppTextBlockArray = new TextBlock[] { };
        FirstEUOpsAppTextBoxArray = new TextBox[] { };
        FirstEUOpsAppButtonArray = new Button[] { };
        SecondEUOpsAppTextBlockArray = new TextBlock[] { };
        SecondEUOpsAppTextBoxArray = new TextBox[] { };
        SecondEUOpsAppButtonArray = new Button[] { };
        ThirdEUOpsAppTextBlockArray = new TextBlock[] { };
        ThirdEUOpsAppTextBoxArray = new TextBox[] { };
        ThirdEUOpsAppButtonArray = new Button[] { };
        FourthEUOpsAppTextBlockArray = new TextBlock[] { };
        FourthEUOpsAppTextBoxArray = new TextBox[] { };
        FourthEUOpsAppButtonArray = new Button[] { };
        FifthEUOpsAppTextBlockArray = new TextBlock[] { };
        FifthEUOpsAppTextBoxArray = new TextBox[] { };
        FifthEUOpsAppButtonArray = new Button[] { };
        SixthEUOpsAppTextBlockArray = new TextBlock[] { };
        SixthEUOpsAppTextBoxArray = new TextBox[] { };
        SixthEUOpsAppButtonArray = new Button[] { };
        EUOpsAppLowerRightSP.Children.Clear();
        HasEUOpsAppUIRendered = false;
    }

    private void ResetETLSOpsAppUI()
    {
        ETLSOpsAppUIChooser = 0;
        FirstETLSOpsAppTextBlockArray = new TextBlock[] { };
        FirstETLSOpsAppTextBoxArray = new TextBox[] { };
        FirstETLSOpsAppButtonArray = new Button[] { };
        ETLSOpsAppLowerRightSP.Children.Clear();
        HasETLSOpsAppUIRendered = false;
    }

    private void ResetEncryptionOpsAppUI()
    {
        EncryptionOpsAppUIChooser = 0;
        FirstEncryptionOpsAppTextBlockArray = new TextBlock[] { };
        FirstEncryptionOpsAppTextBoxArray = new TextBox[] { };
        FirstEncryptionOpsAppButtonArray = new Button[] { };
        SecondEncryptionOpsAppTextBlockArray = new TextBlock[] { };
        SecondEncryptionOpsAppTextBoxArray = new TextBox[] { };
        SecondEncryptionOpsAppButtonArray = new Button[] { };
        ThirdEncryptionOpsAppTextBlockArray = new TextBlock[] { };
        ThirdEncryptionOpsAppTextBoxArray = new TextBox[] { };
        ThirdEncryptionOpsAppButtonArray = new Button[] { };
        EncryptionOpsAppLowerRightSP.Children.Clear();
        HasEncryptionOpsAppUIRendered = false;
    }

    private void ResetLSHSMAppUI()
    {
        LSHSMAppUIChooser = 0;
        FirstLSHSMTextBlockArray = new TextBlock[] { };
        FirstLSHSMTextBoxArray = new TextBox[] { };
        FirstLSHSMButtonArray = new Button[] { };
        SecondLSHSMTextBlockArray = new TextBlock[] { };
        SecondLSHSMTextBoxArray = new TextBox[] { };
        SecondLSHSMComboBoxArray = new ComboBox[] { };
        SecondLSHSMButtonArray = new Button[] { };
        ThirdLSHSMTextBlockArray = new TextBlock[] { };
        ThirdLSHSMTextBoxArray = new TextBox[] { };
        ThirdLSHSMButtonArray = new Button[] { };
        LSHSMOpsAppLowerRightSP.Children.Clear();
        HasLSHSMAppUIRendered = false;
    }

    private void IPOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(IPOpsAppUIChooser == 1) 
        {
            String IPAddress = FirstIPOpsAppTextBoxArray[0].Text;
            if(IPAddress!=null && IPAddress.CompareTo("") != 0) 
            {
                File.WriteAllText(ServerFolder + "IP.txt", IPAddress);
                EstablishConnectionHelper.CreateLinkWithServer();
                FirstIPOpsAppTextBoxArray[1].Text = EstablishConnectionHelper.ConnectionStatus;
            }
            else 
            {
                FirstIPOpsAppTextBoxArray[1].Text = "Error: IP Address of the server must not be empty";
            }
        }
    }

    private async void EUOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(EUOpsAppUIChooser == 1) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length) 
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true) 
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists) 
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        FirstEUOpsAppTextBoxArray[0].Text = await UploadFileHelper.UploadCert(CertFolder + "BasicTLCert.txt");
                    }
                    else
                    {
                        FirstEUOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else 
                {
                    FirstEUOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else 
            {
                FirstEUOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EUOpsAppUIChooser == 2) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if(PrivateKeyBytes.Length==64 || PrivateKeyBytes.Length == 56) 
                        {
                            ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Self Access", "Download files");
                            if (PrivateKeyBytes.Length == 64)
                            {
                                SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                            }
                            else
                            {
                                SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                            }
                            SecondEUOpsAppTextBoxArray[0].Text = await DownloadZipHelper.AdminDownloadZip(EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                        }
                        else 
                        {
                            SecondEUOpsAppTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        SecondEUOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    SecondEUOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                SecondEUOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EUOpsAppUIChooser == 3) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    String AdminEndUserID = ThirdEUOpsAppTextBoxArray[0].Text;
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            if(AdminEndUserID!=null && AdminEndUserID.CompareTo("") != 0) 
                            {
                                ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Request Access", $"{EndUserID} request access permission from {AdminEndUserID}");
                                if (PrivateKeyBytes.Length == 64)
                                {
                                    SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                                }
                                else
                                {
                                    SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                                }
                                ThirdEUOpsAppTextBoxArray[1].Text = RequestPermissionHelper.RequestPermission(AdminEndUserID, EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                            }
                            else 
                            {
                                ThirdEUOpsAppTextBoxArray[1].Text = "Error: Admin end user ID must not be empty";
                            }
                        }
                        else
                        {
                            ThirdEUOpsAppTextBoxArray[1].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        ThirdEUOpsAppTextBoxArray[1].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    ThirdEUOpsAppTextBoxArray[1].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                ThirdEUOpsAppTextBoxArray[1].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EUOpsAppUIChooser == 4) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String AdminEndUserID = "";
                    String EndUserID = FourthEUOpsAppTextBoxArray[0].Text;
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                AdminEndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            if (EndUserID != null && EndUserID.CompareTo("") != 0)
                            {
                                ChallengeBytes = GetServerChallenge.GetChallenge(AdminEndUserID, "Grant Access", $"{EndUserID} request access permission from {AdminEndUserID}");
                                if (PrivateKeyBytes.Length == 64)
                                {
                                    SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                                }
                                else
                                {
                                    SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                                }
                                FourthEUOpsAppTextBoxArray[1].Text = GrantPermissionHelper.GrantPermission(AdminEndUserID, EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                            }
                            else
                            {
                                FourthEUOpsAppTextBoxArray[1].Text = "Error: Admin end user ID must not be empty";
                            }
                        }
                        else
                        {
                            FourthEUOpsAppTextBoxArray[1].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        FourthEUOpsAppTextBoxArray[1].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    FourthEUOpsAppTextBoxArray[1].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                FourthEUOpsAppTextBoxArray[1].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EUOpsAppUIChooser == 5) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Retrieve Access", $"{EndUserID} retrieve access list");
                            if (PrivateKeyBytes.Length == 64)
                            {
                                SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                            }
                            else
                            {
                                SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                            }
                            FifthEUOpsAppTextBoxArray[0].Text = RetrieveAccessListHelper.RetrieveAccessList(EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                        }
                        else
                        {
                            FifthEUOpsAppTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        FifthEUOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    FifthEUOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                FifthEUOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EUOpsAppUIChooser == 6) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    String AdminEndUserID = SixthEUOpsAppTextBoxArray[0].Text;
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            if (AdminEndUserID != null && AdminEndUserID.CompareTo("") != 0)
                            {
                                ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Access other decrypted files", $"{EndUserID} retrieves decrypted files from {AdminEndUserID}");
                                if (PrivateKeyBytes.Length == 64)
                                {
                                    SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                                }
                                else
                                {
                                    SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                                }
                                SixthEUOpsAppTextBoxArray[1].Text = await DownloadZipHelper.NormalUsersDownloadZip(EndUserID, Convert.ToBase64String(SignedChallengeBytes), AdminEndUserID);
                            }
                            else
                            {
                                SixthEUOpsAppTextBoxArray[1].Text = "Error: Admin end user ID must not be empty";
                            }
                        }
                        else
                        {
                            SixthEUOpsAppTextBoxArray[1].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        SixthEUOpsAppTextBoxArray[1].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    SixthEUOpsAppTextBoxArray[1].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                SixthEUOpsAppTextBoxArray[1].Text = "Error: Unable to find the certificate";
            }
        }
    }

    private void ETLSOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(ETLSOpsAppUIChooser == 1) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "ETLS Ops", $"{EndUserID} removed his/her own ETLS");
                            if (PrivateKeyBytes.Length == 64)
                            {
                                SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                            }
                            else
                            {
                                SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                            }
                            FirstETLSOpsAppTextBoxArray[0].Text = RemoveETLSHelper.DeleteETLS(EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                        }
                        else
                        {
                            FirstETLSOpsAppTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        FirstETLSOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    FirstETLSOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                FirstETLSOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
    }

    private async void EncryptionOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(EncryptionOpsAppUIChooser == 1) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            String[] FilesPaths = Directory.GetFiles(EncryptionOpsAppDataSourceFolder);
                            String[] FilesWithoutPaths = new String[FilesPaths.Length];
                            List<String> ResultStrings = new List<String>();
                            Boolean HasAllUploaded = true;
                            Loop = 0;
                            while (Loop < FilesPaths.Length) 
                            {
                                FilesWithoutPaths[Loop] = FilesPaths[Loop].Remove(0, EncryptionOpsAppDataSourceFolder.Length);
                                ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Upload Data", $"{EndUserID} uploading data");
                                if (PrivateKeyBytes.Length == 64)
                                {
                                    SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes);
                                }
                                else
                                {
                                    SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { });
                                }
                                ResultStrings.Add(await UploadFileHelper.UploadFile(FilesPaths[Loop], EndUserID, FilesWithoutPaths[Loop],Convert.ToBase64String(SignedChallengeBytes)));
                                Loop += 1;
                            }
                            SodiumSecureMemory.SecureClearBytes(PrivateKeyBytes);
                            Loop = 0;
                            while (Loop < ResultStrings.Count) 
                            {
                                if (ResultStrings[Loop].Contains("Success") == false) 
                                {
                                    HasAllUploaded = false;
                                    break;
                                }
                                Loop += 1;
                            }
                            if (HasAllUploaded) 
                            {
                                FirstEncryptionOpsAppTextBoxArray[0].Text = "Success: All files uploaded";
                            }
                            else 
                            {
                                FirstEncryptionOpsAppTextBoxArray[0].Text = "Error: Some files failed to upload";
                            }
                        }
                        else
                        {
                            FirstEncryptionOpsAppTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        FirstEncryptionOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    FirstEncryptionOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                FirstEncryptionOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EncryptionOpsAppUIChooser == 2) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "LSHSM Encrypt Data", $"{EndUserID} encrypt some files");
                            if (PrivateKeyBytes.Length == 64)
                            {
                                SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                            }
                            else
                            {
                                SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                            }
                            SecondEncryptionOpsAppTextBoxArray[0].Text = EncryptionHelper.ServerEncryptFiles(EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                        }
                        else
                        {
                            SecondEncryptionOpsAppTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        SecondEncryptionOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    SecondEncryptionOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                SecondEncryptionOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
        else if(EncryptionOpsAppUIChooser == 3) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "LSHSM Encrypt Data", $"{EndUserID} encrypt some files");
                            if (PrivateKeyBytes.Length == 64)
                            {
                                SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                            }
                            else
                            {
                                SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                            }
                            ThirdEncryptionOpsAppTextBoxArray[0].Text = EncryptionHelper.ServerDecryptFiles(EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                        }
                        else
                        {
                            ThirdEncryptionOpsAppTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        ThirdEncryptionOpsAppTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    ThirdEncryptionOpsAppTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                ThirdEncryptionOpsAppTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
    }

    private void LSHSMAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(LSHSMAppUIChooser == 1) 
        {
            String StatusString = "";
            Boolean AbleToStart = ActualStartLSHSMHelper.StartLSHSMOnServer(ref StatusString);
            if (AbleToStart) 
            {
                FirstLSHSMTextBoxArray[0].Text = StatusString;
            }
            else 
            {
                FirstLSHSMTextBoxArray[0].Text = "Error: Unable to start."+Environment.NewLine+StatusString;
            }
        }
        else if(LSHSMAppUIChooser == 2) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                int ComboBoxSelectedIndex = SecondLSHSMComboBoxArray[0].SelectedIndex;
                String DurationString = SecondLSHSMTextBoxArray[0].Text;
                if(ComboBoxSelectedIndex!=-1 && DurationString!=null && DurationString.CompareTo("") != 0) 
                {
                    Double DurationDouble = 0;
                    Boolean AbleToParse = true;
                    Boolean IsMoreThan12Hours = false;
                    try 
                    {
                        DurationDouble = Double.Parse(DurationString);
                    }
                    catch 
                    {
                        AbleToParse = false;
                    }
                    if (AbleToParse) 
                    {
                        if (ComboBoxSelectedIndex == 0)
                        {
                            IsMoreThan12Hours = (DurationDouble > 43200);
                        }
                        else if (ComboBoxSelectedIndex == 1)
                        {
                            IsMoreThan12Hours = ((DurationDouble * 60) > 720);
                            DurationDouble = DurationDouble * 60;
                        }
                        else 
                        {
                            IsMoreThan12Hours = (DurationDouble > 12);
                            DurationDouble = DurationDouble * 60 * 60;
                        }
                        if (IsMoreThan12Hours == false) 
                        {
                            String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                            int FilesLoop = 0;
                            Boolean IsPrivateKeyExists = false;
                            while (FilesLoop < FilesWithPath.Length)
                            {
                                if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                                {
                                    IsPrivateKeyExists = true;
                                    break;
                                }
                                FilesLoop += 1;
                            }
                            if (IsPrivateKeyExists)
                            {
                                String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                                String EndUserID = "";
                                int Loop = 0;
                                if (FileContents.Length > 2)
                                {
                                    while (Loop < FileContents.Length)
                                    {
                                        if (Loop == 1)
                                        {
                                            EndUserID = FileContents[Loop];
                                            break;
                                        }
                                        Loop += 1;
                                    }
                                    Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                                    Byte[] ChallengeBytes = new Byte[] { };
                                    Byte[] SignedChallengeBytes = new Byte[] { };
                                    if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                                    {
                                        ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Edit LSHSM", $"{EndUserID} changed his/her LSHSM duration");
                                        if (PrivateKeyBytes.Length == 64)
                                        {
                                            SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                                        }
                                        else
                                        {
                                            SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                                        }
                                        SecondLSHSMTextBoxArray[1].Text = ChangeLSHSMDurationHelper.ChangeLSHSMDuration(EndUserID, Convert.ToBase64String(SignedChallengeBytes), DurationDouble.ToString());
                                    }
                                    else
                                    {
                                        SecondLSHSMTextBoxArray[1].Text = "Error: This is not a valid private key";
                                    }
                                }
                                else
                                {
                                    SecondLSHSMTextBoxArray[1].Text = "Error: This is not a valid certificate";
                                }
                            }
                            else
                            {
                                SecondLSHSMTextBoxArray[1].Text = "Error: Unable to find private key in the certificate folder";
                            }
                        }
                        else 
                        {
                            SecondLSHSMTextBoxArray[1].Text = "Error: You can't add more than 12 hours to your LSHSM";
                        }
                    }
                    else 
                    {
                        SecondLSHSMTextBoxArray[1].Text = "Error: The duration must be in numbers";
                    }
                }
                else 
                {
                    SecondLSHSMTextBoxArray[1].Text = "Error: You must select a duration unit and state the duration";
                }
            }
            else
            {
                SecondLSHSMTextBoxArray[1].Text = "Error: Unable to find the certificate";
            }
        }
        else if(LSHSMAppUIChooser == 3) 
        {
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                Boolean IsPrivateKeyExists = false;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                if (IsPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        Byte[] PrivateKeyBytes = File.ReadAllBytes(FilesWithPath[FilesLoop]);
                        Byte[] ChallengeBytes = new Byte[] { };
                        Byte[] SignedChallengeBytes = new Byte[] { };
                        if (PrivateKeyBytes.Length == 64 || PrivateKeyBytes.Length == 56)
                        {
                            ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Edit LSHSM", $"{EndUserID} deleted his/her LSHSM");
                            if (PrivateKeyBytes.Length == 64)
                            {
                                SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, PrivateKeyBytes, true);
                            }
                            else
                            {
                                SignedChallengeBytes = SecureED448.GenerateSignatureMessage(PrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                            }
                            ThirdLSHSMTextBoxArray[0].Text = DeleteLSHSMHelper.DeleteLSHSM(EndUserID, Convert.ToBase64String(SignedChallengeBytes));
                        }
                        else
                        {
                            ThirdLSHSMTextBoxArray[0].Text = "Error: This is not a valid private key";
                        }
                    }
                    else
                    {
                        ThirdLSHSMTextBoxArray[0].Text = "Error: This is not a valid certificate";
                    }
                }
                else
                {
                    ThirdLSHSMTextBoxArray[0].Text = "Error: Unable to find private key in the certificate folder";
                }
            }
            else
            {
                ThirdLSHSMTextBoxArray[0].Text = "Error: Unable to find the certificate";
            }
        }
    }
}
