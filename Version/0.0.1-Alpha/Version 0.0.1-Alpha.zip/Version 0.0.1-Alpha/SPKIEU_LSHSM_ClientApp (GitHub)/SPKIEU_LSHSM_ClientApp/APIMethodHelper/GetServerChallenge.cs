﻿using System.Net.Http.Headers;
using System.Web;
using System;
using System.Net.Http;
using SPKIEU_LSHSM_ClientApp.Helper;

namespace SPKIEU_LSHSM_ClientApp.APIHelper
{
    public class GetServerChallenge
    {
        public static String StatusString = "";

        public static Byte[] GetChallenge(String User_ID, String Type, String Remarks) 
        {
            Byte[] Challenge = new Byte[] { };
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ChallengeRequestor?End_User_ID=" + User_ID + "&Type="+HttpUtility.UrlEncode(Type)+"&Remarks="+HttpUtility.UrlEncode(Remarks));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    if (Result.Contains("Error") == true)
                    {
                        StatusString = Result;
                    }
                    else
                    {
                        Challenge = Convert.FromBase64String(Result);
                    }
                }
                else
                {
                    StatusString="Error: Server encounter some issues";
                }
            }

            return Challenge;
        }
    }
}
