﻿using ASodium;
using BCASodium;
using SPKIEU_LSHSM_ClientApp.APIHelper;
using SPKIEU_LSHSM_ClientApp.EncryptionMethodHelper;
using SPKIEU_LSHSM_ClientApp.ETLSMethodHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SPKIEU_LSHSM_ClientApp.LSHSMMethodHelper
{
    public static class ActualStartLSHSMHelper
    {
        private static String CertFolder = "";
        private static String ETLSOpsAppFolder = "";
        private static String EncryptionOpsAppMainFolder = "";

        public static Boolean StartLSHSMOnServer(ref String ResultStrings) 
        {
            Boolean AbleToStart = true;
            String InitializeETLSResultString = "";
            String AgreeKeysResultString = "";
            String StartLSHSMResultString = "";
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
            {
                CertFolder = AppContext.BaseDirectory + "\\Cert\\";
                ETLSOpsAppFolder = AppContext.BaseDirectory + "\\ETLS\\";
                EncryptionOpsAppMainFolder = AppContext.BaseDirectory + "\\Encryption\\";
            }
            else 
            {
                CertFolder = AppContext.BaseDirectory + "/Cert/";
                ETLSOpsAppFolder = AppContext.BaseDirectory + "/ETLS/";
                EncryptionOpsAppMainFolder = AppContext.BaseDirectory + "/Encryption/";
            }
            if (File.Exists(CertFolder + "BasicTLCert.txt") == true)
            {
                String[] FilesWithPath = Directory.GetFileSystemEntries(CertFolder);
                int FilesLoop = 0;
                int AuthenticationPrivateKeyIndex = 0;
                int SigningPrivateKeyIndex = 0;
                Boolean IsAuthenticationPrivateKeyExists = false;
                Boolean IsSigningPrivateKeyExists = false;
                Byte[] SigningPrivateKeyBytes = new Byte[] { };
                Byte[] AuthenticationPrivateKeyBytes = new Byte[] { };
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("APrivateKey") == true)
                    {
                        IsAuthenticationPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                AuthenticationPrivateKeyIndex = FilesLoop;
                FilesLoop = 0;
                while (FilesLoop < FilesWithPath.Length)
                {
                    if (FilesWithPath[FilesLoop].Contains("SPrivateKey") == true)
                    {
                        IsSigningPrivateKeyExists = true;
                        break;
                    }
                    FilesLoop += 1;
                }
                SigningPrivateKeyIndex = FilesLoop;
                FilesLoop = 0;
                if (IsAuthenticationPrivateKeyExists)
                {
                    String[] FileContents = File.ReadAllLines(CertFolder + "BasicTLCert.txt");
                    String EndUserID = "";
                    int Loop = 0;
                    if (FileContents.Length > 2)
                    {
                        while (Loop < FileContents.Length)
                        {
                            if (Loop == 1)
                            {
                                EndUserID = FileContents[Loop];
                                break;
                            }
                            Loop += 1;
                        }
                        SigningPrivateKeyBytes = File.ReadAllBytes(FilesWithPath[SigningPrivateKeyIndex]);
                        if (SigningPrivateKeyBytes.Length == 64) 
                        {
                            InitializeETLSResultString = StartETLSHelper.UserStartETLS(EndUserID);
                        }
                        else 
                        {
                            InitializeETLSResultString = StartETLSHelper.UserStartETLS(EndUserID,false);
                        }
                        SodiumSecureMemory.SecureClearBytes(SigningPrivateKeyBytes);
                        if (InitializeETLSResultString.Contains("Error") == false) 
                        {
                            SigningPrivateKeyBytes = File.ReadAllBytes(FilesWithPath[SigningPrivateKeyIndex]);
                            AuthenticationPrivateKeyBytes = File.ReadAllBytes(FilesWithPath[AuthenticationPrivateKeyIndex]);
                            Byte[] ChallengeBytes = new Byte[] { };
                            Byte[] SignedChallengeBytes = new Byte[] { };
                            if(SigningPrivateKeyBytes.Length==64 || SigningPrivateKeyBytes.Length == 56) 
                            {
                                Byte[] SignedMACPublicKeyBytes = new Byte[] { };
                                Byte[] SignedEncryptionPublicKeyBytes = new Byte[] { };
                                String SignedMACPublicKeyString = "";
                                String SignedEncryptionPublicKeyString = "";
                                String EphemeralMACKXPublicKeyString = "";
                                String MACKXPublicKeyString = "";
                                String EphemeralEncryptionKXPublicKeyString = "";
                                String EncryptionKXPublicKeyString = "";
                                if (SigningPrivateKeyBytes.Length == 64) 
                                {
                                    RevampedKeyPair MACX25519KeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                                    RevampedKeyPair EncryptionX25519KeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                                    SignedMACPublicKeyBytes = SodiumPublicKeyAuth.Sign(MACX25519KeyPair.PublicKey, SigningPrivateKeyBytes);
                                    SignedEncryptionPublicKeyBytes = SodiumPublicKeyAuth.Sign(EncryptionX25519KeyPair.PublicKey, SigningPrivateKeyBytes, true);
                                    SignedMACPublicKeyString = Convert.ToBase64String(SignedMACPublicKeyBytes);
                                    SignedEncryptionPublicKeyString = Convert.ToBase64String(SignedEncryptionPublicKeyBytes);
                                    AgreeKeysResultString = ETLSAgreeKeysHelper.AgreeKeys(EndUserID, SignedMACPublicKeyString, SignedEncryptionPublicKeyString);
                                    if (AgreeKeysResultString.Contains("Error") == false)
                                    {
                                        String[] KeyStrings = InitializeETLSResultString.Split(";");
                                        String SignedEphemeralMACKXPublicKeyString = KeyStrings[0];
                                        String EphemeralMACDSAPublicKeyString = KeyStrings[1];
                                        String SignedEphemeralEncryptionKXPublicKeyString = KeyStrings[2];
                                        String EphemeralEncryptionDSAPublicKeyString = KeyStrings[3];
                                        Byte[] SignedEphemeralMACKXPublicKeyBytes = Convert.FromBase64String(SignedEphemeralMACKXPublicKeyString);
                                        Byte[] EphemeralMACDSAPublicKeyBytes = Convert.FromBase64String(EphemeralMACDSAPublicKeyString);
                                        Byte[] SignedEphemeralEncryptionKXPublicKeyBytes = Convert.FromBase64String(SignedEphemeralEncryptionKXPublicKeyString);
                                        Byte[] EphemeralEncryptionDSAPublicKeyBytes = Convert.FromBase64String(EphemeralEncryptionDSAPublicKeyString);
                                        Byte[] EphemeralMACKXPublicKeyBytes = new Byte[] { };
                                        Byte[] EphemeralEncryptionKXPublicKeyBytes = new Byte[] { };
                                        Byte[] MACSharedSecret = new Byte[] { };
                                        Byte[] EncryptionSharedSecret = new Byte[] { };
                                        if (EphemeralMACDSAPublicKeyBytes.Length == 32)
                                        {
                                            EphemeralMACKXPublicKeyBytes = SodiumPublicKeyAuth.Verify(SignedEphemeralMACKXPublicKeyBytes, EphemeralMACDSAPublicKeyBytes);
                                        }
                                        else
                                        {
                                            EphemeralMACKXPublicKeyBytes = SecureED448.GetMessageFromSignatureMessage(EphemeralMACDSAPublicKeyBytes, SignedEphemeralMACKXPublicKeyBytes, new Byte[] { });
                                        }
                                        if (EphemeralEncryptionDSAPublicKeyBytes.Length == 32)
                                        {
                                            EphemeralEncryptionKXPublicKeyBytes = SodiumPublicKeyAuth.Verify(SignedEphemeralEncryptionKXPublicKeyBytes, EphemeralEncryptionDSAPublicKeyBytes);
                                        }
                                        else
                                        {
                                            EphemeralEncryptionKXPublicKeyBytes = SecureED448.GetMessageFromSignatureMessage(EphemeralEncryptionDSAPublicKeyBytes, SignedEphemeralEncryptionKXPublicKeyBytes, new Byte[] { });
                                        }
                                        EphemeralMACKXPublicKeyString = Convert.ToBase64String(EphemeralMACKXPublicKeyBytes);
                                        MACKXPublicKeyString = Convert.ToBase64String(MACX25519KeyPair.PublicKey);
                                        EphemeralEncryptionKXPublicKeyString = Convert.ToBase64String(EphemeralEncryptionKXPublicKeyBytes);
                                        EncryptionKXPublicKeyString = Convert.ToBase64String(EncryptionX25519KeyPair.PublicKey);
                                        MACSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(MACX25519KeyPair.PrivateKey, EphemeralMACKXPublicKeyBytes);
                                        EncryptionSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(EncryptionX25519KeyPair.PrivateKey, EphemeralEncryptionKXPublicKeyBytes);
                                        File.WriteAllBytes(ETLSOpsAppFolder + "MACSecretKey.txt", MACSharedSecret);
                                        File.WriteAllBytes(ETLSOpsAppFolder + "EncryptionSecretKey.txt", EncryptionSharedSecret);
                                        SodiumSecureMemory.SecureClearBytes(MACSharedSecret);
                                        SodiumSecureMemory.SecureClearBytes(EncryptionSharedSecret);
                                    }
                                    else 
                                    {
                                        AbleToStart = false;
                                    }
                                    ResultStrings = AgreeKeysResultString;
                                    MACX25519KeyPair.Clear();
                                    EncryptionX25519KeyPair.Clear();
                                }
                                else 
                                {
                                    X448RevampedKeyPair MACX448KeyPair = SecureX448.GenerateX448RevampedKeyPair();
                                    X448RevampedKeyPair EncryptionX448KeyPair = SecureX448.GenerateX448RevampedKeyPair();
                                    SignedMACPublicKeyBytes = SecureED448.GenerateSignatureMessage(SigningPrivateKeyBytes,MACX448KeyPair.PublicKey, new Byte[] { });
                                    SignedEncryptionPublicKeyBytes = SecureED448.GenerateSignatureMessage(SigningPrivateKeyBytes,EncryptionX448KeyPair.PublicKey, new Byte[] { }, true);
                                    SignedMACPublicKeyString = Convert.ToBase64String(SignedMACPublicKeyBytes);
                                    SignedEncryptionPublicKeyString = Convert.ToBase64String(SignedEncryptionPublicKeyBytes);
                                    AgreeKeysResultString = ETLSAgreeKeysHelper.AgreeKeys(EndUserID, SignedMACPublicKeyString, SignedEncryptionPublicKeyString);
                                    if (AgreeKeysResultString.Contains("Error") == false)
                                    {
                                        String[] KeyStrings = InitializeETLSResultString.Split(";");
                                        String SignedEphemeralMACKXPublicKeyString = KeyStrings[0];
                                        String EphemeralMACDSAPublicKeyString = KeyStrings[1];
                                        String SignedEphemeralEncryptionKXPublicKeyString = KeyStrings[2];
                                        String EphemeralEncryptionDSAPublicKeyString = KeyStrings[3];
                                        Byte[] SignedEphemeralMACKXPublicKeyBytes = Convert.FromBase64String(SignedEphemeralMACKXPublicKeyString);
                                        Byte[] EphemeralMACDSAPublicKeyBytes = Convert.FromBase64String(EphemeralMACDSAPublicKeyString);
                                        Byte[] SignedEphemeralEncryptionKXPublicKeyBytes = Convert.FromBase64String(SignedEphemeralEncryptionKXPublicKeyString);
                                        Byte[] EphemeralEncryptionDSAPublicKeyBytes = Convert.FromBase64String(EphemeralEncryptionDSAPublicKeyString);
                                        Byte[] EphemeralMACKXPublicKeyBytes = new Byte[] { };
                                        Byte[] EphemeralEncryptionKXPublicKeyBytes = new Byte[] { };
                                        Byte[] TempMACSharedSecret = new Byte[] { };
                                        Byte[] TempEncryptionSharedSecret = new Byte[] { };
                                        Byte[] MACSharedSecret = new Byte[] { };
                                        Byte[] EncryptionSharedSecret = new Byte[] { };
                                        if (EphemeralMACDSAPublicKeyBytes.Length == 32)
                                        {
                                            EphemeralMACKXPublicKeyBytes = SodiumPublicKeyAuth.Verify(SignedEphemeralMACKXPublicKeyBytes, EphemeralMACDSAPublicKeyBytes);
                                        }
                                        else
                                        {
                                            EphemeralMACKXPublicKeyBytes = SecureED448.GetMessageFromSignatureMessage(EphemeralMACDSAPublicKeyBytes, SignedEphemeralMACKXPublicKeyBytes, new Byte[] { });
                                        }
                                        if (EphemeralEncryptionDSAPublicKeyBytes.Length == 32)
                                        {
                                            EphemeralEncryptionKXPublicKeyBytes = SodiumPublicKeyAuth.Verify(SignedEphemeralEncryptionKXPublicKeyBytes, EphemeralEncryptionDSAPublicKeyBytes);
                                        }
                                        else
                                        {
                                            EphemeralEncryptionKXPublicKeyBytes = SecureED448.GetMessageFromSignatureMessage(EphemeralEncryptionDSAPublicKeyBytes, SignedEphemeralEncryptionKXPublicKeyBytes, new Byte[] { });
                                        }
                                        EphemeralMACKXPublicKeyString = Convert.ToBase64String(EphemeralMACKXPublicKeyBytes);
                                        MACKXPublicKeyString = Convert.ToBase64String(MACX448KeyPair.PublicKey);
                                        EphemeralEncryptionKXPublicKeyString = Convert.ToBase64String(EphemeralEncryptionKXPublicKeyBytes);
                                        EncryptionKXPublicKeyString = Convert.ToBase64String(EncryptionX448KeyPair.PublicKey);
                                        TempMACSharedSecret = SecureX448.CalculateSecret(EphemeralMACKXPublicKeyBytes,MACX448KeyPair.PrivateKey);
                                        TempEncryptionSharedSecret = SecureX448.CalculateSecret(EphemeralEncryptionKXPublicKeyBytes, EncryptionX448KeyPair.PrivateKey);
                                        MACSharedSecret = SodiumKDF.KDFFunction(32, 1, "FX448KDF", TempMACSharedSecret, true);
                                        EncryptionSharedSecret = SodiumKDF.KDFFunction(32, 1, "FX448KDF", TempEncryptionSharedSecret, true);
                                        File.WriteAllBytes(ETLSOpsAppFolder + "MACSecretKey.txt", MACSharedSecret);
                                        File.WriteAllBytes(ETLSOpsAppFolder + "EncryptionSecretKey.txt", EncryptionSharedSecret);
                                        SodiumSecureMemory.SecureClearBytes(MACSharedSecret);
                                        SodiumSecureMemory.SecureClearBytes(EncryptionSharedSecret);
                                    }
                                    else
                                    {
                                        AbleToStart = false;
                                    }
                                    ResultStrings = AgreeKeysResultString;
                                    MACX448KeyPair.Clear();
                                    EncryptionX448KeyPair.Clear();
                                }
                                if (AuthenticationPrivateKeyBytes.Length == 64 || AuthenticationPrivateKeyBytes.Length == 56)
                                {
                                    if(InitializeETLSResultString.Contains("Error") == false && AgreeKeysResultString.Contains("Error") == false) 
                                    {
                                        ChallengeBytes = GetServerChallenge.GetChallenge(EndUserID, "Start LSHSM", $"{EndUserID} started LSHSM");
                                        if (AuthenticationPrivateKeyBytes.Length == 64)
                                        {
                                            SignedChallengeBytes = SodiumPublicKeyAuth.Sign(ChallengeBytes, AuthenticationPrivateKeyBytes, true);
                                        }
                                        else
                                        {
                                            SignedChallengeBytes = SecureED448.GenerateSignatureMessage(AuthenticationPrivateKeyBytes, ChallengeBytes, new Byte[] { }, true);
                                        }
                                        Boolean IsMACSecretKeyExists = File.Exists(EncryptionOpsAppMainFolder + "MACSecretKey.txt");
                                        Boolean IsEncryptionSecretKeyExists = File.Exists(EncryptionOpsAppMainFolder + "EncryptionSecretKey.txt");
                                        if (IsMACSecretKeyExists == true && IsEncryptionSecretKeyExists == true)
                                        {
                                            Byte[] ETLSMACSecretKey = File.ReadAllBytes(ETLSOpsAppFolder + "MACSecretKey.txt");
                                            Byte[] ETLSEncryptionSecretKey = File.ReadAllBytes(ETLSOpsAppFolder + "EncryptionSecretKey.txt");
                                            Byte[] MACSecretKey = File.ReadAllBytes(EncryptionOpsAppMainFolder + "MACSecretKey.txt");
                                            Byte[] EncryptionSecretKey = File.ReadAllBytes(EncryptionOpsAppMainFolder + "EncryptionSecretKey.txt");
                                            Byte[] EncryptedMACSecretKey = new Byte[] { };
                                            Byte[] EncryptedEncryptionSecretKey = new Byte[] { };
                                            Byte[] MACInEncryptedMACSecretKey = new Byte[] { };
                                            Byte[] MACInEncryptedEncryptionSecretKey = new Byte[] { };
                                            Byte[] ActualEncryptedMACSecretKey = new Byte[] { };
                                            Byte[] ActualEncryptedEncryptionSecretKey = new Byte[] { };
                                            Byte[] MACNonce = Convert.FromBase64String(EphemeralMACKXPublicKeyString).Concat(Convert.FromBase64String(MACKXPublicKeyString)).ToArray();
                                            Byte[] EncryptionNonce = Convert.FromBase64String(EphemeralEncryptionKXPublicKeyString).Concat(Convert.FromBase64String(EncryptionKXPublicKeyString)).ToArray();
                                            MACNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), MACNonce);
                                            EncryptionNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), EncryptionNonce);
                                            EncryptedMACSecretKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(MACSecretKey, MACNonce, ETLSEncryptionSecretKey);
                                            EncryptedEncryptionSecretKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptionSecretKey, EncryptionNonce, ETLSEncryptionSecretKey, true);
                                            MACInEncryptedMACSecretKey = SodiumHMACSHA512.ComputeMAC(EncryptedMACSecretKey, ETLSMACSecretKey);
                                            MACInEncryptedEncryptionSecretKey = SodiumHMACSHA512.ComputeMAC(EncryptedEncryptionSecretKey, ETLSMACSecretKey, true);
                                            ActualEncryptedMACSecretKey = MACInEncryptedMACSecretKey.Concat(EncryptedMACSecretKey).ToArray();
                                            ActualEncryptedEncryptionSecretKey = MACInEncryptedEncryptionSecretKey.Concat(EncryptedEncryptionSecretKey).ToArray();
                                            StartLSHSMResultString = StartLSHSMHelper.StartServerLSHSM(EndUserID, Convert.ToBase64String(SignedChallengeBytes), Convert.ToBase64String(ActualEncryptedMACSecretKey),Convert.ToBase64String(ActualEncryptedEncryptionSecretKey));
                                            ResultStrings = StartLSHSMResultString;
                                            if (StartLSHSMResultString.Contains("Error")) 
                                            {
                                                AbleToStart = false;
                                            }
                                            SodiumSecureMemory.SecureClearBytes(ETLSMACSecretKey);
                                            SodiumSecureMemory.SecureClearBytes(ETLSEncryptionSecretKey);
                                            SodiumSecureMemory.SecureClearBytes(MACSecretKey);
                                            SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
                                        }
                                        else 
                                        {
                                            ResultStrings = "Error: Unable to find secret keys inside encryption main folder";
                                            AbleToStart = false;
                                        }
                                    }
                                    else 
                                    {
                                        ResultStrings = InitializeETLSResultString + Environment.NewLine + AgreeKeysResultString;
                                        AbleToStart = false;
                                    }
                                }
                                else
                                {
                                    ResultStrings += Environment.NewLine + "Error: This is not a valid private key";
                                    AbleToStart = false;
                                }
                            }
                            else 
                            {
                                ResultStrings = "Error: This is not a valid signing private key";
                                AbleToStart = false;
                                SodiumSecureMemory.SecureClearBytes(SigningPrivateKeyBytes);
                            }
                        }
                        else 
                        {
                            AbleToStart = false;
                            ResultStrings = InitializeETLSResultString;
                        }
                    }
                    else
                    {
                        ResultStrings = "Error: This is not a valid certificate";
                        AbleToStart = false;
                    }
                }
                else
                {
                    ResultStrings = "Error: Unable to find private key in the certificate folder";
                    AbleToStart = false;
                }
            }

            return AbleToStart;
        }
    }
}
