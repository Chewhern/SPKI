﻿using SPKIEU_LSHSM_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIEU_LSHSM_ClientApp.LSHSMMethodHelper
{
    //ETLS's StartLSHSM
    public static class StartLSHSMHelper
    {
        public static String StartServerLSHSM(String EndUserID, String SignedChallenge, String EncryptedMACSecretKey, String EncryptedEncryptionSecretKey) 
        {
            string ResultString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync($"ETLSOps/StartLSHSM?EndUserID={EndUserID}&SignedChallenge={HttpUtility.UrlEncode(SignedChallenge)}&EncryptedMACSecretKey={HttpUtility.UrlEncode(EncryptedMACSecretKey)}&EncryptedEncryptionSecretKey={HttpUtility.UrlEncode(EncryptedEncryptionSecretKey)}");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    ResultString = Result;
                }
                else
                {
                    ResultString = "Error: Server encounter issues";
                }
            }
            return ResultString;
        }
    }
}
