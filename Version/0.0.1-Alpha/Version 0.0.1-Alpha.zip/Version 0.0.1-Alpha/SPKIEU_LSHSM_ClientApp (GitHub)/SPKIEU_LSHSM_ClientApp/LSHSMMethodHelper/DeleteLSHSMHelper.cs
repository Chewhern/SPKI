﻿using SPKIEU_LSHSM_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIEU_LSHSM_ClientApp.LSHSMMethodHelper
{
    public static class DeleteLSHSMHelper
    {
        public static String DeleteLSHSM(String EndUserID, String SignedChallenge) 
        {
            string ResultString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync($"EUOps/Delete?EndUserID={EndUserID}&SignedChallenge={HttpUtility.UrlEncode(SignedChallenge)}");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    ResultString = Result;
                }
                else
                {
                    ResultString = "Error: Server encounter issues";
                }
            }
            return ResultString;
        }
    }
}
