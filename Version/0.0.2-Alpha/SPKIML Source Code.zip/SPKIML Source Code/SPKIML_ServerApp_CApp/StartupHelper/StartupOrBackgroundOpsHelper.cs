﻿using SPKIML_ServerApp_CApp.RepetitiveOperationsHelper;
using SPKIML_ServerApp_CApp.SimpleSoftHSM;

namespace SPKIML_ServerApp_CApp.StartupHelper
{
    public static class StartupOrBackgroundOpsHelper
    {
        public static void StartupFunction() 
        {
            SignatureRemovalHelper.RemoveSignatures();
            UsersRemovalHelper.RemoveUsers();
            SigningOperationsHelper.GeneratePCOTForUsers();
            COTOperationsHelper.PerformCOTOperations();
            UpdateNodePKHelper.UpdatePK();
            //Do something.. to make it detects.. whether run at least 1 time..
            if (File.Exists("/Project/SPKIML/Node/HasRunFirstTime.txt") == false) 
            {
                File.WriteAllText("/Project/SPKIML/Node/HasRunFirstTime.txt", "Yes");
            }
        }

        public static Boolean HasStartedUp() 
        {
            Boolean HasStarted = false;
            if (File.Exists("/Project/SPKIML/Node/HasRunFirstTime.txt") == true)
            {
                String TestString = File.ReadAllText("/Project/SPKIML/Node/HasRunFirstTime.txt");
                if(TestString!=null && TestString.CompareTo("Yes") == 0) 
                {
                    HasStarted = true;
                }
            }
            return HasStarted;
        }


        public static void BackgroundOperationsFunction() 
        {
            SignatureRemovalHelper.RemoveSignatures();
            UsersRemovalHelper.RemoveUsers();
            SigningOperationsHelper.GeneratePCOTForUsers();
            COTOperationsHelper.PerformCOTOperations();
            UpdateNodePKHelper.UpdatePK();
        }
    }
}
