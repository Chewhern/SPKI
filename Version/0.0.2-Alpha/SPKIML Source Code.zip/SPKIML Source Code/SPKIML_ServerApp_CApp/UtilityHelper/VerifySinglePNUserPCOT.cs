﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKIML_ServerApp_CApp.APIHelper;
using SPKIML_ServerApp_CApp.DataModel;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.PostDataModel;
using SPKIML_ServerApp_CApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Web;

namespace SPKIML_ServerApp_CApp.UtilityHelper
{
    public static class VerifySinglePNUserPCOT
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void VerifyPCOTForSinglePNUser(String PNode_IP_Address, String Node_User_ID)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String PNode_API_IP_Address = "";
            String CurrentNodeIPAddress = "";
            List<String> PNode_User_IDs = new List<String>();
            List<String> Signed_User_Auth_PKs = new List<String>();
            List<String> Signed_User_Sign_PKs = new List<String>();
            List<DateTime> SignedDates = new List<DateTime>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `PNode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = PNode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            PNode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            Byte[] Challenge = GetSNodeChallenge.GetChallenge(PNode_API_IP_Address);
            if (Challenge.Length != 0)
            {
                Byte[] DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                Byte[] SignedChallenge = new Byte[] { };
                if (DecryptedNodePrivateKey.Length == 64)
                {
                    Boolean IsZero = true;
                    IntPtr DecryptedNodePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, DecryptedNodePrivateKey.Length);
                    Marshal.Copy(DecryptedNodePrivateKey, 0, DecryptedNodePrivateKeyIntPtr, DecryptedNodePrivateKey.Length);
                    SodiumSecureMemory.SecureClearBytes(DecryptedNodePrivateKey);
                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKeyIntPtr, true);
                }
                else
                {
                    SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                }
                String SignedChallengeB64 = Convert.ToBase64String(SignedChallenge);
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `PNode_User_ID`,`Signed_Auth_PK`,`Signed_Sign_PK`,`Valid_DT` FROM `Node_Users_SBPARNU_Log` WHERE `PNode_IP_Address`=@PNode_IP_Address AND `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@PNode_IP_Address", MySqlDbType.Text).Value = PNode_IP_Address;
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = Node_User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MyDataReader = MySQLGeneralQuery.ExecuteReader();
                while (MyDataReader.Read()) 
                {
                    PNode_User_IDs.Add(MyDataReader.GetString("PNode_User_ID"));
                    Signed_User_Auth_PKs.Add(MyDataReader.GetString("Signed_Auth_PK"));
                    Signed_User_Sign_PKs.Add(MyDataReader.GetString("Signed_Sign_PK"));
                    SignedDates.Add(MyDataReader.GetDateTime("Valid_DT"));
                }
                VerifyAuthorizedUserPartialCertificateModel MyModel = new VerifyAuthorizedUserPartialCertificateModel();
                MyModel.TNode_IP_Address = CurrentNodeIPAddress;
                MyModel.TNode_User_ID = Node_User_ID;
                MyModel.SNode_User_IDs = PNode_User_IDs.ToArray();
                MyModel.Signed_TNode_User_Auth_PKs = Signed_User_Auth_PKs.ToArray();
                MyModel.Signed_TNode_User_Sign_PKs = Signed_User_Sign_PKs.ToArray();
                MyModel.SignedDateTimes = SignedDates.ToArray();
                MyModel.SignedChallenge = SignedChallengeB64;
                MyModel.RNode_IP_Address = "";
                String JSONBodyString = "";
                StringContent PostRequestData = new StringContent("");
                JSONBodyString = JsonConvert.SerializeObject(MyModel);
                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(PNode_API_IP_Address);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.PostAsync("SNodeCertificateOps/", PostRequestData);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        if (Result.Contains("Error") == true) 
                        {
                            throw new Exception(Result);
                        }
                    }
                    else
                    {
                        throw new Exception("Error: Parent Node encounter some issues");
                    }
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
