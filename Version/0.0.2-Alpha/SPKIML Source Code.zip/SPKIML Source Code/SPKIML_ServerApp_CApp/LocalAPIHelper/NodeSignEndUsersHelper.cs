﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.SimpleSoftHSM;
using System.Runtime.InteropServices;

namespace SPKIML_ServerApp_CApp.LocalAPIHelper
{
    public static class NodeSignEndUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void SignAllEndUsers()
        {
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(30);
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            int Loop2 = 0;
            String[] EncryptedNodeUsersSignaturePrivateKeyPath = NCOperations.GetEncryptedUserPrivateKeysPath();
            String NodeUsersSignaturePrivateKeyRootDirectory = "/Project/SPKIML/User_SignaturePrivateKeys/";
            String[] NodeUsersIDs = new String[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean[] IsNodeUsersPublicKeyMatched = new Boolean[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean IsSigned = true;
            String NodeUserSignaturePublicKeyString = "";
            Byte[] NodeUserSignaturePrivateKeyBytes = new Byte[] { };
            Byte[] NodeUserSignaturePublicKeyBytes = new Byte[] { };
            List<String> EndUserIDs = new List<String>();
            List<String> EndUserSignPKsString = new List<String>();
            List<String> EndUserAuthPKsString = new List<String>();
            Byte[] SNodeUserPKBytes = new Byte[] { };
            Byte[] SignedSNodeUserPKBytes = new Byte[] { };
            String SignedSNodeUserSignPKString = "";
            String SignedSNodeUserAuthPKString = "";
            Boolean IsZero = true;
            IntPtr NodeUserSignaturePrivateKeyIntPtr = new IntPtr();
            while (Loop < NodeUsersIDs.Length)
            {
                NodeUsersIDs[Loop] = EncryptedNodeUsersSignaturePrivateKeyPath[Loop].Remove(0, NodeUsersSignaturePrivateKeyRootDirectory.Length);
                NodeUsersIDs[Loop] = NodeUsersIDs[Loop].Remove(32, 15);
                Loop += 1;
            }
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `End_Users`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read())
            {
                EndUserIDs.Add(DataReader.GetString("User_ID"));
                EndUserSignPKsString.Add(DataReader.GetString("Sign_PK"));
                EndUserAuthPKsString.Add(DataReader.GetString("Auth_PK"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            Loop = 0;
            while (Loop < NodeUsersIDs.Length)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBPARNU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0) 
                {
                    NodeUserSignaturePrivateKeyBytes = CCOperations.DecryptUserSignaturePrivateKey(EncryptedNodeUsersSignaturePrivateKeyPath[Loop]);
                    if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                    {
                        NodeUserSignaturePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, NodeUserSignaturePrivateKeyBytes.Length);
                        Marshal.Copy(NodeUserSignaturePrivateKeyBytes, 0, NodeUserSignaturePrivateKeyIntPtr, NodeUserSignaturePrivateKeyBytes.Length);
                        SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(NodeUserSignaturePrivateKeyIntPtr);
                        NodeUserSignaturePublicKeyBytes = SodiumPublicKeyAuth.GeneratePublicKey(NodeUserSignaturePrivateKeyIntPtr);
                    }
                    else
                    {
                        NodeUserSignaturePublicKeyBytes = SecureED448.GeneratePublicKey(NodeUserSignaturePrivateKeyBytes);
                    }
                    NodeUserSignaturePublicKeyString = Convert.ToBase64String(NodeUserSignaturePublicKeyBytes);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID AND `Sign_PK`=@Sign_PK";
                    MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = NodeUserSignaturePublicKeyString;
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count > 0)
                    {
                        while (Loop2 < EndUserIDs.Count)
                        {
                            if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                            {
                                SNodeUserPKBytes = Convert.FromBase64String(EndUserSignPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SodiumPublicKeyAuth.Sign(SNodeUserPKBytes, NodeUserSignaturePrivateKeyIntPtr);
                                SignedSNodeUserSignPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                                SNodeUserPKBytes = Convert.FromBase64String(EndUserAuthPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SodiumPublicKeyAuth.Sign(SNodeUserPKBytes, NodeUserSignaturePrivateKeyIntPtr);
                                SignedSNodeUserAuthPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                            }
                            else
                            {
                                SNodeUserPKBytes = Convert.FromBase64String(EndUserSignPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, SNodeUserPKBytes, new Byte[] { });
                                SignedSNodeUserSignPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                                SNodeUserPKBytes = Convert.FromBase64String(EndUserAuthPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, SNodeUserPKBytes, new Byte[] { });
                                SignedSNodeUserAuthPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUserIDs[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 0)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "INSERT INTO `EU_SBNU_Log`(`End_User_ID`, `User_ID`, `Signed_Auth_PK`, `Signed_Sign_PK`, `Valid_DT`) VALUES (@End_User_ID, @User_ID, @Signed_Auth_PK, @Signed_Sign_PK, @Valid_DT)";
                                MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUserIDs[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                            }
                            //Do something in future..
                            /*
                            else
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK";
                                MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUserIDs[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                if (Count == 1)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "UPDATE `EU_SBPNU_Log` SET `Signed_Auth_PK`=@Signed_Auth_PK, `Signed_Sign_PK`=@Signed_Sign_PK, `Valid_DT`=@Valid_DT WHERE `End_User_ID`=@End_User_ID AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUserIDs[Loop2];
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                    MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                }
                            }
                            */
                            Loop2 += 1;
                        }
                        IsNodeUsersPublicKeyMatched[Loop] = true;
                    }
                    else
                    {
                        IsNodeUsersPublicKeyMatched[Loop] = false;
                    }
                }
                else 
                {
                    IsSigned = false;
                    IsNodeUsersPublicKeyMatched[Loop] = false;
                }
                if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                {
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(NodeUserSignaturePrivateKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(NodeUserSignaturePrivateKeyIntPtr);
                }
                else
                {
                    SodiumSecureMemory.SecureClearBytes(NodeUserSignaturePrivateKeyBytes);
                }
                Loop2 = 0;
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            Loop = 0;
            while (Loop < IsNodeUsersPublicKeyMatched.Length)
            {
                if (IsNodeUsersPublicKeyMatched[Loop] == false && IsSigned==true)
                {
                    throw new Exception("Error: Unable to proceed signing due to public keys mismatched.. or specified user doesn't get signed by parent nodes");
                }
                Loop += 1;
            }
        }
    }
}
