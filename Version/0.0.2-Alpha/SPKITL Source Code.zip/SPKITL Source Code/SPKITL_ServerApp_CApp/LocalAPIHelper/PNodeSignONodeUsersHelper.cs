﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using System.Runtime.InteropServices;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeSignONodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void SignAllONodeUsers() 
        {
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(30);
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            int Loop2 = 0;
            String[] EncryptedNodeUsersSignaturePrivateKeyPath = NCOperations.GetEncryptedUserPrivateKeysPath();
            String NodeUsersSignaturePrivateKeyRootDirectory = "/Project/SPKITL/User_SignaturePrivateKeys/";
            String[] NodeUsersIDs = new String[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean[] IsNodeUsersPublicKeyMatched = new Boolean[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            String NodeUserSignaturePublicKeyString = "";
            Byte[] NodeUserSignaturePrivateKeyBytes = new Byte[] { };
            Byte[] NodeUserSignaturePublicKeyBytes = new Byte[] { };
            List<String> ONodeUserIDs = new List<String>();
            List<String> ONodeIPAddresses = new List<String>();
            List<String> ONodeUserSignPKsString = new List<String>();
            List<String> ONodeUserAuthPKsString = new List<String>();
            Byte[] ONodeUserPKBytes = new Byte[] { };
            Byte[] SignedONodeUserPKBytes = new Byte[] { };
            String SignedONodeUserSignPKString = "";
            String SignedONodeUserAuthPKString = "";
            Boolean IsZero = true;
            IntPtr NodeUserSignaturePrivateKeyIntPtr = new IntPtr();
            while (Loop < NodeUsersIDs.Length) 
            {
                NodeUsersIDs[Loop] = EncryptedNodeUsersSignaturePrivateKeyPath[Loop].Remove(0, NodeUsersSignaturePrivateKeyRootDirectory.Length);
                NodeUsersIDs[Loop] = NodeUsersIDs[Loop].Remove(32, 15);
                Loop += 1;
            }
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Users`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read()) 
            {
                ONodeUserIDs.Add(DataReader.GetString("User_ID"));
                ONodeIPAddresses.Add(DataReader.GetString("IP_Address"));
                ONodeUserSignPKsString.Add(DataReader.GetString("Sign_PK"));
                ONodeUserAuthPKsString.Add(DataReader.GetString("Auth_PK"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            Loop = 0;
            while (Loop < NodeUsersIDs.Length) 
            {
                NodeUserSignaturePrivateKeyBytes = CCOperations.DecryptUserSignaturePrivateKey(EncryptedNodeUsersSignaturePrivateKeyPath[Loop]);
                if (NodeUserSignaturePrivateKeyBytes.Length == 64) 
                {
                    NodeUserSignaturePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, NodeUserSignaturePrivateKeyBytes.Length);
                    Marshal.Copy(NodeUserSignaturePrivateKeyBytes, 0, NodeUserSignaturePrivateKeyIntPtr, NodeUserSignaturePrivateKeyBytes.Length);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(NodeUserSignaturePrivateKeyIntPtr);
                    NodeUserSignaturePublicKeyBytes = SodiumPublicKeyAuth.GeneratePublicKey(NodeUserSignaturePrivateKeyIntPtr);
                }
                else 
                {
                    NodeUserSignaturePublicKeyBytes = SecureED448.GeneratePublicKey(NodeUserSignaturePrivateKeyBytes);
                }
                NodeUserSignaturePublicKeyString = Convert.ToBase64String(NodeUserSignaturePublicKeyBytes);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID AND `Sign_PK`=@Sign_PK";
                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = NodeUserSignaturePublicKeyString;
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    while (Loop2 < ONodeUserIDs.Count)
                    {
                        if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                        {
                            ONodeUserPKBytes = Convert.FromBase64String(ONodeUserSignPKsString[Loop2]);
                            SignedONodeUserPKBytes = SodiumPublicKeyAuth.Sign(ONodeUserPKBytes, NodeUserSignaturePrivateKeyIntPtr);
                            SignedONodeUserSignPKString = Convert.ToBase64String(SignedONodeUserPKBytes);
                            ONodeUserPKBytes = Convert.FromBase64String(ONodeUserAuthPKsString[Loop2]);
                            SignedONodeUserPKBytes = SodiumPublicKeyAuth.Sign(ONodeUserPKBytes, NodeUserSignaturePrivateKeyIntPtr);
                            SignedONodeUserAuthPKString = Convert.ToBase64String(SignedONodeUserPKBytes);
                        }
                        else
                        {
                            ONodeUserPKBytes = Convert.FromBase64String(ONodeUserSignPKsString[Loop2]);
                            SignedONodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, ONodeUserPKBytes, new Byte[] { });
                            SignedONodeUserSignPKString = Convert.ToBase64String(SignedONodeUserPKBytes);
                            ONodeUserPKBytes = Convert.FromBase64String(ONodeUserAuthPKsString[Loop2]);
                            SignedONodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, ONodeUserPKBytes, new Byte[] { });
                            SignedONodeUserAuthPKString = Convert.ToBase64String(SignedONodeUserPKBytes);
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONodeIPAddresses[Loop2];
                        MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUserIDs[Loop2];
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count == 0)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "INSERT INTO `ONode_Users_SBPNU_Log`(`ONode_IP_Address`, `ONode_User_ID`, `User_ID`, `Signed_Auth_PK`, `Signed_Sign_PK`, `Valid_DT`) VALUES (@ONode_IP_Address, @ONode_User_ID, @User_ID, @Signed_Auth_PK, @Signed_Sign_PK, @Valid_DT)";
                            MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONodeIPAddresses[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUserIDs[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedONodeUserAuthPKString;
                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedONodeUserSignPKString;
                            MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        //Do something in future
                        /*
                        else
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK";
                            MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONodeIPAddresses[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUserIDs[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedONodeUserAuthPKString;
                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedONodeUserSignPKString;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "UPDATE `ONode_Users_SBPNU_Log` SET `Signed_Auth_PK`=@Signed_Auth_PK, `Signed_Sign_PK`=@Signed_Sign_PK, `Valid_DT`=@Valid_DT WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONodeIPAddresses[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUserIDs[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedONodeUserAuthPKString;
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedONodeUserSignPKString;
                                MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                            }
                        }
                        */
                        Loop2 += 1;
                    }
                    IsNodeUsersPublicKeyMatched[Loop] = true;
                }
                else
                {
                    IsNodeUsersPublicKeyMatched[Loop] = false;
                }
                if (NodeUserSignaturePrivateKeyBytes.Length == 64) 
                {
                    SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(NodeUserSignaturePrivateKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_Free(NodeUserSignaturePrivateKeyIntPtr);
                }
                else 
                {
                    SodiumSecureMemory.SecureClearBytes(NodeUserSignaturePrivateKeyBytes);
                }
                Loop2 = 0;
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            Loop = 0;
            while (Loop < IsNodeUsersPublicKeyMatched.Length) 
            {
                if (IsNodeUsersPublicKeyMatched[Loop] == false) 
                {
                    throw new Exception("Error: Unable to proceed signing due to public keys mismatched..");
                }
                Loop += 1;
            }
        }
    }
}
