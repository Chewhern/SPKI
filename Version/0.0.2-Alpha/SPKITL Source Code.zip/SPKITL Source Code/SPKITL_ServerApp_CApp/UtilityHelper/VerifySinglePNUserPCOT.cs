﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKITL_ServerApp_CApp.APIHelper;
using SPKITL_ServerApp_CApp.DataModel;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.PostDataModel;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Web;

namespace SPKITL_ServerApp_CApp.UtilityHelper
{
    public static class VerifySinglePNUserPCOT
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void VerifyPCOTForSinglePNUser(String ONode_IP_Address, String PNode_User_ID)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String ONode_API_IP_Address = "";
            String CurrentNodeIPAddress = "";
            List<String> ONode_User_IDs = new List<String>();
            List<String> Signed_User_Auth_PKs = new List<String>();
            List<String> Signed_User_Sign_PKs = new List<String>();
            List<DateTime> SignedDates = new List<DateTime>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            ONode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            Byte[] Challenge = GetONodeChallenge.GetChallenge(ONode_API_IP_Address);
            if (Challenge.Length != 0)
            {
                Byte[] DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                Byte[] SignedChallenge = new Byte[] { };
                if (DecryptedNodePrivateKey.Length == 64)
                {
                    Boolean IsZero = true;
                    IntPtr DecryptedNodePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, DecryptedNodePrivateKey.Length);
                    Marshal.Copy(DecryptedNodePrivateKey, 0, DecryptedNodePrivateKeyIntPtr, DecryptedNodePrivateKey.Length);
                    SodiumSecureMemory.SecureClearBytes(DecryptedNodePrivateKey);
                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKeyIntPtr, true);
                }
                else
                {
                    SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                }
                String SignedChallengeB64 = Convert.ToBase64String(SignedChallenge);
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_User_ID`,`Signed_Auth_PK`,`Signed_Sign_PK`,`Valid_DT` FROM `Node_Users_SBONU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONode_IP_Address;
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = PNode_User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MyDataReader = MySQLGeneralQuery.ExecuteReader();
                while (MyDataReader.Read()) 
                {
                    ONode_User_IDs.Add(MyDataReader.GetString("ONode_User_ID"));
                    Signed_User_Auth_PKs.Add(MyDataReader.GetString("Signed_Auth_PK"));
                    Signed_User_Sign_PKs.Add(MyDataReader.GetString("Signed_Sign_PK"));
                    SignedDates.Add(MyDataReader.GetDateTime("Valid_DT"));
                }
                VerifyAuthorizedUserPartialCertificateModel MyModel = new VerifyAuthorizedUserPartialCertificateModel();
                MyModel.TNode_IP_Address = CurrentNodeIPAddress;
                MyModel.TNode_User_ID = PNode_User_ID;
                MyModel.SNode_User_IDs = ONode_User_IDs.ToArray();
                MyModel.Signed_TNode_User_Auth_PKs = Signed_User_Auth_PKs.ToArray();
                MyModel.Signed_TNode_User_Sign_PKs = Signed_User_Sign_PKs.ToArray();
                MyModel.SignedDateTimes = SignedDates.ToArray();
                MyModel.SignedChallenge = SignedChallengeB64;
                MyModel.RNode_IP_Address = "";
                String JSONBodyString = "";
                StringContent PostRequestData = new StringContent("");
                JSONBodyString = JsonConvert.SerializeObject(MyModel);
                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ONode_API_IP_Address);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.PostAsync("ONodeCertificateOps/", PostRequestData);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        if (Result.Contains("Error") == true) 
                        {
                            throw new Exception(Result);
                        }
                    }
                    else
                    {
                        throw new Exception("Error: Other Node encounter some issues");
                    }
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
