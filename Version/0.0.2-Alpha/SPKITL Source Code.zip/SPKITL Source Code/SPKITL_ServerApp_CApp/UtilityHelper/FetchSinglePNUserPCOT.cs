﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKITL_ServerApp_CApp.APIHelper;
using SPKITL_ServerApp_CApp.DataModel;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Web;

namespace SPKITL_ServerApp_CApp.UtilityHelper
{
    public static class FetchSinglePNUserPCOT
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void CreatePCOTForSinglePNUser(String ONode_IP_Address, String PNode_User_ID) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ONode_API_IP_Address = "";
            String CurrentNodeIPAddress = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            ONode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            Byte[] Challenge = GetONodeChallenge.GetChallenge(ONode_API_IP_Address);
            if (Challenge.Length != 0) 
            {
                Byte[] DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                Byte[] SignedChallenge = new Byte[] { };
                if (DecryptedNodePrivateKey.Length == 64)
                {
                    Boolean IsZero = true;
                    IntPtr DecryptedNodePrivateKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZero, DecryptedNodePrivateKey.Length);
                    Marshal.Copy(DecryptedNodePrivateKey, 0, DecryptedNodePrivateKeyIntPtr, DecryptedNodePrivateKey.Length);
                    SodiumSecureMemory.SecureClearBytes(DecryptedNodePrivateKey);
                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKeyIntPtr, true);
                }
                else
                {
                    SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                }
                String SignedChallengeB64 = Convert.ToBase64String(SignedChallenge);
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ONode_API_IP_Address);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.GetAsync("ONodeCertificateOps?IP_Address=" + HttpUtility.UrlEncode(CurrentNodeIPAddress) + "&SignedChallenge=" + HttpUtility.UrlEncode(SignedChallengeB64) + "&User_ID=" + PNode_User_ID);
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        AuthorizedUserPartialCertificateModel MyModel = new AuthorizedUserPartialCertificateModel();
                        MyModel = JsonConvert.DeserializeObject<AuthorizedUserPartialCertificateModel>(Result);
                        if (MyModel.Status.Contains("Error")==false) 
                        {
                            int Count = 0;
                            int Loop = 0;
                            while (Loop < MyModel.SNode_User_IDs.Length) 
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBONU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = MyModel.SNode_IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = MyModel.SNode_User_IDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyModel.TNode_User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                if (Count == 0) 
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "INSERT INTO `Node_Users_SBONU_Log`(`ONode_IP_Address`, `ONode_User_ID`, `User_ID`, `Signed_Auth_PK`, `Signed_Sign_PK`, `Valid_DT`) VALUES (@ONode_IP_Address,@ONode_User_ID,@User_ID,@Signed_Auth_PK,@Signed_Sign_PK,@Valid_DT)";
                                    MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = MyModel.SNode_IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = MyModel.SNode_User_IDs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyModel.TNode_User_ID;
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = MyModel.Signed_TNode_User_Auth_PKs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = MyModel.Signed_TNode_User_Sign_PKs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = MyModel.SignedDateTimes[Loop];
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                }
                                else 
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "UPDATE `Node_Users_SBONU_Log` SET `Signed_Auth_PK`=@Signed_Auth_PK,`Signed_Sign_PK`=@Signed_Sign_PK,`Valid_DT`=@Valid_DT WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = MyModel.SNode_IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = MyModel.SNode_User_IDs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyModel.TNode_User_ID;
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = MyModel.Signed_TNode_User_Auth_PKs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = MyModel.Signed_TNode_User_Sign_PKs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = MyModel.SignedDateTimes[Loop];
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                }
                                Loop += 1;
                            }
                        }
                        else 
                        {
                            throw new Exception(MyModel.Status);
                        }
                    }
                    else
                    {
                        throw new Exception("Error: Other Node encounter some issues");
                    }
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
