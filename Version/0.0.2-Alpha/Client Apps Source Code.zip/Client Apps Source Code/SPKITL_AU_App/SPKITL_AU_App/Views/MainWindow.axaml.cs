﻿using Avalonia.Controls;

namespace SPKITL_AU_App.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
