﻿namespace SPKITL_AU_App.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}
