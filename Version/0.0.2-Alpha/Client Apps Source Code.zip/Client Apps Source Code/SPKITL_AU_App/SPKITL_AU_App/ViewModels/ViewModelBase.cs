﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKITL_AU_App.ViewModels;

public class ViewModelBase : ObservableObject
{
}
