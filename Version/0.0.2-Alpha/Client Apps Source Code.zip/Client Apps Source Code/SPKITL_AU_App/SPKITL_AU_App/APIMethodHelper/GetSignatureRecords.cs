﻿using Org.BouncyCastle.Asn1.Cmp;
using SPKITL_AU_App.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SPKITL_AU_App.Model;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using System.IO;

namespace SPKITL_AU_App.APIMethodHelper
{
    public static class GetSignatureRecords
    {
        public static String StatusString = "";

        public static void GetSignedRecords(String User_ID,String SignedChallengeString,String Path) 
        {
            String TempString = "";
            String FinalResultString = "";
            int Loop = 0;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("PNodeCertificateOps/PNodeUserGetSignatureRecords?User_ID=" + User_ID + "&SignedChallenge="+HttpUtility.UrlEncode(SignedChallengeString));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    AuthorizedUserSignedRecordsModel MyModel = new AuthorizedUserSignedRecordsModel();
                    MyModel = JsonConvert.DeserializeObject<AuthorizedUserSignedRecordsModel>(Result);
                    if (MyModel.Status.Contains("Error") == false) 
                    {
                        while (Loop < MyModel.Signed_Auth_PKs.Length) 
                        {
                            TempString = MyModel.TNode_IP_Addresses[Loop] + ";" + MyModel.TNode_User_IDs[Loop] + ";"
                                + MyModel.Signed_Auth_PKs[Loop] + ";" + MyModel.Signed_Sign_PKs[Loop] + ";"
                                + MyModel.Signed_Dates[Loop].ToString();
                            if (Loop == MyModel.Signed_Auth_PKs.Length - 1) 
                            {
                                FinalResultString += TempString;
                            }
                            else 
                            {
                                FinalResultString += TempString + Environment.NewLine;
                            }
                            Loop += 1;
                        }
                        if (Directory.Exists(Path) == false)
                        {
                            Directory.CreateDirectory(Path);
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllText(Path + "\\SignedRecords.txt", FinalResultString);
                        }
                        else
                        {
                            File.WriteAllText(Path + "/SignedRecords.txt", FinalResultString);
                        }
                    }
                    StatusString = MyModel.Status;
                }
                else
                {
                    StatusString = "Error: Other Node encounter some issues";
                }
            }
        }
    }
}
