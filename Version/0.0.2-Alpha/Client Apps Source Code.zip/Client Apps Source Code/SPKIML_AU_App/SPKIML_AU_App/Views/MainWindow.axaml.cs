﻿using Avalonia.Controls;

namespace SPKIML_AU_App.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
