﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SPKIML_AU_App.Helper;
using SPKIML_AU_App.Model;
using System.IO;
using System.Runtime.InteropServices;

namespace SPKIML_AU_App.APIMethodHelper
{
    public static class GetAUFullCertHelper
    {
        public static String StatusString = "";

        public static void GetFullCert(String User_ID,String Path,Boolean IncludeSignerPK=true,Boolean IncludeSignerOOBPKAndContact=true) 
        {
            int Loop = 0;
            String TempString = "";
            String FinalResultString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("MasterNodeCertificateOps?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    AuthorizedUserFullCertificateModel MyModel = new AuthorizedUserFullCertificateModel();
                    String TempAPI_IP_Addresss = "";
                    MyModel = JsonConvert.DeserializeObject<AuthorizedUserFullCertificateModel>(Result);
                    if (MyModel.Status.Contains("Error") == false)
                    {
                        FinalResultString = MyModel.TNode_IP_Address + Environment.NewLine + MyModel.TNode_User_ID;
                        while (Loop < MyModel.SNode_IP_Addresses.Length) 
                        {
                            TempString = Environment.NewLine+MyModel.SNode_IP_Addresses[Loop] + ";" + MyModel.SNode_User_IDs[Loop] + ";"
                                + MyModel.Signed_TNode_User_Auth_PKs[Loop] + ";" + MyModel.Signed_TNode_User_Sign_PKs[Loop] + ";"
                                + MyModel.SignedDateTimes[Loop].ToString() + ";";
                            TempAPI_IP_Addresss = GetPNodeAPIIPAddressHelper.GetAPIIPAddress(MyModel.SNode_IP_Addresses[Loop]);
                            if (IncludeSignerPK == true) 
                            {
                                String ResultString = GetSignerUserPKHelper.GetSignerUserPK(MyModel.SNode_User_IDs[Loop],TempAPI_IP_Addresss);
                                if (ResultString.Contains("Error") == false) 
                                {
                                    TempString += ResultString + ";";
                                }
                            }
                            if (IncludeSignerOOBPKAndContact == true) 
                            {
                                String ResultString = GetSignerContactOOBPKHelper.GetSignerUserContactOOBPK(MyModel.SNode_User_IDs[Loop],TempAPI_IP_Addresss);
                                if (ResultString.Contains("Error") == false) 
                                {
                                    TempString += ResultString;
                                }
                            }
                            FinalResultString += TempString;
                            Loop += 1;
                        }
                        if (Directory.Exists(Path) == false)
                        {
                            Directory.CreateDirectory(Path);
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                        {
                            File.WriteAllText(Path + "\\BasicTLCert.txt", FinalResultString);
                        }
                        else 
                        {
                            File.WriteAllText(Path + "/BasicTLCert.txt", FinalResultString);
                        }
                    }
                    StatusString = MyModel.Status;
                }
                else
                {
                    StatusString= "Error: Parent node encounter some issues";
                }
            }
        }
    }
}
