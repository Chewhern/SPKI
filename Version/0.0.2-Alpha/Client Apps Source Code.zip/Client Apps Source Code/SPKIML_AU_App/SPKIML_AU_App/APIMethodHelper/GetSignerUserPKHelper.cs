﻿using Newtonsoft.Json;
using SPKIML_AU_App.Helper;
using SPKIML_AU_App.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SPKIML_AU_App.APIMethodHelper
{
    public static class GetSignerUserPKHelper
    {
        public static String GetSignerUserPK(String User_ID,String API_IP_Address) 
        {
            String ResultString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetNodeUserSignPK?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    ResultString = Result.Substring(1, Result.Length - 2);
                }
                else
                {
                    ResultString = "Error: Other Node encounter some issues";
                }
            }
            return ResultString;
        }
    }
}
