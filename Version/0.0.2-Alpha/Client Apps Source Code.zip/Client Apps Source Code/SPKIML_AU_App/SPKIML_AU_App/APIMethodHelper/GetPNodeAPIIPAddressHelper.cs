﻿using Newtonsoft.Json;
using SPKIML_AU_App.Helper;
using SPKIML_AU_App.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIML_AU_App.APIMethodHelper
{
    public static class GetPNodeAPIIPAddressHelper
    {
        public static String GetAPIIPAddress(String IP_Address) 
        {
            String API_IP_Address = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("MasterNodeCertificateOps/UserHelper?IP_Address=" + HttpUtility.UrlEncode(IP_Address));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    API_IP_Address = Result.Substring(1, Result.Length - 2);
                }
            }
            return API_IP_Address;
        }
    }
}
