﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKIML_AU_App.ViewModels;

public class ViewModelBase : ObservableObject
{
}
