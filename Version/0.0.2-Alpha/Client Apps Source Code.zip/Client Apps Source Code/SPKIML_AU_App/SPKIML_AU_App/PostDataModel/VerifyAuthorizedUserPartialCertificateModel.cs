﻿using System;
namespace SPKIML_AU_App.PostDataModel
{
    public class VerifyAuthorizedUserPartialCertificateModel
    {
        public String SignedChallenge { get; set; }

        public String RNode_IP_Address { get; set; }

        public String TNode_IP_Address { get; set; }

        public String[] SNode_User_IDs { get; set; }

        public String TNode_User_ID { get; set; }

        public String[] Signed_TNode_User_Auth_PKs { get; set; }

        public String[] Signed_TNode_User_Sign_PKs { get; set; }

        public DateTime[] SignedDateTimes { get; set; }
    }
}
