﻿using Avalonia.Controls;

namespace SPKIML_EU_App.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
