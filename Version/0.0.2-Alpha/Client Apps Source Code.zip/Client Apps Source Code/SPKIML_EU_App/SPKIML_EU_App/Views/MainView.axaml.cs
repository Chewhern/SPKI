﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using SPKIML_EU_App.APIHelper;
using SPKIML_EU_App.APIMethodHelper;
using SPKIML_EU_App.Helper;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace SPKIML_EU_App.Views;

public partial class MainView : UserControl
{
    private static int COTOpsAppUIChooser = 0;
    private static int RegistrationAppUIChooser = 0;
    private static int OOBOpsAppUIChooser = 0;
    private static TextBlock[] FirstCOTOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstCOTOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstCOTOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondCOTOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondCOTOpsAppTextBoxArray = new TextBox[] { };
    private static CheckBox[] SecondCOTOpsAppCheckBoxArray = new CheckBox[] { };
    private static Button[] SecondCOTOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdCOTOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdCOTOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] ThirdCOTOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] ThirdCOTOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FirstRegistrationAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstRegistrationAppTextBoxArray = new TextBox[] { };
    private static RadioButton[] FirstRegistrationAppRadioButtonArray = new RadioButton[] { };
    private static Button[] FirstRegistrationAppButtonArray = new Button[] { };
    private static TextBlock[] SecondRegistrationAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondRegistrationAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondRegistrationAppComboBoxArray = new ComboBox[] { };
    private static Button[] SecondRegistrationAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdRegistrationAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdRegistrationAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] ThirdRegistrationAppComboBoxArray = new ComboBox[] { };
    private static RadioButton[] ThirdRegistrationAppRadioButtonArray = new RadioButton[] { };
    private static Button[] ThirdRegistrationAppButtonArray = new Button[] { };
    private static TextBlock[] FirstOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstOOBOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstOOBOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondOOBOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondOOBOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] SecondOOBOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdOOBOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdOOBOpsAppButtonArray = new Button[] { };
    private static String COTOpsAppRootFolder = "";
    private static String COTOpsAppServerRootFolder = "";
    private static String COTOpsAppCertificateFolder = "";
    private static String COTOpsAppSignedRecordsFolder = "";
    private static String COTOpsAppONodeUserCertificateFolder = "";
    private static String RegistrationAppRootFolder = "";
    private static String OOBOpsAppRootFolder = "";
    private static String EncryptedKeysFolder = "";
    private static Boolean HasCOTOpsAppUIRendered = false;
    private static Boolean HasRegistrationAppUIRendered = false;
    private static Boolean HasOOBOpsAppUIRendered = false;


    public MainView()
    {
        InitializeComponent();
        COTOpsAppInitialization();
        RegistrationAppInitialization();
        OOBOpsAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            COTOpsAppRootFolder = AppContext.BaseDirectory + "\\Certificate\\";
            COTOpsAppServerRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
            COTOpsAppCertificateFolder = AppContext.BaseDirectory + "\\AU_Cert\\";
            COTOpsAppSignedRecordsFolder = AppContext.BaseDirectory + "\\SignedRecords\\";
            COTOpsAppONodeUserCertificateFolder = AppContext.BaseDirectory + "\\OAU_Cert\\";
            RegistrationAppRootFolder = AppContext.BaseDirectory + "\\Users\\";
            OOBOpsAppRootFolder = AppContext.BaseDirectory + "\\OOB\\";
            EncryptedKeysFolder = AppContext.BaseDirectory + "\\Encrypted_Keys\\";
        }
        else
        {
            COTOpsAppRootFolder = AppContext.BaseDirectory + "/Certificate/";
            COTOpsAppServerRootFolder = AppContext.BaseDirectory + "/ServerIP/";
            COTOpsAppCertificateFolder = AppContext.BaseDirectory + "/AU_Cert/";
            COTOpsAppSignedRecordsFolder = AppContext.BaseDirectory + "/SignedRecords/";
            COTOpsAppONodeUserCertificateFolder = AppContext.BaseDirectory + "/OAU_Cert/";
            RegistrationAppRootFolder = AppContext.BaseDirectory + "/Users/";
            OOBOpsAppRootFolder = AppContext.BaseDirectory + "/OOB/";
            EncryptedKeysFolder = AppContext.BaseDirectory + "/Encrypted_Keys/";
        }
        if (Directory.Exists(COTOpsAppRootFolder) == false)
        {
            Directory.CreateDirectory(COTOpsAppRootFolder);
        }
        if (Directory.Exists(COTOpsAppServerRootFolder) == false)
        {
            Directory.CreateDirectory(COTOpsAppServerRootFolder);
        }
        if (Directory.Exists(COTOpsAppCertificateFolder) == false)
        {
            Directory.CreateDirectory(COTOpsAppCertificateFolder);
        }
        if (Directory.Exists(COTOpsAppSignedRecordsFolder) == false)
        {
            Directory.CreateDirectory(COTOpsAppSignedRecordsFolder);
        }
        if (Directory.Exists(COTOpsAppONodeUserCertificateFolder) == false)
        {
            Directory.CreateDirectory(COTOpsAppONodeUserCertificateFolder);
        }
        if (Directory.Exists(RegistrationAppRootFolder) == false)
        {
            Directory.CreateDirectory(RegistrationAppRootFolder);
        }
        if (Directory.Exists(OOBOpsAppRootFolder) == false)
        {
            Directory.CreateDirectory(OOBOpsAppRootFolder);
        }
        if (Directory.Exists(EncryptedKeysFolder) == false)
        {
            Directory.CreateDirectory(EncryptedKeysFolder);
        }
        StartupFunction();
    }

    private void StartupFunction()
    {
        if (Directory.Exists(COTOpsAppServerRootFolder) == true)
        {
            if (File.Exists(COTOpsAppServerRootFolder + "IP.txt") == true)
            {
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
    }

    private void COTOpsAppInitialization()
    {
        COTOpsAppUIChooser = 0;
        COTOpsAppToggleBTN1.IsCheckedChanged += COTOpsAppToggleBTNSFunction;
        COTOpsAppToggleBTN2.IsCheckedChanged += COTOpsAppToggleBTNSFunction;
        COTOpsAppToggleBTN3.IsCheckedChanged += COTOpsAppToggleBTNSFunction;
    }

    private void RegistrationAppInitialization()
    {
        RegistrationAppUIChooser = 0;
        RegistrationAppToggleBTN1.IsCheckedChanged += RegistrationAppToggleBTNSFunction;
        RegistrationAppToggleBTN2.IsCheckedChanged += RegistrationAppToggleBTNSFunction;
        RegistrationAppToggleBTN3.IsCheckedChanged += RegistrationAppToggleBTNSFunction;
    }

    private void OOBOpsAppInitialization()
    {
        OOBOpsAppUIChooser = 0;
        OOBOpsAppToggleBTN1.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN2.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN3.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
    }

    private void COTOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (COTOpsAppToggleBTN1.IsChecked == true)
        {
            COTOpsAppToggleBTN2.IsChecked = false;
            COTOpsAppToggleBTN3.IsChecked = false;
            COTOpsAppUIChooser = 1;
        }
        else if (COTOpsAppToggleBTN2.IsChecked == true)
        {
            COTOpsAppToggleBTN1.IsChecked = false;
            COTOpsAppToggleBTN3.IsChecked = false;
            COTOpsAppUIChooser = 2;
        }
        else if (COTOpsAppToggleBTN3.IsChecked == true)
        {
            COTOpsAppToggleBTN2.IsChecked = false;
            COTOpsAppToggleBTN1.IsChecked = false;
            COTOpsAppUIChooser = 3;
        }
        else
        {
            ResetCOTOpsAppUI();
        }
        COTOpsAppDrawUI();
    }

    private void RegistrationAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (RegistrationAppToggleBTN1.IsChecked == true)
        {
            RegistrationAppToggleBTN2.IsChecked = false;
            RegistrationAppToggleBTN3.IsChecked = false;
            RegistrationAppUIChooser = 1;
        }
        else if (RegistrationAppToggleBTN2.IsChecked == true)
        {
            RegistrationAppToggleBTN1.IsChecked = false;
            RegistrationAppToggleBTN3.IsChecked = false;
            RegistrationAppUIChooser = 2;
        }
        else if (RegistrationAppToggleBTN3.IsChecked == true)
        {
            RegistrationAppToggleBTN2.IsChecked = false;
            RegistrationAppToggleBTN1.IsChecked = false;
            RegistrationAppUIChooser = 3;
        }
        else
        {
            ResetRegistrationAppUI();
        }
        RegistrationAppDrawUI();
    }

    private void OOBOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (OOBOpsAppToggleBTN1.IsChecked == true)
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsAppUIChooser = 1;
        }
        else if (OOBOpsAppToggleBTN2.IsChecked == true)
        {
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsAppUIChooser = 2;
        }
        else if (OOBOpsAppToggleBTN3.IsChecked == true)
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppUIChooser = 3;
        }
        else
        {
            ResetOOBOpsAppUI();
        }
        OOBOpsAppDrawUI();
    }

    private void COTOpsAppDrawUI()
    {
        if (COTOpsAppUIChooser == 1)
        {
            if (HasCOTOpsAppUIRendered == false)
            {
                FirstCOTOpsAppTextBlockArray = new TextBlock[2];
                FirstCOTOpsAppTextBlockArray[0] = new TextBlock();
                FirstCOTOpsAppTextBlockArray[1] = new TextBlock();
                FirstCOTOpsAppTextBlockArray[0].Text = "Server API IP address of SPKIML?";
                FirstCOTOpsAppTextBlockArray[1].Text = "Server IP address status (Read Only)";
                FirstCOTOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCOTOpsAppTextBoxArray = new TextBox[2];
                FirstCOTOpsAppTextBoxArray[0] = new TextBox();
                FirstCOTOpsAppTextBoxArray[1] = new TextBox();
                FirstCOTOpsAppTextBoxArray[0].Height = 125;
                FirstCOTOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstCOTOpsAppTextBoxArray[0].Width = 250;
                FirstCOTOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstCOTOpsAppTextBoxArray[1].Height = 125;
                FirstCOTOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstCOTOpsAppTextBoxArray[1].Width = 250;
                FirstCOTOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstCOTOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstCOTOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstCOTOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstCOTOpsAppButtonArray = new Button[1];
                FirstCOTOpsAppButtonArray[0] = new Button();
                FirstCOTOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCOTOpsAppButtonArray[0].Content = "Add and establish a connection";
                FirstCOTOpsAppButtonArray[0].Click += COTOpsAppBTN_Click;
                COTOpsAppLowerRightLPSP.Children.Add(FirstCOTOpsAppTextBlockArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(FirstCOTOpsAppTextBoxArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(FirstCOTOpsAppTextBlockArray[1]);
                COTOpsAppLowerRightLPSP.Children.Add(FirstCOTOpsAppTextBoxArray[1]);
                COTOpsAppLowerRightLPSP.Children.Add(FirstCOTOpsAppButtonArray[0]);
                HasCOTOpsAppUIRendered = true;
            }
        }
        else if (COTOpsAppUIChooser == 2)
        {
            if (HasCOTOpsAppUIRendered == false)
            {
                SecondCOTOpsAppTextBlockArray = new TextBlock[4];
                SecondCOTOpsAppTextBlockArray[0] = new TextBlock();
                SecondCOTOpsAppTextBlockArray[1] = new TextBlock();
                SecondCOTOpsAppTextBlockArray[2] = new TextBlock();
                SecondCOTOpsAppTextBlockArray[3] = new TextBlock();
                SecondCOTOpsAppTextBlockArray[0].Text = "User ID?";
                SecondCOTOpsAppTextBlockArray[1].Text = "Include signer pk?";
                SecondCOTOpsAppTextBlockArray[2].Text = "Include signer oob pk and contact?";
                SecondCOTOpsAppTextBlockArray[3].Text = "Status (Read Only)";
                SecondCOTOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCOTOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCOTOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCOTOpsAppTextBoxArray = new TextBox[2];
                SecondCOTOpsAppTextBoxArray[0] = new TextBox();
                SecondCOTOpsAppTextBoxArray[1] = new TextBox();
                SecondCOTOpsAppTextBoxArray[0].Height = 125;
                SecondCOTOpsAppTextBoxArray[1].Height = 125;
                SecondCOTOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondCOTOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondCOTOpsAppTextBoxArray[0].Width = 250;
                SecondCOTOpsAppTextBoxArray[1].Width = 250;
                SecondCOTOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondCOTOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondCOTOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondCOTOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondCOTOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondCOTOpsAppCheckBoxArray = new CheckBox[2];
                SecondCOTOpsAppCheckBoxArray[0] = new CheckBox();
                SecondCOTOpsAppCheckBoxArray[1] = new CheckBox();
                SecondCOTOpsAppCheckBoxArray[0].Content = "Yes/No";
                SecondCOTOpsAppCheckBoxArray[1].Content = "Yes/No";
                SecondCOTOpsAppCheckBoxArray[0].IsChecked = true;
                SecondCOTOpsAppCheckBoxArray[1].IsChecked = true;
                SecondCOTOpsAppButtonArray = new Button[1];
                SecondCOTOpsAppButtonArray[0] = new Button();
                SecondCOTOpsAppButtonArray[0].Content = "Fetch Certificate";
                SecondCOTOpsAppButtonArray[0].Click += COTOpsAppBTN_Click;
                SecondCOTOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppTextBlockArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppTextBoxArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppTextBlockArray[1]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppCheckBoxArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppTextBlockArray[2]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppCheckBoxArray[1]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppTextBlockArray[3]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppTextBoxArray[1]);
                COTOpsAppLowerRightLPSP.Children.Add(SecondCOTOpsAppButtonArray[0]);
                HasCOTOpsAppUIRendered = true;
            }
        }
        else if (COTOpsAppUIChooser == 3)
        {
            if (HasCOTOpsAppUIRendered == false)
            {
                ThirdCOTOpsAppTextBlockArray = new TextBlock[1];
                ThirdCOTOpsAppTextBlockArray[0] = new TextBlock();
                ThirdCOTOpsAppTextBlockArray[0].Text = "Server Status (Read Only)";
                ThirdCOTOpsAppTextBoxArray = new TextBox[1];
                ThirdCOTOpsAppTextBoxArray[0] = new TextBox();
                ThirdCOTOpsAppTextBoxArray[0].IsReadOnly = true;
                ThirdCOTOpsAppTextBoxArray[0].Width = 250;
                ThirdCOTOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdCOTOpsAppTextBoxArray[0].Height = 125;
                ThirdCOTOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdCOTOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdCOTOpsAppButtonArray = new Button[1];
                ThirdCOTOpsAppButtonArray[0] = new Button();
                ThirdCOTOpsAppButtonArray[0].Content = "Verify Certificate";
                ThirdCOTOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdCOTOpsAppButtonArray[0].Click += COTOpsAppBTN_Click;
                COTOpsAppLowerRightLPSP.Children.Add(ThirdCOTOpsAppTextBlockArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(ThirdCOTOpsAppTextBoxArray[0]);
                COTOpsAppLowerRightLPSP.Children.Add(ThirdCOTOpsAppButtonArray[0]);
                HasCOTOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetCOTOpsAppUI();
        }
    }

    private void RegistrationAppDrawUI()
    {
        if (RegistrationAppUIChooser == 1)
        {
            if (HasRegistrationAppUIRendered == false)
            {
                FirstRegistrationAppTextBlockArray = new TextBlock[8];
                FirstRegistrationAppTextBlockArray[0] = new TextBlock();
                FirstRegistrationAppTextBlockArray[1] = new TextBlock();
                FirstRegistrationAppTextBlockArray[2] = new TextBlock();
                FirstRegistrationAppTextBlockArray[3] = new TextBlock();
                FirstRegistrationAppTextBlockArray[4] = new TextBlock();
                FirstRegistrationAppTextBlockArray[5] = new TextBlock();
                FirstRegistrationAppTextBlockArray[6] = new TextBlock();
                FirstRegistrationAppTextBlockArray[7] = new TextBlock();
                FirstRegistrationAppTextBlockArray[0].Text = "User ID (Read Only)";
                FirstRegistrationAppTextBlockArray[1].Text = "Contact";
                FirstRegistrationAppTextBlockArray[2].Text = "Auth PK (Read Only)";
                FirstRegistrationAppTextBlockArray[3].Text = "Sign PK (Read Only)";
                FirstRegistrationAppTextBlockArray[4].Text = "OOB PK (Read Only)";
                FirstRegistrationAppTextBlockArray[5].Text = "ASPK DT (Read Only)";
                FirstRegistrationAppTextBlockArray[6].Text = "What's the DSA?";
                FirstRegistrationAppTextBlockArray[7].Text = "Server Status (Read Only)";
                FirstRegistrationAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBoxArray = new TextBox[7];
                FirstRegistrationAppTextBoxArray[0] = new TextBox();
                FirstRegistrationAppTextBoxArray[1] = new TextBox();
                FirstRegistrationAppTextBoxArray[2] = new TextBox();
                FirstRegistrationAppTextBoxArray[3] = new TextBox();
                FirstRegistrationAppTextBoxArray[4] = new TextBox();
                FirstRegistrationAppTextBoxArray[5] = new TextBox();
                FirstRegistrationAppTextBoxArray[6] = new TextBox();
                FirstRegistrationAppTextBoxArray[0].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[2].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[3].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[4].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[5].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[6].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[0].Width = 250;
                FirstRegistrationAppTextBoxArray[0].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[1].Width = 250;
                FirstRegistrationAppTextBoxArray[1].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[2].Width = 250;
                FirstRegistrationAppTextBoxArray[2].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[3].Width = 250;
                FirstRegistrationAppTextBoxArray[3].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[4].Width = 250;
                FirstRegistrationAppTextBoxArray[4].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[5].Width = 250;
                FirstRegistrationAppTextBoxArray[5].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[6].Width = 250;
                FirstRegistrationAppTextBoxArray[6].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[0].Height = 125;
                FirstRegistrationAppTextBoxArray[0].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[1].Height = 125;
                FirstRegistrationAppTextBoxArray[1].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[2].Height = 125;
                FirstRegistrationAppTextBoxArray[2].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[3].Height = 125;
                FirstRegistrationAppTextBoxArray[3].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[4].Height = 125;
                FirstRegistrationAppTextBoxArray[4].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[5].Height = 125;
                FirstRegistrationAppTextBoxArray[5].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[6].Height = 125;
                FirstRegistrationAppTextBoxArray[6].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppRadioButtonArray = new RadioButton[2];
                FirstRegistrationAppRadioButtonArray[0] = new RadioButton();
                FirstRegistrationAppRadioButtonArray[1] = new RadioButton();
                FirstRegistrationAppRadioButtonArray[0].GroupName = "CurveTypes";
                FirstRegistrationAppRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                FirstRegistrationAppRadioButtonArray[0].IsChecked = true;
                FirstRegistrationAppRadioButtonArray[1].GroupName = "CurveTypes";
                FirstRegistrationAppRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                FirstRegistrationAppButtonArray = new Button[1];
                FirstRegistrationAppButtonArray[0] = new Button();
                FirstRegistrationAppButtonArray[0].Content = "Register Account";
                FirstRegistrationAppButtonArray[0].Click += RegistrationAppBTN_Click;
                FirstRegistrationAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[0]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[0]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[1]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[1]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[2]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[2]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[3]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[3]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[4]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[4]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[5]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[5]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[6]);
                MyStackPanel.Children.Add(FirstRegistrationAppRadioButtonArray[0]);
                MyStackPanel.Children.Add(FirstRegistrationAppRadioButtonArray[1]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[7]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[6]);
                MyStackPanel.Children.Add(FirstRegistrationAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                RegistrationAppLowerRightSP.Children.Add(MyScrollViewer);
                HasRegistrationAppUIRendered = true;
            }
        }
        else if (RegistrationAppUIChooser == 2)
        {
            if (HasRegistrationAppUIRendered == false)
            {
                SecondRegistrationAppTextBlockArray = new TextBlock[8];
                SecondRegistrationAppTextBlockArray[0] = new TextBlock();
                SecondRegistrationAppTextBlockArray[1] = new TextBlock();
                SecondRegistrationAppTextBlockArray[2] = new TextBlock();
                SecondRegistrationAppTextBlockArray[3] = new TextBlock();
                SecondRegistrationAppTextBlockArray[4] = new TextBlock();
                SecondRegistrationAppTextBlockArray[5] = new TextBlock();
                SecondRegistrationAppTextBlockArray[6] = new TextBlock();
                SecondRegistrationAppTextBlockArray[7] = new TextBlock();
                SecondRegistrationAppTextBlockArray[0].Text = "User ID?";
                SecondRegistrationAppTextBlockArray[1].Text = "User ID (Read Only)";
                SecondRegistrationAppTextBlockArray[2].Text = "Contact";
                SecondRegistrationAppTextBlockArray[3].Text = "Auth PK (Read Only)";
                SecondRegistrationAppTextBlockArray[4].Text = "Sign PK (Read Only)";
                SecondRegistrationAppTextBlockArray[5].Text = "OOB PK (Read Only)";
                SecondRegistrationAppTextBlockArray[6].Text = "ASPK DT (Read Only)";
                SecondRegistrationAppTextBlockArray[7].Text = "What's the DSA?";
                SecondRegistrationAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppTextBoxArray = new TextBox[7];
                SecondRegistrationAppTextBoxArray[0] = new TextBox();
                SecondRegistrationAppTextBoxArray[1] = new TextBox();
                SecondRegistrationAppTextBoxArray[2] = new TextBox();
                SecondRegistrationAppTextBoxArray[3] = new TextBox();
                SecondRegistrationAppTextBoxArray[4] = new TextBox();
                SecondRegistrationAppTextBoxArray[5] = new TextBox();
                SecondRegistrationAppTextBoxArray[6] = new TextBox();
                SecondRegistrationAppTextBoxArray[0].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[1].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[2].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[3].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[4].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[5].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[6].IsReadOnly = true;
                SecondRegistrationAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                SecondRegistrationAppTextBoxArray[0].Width = 250;
                SecondRegistrationAppTextBoxArray[0].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[0].Height = 125;
                SecondRegistrationAppTextBoxArray[0].MaxHeight = 125;
                SecondRegistrationAppTextBoxArray[1].Width = 250;
                SecondRegistrationAppTextBoxArray[1].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[1].Height = 125;
                SecondRegistrationAppTextBoxArray[1].MaxHeight = 125;
                SecondRegistrationAppTextBoxArray[2].Width = 250;
                SecondRegistrationAppTextBoxArray[2].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[2].Height = 125;
                SecondRegistrationAppTextBoxArray[2].MaxHeight = 125;
                SecondRegistrationAppTextBoxArray[3].Width = 250;
                SecondRegistrationAppTextBoxArray[3].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[3].Height = 125;
                SecondRegistrationAppTextBoxArray[3].MaxHeight = 125;
                SecondRegistrationAppTextBoxArray[4].Width = 250;
                SecondRegistrationAppTextBoxArray[4].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[4].Height = 125;
                SecondRegistrationAppTextBoxArray[4].MaxHeight = 125;
                SecondRegistrationAppTextBoxArray[5].Width = 250;
                SecondRegistrationAppTextBoxArray[5].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[5].Height = 125;
                SecondRegistrationAppTextBoxArray[5].MaxHeight = 125;
                SecondRegistrationAppTextBoxArray[6].Width = 250;
                SecondRegistrationAppTextBoxArray[6].MaxWidth = 250;
                SecondRegistrationAppTextBoxArray[6].Height = 125;
                SecondRegistrationAppTextBoxArray[6].MaxHeight = 125;
                SecondRegistrationAppComboBoxArray = new ComboBox[1];
                SecondRegistrationAppComboBoxArray[0] = new ComboBox();
                SecondRegistrationAppComboBoxArray[0].MaxWidth = 250;
                RegistrationAppLoadUserIDs();
                SecondRegistrationAppComboBoxArray[0].SelectionChanged += RegistrationAppComboBoxSelectedItemsChanged;
                SecondRegistrationAppButtonArray = new Button[1];
                SecondRegistrationAppButtonArray[0] = new Button();
                SecondRegistrationAppButtonArray[0].Content = "Get Info";
                SecondRegistrationAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondRegistrationAppButtonArray[0].Click += RegistrationAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[0]);
                MyStackPanel.Children.Add(SecondRegistrationAppComboBoxArray[0]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[1]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[0]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[2]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[1]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[3]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[2]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[4]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[3]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[5]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[4]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[6]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[5]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBlockArray[7]);
                MyStackPanel.Children.Add(SecondRegistrationAppTextBoxArray[6]);
                MyStackPanel.Children.Add(SecondRegistrationAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                RegistrationAppLowerRightSP.Children.Add(MyScrollViewer);
                HasRegistrationAppUIRendered = true;
            }
        }
        else if (RegistrationAppUIChooser == 3)
        {
            if (HasRegistrationAppUIRendered == false)
            {
                ThirdRegistrationAppTextBlockArray = new TextBlock[11];
                ThirdRegistrationAppTextBlockArray[0] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[1] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[2] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[3] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[4] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[5] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[6] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[7] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[8] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[9] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[10] = new TextBlock();
                ThirdRegistrationAppTextBlockArray[0].Text = "User ID?";
                ThirdRegistrationAppTextBlockArray[1].Text = "User ID (Read Only)";
                ThirdRegistrationAppTextBlockArray[2].Text = "Contact";
                ThirdRegistrationAppTextBlockArray[3].Text = "Auth PK (Read Only)";
                ThirdRegistrationAppTextBlockArray[4].Text = "Sign PK (Read Only)";
                ThirdRegistrationAppTextBlockArray[5].Text = "OOB PK (Read Only)";
                ThirdRegistrationAppTextBlockArray[6].Text = "ASPK DT (Read Only)";
                ThirdRegistrationAppTextBlockArray[7].Text = "What's the DSA?";
                ThirdRegistrationAppTextBlockArray[8].Text = "Server Status (Read Only)";
                ThirdRegistrationAppTextBlockArray[9].Text = "If certificate exist, only";
                ThirdRegistrationAppTextBlockArray[10].Text = "change OOBPK and contact";
                ThirdRegistrationAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[8].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[9].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBlockArray[10].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppTextBoxArray = new TextBox[7];
                ThirdRegistrationAppTextBoxArray[0] = new TextBox();
                ThirdRegistrationAppTextBoxArray[1] = new TextBox();
                ThirdRegistrationAppTextBoxArray[2] = new TextBox();
                ThirdRegistrationAppTextBoxArray[3] = new TextBox();
                ThirdRegistrationAppTextBoxArray[4] = new TextBox();
                ThirdRegistrationAppTextBoxArray[5] = new TextBox();
                ThirdRegistrationAppTextBoxArray[6] = new TextBox();
                ThirdRegistrationAppTextBoxArray[0].IsReadOnly = true;
                ThirdRegistrationAppTextBoxArray[2].IsReadOnly = true;
                ThirdRegistrationAppTextBoxArray[3].IsReadOnly = true;
                ThirdRegistrationAppTextBoxArray[4].IsReadOnly = true;
                ThirdRegistrationAppTextBoxArray[5].IsReadOnly = true;
                ThirdRegistrationAppTextBoxArray[6].IsReadOnly = true;
                ThirdRegistrationAppTextBoxArray[0].Width = 250;
                ThirdRegistrationAppTextBoxArray[0].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[0].Height = 125;
                ThirdRegistrationAppTextBoxArray[0].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[1].Width = 250;
                ThirdRegistrationAppTextBoxArray[1].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[1].Height = 125;
                ThirdRegistrationAppTextBoxArray[1].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[2].Width = 250;
                ThirdRegistrationAppTextBoxArray[2].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[2].Height = 125;
                ThirdRegistrationAppTextBoxArray[2].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[3].Width = 250;
                ThirdRegistrationAppTextBoxArray[3].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[3].Height = 125;
                ThirdRegistrationAppTextBoxArray[3].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[4].Width = 250;
                ThirdRegistrationAppTextBoxArray[4].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[4].Height = 125;
                ThirdRegistrationAppTextBoxArray[4].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[5].Width = 250;
                ThirdRegistrationAppTextBoxArray[5].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[5].Height = 125;
                ThirdRegistrationAppTextBoxArray[5].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[6].Width = 250;
                ThirdRegistrationAppTextBoxArray[6].MaxWidth = 250;
                ThirdRegistrationAppTextBoxArray[6].Height = 125;
                ThirdRegistrationAppTextBoxArray[6].MaxHeight = 125;
                ThirdRegistrationAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                ThirdRegistrationAppComboBoxArray = new ComboBox[1];
                ThirdRegistrationAppComboBoxArray[0] = new ComboBox();
                ThirdRegistrationAppComboBoxArray[0].MaxWidth = 250;
                RegistrationAppLoadUserIDs();
                ThirdRegistrationAppComboBoxArray[0].SelectionChanged += RegistrationAppComboBoxSelectedItemsChanged;
                ThirdRegistrationAppRadioButtonArray = new RadioButton[2];
                ThirdRegistrationAppRadioButtonArray[0] = new RadioButton();
                ThirdRegistrationAppRadioButtonArray[1] = new RadioButton();
                ThirdRegistrationAppRadioButtonArray[0].GroupName = "CurveTypes";
                ThirdRegistrationAppRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                ThirdRegistrationAppRadioButtonArray[0].IsChecked = true;
                ThirdRegistrationAppRadioButtonArray[1].GroupName = "CurveTypes";
                ThirdRegistrationAppRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                ThirdRegistrationAppButtonArray = new Button[1];
                ThirdRegistrationAppButtonArray[0] = new Button();
                ThirdRegistrationAppButtonArray[0].Content = "Change Info";
                ThirdRegistrationAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdRegistrationAppButtonArray[0].Click += RegistrationAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[0]);
                MyStackPanel.Children.Add(ThirdRegistrationAppComboBoxArray[0]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[1]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[0]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[2]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[1]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[3]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[2]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[4]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[3]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[5]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[4]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[6]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[5]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[7]);
                MyStackPanel.Children.Add(ThirdRegistrationAppRadioButtonArray[0]);
                MyStackPanel.Children.Add(ThirdRegistrationAppRadioButtonArray[1]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[8]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBoxArray[6]);
                MyStackPanel.Children.Add(ThirdRegistrationAppButtonArray[0]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[9]);
                MyStackPanel.Children.Add(ThirdRegistrationAppTextBlockArray[10]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                RegistrationAppLowerRightSP.Children.Add(MyScrollViewer);
                HasRegistrationAppUIRendered = true;
            }
        }
        else
        {
            ResetRegistrationAppUI();
        }
    }

    private void OOBOpsAppDrawUI()
    {
        if (OOBOpsAppUIChooser == 1)
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                FirstOOBOpsAppTextBlockArray = new TextBlock[2];
                FirstOOBOpsAppTextBlockArray[0] = new TextBlock();
                FirstOOBOpsAppTextBlockArray[1] = new TextBlock();
                FirstOOBOpsAppTextBlockArray[0].Text = "Challenge Bytes? (>=16 bytes)";
                FirstOOBOpsAppTextBlockArray[1].Text = "Generated Challenge (Base64)";
                FirstOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsAppTextBoxArray = new TextBox[2];
                FirstOOBOpsAppTextBoxArray[0] = new TextBox();
                FirstOOBOpsAppTextBoxArray[1] = new TextBox();
                FirstOOBOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstOOBOpsAppTextBoxArray[0].Width = 250;
                FirstOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstOOBOpsAppTextBoxArray[0].Height = 125;
                FirstOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsAppTextBoxArray[1].Width = 250;
                FirstOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstOOBOpsAppTextBoxArray[1].Height = 125;
                FirstOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsButtonArray = new Button[1];
                FirstOOBOpsButtonArray[0] = new Button();
                FirstOOBOpsButtonArray[0].Content = "Generate Challenge";
                FirstOOBOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else if (OOBOpsAppUIChooser == 2)
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                SecondOOBOpsAppTextBlockArray = new TextBlock[4];
                SecondOOBOpsAppTextBlockArray[0] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[1] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[2] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[3] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[0].Text = "User ID?";
                SecondOOBOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                SecondOOBOpsAppTextBlockArray[2].Text = "Challenge";
                SecondOOBOpsAppTextBlockArray[3].Text = "Signed Challenge (Read Only)";
                SecondOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBoxArray = new TextBox[3];
                SecondOOBOpsAppTextBoxArray[0] = new TextBox();
                SecondOOBOpsAppTextBoxArray[1] = new TextBox();
                SecondOOBOpsAppTextBoxArray[2] = new TextBox();
                SecondOOBOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondOOBOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondOOBOpsAppTextBoxArray[0].Width = 250;
                SecondOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[0].Height = 125;
                SecondOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppTextBoxArray[1].Width = 250;
                SecondOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[1].Height = 125;
                SecondOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppTextBoxArray[2].Width = 250;
                SecondOOBOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[2].Height = 125;
                SecondOOBOpsAppTextBoxArray[2].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppComboBoxArray = new ComboBox[1];
                SecondOOBOpsAppComboBoxArray[0] = new ComboBox();
                SecondOOBOpsAppComboBoxArray[0].MaxWidth = 250;
                OOBOpsAppLoadUserIDs();
                SecondOOBOpsAppComboBoxArray[0].SelectionChanged += OOBOpsAppComboBoxSelectedItemsChanged;
                SecondOOBOpsAppButtonArray = new Button[1];
                SecondOOBOpsAppButtonArray[0] = new Button();
                SecondOOBOpsAppButtonArray[0].Content = "Sign Challenge";
                SecondOOBOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppComboBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[3]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else if (OOBOpsAppUIChooser == 3)
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                ThirdOOBOpsAppTextBlockArray = new TextBlock[3];
                ThirdOOBOpsAppTextBlockArray[0] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[1] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[2] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[0].Text = "Signed Challenge";
                ThirdOOBOpsAppTextBlockArray[1].Text = "Others' DSA Public Key";
                ThirdOOBOpsAppTextBlockArray[2].Text = "Status (Read Only)";
                ThirdOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppTextBoxArray = new TextBox[3];
                ThirdOOBOpsAppTextBoxArray[0] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[1] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[2] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[2].IsReadOnly = true;
                ThirdOOBOpsAppTextBoxArray[0].Width = 250;
                ThirdOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[0].Height = 125;
                ThirdOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppTextBoxArray[1].Width = 250;
                ThirdOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[1].Height = 125;
                ThirdOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppTextBoxArray[2].Width = 250;
                ThirdOOBOpsAppTextBoxArray[2].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[2].Height = 125;
                ThirdOOBOpsAppTextBoxArray[2].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppButtonArray = new Button[1];
                ThirdOOBOpsAppButtonArray[0] = new Button();
                ThirdOOBOpsAppButtonArray[0].Content = "Verify Signed Challenge";
                ThirdOOBOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetOOBOpsAppUI();
        }
    }

    private void ResetCOTOpsAppUI()
    {
        COTOpsAppUIChooser = 0;
        FirstCOTOpsAppTextBlockArray = new TextBlock[] { };
        FirstCOTOpsAppTextBoxArray = new TextBox[] { };
        FirstCOTOpsAppButtonArray = new Button[] { };
        SecondCOTOpsAppTextBlockArray = new TextBlock[] { };
        SecondCOTOpsAppTextBoxArray = new TextBox[] { };
        SecondCOTOpsAppCheckBoxArray = new CheckBox[] { };
        SecondCOTOpsAppButtonArray = new Button[] { };
        ThirdCOTOpsAppTextBlockArray = new TextBlock[] { };
        ThirdCOTOpsAppTextBoxArray = new TextBox[] { };
        ThirdCOTOpsAppComboBoxArray = new ComboBox[] { };
        ThirdCOTOpsAppButtonArray = new Button[] { };
        COTOpsAppLowerRightLPSP.Children.Clear();
        HasCOTOpsAppUIRendered = false;
    }

    private void ResetRegistrationAppUI()
    {
        RegistrationAppUIChooser = 0;
        FirstRegistrationAppTextBlockArray = new TextBlock[] { };
        FirstRegistrationAppTextBoxArray = new TextBox[] { };
        FirstRegistrationAppRadioButtonArray = new RadioButton[] { };
        FirstRegistrationAppButtonArray = new Button[] { };
        SecondRegistrationAppTextBlockArray = new TextBlock[] { };
        SecondRegistrationAppTextBoxArray = new TextBox[] { };
        SecondRegistrationAppComboBoxArray = new ComboBox[] { };
        SecondRegistrationAppButtonArray = new Button[] { };
        ThirdRegistrationAppTextBlockArray = new TextBlock[] { };
        ThirdRegistrationAppTextBoxArray = new TextBox[] { };
        ThirdRegistrationAppComboBoxArray = new ComboBox[] { };
        ThirdRegistrationAppRadioButtonArray = new RadioButton[] { };
        ThirdRegistrationAppButtonArray = new Button[] { };
        RegistrationAppLowerRightSP.Children.Clear();
        HasRegistrationAppUIRendered = false;
    }

    private void ResetOOBOpsAppUI()
    {
        OOBOpsAppUIChooser = 0;
        FirstOOBOpsAppTextBlockArray = new TextBlock[] { };
        FirstOOBOpsAppTextBoxArray = new TextBox[] { };
        FirstOOBOpsButtonArray = new Button[] { };
        SecondOOBOpsAppTextBlockArray = new TextBlock[] { };
        SecondOOBOpsAppTextBoxArray = new TextBox[] { };
        SecondOOBOpsAppComboBoxArray = new ComboBox[] { };
        SecondOOBOpsAppButtonArray = new Button[] { };
        ThirdOOBOpsAppTextBlockArray = new TextBlock[] { };
        ThirdOOBOpsAppTextBoxArray = new TextBox[] { };
        ThirdOOBOpsAppButtonArray = new Button[] { };
        OOBOpsAppLowerRightSP.Children.Clear();
        HasOOBOpsAppUIRendered = false;
    }

    private void COTOpsAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (COTOpsAppUIChooser == 3)
        {
            if (ThirdCOTOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                ThirdCOTOpsAppTextBoxArray[0].Text = ThirdCOTOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void RegistrationAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (RegistrationAppUIChooser == 2)
        {
            if (SecondRegistrationAppComboBoxArray[0].SelectedIndex != -1)
            {
                SecondRegistrationAppTextBoxArray[0].Text = SecondRegistrationAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
        else if (RegistrationAppUIChooser == 3)
        {
            if (ThirdRegistrationAppComboBoxArray[0].SelectedIndex != -1)
            {
                ThirdRegistrationAppTextBoxArray[0].Text = ThirdRegistrationAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void OOBOpsAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (OOBOpsAppUIChooser == 2)
        {
            if (SecondOOBOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                SecondOOBOpsAppTextBoxArray[0].Text = SecondOOBOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void COTOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (COTOpsAppUIChooser == 1)
        {
            String IPAddress = FirstCOTOpsAppTextBoxArray[0].Text;
            if (IPAddress != null && IPAddress.CompareTo("") != 0)
            {
                if (File.Exists(COTOpsAppServerRootFolder + "IP.txt") == true)
                {
                    ServerIPStatusTB.Text = "";
                }
                File.WriteAllText(COTOpsAppServerRootFolder + "IP.txt", IPAddress);
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
                FirstCOTOpsAppTextBoxArray[1].Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
        else if (COTOpsAppUIChooser == 2)
        {
            String User_ID = SecondCOTOpsAppTextBoxArray[0].Text;
            Boolean IncludeSignerPK = (Boolean)SecondCOTOpsAppCheckBoxArray[0].IsChecked;
            Boolean IncludeSignerContactAndOOBPK = (Boolean)SecondCOTOpsAppCheckBoxArray[1].IsChecked;
            if (User_ID != null && User_ID.CompareTo("") != 0)
            {
                GetEUFullCertHelper.GetFullCert(User_ID, COTOpsAppCertificateFolder + User_ID, IncludeSignerPK, IncludeSignerContactAndOOBPK);
                SecondCOTOpsAppTextBoxArray[1].Text = GetEUFullCertHelper.StatusString;
            }
        }
        else if (COTOpsAppUIChooser == 3)
        {
            int Count = Directory.GetFiles(COTOpsAppONodeUserCertificateFolder).Length;
            String[] TargetedFile = Directory.GetFiles(COTOpsAppONodeUserCertificateFolder);
            if (Count == 1)
            {
                VerifyNodeUserCertificate.AbleToVerifyONodeUserCertificate(TargetedFile[0]);
                ThirdCOTOpsAppTextBoxArray[0].Text = VerifyNodeUserCertificate.StatusString;
            }
            else
            {
                ThirdCOTOpsAppTextBoxArray[0].Text = "Error: Either the specified directory had no certificates or exceeded";
            }
        }
    }

    private void RegistrationAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (RegistrationAppUIChooser == 1)
        {
            String Contact = FirstRegistrationAppTextBoxArray[1].Text;
            String AuthenticationPublicKeyB64String = "";
            String SigningPublicKeyB64String = "";
            String OOBPublicKeyB64String = "";
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(32);
            String ASPK_ValidDT_String = CurrentDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            String User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
            if (User_ID.Length > 32)
            {
                User_ID = User_ID.Substring(0, 32);
            }
            while (Directory.Exists(RegistrationAppRootFolder + User_ID) == true)
            {
                User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
                if (User_ID.Length > 32)
                {
                    User_ID = User_ID.Substring(0, 32);
                }
            }
            Directory.CreateDirectory(RegistrationAppRootFolder + User_ID);
            Directory.CreateDirectory(OOBOpsAppRootFolder + User_ID);
            if (FirstRegistrationAppRadioButtonArray[0].IsChecked == true)
            {
                RevampedKeyPair MyAuthenticationKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair MySigningKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair MyOOBKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED25519");
                }
                else
                {
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt", "ED25519");
                }
                AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                MyAuthenticationKeyPair.Clear();
                MySigningKeyPair.Clear();
                MyOOBKeyPair.Clear();
            }
            else
            {
                ED448RevampedKeyPair MyAuthenticationKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair MySigningKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair MyOOBKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED448");
                }
                else
                {
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt", "ED448");
                }
                AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                MyAuthenticationKeyPair.Clear();
                MySigningKeyPair.Clear();
                MyOOBKeyPair.Clear();
            }
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\ASPK_ValidDT.txt", ASPK_ValidDT_String);
            }
            else
            {
                File.WriteAllText(RegistrationAppRootFolder + User_ID + "/ASPK_ValidDT.txt", ASPK_ValidDT_String);
            }
            if (Contact != null && Contact.CompareTo("") != 0)
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\Contact.txt", Contact);
                }
                else
                {
                    File.WriteAllText(RegistrationAppRootFolder + User_ID + "/Contact.txt", Contact);
                }
            }
            FirstRegistrationAppTextBoxArray[0].Text = User_ID;
            FirstRegistrationAppTextBoxArray[2].Text = AuthenticationPublicKeyB64String;
            FirstRegistrationAppTextBoxArray[3].Text = SigningPublicKeyB64String;
            FirstRegistrationAppTextBoxArray[4].Text = OOBPublicKeyB64String;
            FirstRegistrationAppTextBoxArray[5].Text = ASPK_ValidDT_String;
            FirstRegistrationAppTextBoxArray[6].Text = EndUserRegistration.RegisterEndUser(User_ID, AuthenticationPublicKeyB64String, SigningPublicKeyB64String, ASPK_ValidDT_String, Contact, OOBPublicKeyB64String);
            RegistrationAppLoadUserIDs();
        }
        else if (RegistrationAppUIChooser == 2)
        {
            if (SecondRegistrationAppComboBoxArray[0].SelectedIndex != -1)
            {
                String User_ID = SecondRegistrationAppTextBoxArray[0].Text;
                String Contact = "";
                Byte[] AuthenticationPublicKey = new Byte[] { };
                Byte[] SigningPublicKey = new Byte[] { };
                Byte[] OOBPublicKey = new Byte[] { };
                String ASPK_ValidDTString = "";
                String AlgorithmType = "";
                String AuthPublicKeyB64 = "";
                String SigningPublicKeyB64 = "";
                String OOBPublicKeyB64 = "";
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    if (File.Exists(RegistrationAppRootFolder + User_ID + "\\Contact.txt") == true)
                    {
                        Contact = File.ReadAllText(RegistrationAppRootFolder + User_ID + "\\Contact.txt");
                    }
                    AuthenticationPublicKey = File.ReadAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt");
                    SigningPublicKey = File.ReadAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt");
                    OOBPublicKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt");
                    ASPK_ValidDTString = File.ReadAllText(RegistrationAppRootFolder + User_ID + "\\ASPK_ValidDT.txt");
                    AlgorithmType = File.ReadAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt");
                }
                else
                {
                    if (File.Exists(RegistrationAppRootFolder + User_ID + "/Contact.txt") == true)
                    {
                        Contact = File.ReadAllText(RegistrationAppRootFolder + User_ID + "/Contact.txt");
                    }
                    AuthenticationPublicKey = File.ReadAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt");
                    SigningPublicKey = File.ReadAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt");
                    OOBPublicKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt");
                    ASPK_ValidDTString = File.ReadAllText(RegistrationAppRootFolder + User_ID + "/ASPK_ValidDT.txt");
                    AlgorithmType = File.ReadAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt");
                }
                AuthPublicKeyB64 = Convert.ToBase64String(AuthenticationPublicKey);
                SigningPublicKeyB64 = Convert.ToBase64String(SigningPublicKey);
                OOBPublicKeyB64 = Convert.ToBase64String(OOBPublicKey);
                SecondRegistrationAppTextBoxArray[1].Text = Contact;
                SecondRegistrationAppTextBoxArray[2].Text = AuthPublicKeyB64;
                SecondRegistrationAppTextBoxArray[3].Text = SigningPublicKeyB64;
                SecondRegistrationAppTextBoxArray[4].Text = OOBPublicKeyB64;
                SecondRegistrationAppTextBoxArray[5].Text = ASPK_ValidDTString;
                SecondRegistrationAppTextBoxArray[6].Text = AlgorithmType;
            }
        }
        else if (RegistrationAppUIChooser == 3)
        {
            if (ThirdRegistrationAppComboBoxArray[0].SelectedIndex != -1)
            {
                String User_ID = ThirdRegistrationAppTextBoxArray[0].Text;
                String Contact = ThirdRegistrationAppTextBoxArray[1].Text;
                String AuthenticationPublicKeyB64String = "";
                String SigningPublicKeyB64String = "";
                String OOBPublicKeyB64String = "";
                DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(32);
                //Forcing it to be MySQL compliant..
                String ASPK_ValidDT_String = CurrentDateTime.ToString("yyyy-MM-dd HH:mm:ss");
                if (ThirdRegistrationAppRadioButtonArray[0].IsChecked == true)
                {
                    RevampedKeyPair MyAuthenticationKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    RevampedKeyPair MySigningKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    RevampedKeyPair MyOOBKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                    SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                    OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                    ThirdRegistrationAppTextBoxArray[6].Text = EndUserInfoUpdate.UpdateEndUser(User_ID, AuthenticationPublicKeyB64String, SigningPublicKeyB64String, ASPK_ValidDT_String, OOBPublicKeyB64String, Contact);
                    if (ThirdRegistrationAppTextBoxArray[6].Text.CompareTo("Success: All of this end user's info had been updated..") == 0) 
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED25519");
                        }
                        else
                        {
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt", "ED25519");
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\ASPK_ValidDT.txt", ASPK_ValidDT_String);
                        }
                        else
                        {
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "/ASPK_ValidDT.txt", ASPK_ValidDT_String);
                        }
                        if (Contact != null && Contact.CompareTo("") != 0)
                        {
                            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\Contact.txt", Contact);
                            }
                            else
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "/Contact.txt", Contact);
                            }
                        }
                    }
                    else if (ThirdRegistrationAppTextBoxArray[6].Text.CompareTo("Success: Some of this end user's info had been updated..") == 0) 
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED25519");
                        }
                        else
                        {
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt", "ED25519");
                        }
                        if (Contact != null && Contact.CompareTo("") != 0)
                        {
                            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\Contact.txt", Contact);
                            }
                            else
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "/Contact.txt", Contact);
                            }
                        }
                    }
                    MyAuthenticationKeyPair.Clear();
                    MySigningKeyPair.Clear();
                    MyOOBKeyPair.Clear();
                }
                else
                {
                    ED448RevampedKeyPair MyAuthenticationKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    ED448RevampedKeyPair MySigningKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    ED448RevampedKeyPair MyOOBKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                    SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                    OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                    ThirdRegistrationAppTextBoxArray[6].Text = EndUserInfoUpdate.UpdateEndUser(User_ID, AuthenticationPublicKeyB64String, SigningPublicKeyB64String, ASPK_ValidDT_String, OOBPublicKeyB64String, Contact);
                    if (ThirdRegistrationAppTextBoxArray[6].Text.CompareTo("Success: All of this end user's info had been updated..") == 0)
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED448");
                        }
                        else
                        {
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt", "ED448");
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\ASPK_ValidDT.txt", ASPK_ValidDT_String);
                        }
                        else
                        {
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "/ASPK_ValidDT.txt", ASPK_ValidDT_String);
                        }
                        if (Contact != null && Contact.CompareTo("") != 0)
                        {
                            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\Contact.txt", Contact);
                            }
                            else
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "/Contact.txt", Contact);
                            }
                        }
                    }
                    else if (ThirdRegistrationAppTextBoxArray[6].Text.CompareTo("Success: Some of this end user's info had been updated..") == 0)
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED448");
                        }
                        else
                        {
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(RegistrationAppRootFolder + User_ID + "/AlgorithmType.txt", "ED448");
                        }
                        if (Contact != null && Contact.CompareTo("") != 0)
                        {
                            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "\\Contact.txt", Contact);
                            }
                            else
                            {
                                File.WriteAllText(RegistrationAppRootFolder + User_ID + "/Contact.txt", Contact);
                            }
                        }
                    }
                    MyAuthenticationKeyPair.Clear();
                    MySigningKeyPair.Clear();
                    MyOOBKeyPair.Clear();
                }
                ThirdRegistrationAppTextBoxArray[2].Text = AuthenticationPublicKeyB64String;
                ThirdRegistrationAppTextBoxArray[3].Text = SigningPublicKeyB64String;
                ThirdRegistrationAppTextBoxArray[4].Text = OOBPublicKeyB64String;
                ThirdRegistrationAppTextBoxArray[5].Text = ASPK_ValidDT_String;
            }
        }
    }

    private void OOBOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (OOBOpsAppUIChooser == 1)
        {
            String ChallengeLengthString = FirstOOBOpsAppTextBoxArray[0].Text;
            Boolean AbleToParse = true;
            Boolean IsGreaterOrEqual16Bytes = true;
            int ChallengeLength = 0;
            Byte[] Challenge = new Byte[] { };
            if (ChallengeLengthString != null && ChallengeLengthString.CompareTo("") != 0)
            {
                try
                {
                    ChallengeLength = int.Parse(ChallengeLengthString);
                    if (ChallengeLength < 16)
                    {
                        IsGreaterOrEqual16Bytes = false;
                    }
                }
                catch
                {
                    AbleToParse = false;
                }
                if (AbleToParse == true && IsGreaterOrEqual16Bytes == true)
                {
                    Challenge = SodiumRNG.GetRandomBytes(ChallengeLength);
                    FirstOOBOpsAppTextBoxArray[1].Text = Convert.ToBase64String(Challenge);
                }
                else
                {
                    FirstOOBOpsAppTextBlockArray[1].Text = "Error: Either you didn't put in round number or the challenge length is not at least 16 bytes";
                }
            }
        }
        else if (OOBOpsAppUIChooser == 2)
        {
            if (SecondOOBOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                String User_ID = SecondOOBOpsAppTextBoxArray[0].Text;
                String ChallengeString = SecondOOBOpsAppTextBoxArray[1].Text;
                Byte[] Challenge = new Byte[] { };
                Byte[] SignedChallenge = new Byte[] { };
                Byte[] UserOOBPrivateKey = new Byte[] { };
                Boolean AbleToParse = true;
                if (ChallengeString != null && ChallengeString.CompareTo("") != 0)
                {
                    try
                    {
                        Challenge = Convert.FromBase64String(ChallengeString);
                    }
                    catch
                    {
                        AbleToParse = false;
                    }
                    if (AbleToParse)
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            UserOOBPrivateKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt");
                        }
                        else
                        {
                            UserOOBPrivateKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt");
                        }
                        if (UserOOBPrivateKey.Length == 64)
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, UserOOBPrivateKey, true);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(UserOOBPrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SecondOOBOpsAppTextBoxArray[2].Text = Convert.ToBase64String(SignedChallenge);
                    }
                    else
                    {
                        SecondOOBOpsAppTextBoxArray[2].Text = "Error: The challenge was not properly encoded with base64";
                    }
                }
            }
        }
        else if (OOBOpsAppUIChooser == 3)
        {
            String SignedChallengeString = ThirdOOBOpsAppTextBoxArray[0].Text;
            String OtherOOBPublicKeyString = ThirdOOBOpsAppTextBoxArray[1].Text;
            Byte[] SignedChallenge = new Byte[] { };
            Byte[] Challenge = new Byte[] { };
            Byte[] OtherOOBPublicKey = new Byte[] { };
            Boolean AbleToParse = true;
            Boolean AbleToVerify = true;
            if (SignedChallengeString != null && SignedChallengeString.CompareTo("") != 0 && OtherOOBPublicKeyString != null && OtherOOBPublicKeyString.CompareTo("") != 0)
            {
                try
                {
                    SignedChallenge = Convert.FromBase64String(SignedChallengeString);
                    OtherOOBPublicKey = Convert.FromBase64String(OtherOOBPublicKeyString);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (AbleToParse == true)
                {
                    try
                    {
                        if (OtherOOBPublicKey.Length == 32)
                        {
                            Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, OtherOOBPublicKey);
                        }
                        else
                        {
                            Challenge = SecureED448.GetMessageFromSignatureMessage(OtherOOBPublicKey, SignedChallenge, new Byte[] { });
                        }
                    }
                    catch
                    {
                        AbleToVerify = false;
                    }
                    if (AbleToVerify)
                    {
                        ThirdOOBOpsAppTextBoxArray[2].Text = "Success: Able to verify the signed challenge with given digital signature public key from other user";
                    }
                    else
                    {
                        ThirdOOBOpsAppTextBoxArray[2].Text = "Error: Unable to verify this signed challenge with given digital signature public key from other user";
                    }
                }
                else
                {
                    ThirdOOBOpsAppTextBoxArray[2].Text = "Error: Signed Challenge or other user's out of band digital signature public key was not encoded in base64";
                }
            }
        }
    }

    private void RegistrationAppLoadUserIDs()
    {
        if (RegistrationAppUIChooser >= 2 && RegistrationAppUIChooser <= 3)
        {
            String[] User_IDWithDirectoryPath = Directory.GetDirectories(RegistrationAppRootFolder);
            String[] User_ID = new String[User_IDWithDirectoryPath.Length];
            int Loop = 0;
            while (Loop < User_IDWithDirectoryPath.Length)
            {
                User_ID[Loop] = User_IDWithDirectoryPath[Loop].Remove(0, RegistrationAppRootFolder.Length);
                Loop += 1;
            }
            if (RegistrationAppUIChooser == 2)
            {
                SecondRegistrationAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    SecondRegistrationAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
            else if (RegistrationAppUIChooser == 3)
            {
                ThirdRegistrationAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    ThirdRegistrationAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
        }
    }

    private void OOBOpsAppLoadUserIDs()
    {
        String[] User_IDWithDirectoryPath = Directory.GetDirectories(OOBOpsAppRootFolder);
        String[] User_ID = new String[User_IDWithDirectoryPath.Length];
        int Loop = 0;
        if (OOBOpsAppUIChooser == 2)
        {
            SecondOOBOpsAppComboBoxArray[0].Items.Clear();
            while (Loop < User_IDWithDirectoryPath.Length)
            {
                User_ID[Loop] = User_IDWithDirectoryPath[Loop].Remove(0, OOBOpsAppRootFolder.Length);
                SecondOOBOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                Loop += 1;
            }
        }
    }
}
