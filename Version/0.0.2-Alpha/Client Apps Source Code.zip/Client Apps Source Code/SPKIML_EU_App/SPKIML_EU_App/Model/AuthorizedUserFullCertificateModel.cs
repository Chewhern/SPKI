﻿using System;

namespace SPKIML_EU_App.Model
{
    public class AuthorizedUserFullCertificateModel
    {
        public String Status { get; set; }

        public String[] SNode_IP_Addresses { get; set; }

        public String TNode_IP_Address { get; set; }

        public String[] SNode_User_IDs { get; set; }

        public String TNode_User_ID { get; set; }

        public String[] Signed_TNode_User_Auth_PKs { get; set; }

        public String[] Signed_TNode_User_Sign_PKs { get; set; }

        public DateTime[] SignedDateTimes { get; set; }
    }
}
