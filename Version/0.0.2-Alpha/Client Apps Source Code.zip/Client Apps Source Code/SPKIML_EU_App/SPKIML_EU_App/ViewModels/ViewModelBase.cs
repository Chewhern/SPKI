﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKIML_EU_App.ViewModels;

public class ViewModelBase : ObservableObject
{
}
