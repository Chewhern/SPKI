﻿namespace SPKIML_EU_App.ViewModels;

public partial class MainViewModel : ViewModelBase
{
}
