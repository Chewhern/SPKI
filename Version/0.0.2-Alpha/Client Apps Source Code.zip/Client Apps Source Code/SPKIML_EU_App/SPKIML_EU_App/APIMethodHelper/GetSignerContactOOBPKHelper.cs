﻿using SPKIML_EU_App.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SPKIML_EU_App.APIMethodHelper
{
    public static class GetSignerContactOOBPKHelper
    {
        public static String GetSignerUserContactOOBPK(String User_ID,String API_IP_Address)
        {
            String ResultString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetNodeUserOOBPKContact?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    ResultString = Result.Substring(1, Result.Length - 2);
                }
                else
                {
                    ResultString = "Error: Parent node encounter some issues";
                }
            }
            return ResultString;
        }
    }
}
