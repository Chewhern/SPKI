﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKIML_ON_App.ViewModels;

public class ViewModelBase : ObservableObject
{
}
