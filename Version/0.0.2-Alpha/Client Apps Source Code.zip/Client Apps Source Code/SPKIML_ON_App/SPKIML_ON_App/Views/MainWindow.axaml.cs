﻿using Avalonia.Controls;

namespace SPKIML_ON_App.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
