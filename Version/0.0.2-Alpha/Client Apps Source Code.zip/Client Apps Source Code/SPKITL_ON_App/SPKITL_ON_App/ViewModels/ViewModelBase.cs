﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKITL_ON_App.ViewModels;

public class ViewModelBase : ObservableObject
{
}
