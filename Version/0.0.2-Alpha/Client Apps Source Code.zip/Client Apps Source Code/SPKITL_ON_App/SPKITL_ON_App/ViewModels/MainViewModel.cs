﻿namespace SPKITL_ON_App.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}
