﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace SPKITL_ON_App.Views;

public partial class MainView : UserControl
{
    //Need to do OOB communication if time allows..
    private static int LocalOpsUIChooser = 0;
    private static int CommOpsUIChooser = 0;
    private static int OOBOpsUIChooser = 0;
    //..
    private static TextBlock[] FirstLocalOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstLocalOpsTextBoxArray = new TextBox[] { };
    private static Button[] FirstLocalOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondLocalOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondLocalOpsTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondLocalOpsComboBoxArray = new ComboBox[] { };
    private static Button[] SecondLocalOpsButtonArray = new Button[] { };
    private static TextBlock[] ThirdLocalOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdLocalOpsTextBoxArray = new TextBox[] { };
    private static ComboBox[] ThirdLocalOpsComboBoxArray = new ComboBox[] { };
    private static Button[] ThirdLocalOpsButtonArray = new Button[] { };
    private static TextBlock[] FourthLocalOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FourthLocalOpsTextBoxArray = new TextBox[] { };
    private static Button[] FourthLocalOpsButtonArray = new Button[] { };
    private static TextBlock[] FifthLocalOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FifthLocalOpsTextBoxArray = new TextBox[] { };
    private static ComboBox[] FifthLocalOpsComboBoxArray = new ComboBox[] { };
    private static Button[] FifthLocalOpsButtonArray = new Button[] { };
    private static TextBlock[] SixthLocalOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] SixthLocalOpsTextBoxArray = new TextBox[] { };
    private static ComboBox[] SixthLocalOpsComboBoxArray = new ComboBox[] { };
    private static Button[] SixthLocalOpsButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstCommOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstCommOpsTextBoxArray = new TextBox[] { };
    private static RadioButton[] FirstCommOpsRadioButtonArray = new RadioButton[] { };
    private static Button[] FirstCommOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondCommOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondCommOpsTextBoxArray = new TextBox[] { };
    private static Button[] SecondCommOpsButtonArray = new Button[] { };
    private static TextBlock[] ThirdCommOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdCommOpsTextBoxArray = new TextBox[] { };
    private static Button[] ThirdCommOpsButtonArray = new Button[] { };
    private static TextBlock[] FourthCommOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FourthCommOpsTextBoxArray = new TextBox[] { };
    private static RadioButton[] FourthCommOpsRadioButtonArray = new RadioButton[] { };
    private static Button[] FourthCommOpsButtonArray = new Button[] { };
    private static TextBlock[] FifthCommOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FifthCommOpsTextBoxArray = new TextBox[] { };
    private static Button[] FifthCommOpsButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstOOBOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstOOBOpsTextBoxArray = new TextBox[] { };
    private static Button[] FirstOOBOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondOOBOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondOOBOpsTextBoxArray = new TextBox[] { };
    private static Button[] SecondOOBOpsButtonArray = new Button[] { };
    private static TextBlock[] ThirdOOBOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdOOBOpsTextBoxArray = new TextBox[] { };
    private static Button[] ThirdOOBOpsButtonArray = new Button[] { };
    private static Boolean HasLocalOpsUIRendered = false;
    private static Boolean HasCommOpsUIRendered = false;
    private static Boolean HasOOBOpsUIRendered = false;
    private static String RemoteOpsMainRootFolder = "";
    private static String LocalOpsMainRootFolder = "";
    private static String LocalOpsDataToBeEncryptedFolder = "";
    private static String LocalOpsEncryptFolder = "";
    private static String LocalOpsDecryptFolder = "";
    private static String CommOpsMainRootFolder = "";
    private static String CommOpsEncryptFolder = "";
    private static String CommOpsDecryptFolder = "";
    private static Byte[] Nonce1 = SodiumHelper.HexToBinary("352b66077513f1abe7da139522739e16244d0f2f044e6524");
    private static Byte[] Nonce2 = SodiumHelper.HexToBinary("924400f379fbd71f6d9f66b436159078715548e1282600e1");

    public MainView()
    {
        InitializeComponent();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
        {
            RemoteOpsMainRootFolder = AppContext.BaseDirectory + "\\ServerOps\\";
            LocalOpsMainRootFolder = AppContext.BaseDirectory + "\\SecretCredentials\\";
            LocalOpsDataToBeEncryptedFolder = AppContext.BaseDirectory + "\\SCDataToBeEncrypted\\";
            LocalOpsEncryptFolder = AppContext.BaseDirectory + "\\SCEncryptedData\\";
            LocalOpsDecryptFolder = AppContext.BaseDirectory + "\\SCDecryptedData\\";
            CommOpsMainRootFolder = AppContext.BaseDirectory + "\\CommunicationCredentials\\";
            CommOpsEncryptFolder = AppContext.BaseDirectory + "\\CCEncryptedData\\";
            CommOpsDecryptFolder = AppContext.BaseDirectory + "\\CCDecryptedData\\";
        }
        else 
        {
            RemoteOpsMainRootFolder = AppContext.BaseDirectory + "/ServerOps/";
            LocalOpsMainRootFolder = AppContext.BaseDirectory + "/SecretCredentials/";
            LocalOpsDataToBeEncryptedFolder = AppContext.BaseDirectory + "/SCDataToBeEncrypted/";
            LocalOpsEncryptFolder = AppContext.BaseDirectory + "/SCEncryptedData/";
            LocalOpsDecryptFolder = AppContext.BaseDirectory + "/SCDecryptedData/";
            CommOpsMainRootFolder = AppContext.BaseDirectory + "/CommunicationCredentials/";
            CommOpsEncryptFolder = AppContext.BaseDirectory + "/CCEncryptedData/";
            CommOpsDecryptFolder = AppContext.BaseDirectory + "/CCDecryptedData/";
        }
        if (Directory.Exists(RemoteOpsMainRootFolder) == false) 
        {
            Directory.CreateDirectory(RemoteOpsMainRootFolder);
        }
        if (Directory.Exists(LocalOpsMainRootFolder) == false) 
        {
            Directory.CreateDirectory(LocalOpsMainRootFolder);
        }
        if (Directory.Exists(LocalOpsDataToBeEncryptedFolder) == false) 
        {
            Directory.CreateDirectory(LocalOpsDataToBeEncryptedFolder);
        }
        if (Directory.Exists(LocalOpsEncryptFolder) == false) 
        {
            Directory.CreateDirectory(LocalOpsEncryptFolder);
        }
        if (Directory.Exists(LocalOpsDecryptFolder) == false) 
        {
            Directory.CreateDirectory(LocalOpsDecryptFolder);
        }
        if (Directory.Exists(CommOpsMainRootFolder) == false) 
        {
            Directory.CreateDirectory(CommOpsMainRootFolder);
        }
        if (Directory.Exists(CommOpsEncryptFolder) == false) 
        {
            Directory.CreateDirectory(CommOpsEncryptFolder);
        }
        if (Directory.Exists(CommOpsDecryptFolder) == false) 
        {
            Directory.CreateDirectory(CommOpsDecryptFolder);
        }
        LocalOpsAppInitialization();
        CommOpsAppInitialization();
        OOBOpsAppInitialization();
    }

    private void LocalOpsAppInitialization() 
    {
        LocalOpsUIChooser = 0;
        NodeOpsLocalAppToggleBTN1.IsCheckedChanged += LocalOpsAppToggleBTNSFunction;
        NodeOpsLocalAppToggleBTN2.IsCheckedChanged += LocalOpsAppToggleBTNSFunction;
        NodeOpsLocalAppToggleBTN3.IsCheckedChanged += LocalOpsAppToggleBTNSFunction;
        NodeOpsLocalAppToggleBTN4.IsCheckedChanged += LocalOpsAppToggleBTNSFunction;
        NodeOpsLocalAppToggleBTN5.IsCheckedChanged += LocalOpsAppToggleBTNSFunction;
        NodeOpsLocalAppToggleBTN6.IsCheckedChanged += LocalOpsAppToggleBTNSFunction;
    }

    private void CommOpsAppInitialization() 
    {
        CommOpsUIChooser = 0;
        NodeOpsCommAppToggleBTN1.IsCheckedChanged += CommOpsAppToggleBTNSFunction;
        NodeOpsCommAppToggleBTN2.IsCheckedChanged += CommOpsAppToggleBTNSFunction;
        NodeOpsCommAppToggleBTN3.IsCheckedChanged += CommOpsAppToggleBTNSFunction;
        NodeOpsCommAppToggleBTN4.IsCheckedChanged += CommOpsAppToggleBTNSFunction;
        NodeOpsCommAppToggleBTN5.IsCheckedChanged += CommOpsAppToggleBTNSFunction;
    }

    private void OOBOpsAppInitialization() 
    {
        OOBOpsUIChooser = 0;
        OOBOpsAppToggleBTN1.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN2.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN3.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
    }

    private void LocalOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (NodeOpsLocalAppToggleBTN1.IsChecked == true)
        {
            NodeOpsLocalAppToggleBTN2.IsChecked = false;
            NodeOpsLocalAppToggleBTN3.IsChecked = false;
            NodeOpsLocalAppToggleBTN4.IsChecked = false;
            NodeOpsLocalAppToggleBTN5.IsChecked = false;
            NodeOpsLocalAppToggleBTN6.IsChecked = false;
            LocalOpsUIChooser = 1;
        }
        else if (NodeOpsLocalAppToggleBTN2.IsChecked == true)
        {
            NodeOpsLocalAppToggleBTN1.IsChecked = false;
            NodeOpsLocalAppToggleBTN3.IsChecked = false;
            NodeOpsLocalAppToggleBTN4.IsChecked = false;
            NodeOpsLocalAppToggleBTN5.IsChecked = false;
            NodeOpsLocalAppToggleBTN6.IsChecked = false;
            LocalOpsUIChooser = 2;
        }
        else if (NodeOpsLocalAppToggleBTN3.IsChecked == true)
        {
            NodeOpsLocalAppToggleBTN2.IsChecked = false;
            NodeOpsLocalAppToggleBTN1.IsChecked = false;
            NodeOpsLocalAppToggleBTN4.IsChecked = false;
            NodeOpsLocalAppToggleBTN5.IsChecked = false;
            NodeOpsLocalAppToggleBTN6.IsChecked = false;
            LocalOpsUIChooser = 3;
        }
        else if (NodeOpsLocalAppToggleBTN4.IsChecked == true)
        {
            NodeOpsLocalAppToggleBTN2.IsChecked = false;
            NodeOpsLocalAppToggleBTN3.IsChecked = false;
            NodeOpsLocalAppToggleBTN1.IsChecked = false;
            NodeOpsLocalAppToggleBTN5.IsChecked = false;
            NodeOpsLocalAppToggleBTN6.IsChecked = false;
            LocalOpsUIChooser = 4;
        }
        else if (NodeOpsLocalAppToggleBTN5.IsChecked == true)
        {
            NodeOpsLocalAppToggleBTN2.IsChecked = false;
            NodeOpsLocalAppToggleBTN3.IsChecked = false;
            NodeOpsLocalAppToggleBTN4.IsChecked = false;
            NodeOpsLocalAppToggleBTN1.IsChecked = false;
            NodeOpsLocalAppToggleBTN6.IsChecked = false;
            LocalOpsUIChooser = 5;
        }
        else if (NodeOpsLocalAppToggleBTN6.IsChecked == true)
        {
            NodeOpsLocalAppToggleBTN2.IsChecked = false;
            NodeOpsLocalAppToggleBTN3.IsChecked = false;
            NodeOpsLocalAppToggleBTN4.IsChecked = false;
            NodeOpsLocalAppToggleBTN5.IsChecked = false;
            NodeOpsLocalAppToggleBTN1.IsChecked = false;
            LocalOpsUIChooser = 6;
        }
        else 
        {
            LocalOpsAppResetUI();
        }
        LocalOpsAppDrawUI();
    }

    private void CommOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (NodeOpsCommAppToggleBTN1.IsChecked == true)
        {
            NodeOpsCommAppToggleBTN2.IsChecked = false;
            NodeOpsCommAppToggleBTN3.IsChecked = false;
            NodeOpsCommAppToggleBTN4.IsChecked = false;
            NodeOpsCommAppToggleBTN5.IsChecked = false;
            CommOpsUIChooser = 1;
        }
        else if (NodeOpsCommAppToggleBTN2.IsChecked == true)
        {
            NodeOpsCommAppToggleBTN1.IsChecked = false;
            NodeOpsCommAppToggleBTN3.IsChecked = false;
            NodeOpsCommAppToggleBTN4.IsChecked = false;
            NodeOpsCommAppToggleBTN5.IsChecked = false;
            CommOpsUIChooser = 2;
        }
        else if (NodeOpsCommAppToggleBTN3.IsChecked == true)
        {
            NodeOpsCommAppToggleBTN2.IsChecked = false;
            NodeOpsCommAppToggleBTN1.IsChecked = false;
            NodeOpsCommAppToggleBTN4.IsChecked = false;
            NodeOpsCommAppToggleBTN5.IsChecked = false;
            CommOpsUIChooser = 3;
        }
        else if (NodeOpsCommAppToggleBTN4.IsChecked == true)
        {
            NodeOpsCommAppToggleBTN2.IsChecked = false;
            NodeOpsCommAppToggleBTN3.IsChecked = false;
            NodeOpsCommAppToggleBTN1.IsChecked = false;
            NodeOpsCommAppToggleBTN5.IsChecked = false;
            CommOpsUIChooser = 4;
        }
        else if (NodeOpsCommAppToggleBTN5.IsChecked == true)
        {
            NodeOpsCommAppToggleBTN2.IsChecked = false;
            NodeOpsCommAppToggleBTN3.IsChecked = false;
            NodeOpsCommAppToggleBTN4.IsChecked = false;
            NodeOpsCommAppToggleBTN1.IsChecked = false;
            CommOpsUIChooser = 5;
        }
        else 
        {
            CommOpsAppResetUI();
        }
        CommOpsAppDrawUI();
    }

    private void OOBOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (OOBOpsAppToggleBTN1.IsChecked == true)
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsUIChooser = 1;
        }
        else if (OOBOpsAppToggleBTN2.IsChecked == true)
        {
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsUIChooser = 2;
        }
        else if (OOBOpsAppToggleBTN3.IsChecked == true)
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsUIChooser = 3;
        }
        else
        {
            OOBOpsAppResetUI();
        }
        OOBOpsAppDrawUI();
    }

    private void LocalOpsAppDrawUI() 
    {
        //6
        if(LocalOpsUIChooser == 1) 
        {
            if (HasLocalOpsUIRendered == false) 
            {
                FirstLocalOpsTextBlockArray = new TextBlock[2];
                FirstLocalOpsTextBlockArray[0] = new TextBlock();
                FirstLocalOpsTextBlockArray[1] = new TextBlock();
                FirstLocalOpsTextBlockArray[0].Text = "MAC Seed (Read Only)";
                FirstLocalOpsTextBlockArray[1].Text = "Encryption Seed (Read Only)";
                FirstLocalOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstLocalOpsTextBoxArray = new TextBox[2];
                FirstLocalOpsTextBoxArray[0] = new TextBox();
                FirstLocalOpsTextBoxArray[1] = new TextBox();
                FirstLocalOpsTextBoxArray[0].IsReadOnly = true;
                FirstLocalOpsTextBoxArray[1].IsReadOnly = true;
                FirstLocalOpsTextBoxArray[0].Width = 250;
                FirstLocalOpsTextBoxArray[0].MaxWidth = 250;
                FirstLocalOpsTextBoxArray[0].Height = 125;
                FirstLocalOpsTextBoxArray[0].MaxHeight = 125;
                FirstLocalOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstLocalOpsTextBoxArray[1].Width = 250;
                FirstLocalOpsTextBoxArray[1].MaxWidth = 250;
                FirstLocalOpsTextBoxArray[1].Height = 125;
                FirstLocalOpsTextBoxArray[1].MaxHeight = 125;
                FirstLocalOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstLocalOpsButtonArray = new Button[1];
                FirstLocalOpsButtonArray[0] = new Button();
                FirstLocalOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstLocalOpsButtonArray[0].Content = "Generate Seeds";
                FirstLocalOpsButtonArray[0].Click += LocalOpsAppBTN_Click;
                NodeOpsLocalAppLowerRightSP.Children.Add(FirstLocalOpsTextBlockArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FirstLocalOpsTextBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FirstLocalOpsTextBlockArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FirstLocalOpsTextBoxArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FirstLocalOpsButtonArray[0]);
                HasLocalOpsUIRendered = true;
            }
        }
        else if (LocalOpsUIChooser == 2)
        {
            if (HasLocalOpsUIRendered == false)
            {
                SecondLocalOpsTextBlockArray = new TextBlock[3];
                SecondLocalOpsTextBlockArray[0] = new TextBlock();
                SecondLocalOpsTextBlockArray[1] = new TextBlock();
                SecondLocalOpsTextBlockArray[2] = new TextBlock();
                SecondLocalOpsTextBlockArray[0].Text = "MAC Seed (Read Only)";
                SecondLocalOpsTextBlockArray[1].Text = "Encryption Seed (Read Only)";
                SecondLocalOpsTextBlockArray[2].Text = "Choose an action";
                SecondLocalOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLocalOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLocalOpsTextBoxArray = new TextBox[2];
                SecondLocalOpsTextBoxArray[0] = new TextBox();
                SecondLocalOpsTextBoxArray[1] = new TextBox();
                SecondLocalOpsTextBoxArray[0].IsReadOnly = true;
                SecondLocalOpsTextBoxArray[1].IsReadOnly = true;
                SecondLocalOpsTextBoxArray[0].Width = 250;
                SecondLocalOpsTextBoxArray[0].MaxWidth = 250;
                SecondLocalOpsTextBoxArray[0].Height = 125;
                SecondLocalOpsTextBoxArray[0].MaxHeight = 125;
                SecondLocalOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondLocalOpsTextBoxArray[1].Width = 250;
                SecondLocalOpsTextBoxArray[1].MaxWidth = 250;
                SecondLocalOpsTextBoxArray[1].Height = 125;
                SecondLocalOpsTextBoxArray[1].MaxHeight = 125;
                SecondLocalOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondLocalOpsComboBoxArray = new ComboBox[1];
                SecondLocalOpsComboBoxArray[0] = new ComboBox();
                SecondLocalOpsComboBoxArray[0].Items.Add("Change Seeds");
                SecondLocalOpsComboBoxArray[0].Items.Add("View Seeds");
                SecondLocalOpsButtonArray = new Button[1];
                SecondLocalOpsButtonArray[0] = new Button();
                SecondLocalOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLocalOpsButtonArray[0].Content = "Perform Action";
                SecondLocalOpsButtonArray[0].Click += LocalOpsAppBTN_Click;
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsTextBlockArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsTextBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsTextBlockArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsTextBoxArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsTextBlockArray[2]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsComboBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SecondLocalOpsButtonArray[0]);
                HasLocalOpsUIRendered = true;
            }
        }
        else if (LocalOpsUIChooser == 3)
        {
            if (HasLocalOpsUIRendered == false)
            {
                ThirdLocalOpsTextBlockArray = new TextBlock[2];
                ThirdLocalOpsTextBlockArray[0] = new TextBlock();
                ThirdLocalOpsTextBlockArray[1] = new TextBlock();
                ThirdLocalOpsTextBlockArray[0].Text = "Status (Read Only)";
                ThirdLocalOpsTextBlockArray[1].Text = "Choose an action";
                ThirdLocalOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdLocalOpsTextBoxArray = new TextBox[1];
                ThirdLocalOpsTextBoxArray[0] = new TextBox();
                ThirdLocalOpsTextBoxArray[0].IsReadOnly = true;
                ThirdLocalOpsTextBoxArray[0].Width = 250;
                ThirdLocalOpsTextBoxArray[0].MaxWidth = 250;
                ThirdLocalOpsTextBoxArray[0].Height = 125;
                ThirdLocalOpsTextBoxArray[0].MaxHeight = 125;
                ThirdLocalOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdLocalOpsComboBoxArray = new ComboBox[1];
                ThirdLocalOpsComboBoxArray[0] = new ComboBox();
                ThirdLocalOpsComboBoxArray[0].Items.Add("Encrypt Data");
                ThirdLocalOpsComboBoxArray[0].Items.Add("Decrypt Data");
                ThirdLocalOpsComboBoxArray[0].Width = 250;
                ThirdLocalOpsComboBoxArray[0].MaxWidth = 250;
                ThirdLocalOpsButtonArray = new Button[1];
                ThirdLocalOpsButtonArray[0] = new Button();
                ThirdLocalOpsButtonArray[0].Content = "Perform Action";
                ThirdLocalOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdLocalOpsButtonArray[0].Click += LocalOpsAppBTN_Click;
                NodeOpsLocalAppLowerRightSP.Children.Add(ThirdLocalOpsTextBlockArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(ThirdLocalOpsTextBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(ThirdLocalOpsTextBlockArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(ThirdLocalOpsComboBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(ThirdLocalOpsButtonArray[0]);
                HasLocalOpsUIRendered = true;
            }
        }
        else if (LocalOpsUIChooser == 4)
        {
            if (HasLocalOpsUIRendered == false)
            {
                FourthLocalOpsTextBlockArray = new TextBlock[2];
                FourthLocalOpsTextBlockArray[0] = new TextBlock();
                FourthLocalOpsTextBlockArray[1] = new TextBlock();
                FourthLocalOpsTextBlockArray[0].Text = "MAC Key (Read Only)";
                FourthLocalOpsTextBlockArray[1].Text = "Encryption Key (Read Only)";
                FourthLocalOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthLocalOpsTextBoxArray = new TextBox[2];
                FourthLocalOpsTextBoxArray[0] = new TextBox();
                FourthLocalOpsTextBoxArray[1] = new TextBox();
                FourthLocalOpsTextBoxArray[0].IsReadOnly = true;
                FourthLocalOpsTextBoxArray[1].IsReadOnly = true;
                FourthLocalOpsTextBoxArray[0].Width = 250;
                FourthLocalOpsTextBoxArray[0].MaxWidth = 250;
                FourthLocalOpsTextBoxArray[0].Height = 125;
                FourthLocalOpsTextBoxArray[0].MaxHeight = 125;
                FourthLocalOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FourthLocalOpsTextBoxArray[1].Width = 250;
                FourthLocalOpsTextBoxArray[1].MaxWidth = 250;
                FourthLocalOpsTextBoxArray[1].Height = 125;
                FourthLocalOpsTextBoxArray[1].MaxHeight = 125;
                FourthLocalOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FourthLocalOpsButtonArray = new Button[1];
                FourthLocalOpsButtonArray[0] = new Button();
                FourthLocalOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthLocalOpsButtonArray[0].Content = "Generate Keys";
                FourthLocalOpsButtonArray[0].Click += LocalOpsAppBTN_Click;
                NodeOpsLocalAppLowerRightSP.Children.Add(FourthLocalOpsTextBlockArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FourthLocalOpsTextBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FourthLocalOpsTextBlockArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FourthLocalOpsTextBoxArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FourthLocalOpsButtonArray[0]);
                HasLocalOpsUIRendered = true;
            }
        }
        else if (LocalOpsUIChooser == 5)
        {
            if (HasLocalOpsUIRendered == false)
            {
                FifthLocalOpsTextBlockArray = new TextBlock[3];
                FifthLocalOpsTextBlockArray[0] = new TextBlock();
                FifthLocalOpsTextBlockArray[1] = new TextBlock();
                FifthLocalOpsTextBlockArray[2] = new TextBlock();
                FifthLocalOpsTextBlockArray[0].Text = "MAC Key (Read Only)";
                FifthLocalOpsTextBlockArray[1].Text = "Encryption Key (Read Only)";
                FifthLocalOpsTextBlockArray[2].Text = "Choose an action";
                FifthLocalOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthLocalOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthLocalOpsTextBoxArray = new TextBox[2];
                FifthLocalOpsTextBoxArray[0] = new TextBox();
                FifthLocalOpsTextBoxArray[1] = new TextBox();
                FifthLocalOpsTextBoxArray[0].IsReadOnly = true;
                FifthLocalOpsTextBoxArray[1].IsReadOnly = true;
                FifthLocalOpsTextBoxArray[0].Width = 250;
                FifthLocalOpsTextBoxArray[0].MaxWidth = 250;
                FifthLocalOpsTextBoxArray[0].Height = 125;
                FifthLocalOpsTextBoxArray[0].MaxHeight = 125;
                FifthLocalOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FifthLocalOpsTextBoxArray[1].Width = 250;
                FifthLocalOpsTextBoxArray[1].MaxWidth = 250;
                FifthLocalOpsTextBoxArray[1].Height = 125;
                FifthLocalOpsTextBoxArray[1].MaxHeight = 125;
                FifthLocalOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FifthLocalOpsComboBoxArray = new ComboBox[1];
                FifthLocalOpsComboBoxArray[0] = new ComboBox();
                FifthLocalOpsComboBoxArray[0].Items.Add("Change Keys");
                FifthLocalOpsComboBoxArray[0].Items.Add("View Key");
                FifthLocalOpsButtonArray = new Button[1];
                FifthLocalOpsButtonArray[0] = new Button();
                FifthLocalOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthLocalOpsButtonArray[0].Content = "Perform Action";
                FifthLocalOpsButtonArray[0].Click += LocalOpsAppBTN_Click;
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsTextBlockArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsTextBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsTextBlockArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsTextBoxArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsTextBlockArray[2]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsComboBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(FifthLocalOpsButtonArray[0]);
                HasLocalOpsUIRendered = true;
            }
        }
        else if (LocalOpsUIChooser == 6)
        {
            if (HasLocalOpsUIRendered == false)
            {
                SixthLocalOpsTextBlockArray = new TextBlock[2];
                SixthLocalOpsTextBlockArray[0] = new TextBlock();
                SixthLocalOpsTextBlockArray[1] = new TextBlock();
                SixthLocalOpsTextBlockArray[0].Text = "Status (Read Only)";
                SixthLocalOpsTextBlockArray[1].Text = "Choose an action";
                SixthLocalOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthLocalOpsTextBoxArray = new TextBox[1];
                SixthLocalOpsTextBoxArray[0] = new TextBox();
                SixthLocalOpsTextBoxArray[0].IsReadOnly = true;
                SixthLocalOpsTextBoxArray[0].Width = 250;
                SixthLocalOpsTextBoxArray[0].MaxWidth = 250;
                SixthLocalOpsTextBoxArray[0].Height = 125;
                SixthLocalOpsTextBoxArray[0].MaxHeight = 125;
                SixthLocalOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SixthLocalOpsComboBoxArray = new ComboBox[1];
                SixthLocalOpsComboBoxArray[0] = new ComboBox();
                SixthLocalOpsComboBoxArray[0].Items.Add("Encrypt Data");
                SixthLocalOpsComboBoxArray[0].Items.Add("Decrypt Data");
                SixthLocalOpsComboBoxArray[0].Width = 250;
                SixthLocalOpsComboBoxArray[0].MaxWidth = 250;
                SixthLocalOpsButtonArray = new Button[1];
                SixthLocalOpsButtonArray[0] = new Button();
                SixthLocalOpsButtonArray[0].Content = "Perform Action";
                SixthLocalOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SixthLocalOpsButtonArray[0].Click += LocalOpsAppBTN_Click;
                NodeOpsLocalAppLowerRightSP.Children.Add(SixthLocalOpsTextBlockArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SixthLocalOpsTextBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SixthLocalOpsTextBlockArray[1]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SixthLocalOpsComboBoxArray[0]);
                NodeOpsLocalAppLowerRightSP.Children.Add(SixthLocalOpsButtonArray[0]);
                HasLocalOpsUIRendered = true;
            }
        }
        else 
        {
            LocalOpsAppResetUI();
        }
    }

    private void CommOpsAppDrawUI() 
    {
        if(CommOpsUIChooser == 1) 
        {
            if (HasCommOpsUIRendered == false) 
            {
                FirstCommOpsTextBlockArray = new TextBlock[4];
                FirstCommOpsTextBlockArray[0] = new TextBlock();
                FirstCommOpsTextBlockArray[1] = new TextBlock();
                FirstCommOpsTextBlockArray[2] = new TextBlock();
                FirstCommOpsTextBlockArray[3] = new TextBlock();
                FirstCommOpsTextBlockArray[0].Text = "Server one way KX public key";
                FirstCommOpsTextBlockArray[1].Text = "AU one way KX public key";
                FirstCommOpsTextBlockArray[2].Text = "Choose an algorithm";
                FirstCommOpsTextBlockArray[3].Text = "If keys exist then overwrite..";
                FirstCommOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCommOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCommOpsTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCommOpsTextBoxArray = new TextBox[2];
                FirstCommOpsTextBoxArray[0] = new TextBox();
                FirstCommOpsTextBoxArray[1] = new TextBox();
                FirstCommOpsTextBoxArray[0].IsReadOnly = true;
                FirstCommOpsTextBoxArray[0].Width = 250;
                FirstCommOpsTextBoxArray[0].MaxWidth = 250;
                FirstCommOpsTextBoxArray[0].Height = 125;
                FirstCommOpsTextBoxArray[0].MaxHeight = 125;
                FirstCommOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstCommOpsTextBoxArray[1].IsReadOnly = true;
                FirstCommOpsTextBoxArray[1].Width = 250;
                FirstCommOpsTextBoxArray[1].MaxWidth = 250;
                FirstCommOpsTextBoxArray[1].Height = 125;
                FirstCommOpsTextBoxArray[1].MaxHeight = 125;
                FirstCommOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstCommOpsRadioButtonArray = new RadioButton[2];
                FirstCommOpsRadioButtonArray[0] = new RadioButton();
                FirstCommOpsRadioButtonArray[1] = new RadioButton();
                FirstCommOpsRadioButtonArray[0].GroupName = "CurveTypes";
                FirstCommOpsRadioButtonArray[0].Content = "Curve25519 - X25519 (Stable)";
                FirstCommOpsRadioButtonArray[0].IsChecked = true;
                FirstCommOpsRadioButtonArray[1].GroupName = "CurveTypes";
                FirstCommOpsRadioButtonArray[1].Content = "Curve448 - X448 (Experimental)";
                FirstCommOpsButtonArray = new Button[1];
                FirstCommOpsButtonArray[0] = new Button();
                FirstCommOpsButtonArray[0].Content = "Generate KX Key Pairs";
                FirstCommOpsButtonArray[0].Click += CommOpsAppBTN_Click;
                FirstCommOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsTextBlockArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsTextBoxArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsTextBlockArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsTextBoxArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsTextBlockArray[2]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsRadioButtonArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsRadioButtonArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsButtonArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FirstCommOpsTextBlockArray[3]);
                HasCommOpsUIRendered = true;
            }
        }
        else if (CommOpsUIChooser == 2)
        {
            if (HasCommOpsUIRendered == false)
            {
                SecondCommOpsTextBlockArray = new TextBlock[2];
                SecondCommOpsTextBlockArray[0] = new TextBlock();
                SecondCommOpsTextBlockArray[1] = new TextBlock();
                SecondCommOpsTextBlockArray[0].Text = "Server one way KX public key";
                SecondCommOpsTextBlockArray[1].Text = "AU one way KX public key";
                SecondCommOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCommOpsTextBoxArray = new TextBox[2];
                SecondCommOpsTextBoxArray[0] = new TextBox();
                SecondCommOpsTextBoxArray[1] = new TextBox();
                SecondCommOpsTextBoxArray[0].IsReadOnly = true;
                SecondCommOpsTextBoxArray[0].Width = 250;
                SecondCommOpsTextBoxArray[0].MaxWidth = 250;
                SecondCommOpsTextBoxArray[0].Height = 125;
                SecondCommOpsTextBoxArray[0].MaxHeight = 125;
                SecondCommOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondCommOpsTextBoxArray[1].IsReadOnly = true;
                SecondCommOpsTextBoxArray[1].Width = 250;
                SecondCommOpsTextBoxArray[1].MaxWidth = 250;
                SecondCommOpsTextBoxArray[1].Height = 125;
                SecondCommOpsTextBoxArray[1].MaxHeight = 125;
                SecondCommOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondCommOpsButtonArray = new Button[1];
                SecondCommOpsButtonArray[0] = new Button();
                SecondCommOpsButtonArray[0].Content = "View KX Key Pairs";
                SecondCommOpsButtonArray[0].Click += CommOpsAppBTN_Click;
                SecondCommOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                NodeOpsCommAppLowerRightSP.Children.Add(SecondCommOpsTextBlockArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(SecondCommOpsTextBoxArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(SecondCommOpsTextBlockArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(SecondCommOpsTextBoxArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(SecondCommOpsButtonArray[0]);
                HasCommOpsUIRendered = true;
            }
        }
        else if (CommOpsUIChooser == 3)
        {
            if (HasCommOpsUIRendered == false)
            {
                ThirdCommOpsTextBlockArray = new TextBlock[1];
                ThirdCommOpsTextBlockArray[0] = new TextBlock();
                ThirdCommOpsTextBlockArray[0].Text = "Status (Read Only)";
                ThirdCommOpsTextBoxArray = new TextBox[1];
                ThirdCommOpsTextBoxArray[0] = new TextBox();
                ThirdCommOpsTextBoxArray[0].IsReadOnly = true;
                ThirdCommOpsTextBoxArray[0].Width = 250;
                ThirdCommOpsTextBoxArray[0].MaxWidth = 250;
                ThirdCommOpsTextBoxArray[0].Height = 125;
                ThirdCommOpsTextBoxArray[0].MaxHeight = 125;
                ThirdCommOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdCommOpsButtonArray = new Button[1];
                ThirdCommOpsButtonArray[0] = new Button();
                ThirdCommOpsButtonArray[0].Content = "Decrypt Data";
                ThirdCommOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdCommOpsButtonArray[0].Click += CommOpsAppBTN_Click;
                NodeOpsCommAppLowerRightSP.Children.Add(ThirdCommOpsTextBlockArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(ThirdCommOpsTextBoxArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(ThirdCommOpsButtonArray[0]);
                HasCommOpsUIRendered = true;
            }
        }
        else if (CommOpsUIChooser == 4)
        {
            if (HasCommOpsUIRendered == false)
            {
                FourthCommOpsTextBlockArray = new TextBlock[3];
                FourthCommOpsTextBlockArray[0] = new TextBlock();
                FourthCommOpsTextBlockArray[1] = new TextBlock();
                FourthCommOpsTextBlockArray[2] = new TextBlock();
                FourthCommOpsTextBlockArray[0].Text = "Server DSA public key";
                FourthCommOpsTextBlockArray[1].Text = "Choose an algorithm";
                FourthCommOpsTextBlockArray[2].Text = "If keys exist then overwrite..";
                FourthCommOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthCommOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthCommOpsTextBoxArray = new TextBox[1];
                FourthCommOpsTextBoxArray[0] = new TextBox();
                FourthCommOpsTextBoxArray[0].IsReadOnly = true;
                FourthCommOpsTextBoxArray[0].Width = 250;
                FourthCommOpsTextBoxArray[0].MaxWidth = 250;
                FourthCommOpsTextBoxArray[0].Height = 125;
                FourthCommOpsTextBoxArray[0].MaxHeight = 125;
                FourthCommOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FourthCommOpsRadioButtonArray = new RadioButton[2];
                FourthCommOpsRadioButtonArray[0] = new RadioButton();
                FourthCommOpsRadioButtonArray[1] = new RadioButton();
                FourthCommOpsRadioButtonArray[0].GroupName = "CurveTypes";
                FourthCommOpsRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                FourthCommOpsRadioButtonArray[0].IsChecked = true;
                FourthCommOpsRadioButtonArray[1].GroupName = "CurveTypes";
                FourthCommOpsRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                FourthCommOpsButtonArray = new Button[1];
                FourthCommOpsButtonArray[0] = new Button();
                FourthCommOpsButtonArray[0].Content = "Generate DSA Key Pairs";
                FourthCommOpsButtonArray[0].Click += CommOpsAppBTN_Click;
                FourthCommOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsTextBlockArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsTextBoxArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsTextBlockArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsRadioButtonArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsRadioButtonArray[1]);
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsButtonArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FourthCommOpsTextBlockArray[2]);
                HasCommOpsUIRendered = true;
            }
        }
        else if (CommOpsUIChooser == 5)
        {
            if (HasCommOpsUIRendered == false)
            {
                FifthCommOpsTextBlockArray = new TextBlock[1];
                FifthCommOpsTextBlockArray[0] = new TextBlock();
                FifthCommOpsTextBlockArray[0].Text = "Server and OOB DSA public keys";
                FifthCommOpsTextBoxArray = new TextBox[1];
                FifthCommOpsTextBoxArray[0] = new TextBox();
                FifthCommOpsTextBoxArray[0].IsReadOnly = true;
                FifthCommOpsTextBoxArray[0].Width = 250;
                FifthCommOpsTextBoxArray[0].MaxWidth = 250;
                FifthCommOpsTextBoxArray[0].Height = 125;
                FifthCommOpsTextBoxArray[0].MaxHeight = 125;
                FifthCommOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FifthCommOpsButtonArray = new Button[1];
                FifthCommOpsButtonArray[0] = new Button();
                FifthCommOpsButtonArray[0].Content = "View DSA Key Pairs";
                FifthCommOpsButtonArray[0].Click += CommOpsAppBTN_Click;
                FifthCommOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                NodeOpsCommAppLowerRightSP.Children.Add(FifthCommOpsTextBlockArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FifthCommOpsTextBoxArray[0]);
                NodeOpsCommAppLowerRightSP.Children.Add(FifthCommOpsButtonArray[0]);
                HasCommOpsUIRendered = true;
            }
        }
        else 
        {
            CommOpsAppResetUI();
        }
    }

    private void OOBOpsAppDrawUI() 
    {
        if (OOBOpsUIChooser == 1) 
        {
            if (HasOOBOpsUIRendered == false) 
            {
                FirstOOBOpsTextBlockArray = new TextBlock[2];
                FirstOOBOpsTextBlockArray[0] = new TextBlock();
                FirstOOBOpsTextBlockArray[1] = new TextBlock();
                FirstOOBOpsTextBlockArray[0].Text = "Challenge Length (>=16 Bytes)";
                FirstOOBOpsTextBlockArray[1].Text = "Challenge (Read Only)";
                FirstOOBOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsTextBoxArray = new TextBox[2];
                FirstOOBOpsTextBoxArray[0] = new TextBox();
                FirstOOBOpsTextBoxArray[0].Width = 250;
                FirstOOBOpsTextBoxArray[0].MaxWidth = 250;
                FirstOOBOpsTextBoxArray[0].Height = 125;
                FirstOOBOpsTextBoxArray[0].MaxHeight = 125;
                FirstOOBOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsTextBoxArray[1] = new TextBox();
                FirstOOBOpsTextBoxArray[1].IsReadOnly = true;
                FirstOOBOpsTextBoxArray[1].Width = 250;
                FirstOOBOpsTextBoxArray[1].MaxWidth = 250;
                FirstOOBOpsTextBoxArray[1].Height = 125;
                FirstOOBOpsTextBoxArray[1].MaxHeight = 125;
                FirstOOBOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsButtonArray = new Button[1];
                FirstOOBOpsButtonArray[0] = new Button();
                FirstOOBOpsButtonArray[0].Content = "Generate Challenge";
                FirstOOBOpsButtonArray[0].Click += OOBOpsAppBTN_Click;
                FirstOOBOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsButtonArray[0]);
                HasOOBOpsUIRendered = true;
            }
        }
        else if (OOBOpsUIChooser == 2)
        {
            if (HasOOBOpsUIRendered == false)
            {
                SecondOOBOpsTextBlockArray = new TextBlock[2];
                SecondOOBOpsTextBlockArray[0] = new TextBlock();
                SecondOOBOpsTextBlockArray[1] = new TextBlock();
                SecondOOBOpsTextBlockArray[0].Text = "Challenge (Base64)";
                SecondOOBOpsTextBlockArray[1].Text = "Signed Challenge (Read Only)";
                SecondOOBOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsTextBoxArray = new TextBox[2];
                SecondOOBOpsTextBoxArray[0] = new TextBox();
                SecondOOBOpsTextBoxArray[0].Width = 250;
                SecondOOBOpsTextBoxArray[0].MaxWidth = 250;
                SecondOOBOpsTextBoxArray[0].Height = 125;
                SecondOOBOpsTextBoxArray[0].MaxHeight = 125;
                SecondOOBOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsTextBoxArray[1] = new TextBox();
                SecondOOBOpsTextBoxArray[1].IsReadOnly = true;
                SecondOOBOpsTextBoxArray[1].Width = 250;
                SecondOOBOpsTextBoxArray[1].MaxWidth = 250;
                SecondOOBOpsTextBoxArray[1].Height = 125;
                SecondOOBOpsTextBoxArray[1].MaxHeight = 125;
                SecondOOBOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsButtonArray = new Button[1];
                SecondOOBOpsButtonArray[0] = new Button();
                SecondOOBOpsButtonArray[0].Content = "Sign Challenge";
                SecondOOBOpsButtonArray[0].Click += OOBOpsAppBTN_Click;
                SecondOOBOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsButtonArray[0]);
                HasOOBOpsUIRendered = true;
            }
        }
        else if (OOBOpsUIChooser == 3)
        {
            if (HasOOBOpsUIRendered == false)
            {
                ThirdOOBOpsTextBlockArray = new TextBlock[3];
                ThirdOOBOpsTextBlockArray[0] = new TextBlock();
                ThirdOOBOpsTextBlockArray[1] = new TextBlock();
                ThirdOOBOpsTextBlockArray[2] = new TextBlock();
                ThirdOOBOpsTextBlockArray[0].Text = "Signed Challenge (Base64)";
                ThirdOOBOpsTextBlockArray[1].Text = "DSA Public Key (Base64)";
                ThirdOOBOpsTextBlockArray[2].Text = "Verify Status (Read Only)";
                ThirdOOBOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsTextBoxArray = new TextBox[3];
                ThirdOOBOpsTextBoxArray[0] = new TextBox();
                ThirdOOBOpsTextBoxArray[0].Width = 250;
                ThirdOOBOpsTextBoxArray[0].MaxWidth = 250;
                ThirdOOBOpsTextBoxArray[0].Height = 125;
                ThirdOOBOpsTextBoxArray[0].MaxHeight = 125;
                ThirdOOBOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsTextBoxArray[1] = new TextBox();
                ThirdOOBOpsTextBoxArray[1].Width = 250;
                ThirdOOBOpsTextBoxArray[1].MaxWidth = 250;
                ThirdOOBOpsTextBoxArray[1].Height = 125;
                ThirdOOBOpsTextBoxArray[1].MaxHeight = 125;
                ThirdOOBOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsTextBoxArray[2] = new TextBox();
                ThirdOOBOpsTextBoxArray[2].IsReadOnly = true;
                ThirdOOBOpsTextBoxArray[2].Width = 250;
                ThirdOOBOpsTextBoxArray[2].MaxWidth = 250;
                ThirdOOBOpsTextBoxArray[2].Height = 125;
                ThirdOOBOpsTextBoxArray[2].MaxHeight = 125;
                ThirdOOBOpsTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsButtonArray = new Button[1];
                ThirdOOBOpsButtonArray[0] = new Button();
                ThirdOOBOpsButtonArray[0].Content = "Verify Signed Challenge";
                ThirdOOBOpsButtonArray[0].Click += OOBOpsAppBTN_Click;
                ThirdOOBOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsButtonArray[0]);
                HasOOBOpsUIRendered = true;
            }
        }
        else 
        {
            OOBOpsAppResetUI();
        }
    }

    private void LocalOpsAppResetUI() 
    {
        FirstLocalOpsTextBlockArray = new TextBlock[] { };
        FirstLocalOpsTextBoxArray = new TextBox[] { };
        FirstLocalOpsButtonArray = new Button[] { };
        SecondLocalOpsTextBlockArray = new TextBlock[] { };
        SecondLocalOpsTextBoxArray = new TextBox[] { };
        SecondLocalOpsComboBoxArray = new ComboBox[] { };
        SecondLocalOpsButtonArray = new Button[] { };
        ThirdLocalOpsTextBlockArray = new TextBlock[] { };
        ThirdLocalOpsTextBoxArray = new TextBox[] { };
        ThirdLocalOpsComboBoxArray = new ComboBox[] { };
        ThirdLocalOpsButtonArray = new Button[] { };
        FourthLocalOpsTextBlockArray = new TextBlock[] { };
        FourthLocalOpsTextBoxArray = new TextBox[] { };
        FourthLocalOpsButtonArray = new Button[] { };
        FifthLocalOpsTextBlockArray = new TextBlock[] { };
        FifthLocalOpsTextBoxArray = new TextBox[] { };
        FifthLocalOpsComboBoxArray = new ComboBox[] { };
        FifthLocalOpsButtonArray = new Button[] { };
        SixthLocalOpsTextBlockArray = new TextBlock[] { };
        SixthLocalOpsTextBoxArray = new TextBox[] { };
        SixthLocalOpsComboBoxArray = new ComboBox[] { };
        SixthLocalOpsButtonArray = new Button[] { };
        HasLocalOpsUIRendered = false;
        LocalOpsUIChooser = 0;
        NodeOpsLocalAppLowerRightSP.Children.Clear();
    }

    private void CommOpsAppResetUI() 
    {
        FirstCommOpsTextBlockArray = new TextBlock[] { };
        FirstCommOpsTextBoxArray = new TextBox[] { };
        FirstCommOpsRadioButtonArray = new RadioButton[] { };
        FirstCommOpsButtonArray = new Button[] { };
        SecondCommOpsTextBlockArray = new TextBlock[] { };
        SecondCommOpsTextBoxArray = new TextBox[] { };
        SecondCommOpsButtonArray = new Button[] { };
        ThirdCommOpsTextBlockArray = new TextBlock[] { };
        ThirdCommOpsTextBoxArray = new TextBox[] { };
        ThirdCommOpsButtonArray = new Button[] { };
        FourthCommOpsTextBlockArray = new TextBlock[] { };
        FourthCommOpsTextBoxArray = new TextBox[] { };
        FourthCommOpsRadioButtonArray = new RadioButton[] { };
        FourthCommOpsButtonArray = new Button[] { };
        FifthCommOpsTextBlockArray = new TextBlock[] { };
        FifthCommOpsTextBoxArray = new TextBox[] { };
        FifthCommOpsButtonArray = new Button[] { };
        HasCommOpsUIRendered = false;
        CommOpsUIChooser = 0;
        NodeOpsCommAppLowerRightSP.Children.Clear();
    }

    private void OOBOpsAppResetUI() 
    {
        FirstOOBOpsTextBlockArray = new TextBlock[] { };
        FirstOOBOpsTextBoxArray = new TextBox[] { };
        FirstOOBOpsButtonArray = new Button[] { };
        SecondOOBOpsTextBlockArray = new TextBlock[] { };
        SecondOOBOpsTextBoxArray = new TextBox[] { };
        SecondOOBOpsButtonArray = new Button[] { };
        ThirdOOBOpsTextBlockArray = new TextBlock[] { };
        ThirdOOBOpsTextBoxArray = new TextBox[] { };
        ThirdOOBOpsButtonArray = new Button[] { };
        HasOOBOpsUIRendered = false;
        OOBOpsUIChooser = 0;
        OOBOpsAppLowerRightSP.Children.Clear();
    }

    private void LocalOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(LocalOpsUIChooser == 1) 
        {
            Byte[] EncryptionSecretKeySeed = SodiumRNG.GetRandomBytes(32);
            Byte[] MACSecretKeySeed = SodiumRNG.GetRandomBytes(32);
            String OriginalHexaEncodedEncryptionSecretKeySeed = SodiumHelper.BinaryToHex(EncryptionSecretKeySeed);
            String OriginalHexaEncodedMACSecretKeySeed = SodiumHelper.BinaryToHex(MACSecretKeySeed);
            String EncodedEncryptionSecretKeySeedHexaString = "";
            String EncodedMACSecretKeySeedHexaString = "";
            int Loop = 0;
            while(Loop < OriginalHexaEncodedEncryptionSecretKeySeed.Length) 
            {
                if (Loop + 2 > OriginalHexaEncodedEncryptionSecretKeySeed.Length - 1) 
                {
                    EncodedEncryptionSecretKeySeedHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKeySeed.Substring(Loop, 2);
                    EncodedMACSecretKeySeedHexaString += "0x" + OriginalHexaEncodedMACSecretKeySeed.Substring(Loop, 2);
                }
                else 
                {
                    EncodedEncryptionSecretKeySeedHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKeySeed.Substring(Loop, 2)+",";
                    EncodedMACSecretKeySeedHexaString += "0x" + OriginalHexaEncodedMACSecretKeySeed.Substring(Loop, 2)+",";
                }
                Loop += 2;
            }
            FirstLocalOpsTextBoxArray[0].Text = EncodedMACSecretKeySeedHexaString;
            FirstLocalOpsTextBoxArray[1].Text = EncodedEncryptionSecretKeySeedHexaString;
            File.WriteAllBytes(LocalOpsMainRootFolder + "ServerEncryptionKeySeed.txt",EncryptionSecretKeySeed);
            File.WriteAllBytes(LocalOpsMainRootFolder + "ServerMACKeySeed.txt", MACSecretKeySeed);
            SodiumSecureMemory.SecureClearBytes(EncryptionSecretKeySeed);
            SodiumSecureMemory.SecureClearBytes(MACSecretKeySeed);
            SodiumSecureMemory.SecureClearString(OriginalHexaEncodedEncryptionSecretKeySeed);
            SodiumSecureMemory.SecureClearString(OriginalHexaEncodedMACSecretKeySeed);
        }
        else if(LocalOpsUIChooser == 2) 
        {
            if (SecondLocalOpsComboBoxArray[0].SelectedIndex != -1) 
            {
                if (SecondLocalOpsComboBoxArray[0].SelectedIndex == 0) 
                {
                    Byte[] EncryptionSecretKeySeed = SodiumRNG.GetRandomBytes(32);
                    Byte[] MACSecretKeySeed = SodiumRNG.GetRandomBytes(32);
                    String OriginalHexaEncodedEncryptionSecretKeySeed = SodiumHelper.BinaryToHex(EncryptionSecretKeySeed);
                    String OriginalHexaEncodedMACSecretKeySeed = SodiumHelper.BinaryToHex(MACSecretKeySeed);
                    String EncodedEncryptionSecretKeySeedHexaString = "";
                    String EncodedMACSecretKeySeedHexaString = "";
                    int Loop = 0;
                    while (Loop < OriginalHexaEncodedEncryptionSecretKeySeed.Length)
                    {
                        if (Loop + 2 > OriginalHexaEncodedEncryptionSecretKeySeed.Length - 1)
                        {
                            EncodedEncryptionSecretKeySeedHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKeySeed.Substring(Loop, 2);
                            EncodedMACSecretKeySeedHexaString += "0x" + OriginalHexaEncodedMACSecretKeySeed.Substring(Loop, 2);
                        }
                        else
                        {
                            EncodedEncryptionSecretKeySeedHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKeySeed.Substring(Loop, 2) + ",";
                            EncodedMACSecretKeySeedHexaString += "0x" + OriginalHexaEncodedMACSecretKeySeed.Substring(Loop, 2) + ",";
                        }
                        Loop += 2;
                    }
                    SecondLocalOpsTextBoxArray[0].Text = EncodedMACSecretKeySeedHexaString;
                    SecondLocalOpsTextBoxArray[1].Text = EncodedEncryptionSecretKeySeedHexaString;
                    File.WriteAllBytes(LocalOpsMainRootFolder + "ServerEncryptionKeySeed.txt", EncryptionSecretKeySeed);
                    File.WriteAllBytes(LocalOpsMainRootFolder + "ServerMACKeySeed.txt", MACSecretKeySeed);
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKeySeed);
                    SodiumSecureMemory.SecureClearBytes(MACSecretKeySeed);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedEncryptionSecretKeySeed);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedMACSecretKeySeed);
                }
                else 
                {
                    Byte[] EncryptionSecretKeySeed = File.ReadAllBytes(LocalOpsMainRootFolder + "ServerEncryptionKeySeed.txt");
                    Byte[] MACSecretKeySeed = File.ReadAllBytes(LocalOpsMainRootFolder + "ServerMACKeySeed.txt");
                    String OriginalHexaEncodedEncryptionSecretKeySeed = SodiumHelper.BinaryToHex(EncryptionSecretKeySeed);
                    String OriginalHexaEncodedMACSecretKeySeed = SodiumHelper.BinaryToHex(MACSecretKeySeed);
                    String EncodedEncryptionSecretKeySeedHexaString = "";
                    String EncodedMACSecretKeySeedHexaString = "";
                    int Loop = 0;
                    while (Loop < OriginalHexaEncodedEncryptionSecretKeySeed.Length)
                    {
                        if (Loop + 2 > OriginalHexaEncodedEncryptionSecretKeySeed.Length - 1)
                        {
                            EncodedEncryptionSecretKeySeedHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKeySeed.Substring(Loop, 2);
                            EncodedMACSecretKeySeedHexaString += "0x" + OriginalHexaEncodedMACSecretKeySeed.Substring(Loop, 2);
                        }
                        else
                        {
                            EncodedEncryptionSecretKeySeedHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKeySeed.Substring(Loop, 2) + ",";
                            EncodedMACSecretKeySeedHexaString += "0x" + OriginalHexaEncodedMACSecretKeySeed.Substring(Loop, 2) + ",";
                        }
                        Loop += 2;
                    }
                    SecondLocalOpsTextBoxArray[0].Text = EncodedMACSecretKeySeedHexaString;
                    SecondLocalOpsTextBoxArray[1].Text = EncodedEncryptionSecretKeySeedHexaString;
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKeySeed);
                    SodiumSecureMemory.SecureClearBytes(MACSecretKeySeed);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedEncryptionSecretKeySeed);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedMACSecretKeySeed);
                }
            }
        }
        else if(LocalOpsUIChooser == 3) 
        {
            if (ThirdLocalOpsComboBoxArray[0].SelectedIndex != -1) 
            {
                if(File.Exists(LocalOpsMainRootFolder + "ServerEncryptionKeySeed.txt") ==true && File.Exists(LocalOpsMainRootFolder + "ServerMACKeySeed.txt") == true) 
                {
                    Byte[] EncryptionSecretKeySeed = File.ReadAllBytes(LocalOpsMainRootFolder + "ServerEncryptionKeySeed.txt");
                    Byte[] MACSecretKeySeed = File.ReadAllBytes(LocalOpsMainRootFolder + "ServerMACKeySeed.txt");
                    if(EncryptionSecretKeySeed.Length==32 && MACSecretKeySeed.Length == 32) 
                    {
                        Byte[] TemporaryEncryptionSecretKey = SodiumRNG.GetSeededRandomBytes(32, EncryptionSecretKeySeed);
                        Byte[] TemporaryMACSecretKey = SodiumRNG.GetSeededRandomBytes(32,MACSecretKeySeed);
                        int Loop = 0;
                        String[] FilesPath = new String[] { };
                        Byte[] EncryptedBuffBytesWithMAC = new Byte[] { };
                        Byte[] BuffBytes = new Byte[] { };
                        Byte[] EncryptedBuffBytes = new Byte[] { };
                        Byte[] EncryptedBuffBytesMAC = new Byte[] { };
                        Byte[] DecryptedBuffBytes = new Byte[] { };
                        Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
                        Byte[] HashedTempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
                        String FilteredFilePath = "";
                        String FinalFilePath = "";
                        Boolean AbleToVerifyHMAC = true;
                        if (ThirdLocalOpsComboBoxArray[0].SelectedIndex == 0)
                        {
                            FilesPath = Directory.GetFiles(LocalOpsDataToBeEncryptedFolder);
                            while (Loop < FilesPath.Length) 
                            {
                                BuffBytes = File.ReadAllBytes(FilesPath[Loop]);
                                if (FilesPath[Loop].Contains("EncryptionSecretKey.txt") == true || FilesPath[Loop].Contains("MACSecretKey.txt") == true) 
                                {
                                    if (FilesPath[Loop].Contains("MACSecretKey.txt") == true) 
                                    {
                                        EncryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(BuffBytes,Nonce1,TemporaryEncryptionSecretKey);
                                    }
                                    else 
                                    {
                                        EncryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(BuffBytes, Nonce2, TemporaryEncryptionSecretKey);
                                    }
                                }
                                else 
                                {
                                    EncryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(BuffBytes, HashedTempNonce, TemporaryEncryptionSecretKey);
                                }
                                EncryptedBuffBytesMAC = SodiumHMACSHA512.ComputeMAC(EncryptedBuffBytes, TemporaryMACSecretKey);
                                EncryptedBuffBytesWithMAC = EncryptedBuffBytesMAC.Concat(EncryptedBuffBytes).ToArray();
                                FilteredFilePath = FilesPath[Loop].Remove(0,LocalOpsDataToBeEncryptedFolder.Length);
                                FinalFilePath = LocalOpsEncryptFolder + FilteredFilePath;
                                File.WriteAllBytes(FinalFilePath, EncryptedBuffBytesWithMAC);
                                Loop += 1;
                            }
                            ThirdLocalOpsTextBoxArray[0].Text = "All data had been encrypted";
                        }
                        else
                        {
                            FilesPath = Directory.GetFiles(LocalOpsEncryptFolder);
                            while (Loop < FilesPath.Length) 
                            {
                                EncryptedBuffBytesWithMAC = File.ReadAllBytes(FilesPath[Loop]);
                                EncryptedBuffBytes = new Byte[EncryptedBuffBytesWithMAC.Length - 64];
                                EncryptedBuffBytesMAC = new Byte[64];
                                Array.Copy(EncryptedBuffBytesWithMAC, 0, EncryptedBuffBytesMAC, 0, 64);
                                Array.Copy(EncryptedBuffBytesWithMAC, 64, EncryptedBuffBytes, 0, EncryptedBuffBytes.Length);
                                AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(EncryptedBuffBytesMAC, EncryptedBuffBytes, TemporaryMACSecretKey);
                                if (AbleToVerifyHMAC) 
                                {
                                    if (FilesPath[Loop].Contains("EncryptionSecretKey.txt") == true || FilesPath[Loop].Contains("MACSecretKey.txt") == true)
                                    {
                                        if (FilesPath[Loop].Contains("MACSecretKey.txt") == true)
                                        {
                                            DecryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(EncryptedBuffBytes, Nonce1, TemporaryEncryptionSecretKey);
                                        }
                                        else
                                        {
                                            DecryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(EncryptedBuffBytes, Nonce2, TemporaryEncryptionSecretKey);
                                        }
                                    }
                                    else
                                    {
                                        DecryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(EncryptedBuffBytes, HashedTempNonce, TemporaryEncryptionSecretKey);
                                    }
                                }
                                else 
                                {
                                    break;
                                }
                                FilteredFilePath = FilesPath[Loop].Remove(0,LocalOpsEncryptFolder.Length);
                                FinalFilePath = LocalOpsDecryptFolder + FilteredFilePath;
                                File.WriteAllBytes(FinalFilePath, DecryptedBuffBytes);
                                Loop += 1;
                            }
                            if (AbleToVerifyHMAC == true) 
                            {
                                ThirdLocalOpsTextBoxArray[0].Text = "All data had been decrypted";
                            }
                            else 
                            {
                                ThirdLocalOpsTextBoxArray[0].Text = "Error: Some data can't be decrypt";
                            }
                        }
                        SodiumSecureMemory.SecureClearBytes(TemporaryEncryptionSecretKey);
                        SodiumSecureMemory.SecureClearBytes(TemporaryMACSecretKey);
                    }
                    else 
                    {
                        ThirdLocalOpsTextBoxArray[0].Text = "Error: Two seeds files were empty";
                    }
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKeySeed);
                    SodiumSecureMemory.SecureClearBytes(MACSecretKeySeed);
                }
                else 
                {
                    ThirdLocalOpsTextBoxArray[0].Text = "Error: Two seeds file don't exist";
                }
            }
        }
        else if(LocalOpsUIChooser == 4) 
        {
            Byte[] EncryptionSecretKey = SodiumRNG.GetRandomBytes(32);
            Byte[] MACSecretKey = SodiumRNG.GetRandomBytes(32);
            String OriginalHexaEncodedEncryptionSecretKey = SodiumHelper.BinaryToHex(EncryptionSecretKey);
            String OriginalHexaEncodedMACSecretKey = SodiumHelper.BinaryToHex(MACSecretKey);
            String EncodedEncryptionSecretKeyHexaString = "";
            String EncodedMACSecretKeyHexaString = "";
            int Loop = 0;
            while (Loop < OriginalHexaEncodedEncryptionSecretKey.Length)
            {
                if (Loop + 2 > OriginalHexaEncodedEncryptionSecretKey.Length - 1)
                {
                    EncodedEncryptionSecretKeyHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKey.Substring(Loop, 2);
                    EncodedMACSecretKeyHexaString += "0x" + OriginalHexaEncodedMACSecretKey.Substring(Loop, 2);
                }
                else
                {
                    EncodedEncryptionSecretKeyHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKey.Substring(Loop, 2) + ",";
                    EncodedMACSecretKeyHexaString += "0x" + OriginalHexaEncodedMACSecretKey.Substring(Loop, 2) + ",";
                }
                Loop += 2;
            }
            FourthLocalOpsTextBoxArray[0].Text = EncodedMACSecretKeyHexaString;
            FourthLocalOpsTextBoxArray[1].Text = EncodedEncryptionSecretKeyHexaString;
            File.WriteAllBytes(LocalOpsMainRootFolder + "EncryptionSecretKey.txt", EncryptionSecretKey);
            File.WriteAllBytes(LocalOpsMainRootFolder + "MACSecretKey.txt", MACSecretKey);
            SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
            SodiumSecureMemory.SecureClearBytes(MACSecretKey);
            SodiumSecureMemory.SecureClearString(OriginalHexaEncodedEncryptionSecretKey);
            SodiumSecureMemory.SecureClearString(OriginalHexaEncodedMACSecretKey);
        }
        else if(LocalOpsUIChooser == 5) 
        {
            if (FifthLocalOpsComboBoxArray[0].SelectedIndex != -1) 
            {
                if (FifthLocalOpsComboBoxArray[0].SelectedIndex == 0) 
                {
                    Byte[] EncryptionSecretKey = SodiumRNG.GetRandomBytes(32);
                    Byte[] MACSecretKey = SodiumRNG.GetRandomBytes(32);
                    String OriginalHexaEncodedEncryptionSecretKey = SodiumHelper.BinaryToHex(EncryptionSecretKey);
                    String OriginalHexaEncodedMACSecretKey = SodiumHelper.BinaryToHex(MACSecretKey);
                    String EncodedEncryptionSecretKeyHexaString = "";
                    String EncodedMACSecretKeyHexaString = "";
                    int Loop = 0;
                    while (Loop < OriginalHexaEncodedEncryptionSecretKey.Length)
                    {
                        if (Loop + 2 > OriginalHexaEncodedEncryptionSecretKey.Length - 1)
                        {
                            EncodedEncryptionSecretKeyHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKey.Substring(Loop, 2);
                            EncodedMACSecretKeyHexaString += "0x" + OriginalHexaEncodedMACSecretKey.Substring(Loop, 2);
                        }
                        else
                        {
                            EncodedEncryptionSecretKeyHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKey.Substring(Loop, 2) + ",";
                            EncodedMACSecretKeyHexaString += "0x" + OriginalHexaEncodedMACSecretKey.Substring(Loop, 2) + ",";
                        }
                        Loop += 2;
                    }
                    FifthLocalOpsTextBoxArray[0].Text = EncodedMACSecretKeyHexaString;
                    FifthLocalOpsTextBoxArray[1].Text = EncodedEncryptionSecretKeyHexaString;
                    File.WriteAllBytes(LocalOpsMainRootFolder + "EncryptionSecretKey.txt", EncryptionSecretKey);
                    File.WriteAllBytes(LocalOpsMainRootFolder + "MACSecretKey.txt", MACSecretKey);
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
                    SodiumSecureMemory.SecureClearBytes(MACSecretKey);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedEncryptionSecretKey);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedMACSecretKey);
                }
                else 
                {
                    Byte[] EncryptionSecretKey = File.ReadAllBytes(LocalOpsMainRootFolder + "EncryptionSecretKey.txt");
                    Byte[] MACSecretKey = File.ReadAllBytes(LocalOpsMainRootFolder + "MACSecretKey.txt");
                    String OriginalHexaEncodedEncryptionSecretKey = SodiumHelper.BinaryToHex(EncryptionSecretKey);
                    String OriginalHexaEncodedMACSecretKey = SodiumHelper.BinaryToHex(MACSecretKey);
                    String EncodedEncryptionSecretKeyHexaString = "";
                    String EncodedMACSecretKeyHexaString = "";
                    int Loop = 0;
                    while (Loop < OriginalHexaEncodedEncryptionSecretKey.Length)
                    {
                        if (Loop + 2 > OriginalHexaEncodedEncryptionSecretKey.Length - 1)
                        {
                            EncodedEncryptionSecretKeyHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKey.Substring(Loop, 2);
                            EncodedMACSecretKeyHexaString += "0x" + OriginalHexaEncodedMACSecretKey.Substring(Loop, 2);
                        }
                        else
                        {
                            EncodedEncryptionSecretKeyHexaString += "0x" + OriginalHexaEncodedEncryptionSecretKey.Substring(Loop, 2) + ",";
                            EncodedMACSecretKeyHexaString += "0x" + OriginalHexaEncodedMACSecretKey.Substring(Loop, 2) + ",";
                        }
                        Loop += 2;
                    }
                    FifthLocalOpsTextBoxArray[0].Text = EncodedMACSecretKeyHexaString;
                    FifthLocalOpsTextBoxArray[1].Text = EncodedEncryptionSecretKeyHexaString;
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
                    SodiumSecureMemory.SecureClearBytes(MACSecretKey);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedEncryptionSecretKey);
                    SodiumSecureMemory.SecureClearString(OriginalHexaEncodedMACSecretKey);
                }
            }
        }
        else if(LocalOpsUIChooser == 6) 
        {
            if (SixthLocalOpsComboBoxArray[0].SelectedIndex != -1) 
            {
                if (File.Exists(LocalOpsMainRootFolder + "EncryptionSecretKey.txt") == true && File.Exists(LocalOpsMainRootFolder + "MACSecretKey.txt") == true)
                {
                    Byte[] EncryptionSecretKey = File.ReadAllBytes(LocalOpsMainRootFolder + "EncryptionSecretKey.txt");
                    Byte[] MACSecretKey = File.ReadAllBytes(LocalOpsMainRootFolder + "MACSecretKey.txt");
                    if (EncryptionSecretKey.Length == 32 && MACSecretKey.Length == 32)
                    {
                        int Loop = 0;
                        String[] FilesPath = new String[] { };
                        Byte[] EncryptedBuffBytesWithMAC = new Byte[] { };
                        Byte[] BuffBytes = new Byte[] { };
                        Byte[] EncryptedBuffBytes = new Byte[] { };
                        Byte[] EncryptedBuffBytesMAC = new Byte[] { };
                        Byte[] DecryptedBuffBytes = new Byte[] { };
                        Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
                        Byte[] HashedTempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
                        String FilteredFilePath = "";
                        String FinalFilePath = "";
                        Boolean AbleToVerifyHMAC = true;
                        if (SixthLocalOpsComboBoxArray[0].SelectedIndex == 0)
                        {
                            FilesPath = Directory.GetFiles(LocalOpsDataToBeEncryptedFolder);
                            while (Loop < FilesPath.Length)
                            {
                                BuffBytes = File.ReadAllBytes(FilesPath[Loop]);
                                EncryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(BuffBytes, HashedTempNonce, EncryptionSecretKey);
                                EncryptedBuffBytesMAC = SodiumHMACSHA512.ComputeMAC(EncryptedBuffBytes, MACSecretKey);
                                EncryptedBuffBytesWithMAC = EncryptedBuffBytesMAC.Concat(EncryptedBuffBytes).ToArray();
                                FilteredFilePath = FilesPath[Loop].Remove(0,LocalOpsDataToBeEncryptedFolder.Length);
                                FinalFilePath = LocalOpsEncryptFolder + FilteredFilePath;
                                File.WriteAllBytes(FinalFilePath, EncryptedBuffBytesWithMAC);
                                Loop += 1;
                            }
                            SixthLocalOpsTextBoxArray[0].Text = "All data had been encrypted";
                        }
                        else
                        {
                            FilesPath = Directory.GetFiles(LocalOpsEncryptFolder);
                            while (Loop < FilesPath.Length)
                            {
                                EncryptedBuffBytesWithMAC = File.ReadAllBytes(FilesPath[Loop]);
                                EncryptedBuffBytes = new Byte[EncryptedBuffBytesWithMAC.Length - 64];
                                EncryptedBuffBytesMAC = new Byte[64];
                                Array.Copy(EncryptedBuffBytesWithMAC, 0, EncryptedBuffBytesMAC, 0, 64);
                                Array.Copy(EncryptedBuffBytesWithMAC, 64, EncryptedBuffBytes, 0, EncryptedBuffBytes.Length);
                                AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(EncryptedBuffBytesMAC, EncryptedBuffBytes, MACSecretKey);
                                if (AbleToVerifyHMAC)
                                {
                                    DecryptedBuffBytes = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(EncryptedBuffBytes, HashedTempNonce, EncryptionSecretKey);
                                }
                                else
                                {
                                    break;
                                }
                                FilteredFilePath = FilesPath[Loop].Remove(0, LocalOpsEncryptFolder.Length);
                                FinalFilePath = LocalOpsDecryptFolder + FilteredFilePath;
                                File.WriteAllBytes(FinalFilePath, DecryptedBuffBytes);
                                Loop += 1;
                            }
                            if (AbleToVerifyHMAC == true)
                            {
                                SixthLocalOpsTextBoxArray[0].Text = "All data had been decrypted";
                            }
                            else
                            {
                                SixthLocalOpsTextBoxArray[0].Text = "Error: Some data can't be decrypt";
                            }
                        }
                    }
                    else
                    {
                        SixthLocalOpsTextBoxArray[0].Text = "Error: Two secret keys' file were empty";
                    }
                    SodiumSecureMemory.SecureClearBytes(EncryptionSecretKey);
                    SodiumSecureMemory.SecureClearBytes(MACSecretKey);
                }
                else
                {
                    SixthLocalOpsTextBoxArray[0].Text = "Error: Two secret keys' file don't exist";
                }
            }
        }
    }

    private void CommOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(CommOpsUIChooser == 1) 
        {
            String ServerSealedPublicKeys = "";
            String AUSealedPublicKeys = "";
            if (FirstCommOpsRadioButtonArray[0].IsChecked == true) 
            {
                RevampedKeyPair ServerSealedMACKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                RevampedKeyPair ServerSealedEncryptionKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                RevampedKeyPair AUSealedMACKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                RevampedKeyPair AUSealedEncryptionKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                ServerSealedPublicKeys = Convert.ToBase64String(ServerSealedMACKeyPair.PublicKey) + ";" + Convert.ToBase64String(ServerSealedEncryptionKeyPair.PublicKey);
                AUSealedPublicKeys = Convert.ToBase64String(AUSealedMACKeyPair.PublicKey) + ";" + Convert.ToBase64String(AUSealedEncryptionKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedMACPrivateKey.txt",ServerSealedMACKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedMACPublicKey.txt",ServerSealedMACKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPrivateKey.txt",ServerSealedEncryptionKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPublicKey.txt",ServerSealedEncryptionKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedMACPrivateKey.txt",AUSealedMACKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedMACPublicKey.txt",AUSealedMACKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPrivateKey.txt",AUSealedEncryptionKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPublicKey.txt",AUSealedEncryptionKeyPair.PublicKey);
                ServerSealedMACKeyPair.Clear();
                ServerSealedEncryptionKeyPair.Clear();
                AUSealedMACKeyPair.Clear();
                AUSealedEncryptionKeyPair.Clear();
            }
            else 
            {
                X448RevampedKeyPair ServerSealedMACKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                X448RevampedKeyPair ServerSealedEncryptionKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                X448RevampedKeyPair AUSealedMACKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                X448RevampedKeyPair AUSealedEncryptionKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                ServerSealedPublicKeys = Convert.ToBase64String(ServerSealedMACKeyPair.PublicKey) + ";" + Convert.ToBase64String(ServerSealedEncryptionKeyPair.PublicKey);
                AUSealedPublicKeys = Convert.ToBase64String(AUSealedMACKeyPair.PublicKey) + ";" + Convert.ToBase64String(AUSealedEncryptionKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedMACPrivateKey.txt", ServerSealedMACKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedMACPublicKey.txt", ServerSealedMACKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPrivateKey.txt", ServerSealedEncryptionKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPublicKey.txt", ServerSealedEncryptionKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedMACPrivateKey.txt", AUSealedMACKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedMACPublicKey.txt", AUSealedMACKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPrivateKey.txt", AUSealedEncryptionKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPublicKey.txt", AUSealedEncryptionKeyPair.PublicKey);
                ServerSealedMACKeyPair.Clear();
                ServerSealedEncryptionKeyPair.Clear();
                AUSealedMACKeyPair.Clear();
                AUSealedEncryptionKeyPair.Clear();
            }
            FirstCommOpsTextBoxArray[0].Text = ServerSealedPublicKeys;
            FirstCommOpsTextBoxArray[1].Text = AUSealedPublicKeys;
        }
        else if(CommOpsUIChooser == 2) 
        {
            String ServerSealedPublicKeys = "";
            String AUSealedPublicKeys = "";
            Byte[] ServerSealedMACPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "ServerSealedMACPublicKey.txt");
            Byte[] ServerSealedEncryptionPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPublicKey.txt");
            Byte[] AUSealedMACPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "AUSealedMACPublicKey.txt");
            Byte[] AUSealedEncryptionPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPublicKey.txt");
            ServerSealedPublicKeys = Convert.ToBase64String(ServerSealedMACPublicKey) + ";" + Convert.ToBase64String(ServerSealedEncryptionPublicKey);
            AUSealedPublicKeys = Convert.ToBase64String(AUSealedMACPublicKey) + ";" + Convert.ToBase64String(AUSealedEncryptionPublicKey);
            SecondCommOpsTextBoxArray[0].Text = ServerSealedPublicKeys;
            SecondCommOpsTextBoxArray[1].Text = AUSealedPublicKeys;
        }
        else if(CommOpsUIChooser == 3) 
        {
            Byte[] ServerSealedMACPrivateKey = File.ReadAllBytes(CommOpsMainRootFolder + "ServerSealedMACPrivateKey.txt");
            Byte[] ServerSealedEncryptionPrivateKey = File.ReadAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPrivateKey.txt");
            Byte[] AUSealedMACPrivateKey = File.ReadAllBytes(CommOpsMainRootFolder + "AUSealedMACPrivateKey.txt");
            Byte[] AUSealedEncryptionPrivateKey = File.ReadAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPrivateKey.txt");
            Byte[] ServerSealedMACPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "ServerSealedMACPublicKey.txt");
            Byte[] ServerSealedEncryptionPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "ServerSealedEncryptionPublicKey.txt");
            Byte[] AUSealedMACPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "AUSealedMACPublicKey.txt");
            Byte[] AUSealedEncryptionPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "AUSealedEncryptionPublicKey.txt");
            String[] FilesPath = Directory.GetFiles(CommOpsEncryptFolder);
            Byte[] EncryptedFileBytesWithMAC = new Byte[] { };
            Byte[] EncryptedFileBytes = new Byte[] { };
            Byte[] EncryptedFileBytesMAC = new Byte[64];
            Byte[] DecryptedFileBytes = new Byte[] { };
            Byte[] TempNonce = new Byte[] { };
            Byte[] EphemeralMACPublicKey = new Byte[] { };
            Byte[] EphemeralEncryptionPublicKey = new Byte[] { };
            Byte[] TemporaryMACSharedSecret = new Byte[] { };
            Byte[] TemporaryEncryptionSharedSecret = new Byte[] { };
            Byte[] ActualMACSharedSecret = new Byte[] { };
            Byte[] ActualEncryptionSharedSecret = new Byte[] { };
            int Loop = 0;
            Boolean AbleToVerifyHMAC = true;
            String FilteredFilePath = "";
            String FinalFilePath = "";
            while (Loop < FilesPath.Length) 
            {
                EncryptedFileBytesWithMAC = File.ReadAllBytes(FilesPath[Loop]);
                EphemeralMACPublicKey = new Byte[ServerSealedMACPrivateKey.Length];
                EphemeralEncryptionPublicKey = new Byte[ServerSealedEncryptionPrivateKey.Length];
                Array.Copy(EncryptedFileBytesWithMAC, 0, EphemeralMACPublicKey, 0, EphemeralMACPublicKey.Length);
                Array.Copy(EncryptedFileBytesWithMAC, EphemeralMACPublicKey.Length, EphemeralEncryptionPublicKey, 0, EphemeralEncryptionPublicKey.Length);
                if (FilesPath[Loop].Contains("EncryptedNodeSPrivateKey.txt") == true) 
                {
                    TempNonce = ServerSealedMACPublicKey.Concat(ServerSealedEncryptionPublicKey).Concat(EphemeralMACPublicKey).Concat(EphemeralEncryptionPublicKey).ToArray();
                    TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
                    if (ServerSealedEncryptionPrivateKey.Length == 32) 
                    {
                        ActualMACSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(ServerSealedMACPrivateKey, EphemeralMACPublicKey);
                        ActualEncryptionSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(ServerSealedEncryptionPrivateKey, EphemeralEncryptionPublicKey);
                    }
                    else 
                    {
                        TemporaryMACSharedSecret = SecureX448.CalculateSecret(EphemeralMACPublicKey, ServerSealedMACPrivateKey);
                        TemporaryEncryptionSharedSecret = SecureX448.CalculateSecret(EphemeralEncryptionPublicKey, ServerSealedEncryptionPrivateKey);
                        ActualMACSharedSecret = SodiumKDF.KDFFunction(32, 1, "MAC'sKDF",TemporaryMACSharedSecret,true);
                        ActualEncryptionSharedSecret = SodiumKDF.KDFFunction(32, 1, "ENC'sKDF",TemporaryEncryptionSharedSecret,true);
                    }
                    EncryptedFileBytesMAC = new Byte[64];
                    EncryptedFileBytes = new Byte[EncryptedFileBytesWithMAC.Length - (EphemeralEncryptionPublicKey.Length * 2) - EncryptedFileBytesMAC.Length];
                    Array.Copy(EncryptedFileBytesWithMAC, EphemeralMACPublicKey.Length * 2, EncryptedFileBytesMAC, 0, EncryptedFileBytesMAC.Length);
                    Array.Copy(EncryptedFileBytesWithMAC, (EphemeralMACPublicKey.Length * 2) + EncryptedFileBytesMAC.Length, EncryptedFileBytes, 0, EncryptedFileBytes.Length);
                    AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(EncryptedFileBytesMAC, EncryptedFileBytes, ActualMACSharedSecret,true);
                    if (AbleToVerifyHMAC == true) 
                    {
                        DecryptedFileBytes = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(EncryptedFileBytes, TempNonce, ActualEncryptionSharedSecret,true);
                        File.WriteAllBytes(CommOpsDecryptFolder+"SPrivateKey.txt", DecryptedFileBytes);
                    }
                    else 
                    {
                        break;
                    }
                }
                else 
                {
                    TempNonce = AUSealedMACPublicKey.Concat(EphemeralMACPublicKey).Concat(AUSealedEncryptionPublicKey).Concat(EphemeralEncryptionPublicKey).ToArray();
                    TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
                    if (AUSealedEncryptionPrivateKey.Length == 32)
                    {
                        ActualMACSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(AUSealedMACPrivateKey, EphemeralMACPublicKey);
                        ActualEncryptionSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(AUSealedEncryptionPrivateKey, EphemeralEncryptionPublicKey);
                    }
                    else
                    {
                        TemporaryMACSharedSecret = SecureX448.CalculateSecret(EphemeralMACPublicKey, AUSealedMACPrivateKey);
                        TemporaryEncryptionSharedSecret = SecureX448.CalculateSecret(EphemeralEncryptionPublicKey, AUSealedEncryptionPrivateKey);
                        ActualMACSharedSecret = SodiumKDF.KDFFunction(32, 1, "MAC'sKDF", TemporaryMACSharedSecret, true);
                        ActualEncryptionSharedSecret = SodiumKDF.KDFFunction(32, 1, "ENC'sKDF", TemporaryEncryptionSharedSecret, true);
                    }
                    EncryptedFileBytesMAC = new Byte[64];
                    EncryptedFileBytes = new Byte[EncryptedFileBytesWithMAC.Length - (EphemeralEncryptionPublicKey.Length * 2) - EncryptedFileBytesMAC.Length];
                    Array.Copy(EncryptedFileBytesWithMAC, EphemeralMACPublicKey.Length * 2, EncryptedFileBytesMAC, 0, EncryptedFileBytesMAC.Length);
                    Array.Copy(EncryptedFileBytesWithMAC, (EphemeralMACPublicKey.Length * 2) + EncryptedFileBytesMAC.Length, EncryptedFileBytes, 0, EncryptedFileBytes.Length);                    
                    AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(EncryptedFileBytesMAC, EncryptedFileBytes, ActualMACSharedSecret);
                    if (AbleToVerifyHMAC == true)
                    {
                        DecryptedFileBytes = SodiumStreamCipherXChaCha20.XChaCha20Decrypt(EncryptedFileBytes, TempNonce, ActualEncryptionSharedSecret);
                        FilteredFilePath = FilesPath[Loop].Remove(0,CommOpsEncryptFolder.Length);
                        FinalFilePath = CommOpsDecryptFolder + FilteredFilePath;
                        File.WriteAllBytes(FinalFilePath, DecryptedFileBytes);
                    }
                    else
                    {
                        break;
                    }
                }
                Loop += 1;
            }
            SodiumSecureMemory.SecureClearBytes(ActualMACSharedSecret);
            SodiumSecureMemory.SecureClearBytes(ActualEncryptionSharedSecret);
            SodiumSecureMemory.SecureClearBytes(ServerSealedMACPrivateKey);
            SodiumSecureMemory.SecureClearBytes(ServerSealedEncryptionPrivateKey);
            SodiumSecureMemory.SecureClearBytes(AUSealedMACPrivateKey);
            SodiumSecureMemory.SecureClearBytes(AUSealedEncryptionPrivateKey);
            if(AbleToVerifyHMAC == true) 
            {
                ThirdCommOpsTextBoxArray[0].Text = "Success: All data had been decrypted";
            }
            else 
            {
                ThirdCommOpsTextBoxArray[0].Text = "Error: Some data can't be decrypted";
            }
        }
        else if(CommOpsUIChooser == 4) 
        {
            String DSAPublicKeysB64String = "";
            if (FourthCommOpsRadioButtonArray[0].IsChecked == true) 
            {
                RevampedKeyPair ServerDSAKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair NodeOperatorDSAKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                File.WriteAllBytes(CommOpsMainRootFolder + "SPrivateKey.txt", ServerDSAKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "SPublicKey.txt", ServerDSAKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "NOPrivateKey.txt", NodeOperatorDSAKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "NOPublicKey.txt", NodeOperatorDSAKeyPair.PublicKey);
                DSAPublicKeysB64String = Convert.ToBase64String(ServerDSAKeyPair.PublicKey) + ";" + Convert.ToBase64String(NodeOperatorDSAKeyPair.PublicKey);
                ServerDSAKeyPair.Clear();
                NodeOperatorDSAKeyPair.Clear();
            }
            else 
            {
                ED448RevampedKeyPair ServerDSAKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair NodeOperatorDSAKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                File.WriteAllBytes(CommOpsMainRootFolder + "SPrivateKey.txt", ServerDSAKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "SPublicKey.txt", ServerDSAKeyPair.PublicKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "NOPrivateKey.txt", NodeOperatorDSAKeyPair.PrivateKey);
                File.WriteAllBytes(CommOpsMainRootFolder + "NOPublicKey.txt", NodeOperatorDSAKeyPair.PublicKey);
                DSAPublicKeysB64String = Convert.ToBase64String(ServerDSAKeyPair.PublicKey) + ";" + Convert.ToBase64String(NodeOperatorDSAKeyPair.PublicKey);
                ServerDSAKeyPair.Clear();
                NodeOperatorDSAKeyPair.Clear();
            }
            FourthCommOpsTextBoxArray[0].Text = DSAPublicKeysB64String;
        }
        else if(CommOpsUIChooser == 5) 
        {
            if(File.Exists(CommOpsMainRootFolder + "SPublicKey.txt") == true) 
            {
                Byte[] DSAPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "SPublicKey.txt");
                Byte[] NODSAPublicKey = File.ReadAllBytes(CommOpsMainRootFolder + "NOPublicKey.txt");
                String DSAPublicKeysB64 = Convert.ToBase64String(DSAPublicKey) + ";" + Convert.ToBase64String(NODSAPublicKey);
                FifthCommOpsTextBoxArray[0].Text = DSAPublicKeysB64;
            }
            else 
            {
                FifthCommOpsTextBoxArray[0].Text = "Error: Unable to find any digital signature keys created";
            }
        }
    }

    private void OOBOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (OOBOpsUIChooser == 1)
        {
            String ChallengeLengthString = FirstOOBOpsTextBoxArray[0].Text;
            if(ChallengeLengthString!=null && ChallengeLengthString.CompareTo("") != 0) 
            {
                Boolean isInteger = true;
                int ChallengeLength = 0;
                try
                {
                    ChallengeLength = int.Parse(ChallengeLengthString);
                }
                catch 
                {
                    isInteger = false;
                }
                if (isInteger) 
                {
                    if (ChallengeLength >= 16) 
                    {
                        Byte[] Challenge = SodiumRNG.GetRandomBytes(ChallengeLength);
                        FirstOOBOpsTextBoxArray[1].Text = Convert.ToBase64String(Challenge);
                    }
                    else 
                    {
                        FirstOOBOpsTextBoxArray[1].Text = "Error: Challenge length must be at least 16 bytes";
                    }
                }
                else 
                {
                    FirstOOBOpsTextBoxArray[1].Text = "Error: Challenge length must be whole number and can't have decimal points";
                }
            }
            else 
            {
                FirstOOBOpsTextBoxArray[1].Text = "Error: You haven't input any data";
            }
        }
        else if (OOBOpsUIChooser == 2)
        {
            String Base64ChallengeString = SecondOOBOpsTextBoxArray[0].Text;
            if (Base64ChallengeString != null && Base64ChallengeString.CompareTo("") != 0)
            {
                Boolean isBase64 = true;
                Byte[] TestBuffer = new Byte[] { };
                try
                {
                    TestBuffer = Convert.FromBase64String(Base64ChallengeString);
                }
                catch 
                {
                    isBase64 = false;
                }
                if (isBase64) 
                {
                    if(File.Exists(CommOpsMainRootFolder + "NOPrivateKey.txt") == true) 
                    {
                        Byte[] DSPrivateKey = File.ReadAllBytes(CommOpsMainRootFolder + "NOPrivateKey.txt");
                        Byte[] Challenge = TestBuffer;
                        Byte[] SignedChallenge = new Byte[] { };
                        if (DSPrivateKey.Length == 64)
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DSPrivateKey, true);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(DSPrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SecondOOBOpsTextBoxArray[1].Text = Convert.ToBase64String(SignedChallenge);
                    }
                    else 
                    {
                        SecondOOBOpsTextBoxArray[1].Text = "Error: Digital signature key pairs has not been created.";
                    }
                }
                else 
                {
                    SecondOOBOpsTextBoxArray[1].Text = "Error: This inputted string is not a valid base64 encoded data";
                }
            }
            else 
            {
                SecondOOBOpsTextBoxArray[1].Text = "Error: You haven't input any data";
            }
        }
        else if (OOBOpsUIChooser == 3)
        {
            String SignedChallengeBase64String = ThirdOOBOpsTextBoxArray[0].Text;
            String DSPublicKeyBase64String = ThirdOOBOpsTextBoxArray[1].Text;
            if(SignedChallengeBase64String!=null && SignedChallengeBase64String.CompareTo("")!=0 
                && DSPublicKeyBase64String!=null && DSPublicKeyBase64String.CompareTo("") != 0) 
            {
                Boolean isBase64 = true;
                Byte[] TestBuffer1 = new Byte[] { };
                Byte[] TestBuffer2 = new Byte[] { };
                try
                {
                    TestBuffer1 = Convert.FromBase64String(SignedChallengeBase64String);
                    TestBuffer2 = Convert.FromBase64String(DSPublicKeyBase64String);
                }
                catch
                {
                    isBase64 = false;
                }
                if (isBase64) 
                {
                    Byte[] SignedChallenge = TestBuffer1;
                    Byte[] DSPublicKey = TestBuffer2;
                    Byte[] Challenge = new Byte[] { };
                    Boolean AbleToVerify = true;
                    try
                    {
                        if (DSPublicKey.Length == 32) 
                        {
                            Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, DSPublicKey);
                        }
                        else 
                        {
                            Challenge = SecureED448.GetMessageFromSignatureMessage(DSPublicKey, SignedChallenge, new Byte[] { });
                        }
                    }
                    catch 
                    {
                        AbleToVerify = false;
                    }
                    if (AbleToVerify)
                    {
                        ThirdOOBOpsTextBoxArray[2].Text = "Success: Signed challenge verified with this public key";
                    }
                    else 
                    {
                        ThirdOOBOpsTextBoxArray[2].Text = "Error: Signed challenge can't be verified with this public key";
                    }
                }
                else 
                {
                    ThirdOOBOpsTextBoxArray[2].Text = "Error: Either signed challenge or DS public key is not encoded in base 64";
                }
            }
            else 
            {
                ThirdOOBOpsTextBoxArray[2].Text = "Error: Either signed challenge or DS public key is empty";
            }
        }
    }
}
