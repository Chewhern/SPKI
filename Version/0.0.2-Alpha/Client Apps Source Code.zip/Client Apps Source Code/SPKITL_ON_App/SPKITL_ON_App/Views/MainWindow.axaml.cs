﻿using Avalonia.Controls;

namespace SPKITL_ON_App.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
