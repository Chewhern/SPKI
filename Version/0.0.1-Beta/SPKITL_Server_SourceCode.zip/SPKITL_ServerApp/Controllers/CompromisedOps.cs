﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.Helper;
using SPKITL_ServerApp.SPKIDataModel;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompromisedOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public TLCompromisedAUsInfosModel GetCompromisedAuthorizedUsers() 
        {
            TLCompromisedAUsInfosModel MyModel = new TLCompromisedAUsInfosModel();
            List<String> CompromisedAUs = new List<String>();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyDataReader;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Compromised_NUS_Info`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read()) 
            {
                CompromisedAUs.Add(MyDataReader.GetString("Arweave_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            MyModel.TLAUInfoArweaveTransactionIDs = CompromisedAUs.ToArray();
            return MyModel;
        }
    }
}
