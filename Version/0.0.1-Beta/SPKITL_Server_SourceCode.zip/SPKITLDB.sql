-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 13, 2026 at 09:01 AM
-- Server version: 8.0.45-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SPKITLDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Compromised_NUS_Info`
--

CREATE TABLE `Compromised_NUS_Info` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Information`
--

CREATE TABLE `Node_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Node_Information`
--

INSERT INTO `Node_Information` (`IP_Address`, `API_IP_Address`) VALUES
('192.168.1.1', 'http://192.168.1.1:1001/api/');

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users`
--

CREATE TABLE `Node_Users` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Pub_Contact` text COLLATE utf8mb4_general_ci,
  `Priv_Contact` text COLLATE utf8mb4_general_ci,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `OOB_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `SigPKs_ValidDay` int DEFAULT NULL,
  `SigPKs_ValidMonth` int DEFAULT NULL,
  `SigPKs_ValidYear` int DEFAULT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Node_Users`
--

INSERT INTO `Node_Users` (`User_ID`, `Pub_Contact`, `Priv_Contact`, `Auth_PK`, `Sign_PK`, `OOB_PK`, `SigPKs_ValidDay`, `SigPKs_ValidMonth`, `SigPKs_ValidYear`, `Arweave_ID`) VALUES
('4iy6jkYxupTjVIqeuztRXSVKhyvE5KKo', 'example2@example.com', NULL, '53mhrAZVdh7gtdbEHVMgtZ5x0BlKG3237K0givo8vU0=', 'zhP2g3hM8HI5FKKsIzEURURP5cbDMsOGyiM3rkjMUPQ=', 'MJt0kZjoFIaEqVrK4sCI5GGMBICX351b49oK5IGqUTc=', 6, 9, 2026, 'sPvSjTHSQD2O8VHFZBrjnQ0ZbgbzeuRm3mGPVOenIvM'),
('TnEzUZNfgNrZulinEbEiXFpHCmM4jir4', 'example1@example.com', NULL, 'gBM7OwDWhrvMl/Bq8t/pF5HIkddrJHq62csTJUbjzt8=', 'gfg6GJc0iH+dg+DP6P9fybFqbDKWaT/gQqrD4cXMtcQ=', 'tonWialuZWvmHTpGmx3lKV/bzXjHNklvOn7NXZRZprY=', 6, 9, 2026, 'd3EOL_DyIdHNm7jcWDbBjrt70RvSipcjghhmUpWNk30');

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users_Cert_Info`
--

CREATE TABLE `Node_Users_Cert_Info` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signer_Arweave_IDs` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Node_Users_Cert_Info`
--

INSERT INTO `Node_Users_Cert_Info` (`User_ID`, `Arweave_ID`, `Signer_Arweave_IDs`) VALUES
('4iy6jkYxupTjVIqeuztRXSVKhyvE5KKo', 'DE_hBG6MhMBHa2icrWKXSQv2PNOHWkLwM3wWlBrp2wI', 'D6YyBg6g8JovP9NcdwPKuqrjtttst3rT081nOyF6Anc;FlC0wWwi6jVxZZWs1LEN3eGJ7BZ0YrJD95d5Aygae20'),
('TnEzUZNfgNrZulinEbEiXFpHCmM4jir4', 'BVj6sMTsSGZJwkhowKPzZNKHoOHWYVOgtFNYtcq4Zk0', 'D6YyBg6g8JovP9NcdwPKuqrjtttst3rT081nOyF6Anc;FlC0wWwi6jVxZZWs1LEN3eGJ7BZ0YrJD95d5Aygae20');

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Information`
--

CREATE TABLE `ONode_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ONode_Information`
--

INSERT INTO `ONode_Information` (`IP_Address`, `API_IP_Address`) VALUES
('192.168.1.2', 'http://192.168.1.2:1001/api/');

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Users`
--

CREATE TABLE `ONode_Users` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Day` int DEFAULT NULL,
  `Valid_Month` int NOT NULL,
  `Valid_Year` int NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ONode_Users`
--

INSERT INTO `ONode_Users` (`IP_Address`, `User_ID`, `Auth_PK`, `Sign_PK`, `Valid_Day`, `Valid_Month`, `Valid_Year`, `Arweave_ID`) VALUES
('192.168.1.2', 'LPmVwzefHFbmg4v3aSuiNLxDDCYgSvXp', 'JMLHPC4Q4ZoBw8O0rem6aWi9m5y+WwZB4fBnnZ7z1x8=', 'cj5+3uFHVN7da5YC8QB6yl4G8rNTepKgE43CTANepmk=', 6, 9, 2026, 'D6YyBg6g8JovP9NcdwPKuqrjtttst3rT081nOyF6Anc'),
('192.168.1.2', 'SghmCdsd5hRfaa90Z22YSq8BEQ3rtPAd', 'zPLShJxu4qCw4nNTgl3MFmvAP9ml07eG3Amj4d/J4Ak=', 'kM9tNBbdhw8E2PavFWPqTY3/oBhMCZzl//TxdXRMTKU=', 6, 9, 2026, 'FlC0wWwi6jVxZZWs1LEN3eGJ7BZ0YrJD95d5Aygae20');

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Users_Cert_Info`
--

CREATE TABLE `ONode_Users_Cert_Info` (
  `ONode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signer_Arweave_IDs` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ONode_Users_Cert_Info`
--

INSERT INTO `ONode_Users_Cert_Info` (`ONode_User_ID`, `Arweave_ID`, `Signer_Arweave_IDs`) VALUES
('LPmVwzefHFbmg4v3aSuiNLxDDCYgSvXp', '1Mb3WHLK4j0HhjCBD4kDvY1movhPEqfYpZPHxPh3APU', 'd3EOL_DyIdHNm7jcWDbBjrt70RvSipcjghhmUpWNk30;sPvSjTHSQD2O8VHFZBrjnQ0ZbgbzeuRm3mGPVOenIvM'),
('SghmCdsd5hRfaa90Z22YSq8BEQ3rtPAd', 'P3G3-drw23hCzLekttb1CnXuO1OckTrRzsium0tou-Q', 'd3EOL_DyIdHNm7jcWDbBjrt70RvSipcjghhmUpWNk30;sPvSjTHSQD2O8VHFZBrjnQ0ZbgbzeuRm3mGPVOenIvM');

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Information`
--

CREATE TABLE `SNode_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Users`
--

CREATE TABLE `SNode_Users` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Day` int DEFAULT NULL,
  `Valid_Month` int DEFAULT NULL,
  `Valid_Year` int DEFAULT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Users_Cert_Info`
--

CREATE TABLE `SNode_Users_Cert_Info` (
  `SNode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Arweave_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signer_Arweave_IDs` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Compromised_NUS_Info`
--
ALTER TABLE `Compromised_NUS_Info`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `Node_Information`
--
ALTER TABLE `Node_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `Node_Users`
--
ALTER TABLE `Node_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Users_Cert_Info`
--
ALTER TABLE `Node_Users_Cert_Info`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `ONode_Information`
--
ALTER TABLE `ONode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `ONode_Users`
--
ALTER TABLE `ONode_Users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `ONode_Users_Cert_Info`
--
ALTER TABLE `ONode_Users_Cert_Info`
  ADD PRIMARY KEY (`ONode_User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `SNode_Information`
--
ALTER TABLE `SNode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `SNode_Users`
--
ALTER TABLE `SNode_Users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);

--
-- Indexes for table `SNode_Users_Cert_Info`
--
ALTER TABLE `SNode_Users_Cert_Info`
  ADD PRIMARY KEY (`SNode_User_ID`),
  ADD UNIQUE KEY `Arweave_ID` (`Arweave_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
