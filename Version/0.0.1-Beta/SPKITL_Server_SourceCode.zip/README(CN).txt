==數據庫==
所有数据库表都需要手动插入/更新数据。

==數據庫設置 (SPKITL_P.txt)==
server=localhost;port=3306;database=<DBName>;user=<DBUser>;password=<DBUserPassword>;

一個正在運行的真正設置..
server=localhost;port=3306;database=SPKITLDB;user=SPKITLAdmin;password=SuperSecurePassword;

==服務器軟件==
服務器的軟件只負責索取數據。