==Database==
All the database tables will require manual data insertion/update.

==Database configuration (SPKITL_P.txt)==
server=localhost;port=3306;database=<DBName>;user=<DBUser>;password=<DBUserPassword>;

A sample working configuration will be..
server=localhost;port=3306;database=SPKITLDB;user=SPKITLAdmin;password=SuperSecurePassword;

==Server Application==
The server application will only be responsible in retrieving data.