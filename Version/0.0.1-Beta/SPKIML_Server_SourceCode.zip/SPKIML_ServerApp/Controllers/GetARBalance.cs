﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SimplifiedArweaveSDK.ArweaveHelper;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetARBalance : ControllerBase
    {
        [HttpGet]
        public String GetBalance()
        {
            return GetWalletBalanceHelper.GetWalletBalance("0nnavc2Y8MU9aXGCpNEZ7nQL3jSCWFmmwyH_lCtmeF4");
        }
    }
}
