﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKIML_ServerApp.DataModel;
using SPKIML_ServerApp.Helper;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterNodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public MLAUFullCertModel GiveTLCertificateToNodeUser(String User_ID)
        {
            MLAUFullCertModel MyModel = new MLAUFullCertModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String CurrentNodeIPAddress = "";
            int Count = 0;
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    MyModel.SNode_User_ID = User_ID;
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyModel.Arweave_Info_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyModel.Arweave_Cert_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Signers_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyModel.PNode_Signers_Arweave_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Signers_Certs_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyModel.PNode_Signers_Arweave_Cert_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Signers_Signers_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyModel.PNode_ONode_Signers_Arweave_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                    MyModel.Status = "Success: Full certificate for this node's authorized user had been retrieved";
                }
                else
                {
                    MyModel.Status = "Error: This user does not have any web of trust/byzantine related chain of trusts..";
                }
            }
            else
            {
                MyModel.Status = "Error: This specified user had not been registered";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }

        [HttpGet("EndUser")]
        public MLEUFullCertModel GiveTLCertificateToEndUser(String User_ID)
        {
            MLEUFullCertModel MyModel = new MLEUFullCertModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            String[] EU_Cert_Signer_Arweave_IDs = new String[] { };
            String EU_Cert_Arweave_ID = "";
            MLAUCertModel[] TempAUCertModel = new MLAUCertModel[] { };
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_Cert_Info` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `EU_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    EU_Cert_Arweave_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Signer_Arweave_IDs` FROM `EU_Cert_Info` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    EU_Cert_Signer_Arweave_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                    TempAUCertModel = new MLAUCertModel[EU_Cert_Signer_Arweave_IDs.Length];
                    while (Loop < TempAUCertModel.Length)
                    {
                        TempAUCertModel[Loop] = new MLAUCertModel();
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `Node_Users` WHERE `Arweave_ID`=@Arweave_ID";
                        MySQLGeneralQuery.Parameters.Add("@Arweave_ID", MySqlDbType.Text).Value = EU_Cert_Signer_Arweave_IDs[Loop];
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        TempAUCertModel[Loop].SNode_User_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                        TempAUCertModel[Loop].Arweave_Info_ID = EU_Cert_Signer_Arweave_IDs[Loop];
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = TempAUCertModel[Loop].SNode_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        TempAUCertModel[Loop].Arweave_Cert_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Signers_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = TempAUCertModel[Loop].SNode_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        TempAUCertModel[Loop].PNode_Signers_Arweave_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Signers_Certs_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = TempAUCertModel[Loop].SNode_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        TempAUCertModel[Loop].PNode_Signers_Arweave_Cert_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Signers_Signers_Arweave_IDs` FROM `Node_Users_Cert_Info` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = TempAUCertModel[Loop].SNode_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        TempAUCertModel[Loop].PNode_ONode_Signers_Arweave_IDs = MySQLGeneralQuery.ExecuteScalar().ToString().Split(";");
                        Loop += 1;
                    }
                    MyModel.SNode_EU_User_ID = User_ID;
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `End_Users` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyModel.SNode_EU_Arweave_Info_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MyModel.SNode_EU_Arweave_Cert_ID = EU_Cert_Arweave_ID;
                    MyModel.SNode_Users_Certs_Info = TempAUCertModel;
                    MyModel.Status = "Success: Full certificate for this end user had been retrieved";
                }
                else
                {
                    MyModel.Status = "Error: This end user does not have any partial chain of trusts..";
                }
            }
            else
            {
                MyModel.Status = "Error: This specified end user had not been registered";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }
    }
}
