﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp.Helper;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NormalUserRegistration : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String RegisterEndUser(String User_ID,String Auth_PK, String Sign_PK, String Pub_Contact = "",String Priv_Contact="",String OOB_PK="")
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "INSERT INTO `End_Users`(`User_ID`, `Pub_Contact`, `Priv_Contact`,`Auth_PK`, `Sign_PK`, `OOB_PK` ,`SigPKs_ValidDay`,`SigPKs_ValidMonth`,`SigPKs_ValidYear`) VALUES (@User_ID,@Pub_Contact,@Priv_Contact,@Auth_PK,@Sign_PK,@OOB_PK,@SigPKs_ValidDay,@SigPKs_ValidMonth,@SigPKs_ValidYear)";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Parameters.Add("@Pub_Contact", MySqlDbType.Text).Value = Pub_Contact;
                MySQLGeneralQuery.Parameters.Add("@Priv_Contact", MySqlDbType.Text).Value = Priv_Contact;
                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Sign_PK;
                MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = OOB_PK;
                MySQLGeneralQuery.Parameters.Add("@SigPKs_ValidDay", MySqlDbType.Int16).Value = CurrentDateTime.Day;
                MySQLGeneralQuery.Parameters.Add("@SigPKs_ValidMonth", MySqlDbType.Int16).Value = CurrentDateTime.Month;
                MySQLGeneralQuery.Parameters.Add("@SigPKs_ValidYear", MySqlDbType.Int16).Value = CurrentDateTime.Year;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                ResultString = "Success: End user had been added..";
            }
            else
            {
                ResultString = "Error: End user existed aborting insertion..";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("UpdateEndUserInfo")]
        public String UpdateEndUser(String User_ID, String SignedChallenge, String Auth_PK, String Sign_PK, String OOB_PK="",String Pub_Contact="",String Priv_Contact="")
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String EU_Old_Auth_PK = "";
            Byte[] EU_Old_Auth_PK_Bytes = new Byte[] { };
            String EU_Old_Sign_PK = "";
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            DateTime OldValidDT = new DateTime();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                //In future need to verify locally with the signed records from authorized users of this node..
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Auth_PK` FROM `End_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                EU_Old_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Sign_PK` FROM `End_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                EU_Old_Sign_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                EU_Old_Auth_PK_Bytes = Convert.FromBase64String(EU_Old_Auth_PK);
                SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                if (EU_Old_Auth_PK_Bytes.Length == 32)
                {
                    ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, EU_Old_Auth_PK_Bytes);
                }
                else
                {
                    ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(EU_Old_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                    if (MyTimeSpan.TotalMinutes < 8)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_Cert_Info` WHERE `User_ID`=@End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count == 0)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@End_User_ID AND `Arweave_ID` IS NULL";
                            MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1) 
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "UPDATE `End_Users` SET `Auth_PK`=@Auth_PK,`Pub_Contact`=@Pub_Contact,`Priv_Contact`=@Priv_Contact,`Sign_PK`=@Sign_PK,`OOB_PK`=@OOB_PK WHERE `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Parameters.Add("@Pub_Contact", MySqlDbType.Text).Value = Pub_Contact;
                                MySQLGeneralQuery.Parameters.Add("@Priv_Contact", MySqlDbType.Text).Value = Priv_Contact;
                                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Sign_PK;
                                MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = OOB_PK;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                                ResultString = "Success: This end user info had been updated..";
                            }
                            else 
                            {
                                ResultString = "Error: This end user information had already been anchored to Arweave.";
                            }
                        }
                        else 
                        {
                            ResultString = "Error: This user already had certificate anchored to Arweave.";
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge had expired.. deleting now..";
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                    }
                }
                else
                {
                    ResultString = "Error: This verified challenge no longer exists..";
                }
            }
            else
            {
                ResultString = "Error: This end user does not exist";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}
