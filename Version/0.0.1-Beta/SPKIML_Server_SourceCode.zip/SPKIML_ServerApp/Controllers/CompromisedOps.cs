﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp.DataModel;
using SPKIML_ServerApp.Helper;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompromisedOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public MLCompromisedAUInfosModel GetCompromisedAuthorizedUsers()
        {
            MLCompromisedAUInfosModel MyModel = new MLCompromisedAUInfosModel();
            List<String> CompromisedAUs = new List<String>();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyDataReader;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Compromised_NUS_Info`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read())
            {
                CompromisedAUs.Add(MyDataReader.GetString("Arweave_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            MyModel.MLAUInfoArweaveTransactionIDs = CompromisedAUs.ToArray();
            return MyModel;
        }

        [HttpGet("EU")]
        public MLCompromisedEUInfosModel GetCompromisedEndUsers()
        {
            MLCompromisedEUInfosModel MyModel = new MLCompromisedEUInfosModel();
            List<String> CompromisedEUs = new List<String>();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyDataReader;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `Arweave_ID` FROM `Compromised_EU_Info`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read())
            {
                CompromisedEUs.Add(MyDataReader.GetString("Arweave_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            MyModel.MLEUInfoArweaveTransactionIDs = CompromisedEUs.ToArray();
            return MyModel;
        }
    }
}
