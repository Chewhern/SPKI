﻿namespace SPKIML_ServerApp.DataModel
{
    public class MLCompromisedEUInfosModel
    {
        public String[] MLEUInfoArweaveTransactionIDs { get; set; }
    }
}
