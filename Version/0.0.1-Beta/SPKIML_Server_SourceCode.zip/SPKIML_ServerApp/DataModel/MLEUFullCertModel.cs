﻿namespace SPKIML_ServerApp.DataModel
{
    public class MLEUFullCertModel
    {
        public String SNode_EU_User_ID { get; set; }

        public String SNode_EU_Arweave_Info_ID { get; set; }

        public String SNode_EU_Arweave_Cert_ID { get; set; }
        //Make another model for these..
        public MLAUCertModel[] SNode_Users_Certs_Info { get; set; }

        public String Status { get; set; }
    }
}
