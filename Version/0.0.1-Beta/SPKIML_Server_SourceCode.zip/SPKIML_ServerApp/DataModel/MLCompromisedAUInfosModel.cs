﻿namespace SPKIML_ServerApp.DataModel
{
    public class MLCompromisedAUInfosModel
    {
        public String[] MLAUInfoArweaveTransactionIDs { get; set; }
    }
}
