﻿namespace SPKIML_ServerApp.DataModel
{
    public class MLAUCertModel
    {
        public String SNode_User_ID { get; set; }

        public String Arweave_Info_ID { get; set; }

        public String Arweave_Cert_ID { get; set; }

        public String[] PNode_Signers_Arweave_IDs { get; set; }

        public String[] PNode_Signers_Arweave_Cert_IDs { get; set; }

        public String[] PNode_ONode_Signers_Arweave_IDs { get; set; }
    }
}
