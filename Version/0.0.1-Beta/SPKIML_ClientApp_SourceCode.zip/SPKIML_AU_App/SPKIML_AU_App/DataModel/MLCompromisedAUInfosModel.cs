﻿using System;
namespace SPKIML_AU_App.DataModel
{
    public class MLCompromisedAUInfosModel
    {
        public String[] MLAUInfoArweaveTransactionIDs { get; set; }
    }
}
