﻿using Newtonsoft.Json;
using SPKIML_AU_App.DataModel;
using SPKIML_AU_App.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SPKIML_AU_App.APIMethodHelper
{
    public static class GetCompromisedAUsHelper
    {
        public static String GetCompromisedAUs()
        {
            String CompromisedAUs_ArweaveIDs = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("CompromisedOps");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    MLCompromisedAUInfosModel MyModel = JsonConvert.DeserializeObject<MLCompromisedAUInfosModel>(Result);
                    CompromisedAUs_ArweaveIDs = String.Join(",",MyModel.MLAUInfoArweaveTransactionIDs);
                }
            }
            return CompromisedAUs_ArweaveIDs;
        }
    }
}
