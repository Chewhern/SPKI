﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SPKIML_AU_App.Helper;
using System.IO;
using System.Runtime.InteropServices;
using SPKIML_AU_App.DataModel;

namespace SPKIML_AU_App.APIMethodHelper
{
    public static class GetAUFullCertHelper
    {
        public static String StatusString = "";

        public static void GetFullCert(String User_ID,String Path, ref MLAUFullCertModel MyModel) 
        {
            int Loop = 0;
            String TempString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("MasterNodeCertificateOps?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    MyModel = JsonConvert.DeserializeObject<MLAUFullCertModel>(Result);

                    if (MyModel.Status.Contains("Error") == false)
                    {
                        if (Directory.Exists(Path) == false)
                        {
                            Directory.CreateDirectory(Path);
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                        {
                            File.WriteAllText(Path + "\\Arweave_Info.txt", MyModel.Arweave_Info_ID);
                            File.WriteAllText(Path + "\\Arweave_Cert.txt", MyModel.Arweave_Cert_ID);
                            TempString = String.Join(Environment.NewLine, MyModel.PNode_Signers_Arweave_IDs);
                            File.WriteAllText(Path + "\\Arweave_Signers.txt", TempString);
                            TempString = String.Join(Environment.NewLine, MyModel.PNode_Signers_Arweave_Cert_IDs);
                            File.WriteAllText(Path + "\\Arweave_Signers_Certs.txt", TempString);
                            TempString = String.Join(Environment.NewLine, MyModel.PNode_ONode_Signers_Arweave_IDs);
                            File.WriteAllText(Path + "\\Arweave_Signers_Signers.txt", TempString);
                        }
                        else 
                        {
                            File.WriteAllText(Path + "/Arweave_Info.txt", MyModel.Arweave_Info_ID);
                            File.WriteAllText(Path + "/Arweave_Cert.txt", MyModel.Arweave_Cert_ID);
                            TempString = String.Join(Environment.NewLine, MyModel.PNode_Signers_Arweave_IDs);
                            File.WriteAllText(Path + "/Arweave_Signers.txt", TempString);
                            TempString = String.Join(Environment.NewLine, MyModel.PNode_Signers_Arweave_Cert_IDs);
                            File.WriteAllText(Path + "/Arweave_Signers_Certs.txt", TempString);
                            TempString = String.Join(Environment.NewLine, MyModel.PNode_ONode_Signers_Arweave_IDs);
                            File.WriteAllText(Path + "/Arweave_Signers_Signers.txt", TempString);
                        }
                    }
                    StatusString = MyModel.Status;
                }
                else
                {
                    StatusString= "Error: Other Node encounter some issues";
                }
            }
        }
    }
}
