﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_ON_App.SPKIDataModel
{
    public class MLEUCertModel
    {
        public String End_User_ID { get; set; }

        public MLEUSignedCredentialsModel[] SignedCredentials { get; set; }
    }
}
