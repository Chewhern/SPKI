﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using Newtonsoft.Json;
using SimplifiedArweaveSDK.ArweaveLocalHelper;
using SimplifiedArweaveSDK.ArweaveSubHelper;
using SPKIML_ON_App.SPKIDataModel;
using SPKITL_ON_App.SPKIDataModel;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace SPKIML_ON_App.Views;

public partial class MainView : UserControl
{
    private static int MLAUOpsUIChooser = 0;
    //..
    private static TextBlock[] FirstMLAUOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstMLAUOpsTextBoxArray = new TextBox[] { };
    private static Button[] FirstMLAUOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondMLAUOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondMLAUOpsTextBoxArray = new TextBox[] { };
    private static Button[] SecondMLAUOpsButtonArray = new Button[] { };
    //..
    private static Boolean HasMLAUOpsUIRendered = false;
    private static String MLAUOpsMainRootFolder = "";
    private static String MLAUOpsRSASubFolder = "";
    private static String MLAUOpsAUSubFolder = "";
    private static String MLAUOpsEUSubFolder = "";

    public MainView()
    {
        InitializeComponent();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            MLAUOpsMainRootFolder = AppContext.BaseDirectory + "\\ArweaveOps\\";
            MLAUOpsRSASubFolder = MLAUOpsMainRootFolder + "\\RSACredentials\\";
            MLAUOpsAUSubFolder = MLAUOpsMainRootFolder + "\\SN_AU\\";
            MLAUOpsEUSubFolder = MLAUOpsMainRootFolder + "\\SN_EU\\";
        }
        else
        {
            MLAUOpsMainRootFolder = AppContext.BaseDirectory + "/ArweaveOps/";
            MLAUOpsRSASubFolder = MLAUOpsMainRootFolder + "/RSACredentials/";
            MLAUOpsAUSubFolder = MLAUOpsMainRootFolder + "/PN_AU/";
            MLAUOpsEUSubFolder = MLAUOpsMainRootFolder + "/ON_AU/";
        }
        if (Directory.Exists(MLAUOpsMainRootFolder) == false)
        {
            Directory.CreateDirectory(MLAUOpsMainRootFolder);
        }
        if (Directory.Exists(MLAUOpsRSASubFolder) == false)
        {
            Directory.CreateDirectory(MLAUOpsRSASubFolder);
        }
        if (Directory.Exists(MLAUOpsAUSubFolder) == false)
        {
            Directory.CreateDirectory(MLAUOpsAUSubFolder);
        }
        if (Directory.Exists(MLAUOpsEUSubFolder) == false)
        {
            Directory.CreateDirectory(MLAUOpsEUSubFolder);
        }
        MLAUOpsAppInitialization();
    }

    private void MLAUOpsAppInitialization()
    {
        MLAUOpsUIChooser = 0;
        MLAUOpsAppToggleBTN1.IsCheckedChanged += MLAUOpsAppToggleBTNSFunction;
        MLAUOpsAppToggleBTN2.IsCheckedChanged += MLAUOpsAppToggleBTNSFunction;
    }

    private void MLAUOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (MLAUOpsAppToggleBTN1.IsChecked == true)
        {
            MLAUOpsAppToggleBTN2.IsChecked = false;
            MLAUOpsUIChooser = 1;
        }
        else if (MLAUOpsAppToggleBTN2.IsChecked == true)
        {
            MLAUOpsAppToggleBTN1.IsChecked = false;
            MLAUOpsUIChooser = 2;
        }
        else
        {
            MLAUOpsAppResetUI();
        }
        TLAUOpsAppDrawUI();
    }

    private void TLAUOpsAppDrawUI()
    {
        if (MLAUOpsUIChooser == 1)
        {
            if (HasMLAUOpsUIRendered == false)
            {
                FirstMLAUOpsTextBlockArray = new TextBlock[11];
                FirstMLAUOpsTextBlockArray[0] = new TextBlock();
                FirstMLAUOpsTextBlockArray[1] = new TextBlock();
                FirstMLAUOpsTextBlockArray[2] = new TextBlock();
                FirstMLAUOpsTextBlockArray[3] = new TextBlock();
                FirstMLAUOpsTextBlockArray[4] = new TextBlock();
                FirstMLAUOpsTextBlockArray[5] = new TextBlock();
                FirstMLAUOpsTextBlockArray[6] = new TextBlock();
                FirstMLAUOpsTextBlockArray[7] = new TextBlock();
                FirstMLAUOpsTextBlockArray[8] = new TextBlock();
                FirstMLAUOpsTextBlockArray[9] = new TextBlock();
                FirstMLAUOpsTextBlockArray[10] = new TextBlock();
                FirstMLAUOpsTextBlockArray[0].Text = "User ID";
                FirstMLAUOpsTextBlockArray[1].Text = "Public Contact";
                FirstMLAUOpsTextBlockArray[2].Text = "Private Contact (Optional, leave blank for now..)";
                FirstMLAUOpsTextBlockArray[3].Text = "Auth PK";
                FirstMLAUOpsTextBlockArray[4].Text = "Sign PK";
                FirstMLAUOpsTextBlockArray[5].Text = "OOB PK";
                FirstMLAUOpsTextBlockArray[6].Text = "SPK Valid Day";
                FirstMLAUOpsTextBlockArray[7].Text = "SPK Valid Month";
                FirstMLAUOpsTextBlockArray[8].Text = "SPK Valid Year";
                FirstMLAUOpsTextBlockArray[9].Text = "What's the DSA?";
                FirstMLAUOpsTextBlockArray[10].Text = "Arweave ID/Status (Read Only)";
                FirstMLAUOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[8].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[9].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBlockArray[10].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsTextBoxArray = new TextBox[11];
                FirstMLAUOpsTextBoxArray[0] = new TextBox();
                FirstMLAUOpsTextBoxArray[1] = new TextBox();
                FirstMLAUOpsTextBoxArray[2] = new TextBox();
                FirstMLAUOpsTextBoxArray[3] = new TextBox();
                FirstMLAUOpsTextBoxArray[4] = new TextBox();
                FirstMLAUOpsTextBoxArray[5] = new TextBox();
                FirstMLAUOpsTextBoxArray[6] = new TextBox();
                FirstMLAUOpsTextBoxArray[7] = new TextBox();
                FirstMLAUOpsTextBoxArray[8] = new TextBox();
                FirstMLAUOpsTextBoxArray[9] = new TextBox();
                FirstMLAUOpsTextBoxArray[10] = new TextBox();
                FirstMLAUOpsTextBoxArray[0].Width = 250;
                FirstMLAUOpsTextBoxArray[0].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[0].Height = 50;
                FirstMLAUOpsTextBoxArray[0].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[1].Width = 250;
                FirstMLAUOpsTextBoxArray[1].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[1].Height = 50;
                FirstMLAUOpsTextBoxArray[1].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[2].Width = 250;
                FirstMLAUOpsTextBoxArray[2].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[2].Height = 50;
                FirstMLAUOpsTextBoxArray[2].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[3].Width = 250;
                FirstMLAUOpsTextBoxArray[3].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[3].Height = 50;
                FirstMLAUOpsTextBoxArray[3].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[4].Width = 250;
                FirstMLAUOpsTextBoxArray[4].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[4].Height = 50;
                FirstMLAUOpsTextBoxArray[4].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[5].Width = 250;
                FirstMLAUOpsTextBoxArray[5].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[5].Height = 50;
                FirstMLAUOpsTextBoxArray[5].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[6].Width = 250;
                FirstMLAUOpsTextBoxArray[6].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[6].Height = 50;
                FirstMLAUOpsTextBoxArray[6].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[7].Width = 250;
                FirstMLAUOpsTextBoxArray[7].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[7].Height = 50;
                FirstMLAUOpsTextBoxArray[7].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[8].Width = 250;
                FirstMLAUOpsTextBoxArray[8].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[8].Height = 50;
                FirstMLAUOpsTextBoxArray[8].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[8].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[9].Width = 250;
                FirstMLAUOpsTextBoxArray[9].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[9].Height = 50;
                FirstMLAUOpsTextBoxArray[9].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[9].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[10].Width = 250;
                FirstMLAUOpsTextBoxArray[10].MaxWidth = 250;
                FirstMLAUOpsTextBoxArray[10].Height = 50;
                FirstMLAUOpsTextBoxArray[10].MaxHeight = 50;
                FirstMLAUOpsTextBoxArray[10].TextWrapping = TextWrapping.Wrap;
                FirstMLAUOpsTextBoxArray[10].IsReadOnly = true;
                FirstMLAUOpsTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[1].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[2].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[3].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[4].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[5].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[6].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[7].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[8].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[9].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsTextBoxArray[10].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstMLAUOpsButtonArray = new Button[1];
                FirstMLAUOpsButtonArray[0] = new Button();
                FirstMLAUOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstMLAUOpsButtonArray[0].Content = "Anchor AU Info";
                FirstMLAUOpsButtonArray[0].Click += TLAUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 350;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[0]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[0]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[1]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[1]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[2]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[2]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[3]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[3]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[4]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[4]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[5]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[5]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[6]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[6]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[7]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[7]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[8]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[8]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[9]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[9]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBlockArray[10]);
                MyStackPanel.Children.Add(FirstMLAUOpsTextBoxArray[10]);
                MyStackPanel.Children.Add(FirstMLAUOpsButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                MLAUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasMLAUOpsUIRendered = true;
            }
        }
        else if (MLAUOpsUIChooser == 2)
        {
            if (HasMLAUOpsUIRendered == false)
            {
                SecondMLAUOpsTextBlockArray = new TextBlock[8];
                SecondMLAUOpsTextBlockArray[0] = new TextBlock();
                SecondMLAUOpsTextBlockArray[1] = new TextBlock();
                SecondMLAUOpsTextBlockArray[2] = new TextBlock();
                SecondMLAUOpsTextBlockArray[3] = new TextBlock();
                SecondMLAUOpsTextBlockArray[4] = new TextBlock();
                SecondMLAUOpsTextBlockArray[5] = new TextBlock();
                SecondMLAUOpsTextBlockArray[6] = new TextBlock();
                SecondMLAUOpsTextBlockArray[7] = new TextBlock();
                SecondMLAUOpsTextBlockArray[0].Text = "End User ID?";
                SecondMLAUOpsTextBlockArray[1].Text = "Signer User IDs (use ',')";
                SecondMLAUOpsTextBlockArray[2].Text = "Signed Auth PKs (use ',')";
                SecondMLAUOpsTextBlockArray[3].Text = "Signed Sign PKs (use ',')";
                SecondMLAUOpsTextBlockArray[4].Text = "Signed Date Days (Read only)";
                SecondMLAUOpsTextBlockArray[5].Text = "Signed Date Months (Read only)";
                SecondMLAUOpsTextBlockArray[6].Text = "Signed Date Years (Read only)";
                SecondMLAUOpsTextBlockArray[7].Text = "Arweave ID/Status (Read Only)";
                SecondMLAUOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsTextBoxArray = new TextBox[8];
                SecondMLAUOpsTextBoxArray[0] = new TextBox();
                SecondMLAUOpsTextBoxArray[1] = new TextBox();
                SecondMLAUOpsTextBoxArray[2] = new TextBox();
                SecondMLAUOpsTextBoxArray[3] = new TextBox();
                SecondMLAUOpsTextBoxArray[4] = new TextBox();
                SecondMLAUOpsTextBoxArray[5] = new TextBox();
                SecondMLAUOpsTextBoxArray[6] = new TextBox();
                SecondMLAUOpsTextBoxArray[7] = new TextBox();
                SecondMLAUOpsTextBoxArray[4].IsReadOnly = true;
                SecondMLAUOpsTextBoxArray[5].IsReadOnly = true;
                SecondMLAUOpsTextBoxArray[6].IsReadOnly = true;
                SecondMLAUOpsTextBoxArray[7].IsReadOnly = true;
                SecondMLAUOpsTextBoxArray[0].Width = 250;
                SecondMLAUOpsTextBoxArray[0].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[0].Height = 50;
                SecondMLAUOpsTextBoxArray[0].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[1].Width = 250;
                SecondMLAUOpsTextBoxArray[1].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[1].Height = 50;
                SecondMLAUOpsTextBoxArray[1].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[2].Width = 250;
                SecondMLAUOpsTextBoxArray[2].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[2].Height = 50;
                SecondMLAUOpsTextBoxArray[2].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[3].Width = 250;
                SecondMLAUOpsTextBoxArray[3].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[3].Height = 50;
                SecondMLAUOpsTextBoxArray[3].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[4].Width = 250;
                SecondMLAUOpsTextBoxArray[4].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[4].Height = 50;
                SecondMLAUOpsTextBoxArray[4].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[5].Width = 250;
                SecondMLAUOpsTextBoxArray[5].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[5].Height = 50;
                SecondMLAUOpsTextBoxArray[5].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[6].Width = 250;
                SecondMLAUOpsTextBoxArray[6].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[6].Height = 50;
                SecondMLAUOpsTextBoxArray[6].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsTextBoxArray[7].Width = 250;
                SecondMLAUOpsTextBoxArray[7].MaxWidth = 250;
                SecondMLAUOpsTextBoxArray[7].Height = 50;
                SecondMLAUOpsTextBoxArray[7].MaxHeight = 50;
                SecondMLAUOpsTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                SecondMLAUOpsButtonArray = new Button[1];
                SecondMLAUOpsButtonArray[0] = new Button();
                SecondMLAUOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondMLAUOpsButtonArray[0].Content = "Create cert for EU";
                SecondMLAUOpsButtonArray[0].Click += TLAUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 350;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[0]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[0]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[1]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[1]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[2]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[2]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[3]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[3]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[4]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[4]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[5]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[5]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[6]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[6]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBlockArray[7]);
                MyStackPanel.Children.Add(SecondMLAUOpsTextBoxArray[7]);
                MyStackPanel.Children.Add(SecondMLAUOpsButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                MLAUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasMLAUOpsUIRendered = true;
            }
        }
        else
        {
            MLAUOpsAppResetUI();
        }
    }

    private void MLAUOpsAppResetUI()
    {
        FirstMLAUOpsTextBlockArray = new TextBlock[] { };
        FirstMLAUOpsTextBoxArray = new TextBox[] { };
        FirstMLAUOpsButtonArray = new Button[] { };
        SecondMLAUOpsTextBlockArray = new TextBlock[] { };
        SecondMLAUOpsTextBoxArray = new TextBox[] { };
        SecondMLAUOpsButtonArray = new Button[] { };
        HasMLAUOpsUIRendered = false;
        MLAUOpsUIChooser = 0;
        MLAUOpsAppLowerRightSP.Children.Clear();
    }

    private async void TLAUOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (MLAUOpsUIChooser == 1)
        {
            String User_ID = FirstMLAUOpsTextBoxArray[0].Text;
            String Public_Contact = FirstMLAUOpsTextBoxArray[1].Text;
            String Private_Contact = FirstMLAUOpsTextBoxArray[2].Text;
            String Sign_PK = FirstMLAUOpsTextBoxArray[4].Text;
            String Auth_PK = FirstMLAUOpsTextBoxArray[3].Text;
            String OOB_PK = FirstMLAUOpsTextBoxArray[5].Text;
            String ValidDate_Day_String = FirstMLAUOpsTextBoxArray[6].Text;
            String ValidDate_Month_String = FirstMLAUOpsTextBoxArray[7].Text;
            String ValidDate_Year_String = FirstMLAUOpsTextBoxArray[8].Text;
            String DSA_Type = FirstMLAUOpsTextBoxArray[9].Text;
            if (String.IsNullOrEmpty(User_ID) == false && String.IsNullOrEmpty(Public_Contact) == false && String.IsNullOrEmpty(Sign_PK) == false
                && String.IsNullOrEmpty(Auth_PK) == false && String.IsNullOrEmpty(OOB_PK) == false && String.IsNullOrEmpty(ValidDate_Day_String) == false
                && String.IsNullOrEmpty(ValidDate_Month_String) == false && String.IsNullOrEmpty(ValidDate_Year_String) == false && String.IsNullOrEmpty(DSA_Type) == false)
            {
                if (File.Exists(MLAUOpsRSASubFolder + "Modulus.txt") == true && File.Exists(MLAUOpsRSASubFolder + "Exponent.txt") == true
                    && File.Exists(MLAUOpsRSASubFolder + "D.txt") == true && File.Exists(MLAUOpsRSASubFolder + "P.txt") == true
                    && File.Exists(MLAUOpsRSASubFolder + "Q.txt") == true && File.Exists(MLAUOpsRSASubFolder + "DP.txt") == true
                    && File.Exists(MLAUOpsRSASubFolder + "DQ.txt") == true && File.Exists(MLAUOpsRSASubFolder + "InverseQ.txt") == true)
                {
                    Byte[] ModulusBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "Modulus.txt");
                    Byte[] ExponentBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "Exponent.txt");
                    Byte[] DBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "D.txt");
                    Byte[] PBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "P.txt");
                    Byte[] QBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "Q.txt");
                    Byte[] DPBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "DP.txt");
                    Byte[] DQBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "DQ.txt");
                    Byte[] InverseQBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "InverseQ.txt");
                    int ValidDate_Day = int.Parse(ValidDate_Day_String);
                    int ValidDate_Month = int.Parse(ValidDate_Month_String);
                    int ValidDate_Year = int.Parse(ValidDate_Year_String);
                    if (String.IsNullOrEmpty(Private_Contact) == true)
                    {
                        Private_Contact = "";
                    }
                    MLAUInfoModel MyModel = new MLAUInfoModel();
                    MyModel.User_ID = User_ID;
                    MyModel.Public_Contact = Public_Contact;
                    MyModel.Private_Contact = Private_Contact;
                    MyModel.Sign_PK = Sign_PK;
                    MyModel.Auth_PK = Auth_PK;
                    MyModel.OOB_PK = OOB_PK;
                    MyModel.ValidDate_Day = ValidDate_Day;
                    MyModel.ValidDate_Month = ValidDate_Month;
                    MyModel.ValidDate_Year = ValidDate_Year;
                    MyModel.DSA_Type = DSA_Type;
                    String JSONString = JsonConvert.SerializeObject(MyModel);
                    (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(JSONString, Base64URLEncodeDecodeHelper.Encode(ModulusBytes),
                    ModulusBytes, ExponentBytes, DBytes, PBytes, QBytes, DPBytes, DQBytes, InverseQBytes);
                    if (MyResults.Status.CompareTo("OK") == 0)
                    {
                        FirstMLAUOpsTextBoxArray[10].Text = MyResults.TransactionID + " is the transaction ID for Arweave. However, due to some constraints on my side or the Arweave network, you have to check via https://viewblock.io/arweave/address/{wallet_address} to see if the transaction was actually submitted.";
                        String DataString = User_ID + "," + MyResults.TransactionID;
                        String FinalDataString = "";
                        String[] DataStringArray = new String[] { };
                        if (File.Exists(MLAUOpsAUSubFolder + "Anchored_AU.txt") == false)
                        {
                            File.WriteAllText(MLAUOpsAUSubFolder + "Anchored_AU.txt", DataString);
                        }
                        else
                        {
                            DataStringArray = File.ReadAllLines(MLAUOpsAUSubFolder + "Anchored_AU.txt");
                            FinalDataString = String.Join(Environment.NewLine, DataStringArray);
                            FinalDataString += Environment.NewLine + DataString;
                            File.WriteAllText(MLAUOpsAUSubFolder + "Anchored_AU.txt", FinalDataString);
                        }
                    }
                    else
                    {
                        FirstMLAUOpsTextBoxArray[10].Text = MyResults.Status;
                    }
                }
                else
                {
                    FirstMLAUOpsTextBoxArray[10].Text = "Error: Neccessary RSA key materials in bytes format were missing..";
                }
            }
            else
            {
                FirstMLAUOpsTextBoxArray[10].Text = "Error: Some or all information were missing..";
            }
        }
        else if (MLAUOpsUIChooser == 2)
        {
            String User_ID = SecondMLAUOpsTextBoxArray[0].Text;
            String Signer_User_IDs_RawString = SecondMLAUOpsTextBoxArray[1].Text;
            String Signed_Auth_PKs_RawString = SecondMLAUOpsTextBoxArray[2].Text;
            String Signed_Sign_PKs_RawString = SecondMLAUOpsTextBoxArray[3].Text;
            //GMT+8
            DateTime SigningDateTime = DateTime.UtcNow.AddHours(8);
            if (String.IsNullOrEmpty(User_ID) == false && String.IsNullOrEmpty(Signer_User_IDs_RawString) == false
                && String.IsNullOrEmpty(Signed_Auth_PKs_RawString) == false && String.IsNullOrEmpty(Signed_Sign_PKs_RawString) == false)
            {
                if (Signer_User_IDs_RawString.Contains(",") == true && Signed_Auth_PKs_RawString.Contains(",") == true
                    && Signed_Sign_PKs_RawString.Contains(",") == true)
                {
                    String[] Signer_User_IDs = Signer_User_IDs_RawString.Split(",");
                    String[] Signed_Auth_PKs = Signed_Auth_PKs_RawString.Split(",");
                    String[] Signed_Sign_PKs = Signed_Sign_PKs_RawString.Split(",");
                    int[] SignDate_Days = new int[Signer_User_IDs.Length];
                    int[] SignDate_Months = new int[Signed_Auth_PKs.Length];
                    int[] SignDate_Years = new int[Signed_Sign_PKs.Length];
                    MLEUSignedCredentialsModel[] SignedRecords = new MLEUSignedCredentialsModel[Signer_User_IDs.Length];
                    int x = 0;
                    while (x < Signer_User_IDs.Length)
                    {
                        SignDate_Days[x] = SigningDateTime.Day;
                        SignDate_Months[x] = SigningDateTime.Month;
                        SignDate_Years[x] = SigningDateTime.Year;
                        SignedRecords[x] = new MLEUSignedCredentialsModel();
                        x += 1;
                    }
                    x = 0;
                    while (x < SignedRecords.Length)
                    {
                        SignedRecords[x].Signer_User_ID = Signer_User_IDs[x]; 
                        SignedRecords[x].Signed_Auth_PK = Signed_Auth_PKs[x];
                        SignedRecords[x].Signed_Sign_PK = Signed_Sign_PKs[x];
                        SignedRecords[x].SignDate_Day = SignDate_Days[x];
                        SignedRecords[x].SignDate_Month = SignDate_Months[x];
                        SignedRecords[x].SignDate_Year = SignDate_Years[x];
                        x += 1;
                    }
                    MLEUCertModel MyModel = new MLEUCertModel();
                    MyModel.End_User_ID = User_ID;
                    MyModel.SignedCredentials = SignedRecords;
                    if (File.Exists(MLAUOpsRSASubFolder + "Modulus.txt") == true && File.Exists(MLAUOpsRSASubFolder + "Exponent.txt") == true
                    && File.Exists(MLAUOpsRSASubFolder + "D.txt") == true && File.Exists(MLAUOpsRSASubFolder + "P.txt") == true
                    && File.Exists(MLAUOpsRSASubFolder + "Q.txt") == true && File.Exists(MLAUOpsRSASubFolder + "DP.txt") == true
                    && File.Exists(MLAUOpsRSASubFolder + "DQ.txt") == true && File.Exists(MLAUOpsRSASubFolder + "InverseQ.txt") == true)
                    {
                        Byte[] ModulusBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "Modulus.txt");
                        Byte[] ExponentBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "Exponent.txt");
                        Byte[] DBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "D.txt");
                        Byte[] PBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "P.txt");
                        Byte[] QBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "Q.txt");
                        Byte[] DPBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "DP.txt");
                        Byte[] DQBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "DQ.txt");
                        Byte[] InverseQBytes = File.ReadAllBytes(MLAUOpsRSASubFolder + "InverseQ.txt");
                        String JSONString = JsonConvert.SerializeObject(MyModel);
                        (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(JSONString, Base64URLEncodeDecodeHelper.Encode(ModulusBytes),
                        ModulusBytes, ExponentBytes, DBytes, PBytes, QBytes, DPBytes, DQBytes, InverseQBytes);
                        if (MyResults.Status.CompareTo("OK") == 0)
                        {
                            SecondMLAUOpsTextBoxArray[7].Text = MyResults.TransactionID + " is the transaction ID for Arweave. However, due to some constraints on my side or the Arweave network, you have to check via https://viewblock.io/arweave/address/{wallet_address} to see if the transaction was actually submitted.";
                            SecondMLAUOpsTextBoxArray[6].Text = SigningDateTime.Year.ToString();
                            SecondMLAUOpsTextBoxArray[5].Text = SigningDateTime.Month.ToString();
                            SecondMLAUOpsTextBoxArray[4].Text = SigningDateTime.Day.ToString();
                            String DataString = User_ID + "," + MyResults.TransactionID;
                            String FinalDataString = "";
                            String[] DataStringArray = new String[] { };
                            if (File.Exists(MLAUOpsEUSubFolder + "EU_Cert.txt") == false)
                            {
                                File.WriteAllText(MLAUOpsEUSubFolder + "EU_Cert.txt", DataString);
                            }
                            else
                            {
                                DataStringArray = File.ReadAllLines(MLAUOpsEUSubFolder + "EU_Cert.txt");
                                FinalDataString = String.Join(Environment.NewLine, DataStringArray);
                                FinalDataString += Environment.NewLine + DataString;
                                File.WriteAllText(MLAUOpsAUSubFolder + "EU_Cert.txt", FinalDataString);
                            }
                        }
                        else
                        {
                            SecondMLAUOpsTextBoxArray[7].Text = MyResults.Status;
                        }
                    }
                }
                else
                {
                    SecondMLAUOpsTextBoxArray[7].Text = "Error: The information for the second to fourth textboxes are not mixed data";
                }
            }
            else
            {
                SecondMLAUOpsTextBoxArray[7].Text = "Error: The information for the first 4 textboxes are empty";
            }
        }
    }
}
