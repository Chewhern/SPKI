﻿using System;
namespace SPKIML_EU_App.SPKIML_ServerModel
{
    public class MLCompromisedEUInfosModel
    {
        public String[] MLEUInfoArweaveTransactionIDs { get; set; }
    }
}
