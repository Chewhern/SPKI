﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using SimplifiedArweaveSDK.ArweaveHelper;
using SimplifiedArweaveSDK.ArweaveSubHelper;
using SPKIML_EU_App.APIMethodHelper;
using SPKIML_EU_App.Helper;
using SPKIML_EU_App.SPKIML_ServerModel;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace SPKIML_EU_App.Views;

public partial class MainView : UserControl
{
    private static int ServerOpsAppUIChooser = 0;
    private static int EUOpsAppUIChooser = 0;
    private static int OOBOpsAppUIChooser = 0;
    private static int CertInfoOpsAppUIChooser = 0;
    //..
    private static TextBlock[] FirstServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FourthServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FourthServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FourthServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FifthServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FifthServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FifthServerOpsAppButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstEUOpsAppTextBoxArray = new TextBox[] { };
    private static RadioButton[] FirstEUOpsAppRadioButtonArray = new RadioButton[] { };
    private static Button[] FirstEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondEUOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondEUOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] SecondEUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdEUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdEUOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] ThirdEUOpsAppComboBoxArray = new ComboBox[] { };
    private static RadioButton[] ThirdEUOpsAppRadioButtonArray = new RadioButton[] { };
    private static Button[] ThirdEUOpsAppButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstOOBOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstOOBOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondOOBOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondOOBOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] SecondOOBOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdOOBOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdOOBOpsAppButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstCertInfoOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstCertInfoOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstCertInfoOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondCertInfoOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondCertInfoOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondCertInfoOpsAppButtonArray = new Button[] { };
    //..
    private static String EUOpsAppServerRootFolder = "";
    private static String EUOpsAppCertificateFolder = "";
    private static String EUOPsAppRootFolder = "";
    private static String OOBOpsAppRootFolder = "";
    private static Boolean HasServerOpsAppUIRendered = false;
    private static Boolean HasEUOpsAppUIRendered = false;
    private static Boolean HasOOBOpsAppUIRendered = false;
    private static Boolean HasCertInfoOpsAppUIRendered = false;

    public MainView()
    {
        InitializeComponent();
        ServerOpsAppInitialization();
        EUOpsAppInitialization();
        OOBOpsAppInitialization();
        CertInfoOpsAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            EUOpsAppServerRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
            EUOpsAppCertificateFolder = AppContext.BaseDirectory + "\\EU_Cert\\";
            EUOPsAppRootFolder = AppContext.BaseDirectory + "\\Users\\";
            OOBOpsAppRootFolder = AppContext.BaseDirectory + "\\OOB\\";
        }
        else
        {
            EUOpsAppServerRootFolder = AppContext.BaseDirectory + "/ServerIP/";
            EUOpsAppCertificateFolder = AppContext.BaseDirectory + "/EU_Cert/";
            EUOPsAppRootFolder = AppContext.BaseDirectory + "/Users/";
            OOBOpsAppRootFolder = AppContext.BaseDirectory + "/OOB/";
        }
        if (Directory.Exists(EUOpsAppServerRootFolder) == false)
        {
            Directory.CreateDirectory(EUOpsAppServerRootFolder);
        }
        if (Directory.Exists(EUOpsAppCertificateFolder) == false)
        {
            Directory.CreateDirectory(EUOpsAppCertificateFolder);
        }
        if (Directory.Exists(EUOPsAppRootFolder) == false)
        {
            Directory.CreateDirectory(EUOPsAppRootFolder);
        }
        if (Directory.Exists(OOBOpsAppRootFolder) == false)
        {
            Directory.CreateDirectory(OOBOpsAppRootFolder);
        }
        StartupFunction();
    }

    private void StartupFunction()
    {
        if (Directory.Exists(EUOpsAppServerRootFolder) == true)
        {
            if (File.Exists(EUOpsAppServerRootFolder + "IP.txt") == true)
            {
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
    }

    private void ServerOpsAppInitialization()
    {
        ServerOpsAppUIChooser = 0;
        ServerOpsAppToggleBTN1.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN2.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN3.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN4.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN5.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
    }

    private void EUOpsAppInitialization()
    {
        EUOpsAppUIChooser = 0;
        EUOpsAppToggleBTN1.IsCheckedChanged += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN2.IsCheckedChanged += EUOpsAppToggleBTNSFunction;
        EUOpsAppToggleBTN3.IsCheckedChanged += EUOpsAppToggleBTNSFunction;
    }

    private void OOBOpsAppInitialization()
    {
        OOBOpsAppUIChooser = 0;
        OOBOpsAppToggleBTN1.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN2.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN3.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
    }

    private void CertInfoOpsAppInitialization()
    {
        CertInfoOpsAppUIChooser = 0;
        CertInfoOpsAppToggleBTN1.IsCheckedChanged += CertInfoOpsAppToggleBTNSFunction;
        CertInfoOpsAppToggleBTN2.IsCheckedChanged += CertInfoOpsAppToggleBTNSFunction;
    }

    private void ServerOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (ServerOpsAppToggleBTN1.IsChecked == true)
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 1;
        }
        else if (ServerOpsAppToggleBTN2.IsChecked == true)
        {
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 2;
        }
        else if (ServerOpsAppToggleBTN3.IsChecked == true)
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 3;
        }
        else if (ServerOpsAppToggleBTN4.IsChecked == true)
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 4;
        }
        else if (ServerOpsAppToggleBTN5.IsChecked == true)
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppUIChooser = 5;
        }
        else
        {
            ResetServerOpsAppUI();
        }
        ServerOpsAppDrawUI();
    }

    private void EUOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (EUOpsAppToggleBTN1.IsChecked == true)
        {
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppUIChooser = 1;
        }
        else if (EUOpsAppToggleBTN2.IsChecked == true)
        {
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppToggleBTN3.IsChecked = false;
            EUOpsAppUIChooser = 2;
        }
        else if (EUOpsAppToggleBTN3.IsChecked == true)
        {
            EUOpsAppToggleBTN2.IsChecked = false;
            EUOpsAppToggleBTN1.IsChecked = false;
            EUOpsAppUIChooser = 3;
        }
        else
        {
            ResetEUOpsAppUI();
        }
        EUOpsAppDrawUI();
    }

    private void OOBOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (OOBOpsAppToggleBTN1.IsChecked == true)
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsAppUIChooser = 1;
        }
        else if (OOBOpsAppToggleBTN2.IsChecked == true)
        {
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsAppUIChooser = 2;
        }
        else if (OOBOpsAppToggleBTN3.IsChecked == true)
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppUIChooser = 3;
        }
        else
        {
            ResetOOBOpsAppUI();
        }
        OOBOpsAppDrawUI();
    }

    private void CertInfoOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (CertInfoOpsAppToggleBTN1.IsChecked == true)
        {
            CertInfoOpsAppToggleBTN2.IsChecked = false;
            CertInfoOpsAppUIChooser = 1;
        }
        else if (CertInfoOpsAppToggleBTN2.IsChecked == true)
        {
            CertInfoOpsAppToggleBTN1.IsChecked = false;
            CertInfoOpsAppUIChooser = 2;
        }
        else
        {
            ResetCertInfoOpsAppUI();
        }
        CertInfoOpsAppDrawUI();
    }

    private void ServerOpsAppDrawUI()
    {
        if (ServerOpsAppUIChooser == 1)
        {
            if (HasServerOpsAppUIRendered == false)
            {
                FirstServerOpsAppTextBlockArray = new TextBlock[2];
                FirstServerOpsAppTextBlockArray[0] = new TextBlock();
                FirstServerOpsAppTextBlockArray[1] = new TextBlock();
                FirstServerOpsAppTextBlockArray[0].Text = "Server API IP address of SPKIML?";
                FirstServerOpsAppTextBlockArray[1].Text = "Server IP address status (Read Only)";
                FirstServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstServerOpsAppTextBoxArray = new TextBox[2];
                FirstServerOpsAppTextBoxArray[0] = new TextBox();
                FirstServerOpsAppTextBoxArray[1] = new TextBox();
                FirstServerOpsAppTextBoxArray[0].Height = 125;
                FirstServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstServerOpsAppTextBoxArray[0].Width = 250;
                FirstServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstServerOpsAppTextBoxArray[1].Height = 125;
                FirstServerOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstServerOpsAppTextBoxArray[1].Width = 250;
                FirstServerOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstServerOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstServerOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstServerOpsAppButtonArray = new Button[1];
                FirstServerOpsAppButtonArray[0] = new Button();
                FirstServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstServerOpsAppButtonArray[0].Content = "Add and establish a connection";
                FirstServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if (ServerOpsAppUIChooser == 2)
        {
            if (HasServerOpsAppUIRendered == false)
            {
                SecondServerOpsAppTextBlockArray = new TextBlock[4];
                SecondServerOpsAppTextBlockArray[0] = new TextBlock();
                SecondServerOpsAppTextBlockArray[1] = new TextBlock();
                SecondServerOpsAppTextBlockArray[2] = new TextBlock();
                SecondServerOpsAppTextBlockArray[3] = new TextBlock();
                SecondServerOpsAppTextBlockArray[0].Text = "User ID?";
                SecondServerOpsAppTextBlockArray[1].Text = "User Arweave ID (RO)";
                SecondServerOpsAppTextBlockArray[2].Text = "User Arweave Cert ID (RO)";
                SecondServerOpsAppTextBlockArray[3].Text = "Status (RO)";
                SecondServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBoxArray = new TextBox[4];
                SecondServerOpsAppTextBoxArray[0] = new TextBox();
                SecondServerOpsAppTextBoxArray[1] = new TextBox();
                SecondServerOpsAppTextBoxArray[2] = new TextBox();
                SecondServerOpsAppTextBoxArray[3] = new TextBox();
                SecondServerOpsAppTextBoxArray[0].Height = 50;
                SecondServerOpsAppTextBoxArray[0].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[1].Height = 50;
                SecondServerOpsAppTextBoxArray[1].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[2].Height = 50;
                SecondServerOpsAppTextBoxArray[2].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[3].Height = 50;
                SecondServerOpsAppTextBoxArray[3].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[0].Width = 250;
                SecondServerOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[1].Width = 250;
                SecondServerOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[2].Width = 250;
                SecondServerOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[3].Width = 250;
                SecondServerOpsAppTextBoxArray[3].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondServerOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondServerOpsAppTextBoxArray[3].IsReadOnly = true;
                SecondServerOpsAppButtonArray = new Button[1];
                SecondServerOpsAppButtonArray[0] = new Button();
                SecondServerOpsAppButtonArray[0].Content = "Fetch Certificate";
                SecondServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                SecondServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if (ServerOpsAppUIChooser == 3)
        {
            if (HasServerOpsAppUIRendered == false)
            {
                ThirdServerOpsAppTextBlockArray = new TextBlock[1];
                ThirdServerOpsAppTextBlockArray[0] = new TextBlock();
                ThirdServerOpsAppTextBlockArray[0].Text = "Server's AR balance (RO)";
                ThirdServerOpsAppTextBoxArray = new TextBox[1];
                ThirdServerOpsAppTextBoxArray[0] = new TextBox();
                ThirdServerOpsAppTextBoxArray[0].IsReadOnly = true;
                ThirdServerOpsAppTextBoxArray[0].Width = 250;
                ThirdServerOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdServerOpsAppTextBoxArray[0].Height = 50;
                ThirdServerOpsAppTextBoxArray[0].MaxHeight = 50;
                ThirdServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdServerOpsAppButtonArray = new Button[1];
                ThirdServerOpsAppButtonArray[0] = new Button();
                ThirdServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdServerOpsAppButtonArray[0].Content = "Inquire Server AR";
                ThirdServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(ThirdServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(ThirdServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(ThirdServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if (ServerOpsAppUIChooser == 4)
        {
            if (HasServerOpsAppUIRendered == false)
            {
                FourthServerOpsAppTextBlockArray = new TextBlock[5];
                FourthServerOpsAppTextBlockArray[0] = new TextBlock();
                FourthServerOpsAppTextBlockArray[1] = new TextBlock();
                FourthServerOpsAppTextBlockArray[2] = new TextBlock();
                FourthServerOpsAppTextBlockArray[3] = new TextBlock();
                FourthServerOpsAppTextBlockArray[4] = new TextBlock();
                FourthServerOpsAppTextBlockArray[0].Text = "IP Address (RO)";
                FourthServerOpsAppTextBlockArray[1].Text = "API IP Address (RO)";
                FourthServerOpsAppTextBlockArray[2].Text = "NO Contact (RO)";
                FourthServerOpsAppTextBlockArray[3].Text = "NO OOB PK (RO)";
                FourthServerOpsAppTextBlockArray[4].Text = "Communication Channel (RO)";
                FourthServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBoxArray = new TextBox[5];
                FourthServerOpsAppTextBoxArray[0] = new TextBox();
                FourthServerOpsAppTextBoxArray[1] = new TextBox();
                FourthServerOpsAppTextBoxArray[2] = new TextBox();
                FourthServerOpsAppTextBoxArray[3] = new TextBox();
                FourthServerOpsAppTextBoxArray[4] = new TextBox();
                FourthServerOpsAppTextBoxArray[0].IsReadOnly = true;
                FourthServerOpsAppTextBoxArray[0].Width = 250;
                FourthServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FourthServerOpsAppTextBoxArray[0].Height = 125;
                FourthServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FourthServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FourthServerOpsAppButtonArray = new Button[1];
                FourthServerOpsAppButtonArray[0] = new Button();
                FourthServerOpsAppButtonArray[0].Content = "Get Node Information";
                FourthServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[4]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[4]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if (ServerOpsAppUIChooser == 5)
        {
            if (HasServerOpsAppUIRendered == false)
            {
                FifthServerOpsAppTextBlockArray = new TextBlock[1];
                FifthServerOpsAppTextBlockArray[0] = new TextBlock();
                FifthServerOpsAppTextBlockArray[0].Text = "Compromised EUs (RO)";
                FifthServerOpsAppTextBoxArray = new TextBox[1];
                FifthServerOpsAppTextBoxArray[0] = new TextBox();
                FifthServerOpsAppTextBoxArray[0].IsReadOnly = true;
                FifthServerOpsAppTextBoxArray[0].Width = 250;
                FifthServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FifthServerOpsAppTextBoxArray[0].Height = 125;
                FifthServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FifthServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FifthServerOpsAppButtonArray = new Button[1];
                FifthServerOpsAppButtonArray[0] = new Button();
                FifthServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthServerOpsAppButtonArray[0].Content = "Get Compromised EUs";
                FifthServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FifthServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FifthServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FifthServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetServerOpsAppUI();
        }
    }

    private void EUOpsAppDrawUI()
    {
        if (EUOpsAppUIChooser == 1)
        {
            if (HasEUOpsAppUIRendered == false)
            {
                FirstEUOpsAppTextBlockArray = new TextBlock[11];
                FirstEUOpsAppTextBlockArray[0] = new TextBlock();
                FirstEUOpsAppTextBlockArray[1] = new TextBlock();
                FirstEUOpsAppTextBlockArray[2] = new TextBlock();
                FirstEUOpsAppTextBlockArray[3] = new TextBlock();
                FirstEUOpsAppTextBlockArray[4] = new TextBlock();
                FirstEUOpsAppTextBlockArray[5] = new TextBlock();
                FirstEUOpsAppTextBlockArray[6] = new TextBlock();
                FirstEUOpsAppTextBlockArray[7] = new TextBlock();
                FirstEUOpsAppTextBlockArray[8] = new TextBlock();
                FirstEUOpsAppTextBlockArray[9] = new TextBlock();
                FirstEUOpsAppTextBlockArray[10] = new TextBlock();
                FirstEUOpsAppTextBlockArray[0].Text = "User ID (Read Only)";
                FirstEUOpsAppTextBlockArray[1].Text = "Public Contact";
                FirstEUOpsAppTextBlockArray[2].Text = "Private Contact";
                FirstEUOpsAppTextBlockArray[3].Text = "Auth PK (Read Only)";
                FirstEUOpsAppTextBlockArray[4].Text = "Sign PK (Read Only)";
                FirstEUOpsAppTextBlockArray[5].Text = "OOB PK (Read Only)";
                FirstEUOpsAppTextBlockArray[6].Text = "ASPK Day (Read Only)";
                FirstEUOpsAppTextBlockArray[7].Text = "ASPK Month (Read Only)";
                FirstEUOpsAppTextBlockArray[8].Text = "ASPK Year (Read Only)";
                FirstEUOpsAppTextBlockArray[9].Text = "What's the DSA?";
                FirstEUOpsAppTextBlockArray[10].Text = "Server Status (Read Only)";
                FirstEUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[8].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[9].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBlockArray[10].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstEUOpsAppTextBoxArray = new TextBox[10];
                FirstEUOpsAppTextBoxArray[0] = new TextBox();
                FirstEUOpsAppTextBoxArray[1] = new TextBox();
                FirstEUOpsAppTextBoxArray[2] = new TextBox();
                FirstEUOpsAppTextBoxArray[3] = new TextBox();
                FirstEUOpsAppTextBoxArray[4] = new TextBox();
                FirstEUOpsAppTextBoxArray[5] = new TextBox();
                FirstEUOpsAppTextBoxArray[6] = new TextBox();
                FirstEUOpsAppTextBoxArray[7] = new TextBox();
                FirstEUOpsAppTextBoxArray[8] = new TextBox();
                FirstEUOpsAppTextBoxArray[9] = new TextBox();
                FirstEUOpsAppTextBoxArray[0].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[3].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[4].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[5].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[6].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[7].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[8].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[9].IsReadOnly = true;
                FirstEUOpsAppTextBoxArray[0].Width = 250;
                FirstEUOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[1].Width = 250;
                FirstEUOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[2].Width = 250;
                FirstEUOpsAppTextBoxArray[2].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[3].Width = 250;
                FirstEUOpsAppTextBoxArray[3].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[4].Width = 250;
                FirstEUOpsAppTextBoxArray[4].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[5].Width = 250;
                FirstEUOpsAppTextBoxArray[5].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[6].Width = 250;
                FirstEUOpsAppTextBoxArray[6].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[7].Width = 250;
                FirstEUOpsAppTextBoxArray[7].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[8].Width = 250;
                FirstEUOpsAppTextBoxArray[8].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[9].Width = 250;
                FirstEUOpsAppTextBoxArray[9].MaxWidth = 250;
                FirstEUOpsAppTextBoxArray[0].Height = 125;
                FirstEUOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[1].Height = 125;
                FirstEUOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[2].Height = 125;
                FirstEUOpsAppTextBoxArray[2].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[3].Height = 125;
                FirstEUOpsAppTextBoxArray[3].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[4].Height = 125;
                FirstEUOpsAppTextBoxArray[4].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[5].Height = 125;
                FirstEUOpsAppTextBoxArray[5].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[6].Height = 125;
                FirstEUOpsAppTextBoxArray[6].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[7].Height = 125;
                FirstEUOpsAppTextBoxArray[7].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[8].Height = 125;
                FirstEUOpsAppTextBoxArray[8].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[9].Height = 125;
                FirstEUOpsAppTextBoxArray[9].MaxHeight = 125;
                FirstEUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[8].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppTextBoxArray[9].TextWrapping = TextWrapping.Wrap;
                FirstEUOpsAppRadioButtonArray = new RadioButton[2];
                FirstEUOpsAppRadioButtonArray[0] = new RadioButton();
                FirstEUOpsAppRadioButtonArray[1] = new RadioButton();
                FirstEUOpsAppRadioButtonArray[0].GroupName = "CurveTypes";
                FirstEUOpsAppRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                FirstEUOpsAppRadioButtonArray[0].IsChecked = true;
                FirstEUOpsAppRadioButtonArray[1].GroupName = "CurveTypes";
                FirstEUOpsAppRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                FirstEUOpsAppButtonArray = new Button[1];
                FirstEUOpsAppButtonArray[0] = new Button();
                FirstEUOpsAppButtonArray[0].Content = "Register Account";
                FirstEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                FirstEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[4]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[5]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[5]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[6]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[6]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[7]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[7]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[8]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[8]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[9]);
                MyStackPanel.Children.Add(FirstEUOpsAppRadioButtonArray[0]);
                MyStackPanel.Children.Add(FirstEUOpsAppRadioButtonArray[1]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBlockArray[10]);
                MyStackPanel.Children.Add(FirstEUOpsAppTextBoxArray[9]);
                MyStackPanel.Children.Add(FirstEUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                EUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if (EUOpsAppUIChooser == 2)
        {
            if (HasEUOpsAppUIRendered == false)
            {
                SecondEUOpsAppTextBlockArray = new TextBlock[7];
                SecondEUOpsAppTextBlockArray[0] = new TextBlock();
                SecondEUOpsAppTextBlockArray[1] = new TextBlock();
                SecondEUOpsAppTextBlockArray[2] = new TextBlock();
                SecondEUOpsAppTextBlockArray[3] = new TextBlock();
                SecondEUOpsAppTextBlockArray[4] = new TextBlock();
                SecondEUOpsAppTextBlockArray[5] = new TextBlock();
                SecondEUOpsAppTextBlockArray[6] = new TextBlock();
                SecondEUOpsAppTextBlockArray[0].Text = "User ID?";
                SecondEUOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                SecondEUOpsAppTextBlockArray[2].Text = "Public Contact (RO)";
                SecondEUOpsAppTextBlockArray[3].Text = "Auth PK (Read Only)";
                SecondEUOpsAppTextBlockArray[4].Text = "Sign PK (Read Only)";
                SecondEUOpsAppTextBlockArray[5].Text = "OOB PK (Read Only)";
                SecondEUOpsAppTextBlockArray[6].Text = "What's the DSA?";
                SecondEUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppTextBoxArray = new TextBox[6];
                SecondEUOpsAppTextBoxArray[0] = new TextBox();
                SecondEUOpsAppTextBoxArray[1] = new TextBox();
                SecondEUOpsAppTextBoxArray[2] = new TextBox();
                SecondEUOpsAppTextBoxArray[3] = new TextBox();
                SecondEUOpsAppTextBoxArray[4] = new TextBox();
                SecondEUOpsAppTextBoxArray[5] = new TextBox();
                SecondEUOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondEUOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondEUOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondEUOpsAppTextBoxArray[3].IsReadOnly = true;
                SecondEUOpsAppTextBoxArray[4].IsReadOnly = true;
                SecondEUOpsAppTextBoxArray[5].IsReadOnly = true;
                SecondEUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondEUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondEUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondEUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondEUOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                SecondEUOpsAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                SecondEUOpsAppTextBoxArray[0].Width = 250;
                SecondEUOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[0].Height = 125;
                SecondEUOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondEUOpsAppTextBoxArray[1].Width = 250;
                SecondEUOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[1].Height = 125;
                SecondEUOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondEUOpsAppTextBoxArray[2].Width = 250;
                SecondEUOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[2].Height = 125;
                SecondEUOpsAppTextBoxArray[2].MaxHeight = 125;
                SecondEUOpsAppTextBoxArray[3].Width = 250;
                SecondEUOpsAppTextBoxArray[3].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[3].Height = 125;
                SecondEUOpsAppTextBoxArray[3].MaxHeight = 125;
                SecondEUOpsAppTextBoxArray[4].Width = 250;
                SecondEUOpsAppTextBoxArray[4].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[4].Height = 125;
                SecondEUOpsAppTextBoxArray[4].MaxHeight = 125;
                SecondEUOpsAppTextBoxArray[5].Width = 250;
                SecondEUOpsAppTextBoxArray[5].MaxWidth = 250;
                SecondEUOpsAppTextBoxArray[5].Height = 125;
                SecondEUOpsAppTextBoxArray[5].MaxHeight = 125;
                SecondEUOpsAppComboBoxArray = new ComboBox[1];
                SecondEUOpsAppComboBoxArray[0] = new ComboBox();
                SecondEUOpsAppComboBoxArray[0].MaxWidth = 250;
                EUOpsAppLoadUserIDs();
                SecondEUOpsAppComboBoxArray[0].SelectionChanged += EUOpsAppComboBoxSelectedItemsChanged;
                SecondEUOpsAppButtonArray = new Button[1];
                SecondEUOpsAppButtonArray[0] = new Button();
                SecondEUOpsAppButtonArray[0].Content = "Get Info";
                SecondEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(SecondEUOpsAppComboBoxArray[0]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[5]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBoxArray[4]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBlockArray[6]);
                MyStackPanel.Children.Add(SecondEUOpsAppTextBoxArray[5]);
                MyStackPanel.Children.Add(SecondEUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                EUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasEUOpsAppUIRendered = true;
            }
        }
        else if (EUOpsAppUIChooser == 3)
        {
            if (HasEUOpsAppUIRendered == false)
            {
                ThirdEUOpsAppTextBlockArray = new TextBlock[11];
                ThirdEUOpsAppTextBlockArray[0] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[1] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[2] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[3] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[4] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[5] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[6] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[7] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[8] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[9] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[10] = new TextBlock();
                ThirdEUOpsAppTextBlockArray[0].Text = "User ID?";
                ThirdEUOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                ThirdEUOpsAppTextBlockArray[2].Text = "Public Contact";
                ThirdEUOpsAppTextBlockArray[3].Text = "Private Contact";
                ThirdEUOpsAppTextBlockArray[4].Text = "Auth PK (Read Only)";
                ThirdEUOpsAppTextBlockArray[5].Text = "Sign PK (Read Only)";
                ThirdEUOpsAppTextBlockArray[6].Text = "OOB PK (Read Only)";
                ThirdEUOpsAppTextBlockArray[7].Text = "What's the DSA?";
                ThirdEUOpsAppTextBlockArray[8].Text = "Server Status (Read Only)";
                ThirdEUOpsAppTextBlockArray[9].Text = "If certificate exist, only";
                ThirdEUOpsAppTextBlockArray[10].Text = "change OOBPK and contact";
                ThirdEUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[8].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[9].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBlockArray[10].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppTextBoxArray = new TextBox[7];
                ThirdEUOpsAppTextBoxArray[0] = new TextBox();
                ThirdEUOpsAppTextBoxArray[1] = new TextBox();
                ThirdEUOpsAppTextBoxArray[2] = new TextBox();
                ThirdEUOpsAppTextBoxArray[3] = new TextBox();
                ThirdEUOpsAppTextBoxArray[4] = new TextBox();
                ThirdEUOpsAppTextBoxArray[5] = new TextBox();
                ThirdEUOpsAppTextBoxArray[6] = new TextBox();
                ThirdEUOpsAppTextBoxArray[0].IsReadOnly = true;
                ThirdEUOpsAppTextBoxArray[3].IsReadOnly = true;
                ThirdEUOpsAppTextBoxArray[4].IsReadOnly = true;
                ThirdEUOpsAppTextBoxArray[5].IsReadOnly = true;
                ThirdEUOpsAppTextBoxArray[6].IsReadOnly = true;
                ThirdEUOpsAppTextBoxArray[0].Width = 250;
                ThirdEUOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[0].Height = 125;
                ThirdEUOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[1].Width = 250;
                ThirdEUOpsAppTextBoxArray[1].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[1].Height = 125;
                ThirdEUOpsAppTextBoxArray[1].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[2].Width = 250;
                ThirdEUOpsAppTextBoxArray[2].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[2].Height = 125;
                ThirdEUOpsAppTextBoxArray[2].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[3].Width = 250;
                ThirdEUOpsAppTextBoxArray[3].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[3].Height = 125;
                ThirdEUOpsAppTextBoxArray[3].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[4].Width = 250;
                ThirdEUOpsAppTextBoxArray[4].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[4].Height = 125;
                ThirdEUOpsAppTextBoxArray[4].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[5].Width = 250;
                ThirdEUOpsAppTextBoxArray[5].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[5].Height = 125;
                ThirdEUOpsAppTextBoxArray[5].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[6].Width = 250;
                ThirdEUOpsAppTextBoxArray[6].MaxWidth = 250;
                ThirdEUOpsAppTextBoxArray[6].Height = 125;
                ThirdEUOpsAppTextBoxArray[6].MaxHeight = 125;
                ThirdEUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                ThirdEUOpsAppComboBoxArray = new ComboBox[1];
                ThirdEUOpsAppComboBoxArray[0] = new ComboBox();
                ThirdEUOpsAppComboBoxArray[0].MaxWidth = 250;
                EUOpsAppLoadUserIDs();
                ThirdEUOpsAppComboBoxArray[0].SelectionChanged += EUOpsAppComboBoxSelectedItemsChanged;
                ThirdEUOpsAppRadioButtonArray = new RadioButton[2];
                ThirdEUOpsAppRadioButtonArray[0] = new RadioButton();
                ThirdEUOpsAppRadioButtonArray[1] = new RadioButton();
                ThirdEUOpsAppRadioButtonArray[0].GroupName = "CurveTypes";
                ThirdEUOpsAppRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                ThirdEUOpsAppRadioButtonArray[0].IsChecked = true;
                ThirdEUOpsAppRadioButtonArray[1].GroupName = "CurveTypes";
                ThirdEUOpsAppRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                ThirdEUOpsAppButtonArray = new Button[1];
                ThirdEUOpsAppButtonArray[0] = new Button();
                ThirdEUOpsAppButtonArray[0].Content = "Change Info";
                ThirdEUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdEUOpsAppButtonArray[0].Click += EUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(ThirdEUOpsAppComboBoxArray[0]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[5]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[4]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[6]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[5]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[7]);
                MyStackPanel.Children.Add(ThirdEUOpsAppRadioButtonArray[0]);
                MyStackPanel.Children.Add(ThirdEUOpsAppRadioButtonArray[1]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[8]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBoxArray[6]);
                MyStackPanel.Children.Add(ThirdEUOpsAppButtonArray[0]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[9]);
                MyStackPanel.Children.Add(ThirdEUOpsAppTextBlockArray[10]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                EUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasEUOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetEUOpsAppUI();
        }
    }

    private void OOBOpsAppDrawUI()
    {
        if (OOBOpsAppUIChooser == 1)
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                FirstOOBOpsAppTextBlockArray = new TextBlock[2];
                FirstOOBOpsAppTextBlockArray[0] = new TextBlock();
                FirstOOBOpsAppTextBlockArray[1] = new TextBlock();
                FirstOOBOpsAppTextBlockArray[0].Text = "Challenge Bytes? (>=16 bytes)";
                FirstOOBOpsAppTextBlockArray[1].Text = "Generated Challenge (Base64)";
                FirstOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsAppTextBoxArray = new TextBox[2];
                FirstOOBOpsAppTextBoxArray[0] = new TextBox();
                FirstOOBOpsAppTextBoxArray[1] = new TextBox();
                FirstOOBOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstOOBOpsAppTextBoxArray[0].Width = 250;
                FirstOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstOOBOpsAppTextBoxArray[0].Height = 125;
                FirstOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsAppTextBoxArray[1].Width = 250;
                FirstOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstOOBOpsAppTextBoxArray[1].Height = 125;
                FirstOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsButtonArray = new Button[1];
                FirstOOBOpsButtonArray[0] = new Button();
                FirstOOBOpsButtonArray[0].Content = "Generate Challenge";
                FirstOOBOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else if (OOBOpsAppUIChooser == 2)
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                SecondOOBOpsAppTextBlockArray = new TextBlock[4];
                SecondOOBOpsAppTextBlockArray[0] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[1] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[2] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[3] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[0].Text = "User ID?";
                SecondOOBOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                SecondOOBOpsAppTextBlockArray[2].Text = "Challenge";
                SecondOOBOpsAppTextBlockArray[3].Text = "Signed Challenge (Read Only)";
                SecondOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBoxArray = new TextBox[3];
                SecondOOBOpsAppTextBoxArray[0] = new TextBox();
                SecondOOBOpsAppTextBoxArray[1] = new TextBox();
                SecondOOBOpsAppTextBoxArray[2] = new TextBox();
                SecondOOBOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondOOBOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondOOBOpsAppTextBoxArray[0].Width = 250;
                SecondOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[0].Height = 125;
                SecondOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppTextBoxArray[1].Width = 250;
                SecondOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[1].Height = 125;
                SecondOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppTextBoxArray[2].Width = 250;
                SecondOOBOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[2].Height = 125;
                SecondOOBOpsAppTextBoxArray[2].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppComboBoxArray = new ComboBox[1];
                SecondOOBOpsAppComboBoxArray[0] = new ComboBox();
                SecondOOBOpsAppComboBoxArray[0].MaxWidth = 250;
                OOBOpsAppLoadUserIDs();
                SecondOOBOpsAppComboBoxArray[0].SelectionChanged += OOBOpsAppComboBoxSelectedItemsChanged;
                SecondOOBOpsAppButtonArray = new Button[1];
                SecondOOBOpsAppButtonArray[0] = new Button();
                SecondOOBOpsAppButtonArray[0].Content = "Sign Challenge";
                SecondOOBOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppComboBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[3]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else if (OOBOpsAppUIChooser == 3)
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                ThirdOOBOpsAppTextBlockArray = new TextBlock[3];
                ThirdOOBOpsAppTextBlockArray[0] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[1] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[2] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[0].Text = "Signed Challenge";
                ThirdOOBOpsAppTextBlockArray[1].Text = "Others' DSA Public Key";
                ThirdOOBOpsAppTextBlockArray[2].Text = "Status (Read Only)";
                ThirdOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppTextBoxArray = new TextBox[3];
                ThirdOOBOpsAppTextBoxArray[0] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[1] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[2] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[2].IsReadOnly = true;
                ThirdOOBOpsAppTextBoxArray[0].Width = 250;
                ThirdOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[0].Height = 125;
                ThirdOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppTextBoxArray[1].Width = 250;
                ThirdOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[1].Height = 125;
                ThirdOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppTextBoxArray[2].Width = 250;
                ThirdOOBOpsAppTextBoxArray[2].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[2].Height = 125;
                ThirdOOBOpsAppTextBoxArray[2].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppButtonArray = new Button[1];
                ThirdOOBOpsAppButtonArray[0] = new Button();
                ThirdOOBOpsAppButtonArray[0].Content = "Verify Signed Challenge";
                ThirdOOBOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetOOBOpsAppUI();
        }
    }

    private void CertInfoOpsAppDrawUI()
    {
        if (CertInfoOpsAppUIChooser == 1)
        {
            if (HasCertInfoOpsAppUIRendered == false)
            {
                FirstCertInfoOpsAppTextBlockArray = new TextBlock[2];
                FirstCertInfoOpsAppTextBlockArray[0] = new TextBlock();
                FirstCertInfoOpsAppTextBlockArray[1] = new TextBlock();
                FirstCertInfoOpsAppTextBlockArray[0].Text = "EU's Arweave ID?";
                FirstCertInfoOpsAppTextBlockArray[1].Text = "Decoded EU's Arweave Info (RO)";
                FirstCertInfoOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCertInfoOpsAppTextBoxArray = new TextBox[2];
                FirstCertInfoOpsAppTextBoxArray[0] = new TextBox();
                FirstCertInfoOpsAppTextBoxArray[1] = new TextBox();
                FirstCertInfoOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstCertInfoOpsAppTextBoxArray[0].Width = 300;
                FirstCertInfoOpsAppTextBoxArray[0].MaxWidth = 300;
                FirstCertInfoOpsAppTextBoxArray[0].Height = 50;
                FirstCertInfoOpsAppTextBoxArray[0].MaxHeight = 50;
                FirstCertInfoOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstCertInfoOpsAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstCertInfoOpsAppTextBoxArray[1].Width = 400;
                FirstCertInfoOpsAppTextBoxArray[1].MaxWidth = 400;
                FirstCertInfoOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstCertInfoOpsAppTextBoxArray[1].Height = 125;
                FirstCertInfoOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstCertInfoOpsAppButtonArray = new Button[1];
                FirstCertInfoOpsAppButtonArray[0] = new Button();
                FirstCertInfoOpsAppButtonArray[0].Content = "Decode EU Info";
                FirstCertInfoOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCertInfoOpsAppButtonArray[0].Click += CertInfoOpsAppBTN_Click;
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBlockArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBoxArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBlockArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBoxArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppButtonArray[0]);
                HasCertInfoOpsAppUIRendered = true;
            }
        }
        else if (CertInfoOpsAppUIChooser == 2)
        {
            if (HasCertInfoOpsAppUIRendered == false)
            {
                SecondCertInfoOpsAppTextBlockArray = new TextBlock[2];
                SecondCertInfoOpsAppTextBlockArray[0] = new TextBlock();
                SecondCertInfoOpsAppTextBlockArray[1] = new TextBlock();
                SecondCertInfoOpsAppTextBlockArray[0].Text = "EU Cert's Arweave ID?";
                SecondCertInfoOpsAppTextBlockArray[1].Text = "Decoded EU Cert (RO)";
                SecondCertInfoOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCertInfoOpsAppTextBoxArray = new TextBox[2];
                SecondCertInfoOpsAppTextBoxArray[0] = new TextBox();
                SecondCertInfoOpsAppTextBoxArray[1] = new TextBox();
                SecondCertInfoOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondCertInfoOpsAppTextBoxArray[0].Width = 300;
                SecondCertInfoOpsAppTextBoxArray[0].MaxWidth = 300;
                SecondCertInfoOpsAppTextBoxArray[0].Height = 50;
                SecondCertInfoOpsAppTextBoxArray[0].MaxHeight = 50;
                SecondCertInfoOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondCertInfoOpsAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                SecondCertInfoOpsAppTextBoxArray[1].MaxWidth = 400;
                SecondCertInfoOpsAppTextBoxArray[1].Width = 400;
                SecondCertInfoOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondCertInfoOpsAppTextBoxArray[1].Height = 125;
                SecondCertInfoOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondCertInfoOpsAppButtonArray = new Button[1];
                SecondCertInfoOpsAppButtonArray[0] = new Button();
                SecondCertInfoOpsAppButtonArray[0].Content = "Decode Cert";
                SecondCertInfoOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCertInfoOpsAppButtonArray[0].Click += CertInfoOpsAppBTN_Click;
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBlockArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBoxArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBlockArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBoxArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppButtonArray[0]);
                HasCertInfoOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetCertInfoOpsAppUI();
        }
    }

    private void ResetServerOpsAppUI()
    {
        ServerOpsAppUIChooser = 0;
        FirstServerOpsAppTextBlockArray = new TextBlock[] { };
        FirstServerOpsAppTextBoxArray = new TextBox[] { };
        FirstServerOpsAppButtonArray = new Button[] { };
        SecondServerOpsAppTextBlockArray = new TextBlock[] { };
        SecondServerOpsAppTextBoxArray = new TextBox[] { };
        SecondServerOpsAppButtonArray = new Button[] { };
        ThirdServerOpsAppTextBlockArray = new TextBlock[] { };
        ThirdServerOpsAppTextBoxArray = new TextBox[] { };
        ThirdServerOpsAppButtonArray = new Button[] { };
        ServerOpsAppLowerRightLPSP.Children.Clear();
        HasServerOpsAppUIRendered = false;
    }

    private void ResetEUOpsAppUI()
    {
        EUOpsAppUIChooser = 0;
        FirstEUOpsAppTextBlockArray = new TextBlock[] { };
        FirstEUOpsAppTextBoxArray = new TextBox[] { };
        FirstEUOpsAppRadioButtonArray = new RadioButton[] { };
        FirstEUOpsAppButtonArray = new Button[] { };
        SecondEUOpsAppTextBlockArray = new TextBlock[] { };
        SecondEUOpsAppTextBoxArray = new TextBox[] { };
        SecondEUOpsAppComboBoxArray = new ComboBox[] { };
        SecondEUOpsAppButtonArray = new Button[] { };
        ThirdEUOpsAppTextBlockArray = new TextBlock[] { };
        ThirdEUOpsAppTextBoxArray = new TextBox[] { };
        ThirdEUOpsAppComboBoxArray = new ComboBox[] { };
        ThirdEUOpsAppRadioButtonArray = new RadioButton[] { };
        ThirdEUOpsAppButtonArray = new Button[] { };
        EUOpsAppLowerRightSP.Children.Clear();
        HasEUOpsAppUIRendered = false;
    }

    private void ResetOOBOpsAppUI()
    {
        OOBOpsAppUIChooser = 0;
        FirstOOBOpsAppTextBlockArray = new TextBlock[] { };
        FirstOOBOpsAppTextBoxArray = new TextBox[] { };
        FirstOOBOpsButtonArray = new Button[] { };
        SecondOOBOpsAppTextBlockArray = new TextBlock[] { };
        SecondOOBOpsAppTextBoxArray = new TextBox[] { };
        SecondOOBOpsAppComboBoxArray = new ComboBox[] { };
        SecondOOBOpsAppButtonArray = new Button[] { };
        ThirdOOBOpsAppTextBlockArray = new TextBlock[] { };
        ThirdOOBOpsAppTextBoxArray = new TextBox[] { };
        ThirdOOBOpsAppButtonArray = new Button[] { };
        OOBOpsAppLowerRightSP.Children.Clear();
        HasOOBOpsAppUIRendered = false;
    }

    private void ResetCertInfoOpsAppUI()
    {
        CertInfoOpsAppUIChooser = 0;
        FirstCertInfoOpsAppTextBlockArray = new TextBlock[] { };
        FirstCertInfoOpsAppTextBoxArray = new TextBox[] { };
        FirstCertInfoOpsAppButtonArray = new Button[] { };
        SecondCertInfoOpsAppTextBlockArray = new TextBlock[] { };
        SecondCertInfoOpsAppTextBoxArray = new TextBox[] { };
        SecondCertInfoOpsAppButtonArray = new Button[] { };
        CertInfoOpsAppLowerRightSP.Children.Clear();
        HasCertInfoOpsAppUIRendered = false;
    }

    private void EUOpsAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (EUOpsAppUIChooser == 2)
        {
            if (SecondEUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                SecondEUOpsAppTextBoxArray[0].Text = SecondEUOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
        else if (EUOpsAppUIChooser == 3)
        {
            if (ThirdEUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                ThirdEUOpsAppTextBoxArray[0].Text = ThirdEUOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void OOBOpsAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (OOBOpsAppUIChooser == 2)
        {
            if (SecondOOBOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                SecondOOBOpsAppTextBoxArray[0].Text = SecondOOBOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void ServerOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (ServerOpsAppUIChooser == 1)
        {
            String IPAddress = FirstServerOpsAppTextBoxArray[0].Text;
            if (IPAddress != null && IPAddress.CompareTo("") != 0)
            {
                if (File.Exists(EUOpsAppServerRootFolder + "IP.txt") == true)
                {
                    ServerIPStatusTB.Text = "";
                }
                File.WriteAllText(EUOpsAppServerRootFolder + "IP.txt", IPAddress);
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
                FirstServerOpsAppTextBoxArray[1].Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
        else if (ServerOpsAppUIChooser == 2)
        {
            String User_ID = SecondServerOpsAppTextBoxArray[0].Text;
            if (User_ID != null && User_ID.CompareTo("") != 0)
            {
                MLEUFullCertModel MyModel = new MLEUFullCertModel();
                MyModel.SNode_EU_User_ID = "";
                MyModel.SNode_EU_Arweave_Info_ID = "";
                MyModel.SNode_EU_Arweave_Cert_ID = "";
                MyModel.SNode_Users_Certs_Info = new MLAUCertModel[] { };
                MyModel.Status = "";
                GetEUFullCertHelper.GetFullCert(User_ID, EUOpsAppCertificateFolder + User_ID, ref MyModel);
                if (MyModel.Status.Contains("Error") == false)
                {
                    SecondServerOpsAppTextBoxArray[1].Text = MyModel.SNode_EU_Arweave_Info_ID;
                    SecondServerOpsAppTextBoxArray[2].Text = MyModel.SNode_EU_Arweave_Cert_ID;
                    SecondServerOpsAppTextBoxArray[3].Text = "Neccessary information fetched. You can check '" + EUOpsAppCertificateFolder + User_ID + "' folder for your reference.";
                }
                else
                {
                    SecondServerOpsAppTextBoxArray[3].Text = MyModel.Status;
                }
            }
        }
        else if (ServerOpsAppUIChooser == 3)
        {
            ThirdServerOpsAppTextBoxArray[0].Text = GetServerARHelper.GetAR();
        }
        else if (ServerOpsAppUIChooser == 4) 
        {
            String RawNodeInformation = GetNodeInformationHelper.GetNodeInfo();
            String[] NodeInformationArray = RawNodeInformation.Split(",");
            FourthServerOpsAppTextBoxArray[0].Text = NodeInformationArray[0];
            FourthServerOpsAppTextBoxArray[1].Text = NodeInformationArray[1];
            FourthServerOpsAppTextBoxArray[2].Text = NodeInformationArray[2];
            FourthServerOpsAppTextBoxArray[3].Text = NodeInformationArray[3];
            FourthServerOpsAppTextBoxArray[4].Text = NodeInformationArray[4];
        }
        else if (ServerOpsAppUIChooser == 5) 
        {
            FifthServerOpsAppTextBoxArray[0].Text = GetCompromisedEUsHelper.GetCompromisedEUs();
        }
    }

    private void EUOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (EUOpsAppUIChooser == 1)
        {
            String Pub_Contact = FirstEUOpsAppTextBoxArray[1].Text;
            String Priv_Contact = FirstEUOpsAppTextBoxArray[2].Text;
            String AuthenticationPublicKeyB64String = "";
            String SigningPublicKeyB64String = "";
            String OOBPublicKeyB64String = "";
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(182);
            String User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
            if (User_ID.Length > 32)
            {
                User_ID = User_ID.Substring(0, 32);
            }
            while (Directory.Exists(EUOPsAppRootFolder + User_ID) == true)
            {
                User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
                if (User_ID.Length > 32)
                {
                    User_ID = User_ID.Substring(0, 32);
                }
            }
            Directory.CreateDirectory(EUOPsAppRootFolder + User_ID);
            Directory.CreateDirectory(OOBOpsAppRootFolder + User_ID);
            if (FirstEUOpsAppRadioButtonArray[0].IsChecked == true)
            {
                RevampedKeyPair MyAuthenticationKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair MySigningKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair MyOOBKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED25519");
                }
                else
                {
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(EUOPsAppRootFolder + User_ID + "/AlgorithmType.txt", "ED25519");
                }
                AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                MyAuthenticationKeyPair.Clear();
                MySigningKeyPair.Clear();
                MyOOBKeyPair.Clear();
            }
            else
            {
                ED448RevampedKeyPair MyAuthenticationKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair MySigningKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair MyOOBKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED448");
                }
                else
                {
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(EUOPsAppRootFolder + User_ID + "/AlgorithmType.txt", "ED448");
                }
                AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                MyAuthenticationKeyPair.Clear();
                MySigningKeyPair.Clear();
                MyOOBKeyPair.Clear();
            }
            if (Pub_Contact != null && Pub_Contact.CompareTo("") != 0)
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\Contact.txt", Pub_Contact);
                }
                else
                {
                    File.WriteAllText(EUOPsAppRootFolder + User_ID + "/Contact.txt", Pub_Contact);
                }
            }
            if (String.IsNullOrEmpty(Priv_Contact)==true) 
            {
                Priv_Contact = "";
            }
            FirstEUOpsAppTextBoxArray[0].Text = User_ID;
            FirstEUOpsAppTextBoxArray[3].Text = AuthenticationPublicKeyB64String;
            FirstEUOpsAppTextBoxArray[4].Text = SigningPublicKeyB64String;
            FirstEUOpsAppTextBoxArray[5].Text = OOBPublicKeyB64String;
            FirstEUOpsAppTextBoxArray[6].Text = CurrentDateTime.Day.ToString();
            FirstEUOpsAppTextBoxArray[7].Text = CurrentDateTime.Month.ToString();
            FirstEUOpsAppTextBoxArray[8].Text = CurrentDateTime.Year.ToString();
            FirstEUOpsAppTextBoxArray[9].Text = EndUserRegistration.RegisterEndUser(User_ID, AuthenticationPublicKeyB64String, SigningPublicKeyB64String, Pub_Contact,Priv_Contact, OOBPublicKeyB64String);
            EUOpsAppLoadUserIDs();
        }
        else if (EUOpsAppUIChooser == 2)
        {
            if (SecondEUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                String User_ID = SecondEUOpsAppTextBoxArray[0].Text;
                String Contact = "";
                Byte[] AuthenticationPublicKey = new Byte[] { };
                Byte[] SigningPublicKey = new Byte[] { };
                Byte[] OOBPublicKey = new Byte[] { };
                String AlgorithmType = "";
                String AuthPublicKeyB64 = "";
                String SigningPublicKeyB64 = "";
                String OOBPublicKeyB64 = "";
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    if (File.Exists(EUOPsAppRootFolder + User_ID + "\\Contact.txt") == true)
                    {
                        Contact = File.ReadAllText(EUOPsAppRootFolder + User_ID + "\\Contact.txt");
                    }
                    AuthenticationPublicKey = File.ReadAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt");
                    SigningPublicKey = File.ReadAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt");
                    OOBPublicKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt");
                    AlgorithmType = File.ReadAllText(EUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt");
                }
                else
                {
                    if (File.Exists(EUOPsAppRootFolder + User_ID + "/Contact.txt") == true)
                    {
                        Contact = File.ReadAllText(EUOPsAppRootFolder + User_ID + "/Contact.txt");
                    }
                    AuthenticationPublicKey = File.ReadAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt");
                    SigningPublicKey = File.ReadAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt");
                    OOBPublicKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt");
                    AlgorithmType = File.ReadAllText(EUOPsAppRootFolder + User_ID + "/AlgorithmType.txt");
                }
                AuthPublicKeyB64 = Convert.ToBase64String(AuthenticationPublicKey);
                SigningPublicKeyB64 = Convert.ToBase64String(SigningPublicKey);
                OOBPublicKeyB64 = Convert.ToBase64String(OOBPublicKey);
                SecondEUOpsAppTextBoxArray[1].Text = Contact;
                SecondEUOpsAppTextBoxArray[2].Text = AuthPublicKeyB64;
                SecondEUOpsAppTextBoxArray[3].Text = SigningPublicKeyB64;
                SecondEUOpsAppTextBoxArray[4].Text = OOBPublicKeyB64;
                SecondEUOpsAppTextBoxArray[5].Text = AlgorithmType;
            }
        }
        else if (EUOpsAppUIChooser == 3)
        {
            if (ThirdEUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                String User_ID = ThirdEUOpsAppTextBoxArray[0].Text;
                String Pub_Contact = ThirdEUOpsAppTextBoxArray[1].Text;
                String Priv_Contact = ThirdEUOpsAppTextBoxArray[2].Text;
                String AuthenticationPublicKeyB64String = "";
                String SigningPublicKeyB64String = "";
                String OOBPublicKeyB64String = "";
                if (String.IsNullOrEmpty(Pub_Contact)) 
                {
                    Pub_Contact = "";
                }
                if (String.IsNullOrEmpty(Priv_Contact)) 
                {
                    Priv_Contact = "";
                }
                if (ThirdEUOpsAppRadioButtonArray[0].IsChecked == true)
                {
                    RevampedKeyPair MyAuthenticationKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    RevampedKeyPair MySigningKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    RevampedKeyPair MyOOBKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                    SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                    OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                    ThirdEUOpsAppTextBoxArray[6].Text = EndUserInfoUpdate.UpdateEndUser(User_ID, AuthenticationPublicKeyB64String, SigningPublicKeyB64String, Pub_Contact, Priv_Contact ,OOBPublicKeyB64String);
                    if (ThirdEUOpsAppTextBoxArray[6].Text.Contains("Error") == false) 
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED25519");
                        }
                        else
                        {
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(EUOPsAppRootFolder + User_ID + "/AlgorithmType.txt", "ED25519");
                        }
                        if (Pub_Contact != null && Pub_Contact.CompareTo("") != 0)
                        {
                            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                            {
                                File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\Contact.txt", Pub_Contact);
                            }
                            else
                            {
                                File.WriteAllText(EUOPsAppRootFolder + User_ID + "/Contact.txt", Pub_Contact);
                            }
                        }
                    }
                    MyAuthenticationKeyPair.Clear();
                    MySigningKeyPair.Clear();
                    MyOOBKeyPair.Clear();
                }
                else
                {
                    ED448RevampedKeyPair MyAuthenticationKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    ED448RevampedKeyPair MySigningKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    ED448RevampedKeyPair MyOOBKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                    SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                    OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                    ThirdEUOpsAppTextBoxArray[6].Text = EndUserInfoUpdate.UpdateEndUser(User_ID, AuthenticationPublicKeyB64String, SigningPublicKeyB64String, Pub_Contact, Priv_Contact, OOBPublicKeyB64String);
                    if (ThirdEUOpsAppTextBoxArray[6].Text.Contains("Error") == false)
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED448");
                        }
                        else
                        {
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                            File.WriteAllBytes(EUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                            File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                            File.WriteAllText(EUOPsAppRootFolder + User_ID + "/AlgorithmType.txt", "ED448");
                        }
                        if (Pub_Contact != null && Pub_Contact.CompareTo("") != 0)
                        {
                            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                            {
                                File.WriteAllText(EUOPsAppRootFolder + User_ID + "\\Contact.txt", Pub_Contact);
                            }
                            else
                            {
                                File.WriteAllText(EUOPsAppRootFolder + User_ID + "/Contact.txt", Pub_Contact);
                            }
                        }
                    }
                    MyAuthenticationKeyPair.Clear();
                    MySigningKeyPair.Clear();
                    MyOOBKeyPair.Clear();
                }
                ThirdEUOpsAppTextBoxArray[2].Text = AuthenticationPublicKeyB64String;
                ThirdEUOpsAppTextBoxArray[3].Text = SigningPublicKeyB64String;
                ThirdEUOpsAppTextBoxArray[4].Text = OOBPublicKeyB64String;
            }
        }
    }

    private void OOBOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (OOBOpsAppUIChooser == 1)
        {
            String ChallengeLengthString = FirstOOBOpsAppTextBoxArray[0].Text;
            Boolean AbleToParse = true;
            Boolean IsGreaterOrEqual16Bytes = true;
            int ChallengeLength = 0;
            Byte[] Challenge = new Byte[] { };
            if (ChallengeLengthString != null && ChallengeLengthString.CompareTo("") != 0)
            {
                try
                {
                    ChallengeLength = int.Parse(ChallengeLengthString);
                    if (ChallengeLength < 16)
                    {
                        IsGreaterOrEqual16Bytes = false;
                    }
                }
                catch
                {
                    AbleToParse = false;
                }
                if (AbleToParse == true && IsGreaterOrEqual16Bytes == true)
                {
                    Challenge = SodiumRNG.GetRandomBytes(ChallengeLength);
                    FirstOOBOpsAppTextBoxArray[1].Text = Convert.ToBase64String(Challenge);
                }
                else
                {
                    FirstOOBOpsAppTextBlockArray[1].Text = "Error: Either you didn't put in round number or the challenge length is not at least 16 bytes";
                }
            }
        }
        else if (OOBOpsAppUIChooser == 2)
        {
            if (SecondOOBOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                String User_ID = SecondOOBOpsAppTextBoxArray[0].Text;
                String ChallengeString = SecondOOBOpsAppTextBoxArray[1].Text;
                Byte[] Challenge = new Byte[] { };
                Byte[] SignedChallenge = new Byte[] { };
                Byte[] UserOOBPrivateKey = new Byte[] { };
                Boolean AbleToParse = true;
                if (ChallengeString != null && ChallengeString.CompareTo("") != 0)
                {
                    try
                    {
                        Challenge = Convert.FromBase64String(ChallengeString);
                    }
                    catch
                    {
                        AbleToParse = false;
                    }
                    if (AbleToParse)
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            UserOOBPrivateKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt");
                        }
                        else
                        {
                            UserOOBPrivateKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt");
                        }
                        if (UserOOBPrivateKey.Length == 64)
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, UserOOBPrivateKey, true);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(UserOOBPrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SecondOOBOpsAppTextBoxArray[2].Text = Convert.ToBase64String(SignedChallenge);
                    }
                    else
                    {
                        SecondOOBOpsAppTextBoxArray[2].Text = "Error: The challenge was not properly encoded with base64";
                    }
                }
            }
        }
        else if (OOBOpsAppUIChooser == 3)
        {
            String SignedChallengeString = ThirdOOBOpsAppTextBoxArray[0].Text;
            String OtherOOBPublicKeyString = ThirdOOBOpsAppTextBoxArray[1].Text;
            Byte[] SignedChallenge = new Byte[] { };
            Byte[] Challenge = new Byte[] { };
            Byte[] OtherOOBPublicKey = new Byte[] { };
            Boolean AbleToParse = true;
            Boolean AbleToVerify = true;
            if (SignedChallengeString != null && SignedChallengeString.CompareTo("") != 0 && OtherOOBPublicKeyString != null && OtherOOBPublicKeyString.CompareTo("") != 0)
            {
                try
                {
                    SignedChallenge = Convert.FromBase64String(SignedChallengeString);
                    OtherOOBPublicKey = Convert.FromBase64String(OtherOOBPublicKeyString);
                }
                catch
                {
                    AbleToParse = false;
                }
                if (AbleToParse == true)
                {
                    try
                    {
                        if (OtherOOBPublicKey.Length == 32)
                        {
                            Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, OtherOOBPublicKey);
                        }
                        else
                        {
                            Challenge = SecureED448.GetMessageFromSignatureMessage(OtherOOBPublicKey, SignedChallenge, new Byte[] { });
                        }
                    }
                    catch
                    {
                        AbleToVerify = false;
                    }
                    if (AbleToVerify)
                    {
                        ThirdOOBOpsAppTextBoxArray[2].Text = "Success: Able to verify the signed challenge with given digital signature public key from other user";
                    }
                    else
                    {
                        ThirdOOBOpsAppTextBoxArray[2].Text = "Error: Unable to verify this signed challenge with given digital signature public key from other user";
                    }
                }
                else
                {
                    ThirdOOBOpsAppTextBoxArray[2].Text = "Error: Signed Challenge or other user's out of band digital signature public key was not encoded in base64";
                }
            }
        }
    }

    private void CertInfoOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (CertInfoOpsAppUIChooser == 1)
        {
            String ArweaveID = FirstCertInfoOpsAppTextBoxArray[0].Text;
            if (String.IsNullOrEmpty(ArweaveID) == false)
            {
                Boolean IsValidArweaveID = true;
                String TXData = "";
                try
                {
                    TXData = GetTransactionDataHelper.GetTransactionData(ArweaveID);
                }
                catch
                {
                    IsValidArweaveID = false;
                }
                if (IsValidArweaveID)
                {
                    Byte[] DecodedArweaveTXData = Base64URLEncodeDecodeHelper.Decode(TXData);
                    String OriginalArweaveTXData = Encoding.UTF8.GetString(DecodedArweaveTXData);
                    FirstCertInfoOpsAppTextBoxArray[1].Text = OriginalArweaveTXData;
                }
                else
                {
                    FirstCertInfoOpsAppTextBoxArray[1].Text = TXData;
                }
            }
            else
            {
                FirstCertInfoOpsAppTextBoxArray[1].Text = "Error: There's no specified Arweave ID";
            }
        }
        else if (CertInfoOpsAppUIChooser == 2)
        {
            String ArweaveID = SecondCertInfoOpsAppTextBoxArray[0].Text;
            if (String.IsNullOrEmpty(ArweaveID) == false)
            {
                Boolean IsValidArweaveID = true;
                String TXData = "";
                try
                {
                    TXData = GetTransactionDataHelper.GetTransactionData(ArweaveID);
                }
                catch
                {
                    IsValidArweaveID = false;
                }
                if (IsValidArweaveID)
                {
                    Byte[] DecodedArweaveTXData = Base64URLEncodeDecodeHelper.Decode(TXData);
                    String OriginalArweaveTXData = Encoding.UTF8.GetString(DecodedArweaveTXData);
                    SecondCertInfoOpsAppTextBoxArray[1].Text = OriginalArweaveTXData;
                }
                else
                {
                    SecondCertInfoOpsAppTextBoxArray[1].Text = TXData;
                }
            }
            else
            {
                SecondCertInfoOpsAppTextBoxArray[1].Text = "Error: There's no specified Arweave ID";
            }
        }
    }

    private void EUOpsAppLoadUserIDs()
    {
        if (EUOpsAppUIChooser >= 2 && EUOpsAppUIChooser <= 3)
        {
            String[] User_IDWithDirectoryPath = Directory.GetDirectories(EUOPsAppRootFolder);
            String[] User_ID = new String[User_IDWithDirectoryPath.Length];
            int Loop = 0;
            while (Loop < User_IDWithDirectoryPath.Length)
            {
                User_ID[Loop] = User_IDWithDirectoryPath[Loop].Remove(0, EUOPsAppRootFolder.Length);
                Loop += 1;
            }
            if (EUOpsAppUIChooser == 2)
            {
                SecondEUOpsAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    SecondEUOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
            else if (EUOpsAppUIChooser == 3)
            {
                ThirdEUOpsAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    ThirdEUOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
        }
    }

    private void OOBOpsAppLoadUserIDs()
    {
        String[] User_IDWithDirectoryPath = Directory.GetDirectories(OOBOpsAppRootFolder);
        String[] User_ID = new String[User_IDWithDirectoryPath.Length];
        int Loop = 0;
        if (OOBOpsAppUIChooser == 2)
        {
            SecondOOBOpsAppComboBoxArray[0].Items.Clear();
            while (Loop < User_IDWithDirectoryPath.Length)
            {
                User_ID[Loop] = User_IDWithDirectoryPath[Loop].Remove(0, OOBOpsAppRootFolder.Length);
                SecondOOBOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                Loop += 1;
            }
        }
    }
}
