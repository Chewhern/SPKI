﻿using SPKIML_EU_App.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SPKIML_EU_App.APIHelper;
using System.Runtime.InteropServices;
using System.IO;
using ASodium;
using BCASodium;

namespace SPKIML_EU_App.APIMethodHelper
{
    public static class EndUserInfoUpdate
    {
        public static String UpdateEndUser(String User_ID, String Auth_PK, String Sign_PK, String Pub_Contact = "", String Priv_Contact = "", String OOB_PK = "")
        {
            String RegistrationAppRootFolder = "";
            Byte[] AuthPrivateKey = new Byte[] { };
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
            {
                RegistrationAppRootFolder = AppContext.BaseDirectory + "\\Users\\";
                AuthPrivateKey = File.ReadAllBytes(RegistrationAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt");
            }
            else 
            {
                RegistrationAppRootFolder = AppContext.BaseDirectory + "/Users/";
                AuthPrivateKey = File.ReadAllBytes(RegistrationAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt");
            }
            Byte[] Challenge = GetPNodeChallenge.GetChallenge(User_ID);
            Byte[] Signed_Challenge = new Byte[] { };
            if (AuthPrivateKey.Length == 64) 
            {
                Signed_Challenge = SodiumPublicKeyAuth.Sign(Challenge, AuthPrivateKey,true);
            }
            else
            {
                Signed_Challenge = SecureED448.GenerateSignatureMessage(AuthPrivateKey, Challenge, new Byte[] { }, true);
            }
            String Signed_ChallengeString = Convert.ToBase64String(Signed_Challenge);
            String StatusString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("NormalUserRegistration/UpdateEndUserInfo?User_ID=" + User_ID + "&SignedChallenge=" + HttpUtility.UrlEncode(Signed_ChallengeString) +"&Auth_PK=" + HttpUtility.UrlEncode(Auth_PK) + "&Sign_PK=" + HttpUtility.UrlEncode(Sign_PK) + "&OOB_PK=" + HttpUtility.UrlEncode(OOB_PK) + "&Pub_Contact=" + HttpUtility.UrlEncode(Pub_Contact) + "&Priv_Contact="+ HttpUtility.UrlEncode(Priv_Contact));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    StatusString = Result.Substring(1, Result.Length - 2);
                }
                else
                {
                    StatusString = "Error: Parent node encounter some issues";
                }
            }
            return StatusString;
        }
    }
}
