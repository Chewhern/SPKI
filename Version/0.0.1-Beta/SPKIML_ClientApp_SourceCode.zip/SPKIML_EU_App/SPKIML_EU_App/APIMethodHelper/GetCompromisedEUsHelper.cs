﻿using Newtonsoft.Json;
using SPKIML_EU_App.SPKIML_ServerModel;
using SPKIML_EU_App.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SPKIML_EU_App.APIMethodHelper
{
    public static class GetCompromisedEUsHelper
    {
        public static String GetCompromisedEUs()
        {
            String CompromisedAUs_ArweaveIDs = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("CompromisedOps/EU");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    MLCompromisedEUInfosModel MyModel = JsonConvert.DeserializeObject<MLCompromisedEUInfosModel>(Result);
                    CompromisedAUs_ArweaveIDs = String.Join(",",MyModel.MLEUInfoArweaveTransactionIDs);
                }
            }
            return CompromisedAUs_ArweaveIDs;
        }
    }
}
