﻿using Newtonsoft.Json;
using SPKIML_EU_App.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIML_EU_App.APIMethodHelper
{
    public static class EndUserRegistration
    {
        public static String RegisterEndUser(String User_ID, String Auth_PK, String Sign_PK, String Pub_Contact = "", String Priv_Contact="",String OOB_PK = "") 
        {
            String StatusString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("NormalUserRegistration?User_ID=" + User_ID +"&Auth_PK=" + HttpUtility.UrlEncode(Auth_PK)+"&Sign_PK="+HttpUtility.UrlEncode(Sign_PK)+"&Pub_Contact="+HttpUtility.UrlEncode(Pub_Contact)+ "&Priv_Contact=" + HttpUtility.UrlEncode(Priv_Contact) + "&OOB_PK="+HttpUtility.UrlEncode(OOB_PK));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    StatusString = Result.Substring(1, Result.Length - 2);
                }
                else
                {
                    StatusString = "Error: Parent node encounter some issues";
                }
            }
            return StatusString;
        }
    }
}
