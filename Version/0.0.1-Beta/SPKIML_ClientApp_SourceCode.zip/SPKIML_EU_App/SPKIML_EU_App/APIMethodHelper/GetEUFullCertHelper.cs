﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SPKIML_EU_App.Helper;
using System.IO;
using System.Runtime.InteropServices;
using SPKIML_EU_App.SPKIML_ServerModel;

namespace SPKIML_EU_App.APIMethodHelper
{
    public static class GetEUFullCertHelper
    {
        public static String StatusString = "";

        public static void GetFullCert(String User_ID, String Path, ref MLEUFullCertModel MyModel)
        {
            int Loop = 0;
            String TempString = "";
            String TempPath = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("MasterNodeCertificateOps/EndUser?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    MyModel = JsonConvert.DeserializeObject<MLEUFullCertModel>(Result);

                    if (MyModel.Status.Contains("Error") == false)
                    {
                        if (Directory.Exists(Path) == false)
                        {
                            Directory.CreateDirectory(Path);
                        }
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllText(Path + "\\Arweave_Info.txt", MyModel.SNode_EU_Arweave_Info_ID);
                            File.WriteAllText(Path + "\\Arweave_Cert.txt", MyModel.SNode_EU_Arweave_Cert_ID);
                            while (Loop < MyModel.SNode_Users_Certs_Info.Length) 
                            {
                                TempPath = Path + "\\" + MyModel.SNode_Users_Certs_Info[Loop].SNode_User_ID;
                                if (Directory.Exists(Path + "\\" + MyModel.SNode_Users_Certs_Info[Loop].SNode_User_ID) == false) 
                                {
                                    Directory.CreateDirectory(Path + "\\" + MyModel.SNode_Users_Certs_Info[Loop].SNode_User_ID);
                                }
                                File.WriteAllText(TempPath + "\\Signer_Arweave_Info.txt", MyModel.SNode_Users_Certs_Info[Loop].Arweave_Info_ID);
                                File.WriteAllText(TempPath + "\\Signer_Arweave_Cert.txt", MyModel.SNode_Users_Certs_Info[Loop].Arweave_Cert_ID);
                                TempString = String.Join(Environment.NewLine, MyModel.SNode_Users_Certs_Info[Loop].PNode_Signers_Arweave_IDs);
                                File.WriteAllText(TempPath + "\\Signer_Signer_Arweave_Info.txt", TempString);
                                TempString = String.Join(Environment.NewLine, MyModel.SNode_Users_Certs_Info[Loop].PNode_Signers_Arweave_Cert_IDs);
                                File.WriteAllText(TempPath + "\\Signer_Signer_Arweave_Cert.txt", TempString);
                                TempString = String.Join(Environment.NewLine, MyModel.SNode_Users_Certs_Info[Loop].PNode_ONode_Signers_Arweave_IDs);
                                File.WriteAllText(TempPath + "\\Signer_Signer_Signer_Arweave_Info.txt", TempString);
                                Loop += 1;
                            }
                        }
                        else
                        {
                            File.WriteAllText(Path + "/Arweave_Info.txt", MyModel.SNode_EU_Arweave_Info_ID);
                            File.WriteAllText(Path + "/Arweave_Cert.txt", MyModel.SNode_EU_Arweave_Cert_ID);
                            while (Loop < MyModel.SNode_Users_Certs_Info.Length)
                            {
                                TempPath = Path + "/" + MyModel.SNode_Users_Certs_Info[Loop].SNode_User_ID;
                                if (Directory.Exists(Path + "/" + MyModel.SNode_Users_Certs_Info[Loop].SNode_User_ID) == false)
                                {
                                    Directory.CreateDirectory(Path + "/" + MyModel.SNode_Users_Certs_Info[Loop].SNode_User_ID);
                                }
                                File.WriteAllText(TempPath + "/Signer_Arweave_Info.txt", MyModel.SNode_Users_Certs_Info[Loop].Arweave_Info_ID);
                                File.WriteAllText(TempPath + "/Signer_Arweave_Cert.txt", MyModel.SNode_Users_Certs_Info[Loop].Arweave_Cert_ID);
                                TempString = String.Join(Environment.NewLine, MyModel.SNode_Users_Certs_Info[Loop].PNode_Signers_Arweave_IDs);
                                File.WriteAllText(TempPath + "/Signer_Signer_Arweave_Info.txt", TempString);
                                TempString = String.Join(Environment.NewLine, MyModel.SNode_Users_Certs_Info[Loop].PNode_Signers_Arweave_Cert_IDs);
                                File.WriteAllText(TempPath + "/Signer_Signer_Arweave_Cert.txt", TempString);
                                TempString = String.Join(Environment.NewLine, MyModel.SNode_Users_Certs_Info[Loop].PNode_ONode_Signers_Arweave_IDs);
                                File.WriteAllText(TempPath + "/Signer_Signer_Signer_Arweave_Info.txt", TempString);
                                Loop += 1;
                            }
                        }
                    }
                    StatusString = MyModel.Status;
                }
                else
                {
                    StatusString = "Error: Other Node encounter some issues";
                }
            }
        }
    }
}
