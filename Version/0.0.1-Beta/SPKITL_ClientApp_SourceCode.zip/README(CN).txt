==設置RSA的憑證==
1. 使用任何方法从任何 Arweave 默认钱包应用程序导出 arweave-keyfile-<钱包地址>.json。
2. 将字段从“e”一直复制到“qi”，逐个复制。
3. 对于每个字段，请使用“SimplifiedArweaveSDK”C# SDK。
4. 使用 SDK 将字符串转换为等效的 Byte[] 类型。
5. 使用“File.WriteAllBytes(<Path>,RSAExponentBytes);”以二进制格式创建文件并写入文件。
6. 在“ArweaveOps/RSACredentials”文件夹中，确保存在“D.txt”、“DP.txt”、“DQ.txt”、“Exponent.txt”、“InverseQ.txt”、“Modulus.txt”、“P.txt”、“Q.txt”等文件。

==ON 軟件==
授权用户信息或证书的锚定依赖于人工数据检查和插入操作。如果您负责運行从頂层节点到"ML"服务器应用程序的所有节点，那么人为失誤的概率就会很高。

==AR 最低額度==
相当于 26 美元的 AR 足以满足 TL 和 ML 操作的需求。