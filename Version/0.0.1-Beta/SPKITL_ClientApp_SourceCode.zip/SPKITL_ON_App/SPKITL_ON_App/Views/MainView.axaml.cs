﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using Newtonsoft.Json;
using SimplifiedArweaveSDK.ArweaveLocalHelper;
using SPKITL_ON_App.SPKIDataModel;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace SPKITL_ON_App.Views;

public partial class MainView : UserControl
{
    //Need to do OOB communication if time allows..
    private static int TLAUOpsUIChooser = 0;
    private static int OOBOpsUIChooser = 0;
    //..
    private static TextBlock[] FirstTLAUOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstTLAUOpsTextBoxArray = new TextBox[] { };
    private static Button[] FirstTLAUOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondTLAUOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondTLAUOpsTextBoxArray = new TextBox[] { };
    private static Button[] SecondTLAUOpsButtonArray = new Button[] { };
    private static TextBlock[] ThirdTLAUOpsTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdTLAUOpsTextBoxArray = new TextBox[] { };
    private static Button[] ThirdTLAUOpsButtonArray = new Button[] { };
    //..
    private static Boolean HasTLAUOpsUIRendered = false;
    private static String TLAUOpsMainRootFolder = "";
    private static String TLAUOpsRSASubFolder = "";
    private static String TLAUOpsAUSubFolder = "";
    private static String TLAUOpsONAUSubFolder = "";
    private static String TLAUOpsSNAUSubFolder = "";

    public MainView()
    {
        InitializeComponent();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
        {
            TLAUOpsMainRootFolder = AppContext.BaseDirectory + "\\ArweaveOps\\";
            TLAUOpsRSASubFolder = TLAUOpsMainRootFolder + "\\RSACredentials\\";
            TLAUOpsAUSubFolder = TLAUOpsMainRootFolder + "\\PN_AU\\";
            TLAUOpsONAUSubFolder = TLAUOpsMainRootFolder + "\\ON_AU\\";
            TLAUOpsSNAUSubFolder = TLAUOpsMainRootFolder + "\\SN_AU\\";
        }
        else 
        {
            TLAUOpsMainRootFolder = AppContext.BaseDirectory + "/ArweaveOps/";
            TLAUOpsRSASubFolder = TLAUOpsMainRootFolder + "/RSACredentials/";
            TLAUOpsAUSubFolder = TLAUOpsMainRootFolder + "/PN_AU/";
            TLAUOpsONAUSubFolder = TLAUOpsMainRootFolder + "/ON_AU/";
            TLAUOpsSNAUSubFolder = TLAUOpsMainRootFolder + "/SN_AU/";
        }
        if (Directory.Exists(TLAUOpsMainRootFolder) == false) 
        {
            Directory.CreateDirectory(TLAUOpsMainRootFolder);
        }
        if (Directory.Exists(TLAUOpsRSASubFolder) == false)
        {
            Directory.CreateDirectory(TLAUOpsRSASubFolder);
        }
        if (Directory.Exists(TLAUOpsAUSubFolder) == false)
        {
            Directory.CreateDirectory(TLAUOpsAUSubFolder);
        }
        if (Directory.Exists(TLAUOpsONAUSubFolder) == false)
        {
            Directory.CreateDirectory(TLAUOpsONAUSubFolder);
        }
        if (Directory.Exists(TLAUOpsSNAUSubFolder) == false)
        {
            Directory.CreateDirectory(TLAUOpsSNAUSubFolder);
        }
        TLAUOpsAppInitialization();
    }

    private void TLAUOpsAppInitialization() 
    {
        TLAUOpsUIChooser = 0;
        TLAUOpsAppToggleBTN1.IsCheckedChanged += TLAUOpsAppToggleBTNSFunction;
        TLAUOpsAppToggleBTN2.IsCheckedChanged += TLAUOpsAppToggleBTNSFunction;
        TLAUOpsAppToggleBTN3.IsCheckedChanged += TLAUOpsAppToggleBTNSFunction;
    }

    private void TLAUOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (TLAUOpsAppToggleBTN1.IsChecked == true)
        {
            TLAUOpsAppToggleBTN2.IsChecked = false;
            TLAUOpsAppToggleBTN3.IsChecked = false;
            TLAUOpsUIChooser = 1;
        }
        else if (TLAUOpsAppToggleBTN2.IsChecked == true)
        {
            TLAUOpsAppToggleBTN1.IsChecked = false;
            TLAUOpsAppToggleBTN3.IsChecked = false;
            TLAUOpsUIChooser = 2;
        }
        else if (TLAUOpsAppToggleBTN3.IsChecked == true)
        {
            TLAUOpsAppToggleBTN2.IsChecked = false;
            TLAUOpsAppToggleBTN1.IsChecked = false;
            TLAUOpsUIChooser = 3;
        }
        else 
        {
            TLAUOpsAppResetUI();
        }
        TLAUOpsAppDrawUI();
    }

    private void TLAUOpsAppDrawUI() 
    {
        //3
        if(TLAUOpsUIChooser == 1) 
        {
            if (HasTLAUOpsUIRendered == false) 
            {
                //Priority finish the function
                //later make the code here less messy.. or more organized..
                FirstTLAUOpsTextBlockArray = new TextBlock[11];
                FirstTLAUOpsTextBlockArray[0] = new TextBlock();
                FirstTLAUOpsTextBlockArray[1] = new TextBlock();
                FirstTLAUOpsTextBlockArray[2] = new TextBlock();
                FirstTLAUOpsTextBlockArray[3] = new TextBlock();
                FirstTLAUOpsTextBlockArray[4] = new TextBlock();
                FirstTLAUOpsTextBlockArray[5] = new TextBlock();
                FirstTLAUOpsTextBlockArray[6] = new TextBlock();
                FirstTLAUOpsTextBlockArray[7] = new TextBlock();
                FirstTLAUOpsTextBlockArray[8] = new TextBlock();
                FirstTLAUOpsTextBlockArray[9] = new TextBlock();
                FirstTLAUOpsTextBlockArray[10] = new TextBlock();
                FirstTLAUOpsTextBlockArray[0].Text = "User ID";
                FirstTLAUOpsTextBlockArray[1].Text = "Public Contact";
                FirstTLAUOpsTextBlockArray[2].Text = "Private Contact (Optional, leave blank for now..)";
                FirstTLAUOpsTextBlockArray[3].Text = "Auth PK";
                FirstTLAUOpsTextBlockArray[4].Text = "Sign PK";
                FirstTLAUOpsTextBlockArray[5].Text = "OOB PK";
                FirstTLAUOpsTextBlockArray[6].Text = "SPK Valid Day";
                FirstTLAUOpsTextBlockArray[7].Text = "SPK Valid Month";
                FirstTLAUOpsTextBlockArray[8].Text = "SPK Valid Year";
                FirstTLAUOpsTextBlockArray[9].Text = "What's the DSA?";
                FirstTLAUOpsTextBlockArray[10].Text = "Arweave ID/Status (Read Only)";
                FirstTLAUOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[8].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[9].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBlockArray[10].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsTextBoxArray = new TextBox[11];
                FirstTLAUOpsTextBoxArray[0] = new TextBox();
                FirstTLAUOpsTextBoxArray[1] = new TextBox();
                FirstTLAUOpsTextBoxArray[2] = new TextBox();
                FirstTLAUOpsTextBoxArray[3] = new TextBox();
                FirstTLAUOpsTextBoxArray[4] = new TextBox();
                FirstTLAUOpsTextBoxArray[5] = new TextBox();
                FirstTLAUOpsTextBoxArray[6] = new TextBox();
                FirstTLAUOpsTextBoxArray[7] = new TextBox();
                FirstTLAUOpsTextBoxArray[8] = new TextBox();
                FirstTLAUOpsTextBoxArray[9] = new TextBox();
                FirstTLAUOpsTextBoxArray[10] = new TextBox();
                FirstTLAUOpsTextBoxArray[0].Width = 250;
                FirstTLAUOpsTextBoxArray[0].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[0].Height = 50;
                FirstTLAUOpsTextBoxArray[0].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[1].Width = 250;
                FirstTLAUOpsTextBoxArray[1].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[1].Height = 50;
                FirstTLAUOpsTextBoxArray[1].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[2].Width = 250;
                FirstTLAUOpsTextBoxArray[2].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[2].Height = 50;
                FirstTLAUOpsTextBoxArray[2].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[3].Width = 250;
                FirstTLAUOpsTextBoxArray[3].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[3].Height = 50;
                FirstTLAUOpsTextBoxArray[3].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[4].Width = 250;
                FirstTLAUOpsTextBoxArray[4].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[4].Height = 50;
                FirstTLAUOpsTextBoxArray[4].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[5].Width = 250;
                FirstTLAUOpsTextBoxArray[5].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[5].Height = 50;
                FirstTLAUOpsTextBoxArray[5].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[6].Width = 250;
                FirstTLAUOpsTextBoxArray[6].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[6].Height = 50;
                FirstTLAUOpsTextBoxArray[6].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[7].Width = 250;
                FirstTLAUOpsTextBoxArray[7].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[7].Height = 50;
                FirstTLAUOpsTextBoxArray[7].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[8].Width = 250;
                FirstTLAUOpsTextBoxArray[8].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[8].Height = 50;
                FirstTLAUOpsTextBoxArray[8].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[8].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[9].Width = 250;
                FirstTLAUOpsTextBoxArray[9].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[9].Height = 50;
                FirstTLAUOpsTextBoxArray[9].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[9].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[10].Width = 250;
                FirstTLAUOpsTextBoxArray[10].MaxWidth = 250;
                FirstTLAUOpsTextBoxArray[10].Height = 50;
                FirstTLAUOpsTextBoxArray[10].MaxHeight = 50;
                FirstTLAUOpsTextBoxArray[10].TextWrapping = TextWrapping.Wrap;
                FirstTLAUOpsTextBoxArray[10].IsReadOnly = true;
                FirstTLAUOpsTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[1].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[2].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[3].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[4].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[5].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[6].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[7].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[8].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[9].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsTextBoxArray[10].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstTLAUOpsButtonArray = new Button[1];
                FirstTLAUOpsButtonArray[0] = new Button();
                FirstTLAUOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstTLAUOpsButtonArray[0].Content = "Anchor AU Info";
                FirstTLAUOpsButtonArray[0].Click += TLAUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 350;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[0]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[0]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[1]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[1]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[2]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[2]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[3]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[3]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[4]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[4]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[5]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[5]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[6]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[6]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[7]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[7]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[8]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[8]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[9]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[9]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBlockArray[10]);
                MyStackPanel.Children.Add(FirstTLAUOpsTextBoxArray[10]);
                MyStackPanel.Children.Add(FirstTLAUOpsButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                TLAUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasTLAUOpsUIRendered = true;
            }
        }
        else if (TLAUOpsUIChooser == 2)
        {
            if (HasTLAUOpsUIRendered == false)
            {
                SecondTLAUOpsTextBlockArray = new TextBlock[8];
                SecondTLAUOpsTextBlockArray[0] = new TextBlock();
                SecondTLAUOpsTextBlockArray[1] = new TextBlock();
                SecondTLAUOpsTextBlockArray[2] = new TextBlock();
                SecondTLAUOpsTextBlockArray[3] = new TextBlock();
                SecondTLAUOpsTextBlockArray[4] = new TextBlock();
                SecondTLAUOpsTextBlockArray[5] = new TextBlock();
                SecondTLAUOpsTextBlockArray[6] = new TextBlock();
                SecondTLAUOpsTextBlockArray[7] = new TextBlock();
                SecondTLAUOpsTextBlockArray[0].Text = "ONode User ID ";
                SecondTLAUOpsTextBlockArray[1].Text = "Signer User IDs (use ',')";
                SecondTLAUOpsTextBlockArray[2].Text = "Signed Auth PKs (use ',')";
                SecondTLAUOpsTextBlockArray[3].Text = "Signed Sign PKs (use ',')";
                SecondTLAUOpsTextBlockArray[4].Text = "Signed Date Days (Read only)";
                SecondTLAUOpsTextBlockArray[5].Text = "Signed Date Months (Read only)";
                SecondTLAUOpsTextBlockArray[6].Text = "Signed Date Years (Read only)";
                SecondTLAUOpsTextBlockArray[7].Text = "Arweave ID/Status (Read Only)";
                SecondTLAUOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsTextBoxArray = new TextBox[8];
                SecondTLAUOpsTextBoxArray[0] = new TextBox();
                SecondTLAUOpsTextBoxArray[1] = new TextBox();
                SecondTLAUOpsTextBoxArray[2] = new TextBox();
                SecondTLAUOpsTextBoxArray[3] = new TextBox();
                SecondTLAUOpsTextBoxArray[4] = new TextBox();
                SecondTLAUOpsTextBoxArray[5] = new TextBox();
                SecondTLAUOpsTextBoxArray[6] = new TextBox();
                SecondTLAUOpsTextBoxArray[7] = new TextBox();
                SecondTLAUOpsTextBoxArray[4].IsReadOnly = true;
                SecondTLAUOpsTextBoxArray[5].IsReadOnly = true;
                SecondTLAUOpsTextBoxArray[6].IsReadOnly = true;
                SecondTLAUOpsTextBoxArray[7].IsReadOnly = true;
                SecondTLAUOpsTextBoxArray[0].Width = 250;
                SecondTLAUOpsTextBoxArray[0].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[0].Height = 50;
                SecondTLAUOpsTextBoxArray[0].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[1].Width = 250;
                SecondTLAUOpsTextBoxArray[1].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[1].Height = 50;
                SecondTLAUOpsTextBoxArray[1].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[2].Width = 250;
                SecondTLAUOpsTextBoxArray[2].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[2].Height = 50;
                SecondTLAUOpsTextBoxArray[2].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[3].Width = 250;
                SecondTLAUOpsTextBoxArray[3].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[3].Height = 50;
                SecondTLAUOpsTextBoxArray[3].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[4].Width = 250;
                SecondTLAUOpsTextBoxArray[4].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[4].Height = 50;
                SecondTLAUOpsTextBoxArray[4].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[5].Width = 250;
                SecondTLAUOpsTextBoxArray[5].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[5].Height = 50;
                SecondTLAUOpsTextBoxArray[5].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[6].Width = 250;
                SecondTLAUOpsTextBoxArray[6].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[6].Height = 50;
                SecondTLAUOpsTextBoxArray[6].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsTextBoxArray[7].Width = 250;
                SecondTLAUOpsTextBoxArray[7].MaxWidth = 250;
                SecondTLAUOpsTextBoxArray[7].Height = 50;
                SecondTLAUOpsTextBoxArray[7].MaxHeight = 50;
                SecondTLAUOpsTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                SecondTLAUOpsButtonArray = new Button[1];
                SecondTLAUOpsButtonArray[0] = new Button();
                SecondTLAUOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondTLAUOpsButtonArray[0].Content = "Create cert for ONode AU";
                SecondTLAUOpsButtonArray[0].Click += TLAUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 350;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[0]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[0]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[1]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[1]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[2]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[2]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[3]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[3]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[4]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[4]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[5]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[5]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[6]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[6]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBlockArray[7]);
                MyStackPanel.Children.Add(SecondTLAUOpsTextBoxArray[7]);
                MyStackPanel.Children.Add(SecondTLAUOpsButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                TLAUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasTLAUOpsUIRendered = true;
            }
        }
        else if (TLAUOpsUIChooser == 3)
        {
            if (HasTLAUOpsUIRendered == false)
            {
                ThirdTLAUOpsTextBlockArray = new TextBlock[8];
                ThirdTLAUOpsTextBlockArray[0] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[1] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[2] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[3] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[4] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[5] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[6] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[7] = new TextBlock();
                ThirdTLAUOpsTextBlockArray[0].Text = "SNode User ID ";
                ThirdTLAUOpsTextBlockArray[1].Text = "Signer User IDs (use ',')";
                ThirdTLAUOpsTextBlockArray[2].Text = "Signed Auth PKs (use ',')";
                ThirdTLAUOpsTextBlockArray[3].Text = "Signed Sign PKs (use ',')";
                ThirdTLAUOpsTextBlockArray[4].Text = "Signed Date Days (Read only)";
                ThirdTLAUOpsTextBlockArray[5].Text = "Signed Date Months (Read only)";
                ThirdTLAUOpsTextBlockArray[6].Text = "Signed Date Years (Read only)";
                ThirdTLAUOpsTextBlockArray[7].Text = "Arweave ID/Status (Read Only)";
                ThirdTLAUOpsTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsTextBoxArray = new TextBox[8];
                ThirdTLAUOpsTextBoxArray[0] = new TextBox();
                ThirdTLAUOpsTextBoxArray[1] = new TextBox();
                ThirdTLAUOpsTextBoxArray[2] = new TextBox();
                ThirdTLAUOpsTextBoxArray[3] = new TextBox();
                ThirdTLAUOpsTextBoxArray[4] = new TextBox();
                ThirdTLAUOpsTextBoxArray[5] = new TextBox();
                ThirdTLAUOpsTextBoxArray[6] = new TextBox();
                ThirdTLAUOpsTextBoxArray[7] = new TextBox();
                ThirdTLAUOpsTextBoxArray[4].IsReadOnly = true;
                ThirdTLAUOpsTextBoxArray[5].IsReadOnly = true;
                ThirdTLAUOpsTextBoxArray[6].IsReadOnly = true;
                ThirdTLAUOpsTextBoxArray[7].IsReadOnly = true;
                ThirdTLAUOpsTextBoxArray[0].Width = 250;
                ThirdTLAUOpsTextBoxArray[0].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[0].Height = 50;
                ThirdTLAUOpsTextBoxArray[0].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[1].Width = 250;
                ThirdTLAUOpsTextBoxArray[1].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[1].Height = 50;
                ThirdTLAUOpsTextBoxArray[1].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[2].Width = 250;
                ThirdTLAUOpsTextBoxArray[2].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[2].Height = 50;
                ThirdTLAUOpsTextBoxArray[2].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[3].Width = 250;
                ThirdTLAUOpsTextBoxArray[3].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[3].Height = 50;
                ThirdTLAUOpsTextBoxArray[3].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[4].Width = 250;
                ThirdTLAUOpsTextBoxArray[4].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[4].Height = 50;
                ThirdTLAUOpsTextBoxArray[4].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[5].Width = 250;
                ThirdTLAUOpsTextBoxArray[5].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[5].Height = 50;
                ThirdTLAUOpsTextBoxArray[5].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[6].Width = 250;
                ThirdTLAUOpsTextBoxArray[6].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[6].Height = 50;
                ThirdTLAUOpsTextBoxArray[6].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsTextBoxArray[7].Width = 250;
                ThirdTLAUOpsTextBoxArray[7].MaxWidth = 250;
                ThirdTLAUOpsTextBoxArray[7].Height = 50;
                ThirdTLAUOpsTextBoxArray[7].MaxHeight = 50;
                ThirdTLAUOpsTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                ThirdTLAUOpsButtonArray = new Button[1];
                ThirdTLAUOpsButtonArray[0] = new Button();
                ThirdTLAUOpsButtonArray[0].Content = "Create cert for ML AU";
                ThirdTLAUOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdTLAUOpsButtonArray[0].Click += TLAUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 350;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[0]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[0]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[1]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[1]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[2]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[2]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[3]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[3]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[4]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[4]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[5]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[5]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[6]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[6]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBlockArray[7]);
                MyStackPanel.Children.Add(ThirdTLAUOpsTextBoxArray[7]);
                MyStackPanel.Children.Add(ThirdTLAUOpsButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                TLAUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasTLAUOpsUIRendered = true;
            }
        }
        else 
        {
            TLAUOpsAppResetUI();
        }
    }

    private void TLAUOpsAppResetUI() 
    {
        FirstTLAUOpsTextBlockArray = new TextBlock[] { };
        FirstTLAUOpsTextBoxArray = new TextBox[] { };
        FirstTLAUOpsButtonArray = new Button[] { };
        SecondTLAUOpsTextBlockArray = new TextBlock[] { };
        SecondTLAUOpsTextBoxArray = new TextBox[] { };
        SecondTLAUOpsButtonArray = new Button[] { };
        ThirdTLAUOpsTextBlockArray = new TextBlock[] { };
        ThirdTLAUOpsTextBoxArray = new TextBox[] { };
        ThirdTLAUOpsButtonArray = new Button[] { };
        HasTLAUOpsUIRendered = false;
        TLAUOpsUIChooser = 0;
        TLAUOpsAppLowerRightSP.Children.Clear();
    }

    private async void TLAUOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(TLAUOpsUIChooser == 1) 
        {
            String User_ID = FirstTLAUOpsTextBoxArray[0].Text;
            String Public_Contact = FirstTLAUOpsTextBoxArray[1].Text;
            String Private_Contact = FirstTLAUOpsTextBoxArray[2].Text;
            String Sign_PK = FirstTLAUOpsTextBoxArray[3].Text;
            String Auth_PK = FirstTLAUOpsTextBoxArray[4].Text;
            String OOB_PK = FirstTLAUOpsTextBoxArray[5].Text;
            String ValidDate_Day_String = FirstTLAUOpsTextBoxArray[6].Text;
            String ValidDate_Month_String = FirstTLAUOpsTextBoxArray[7].Text;
            String ValidDate_Year_String = FirstTLAUOpsTextBoxArray[8].Text;
            String DSA_Type = FirstTLAUOpsTextBoxArray[9].Text;
            if(String.IsNullOrEmpty(User_ID) == false &&  String.IsNullOrEmpty(Public_Contact) == false && String.IsNullOrEmpty(Sign_PK)==false
                && String.IsNullOrEmpty(Auth_PK)==false && String.IsNullOrEmpty(OOB_PK)==false && String.IsNullOrEmpty(ValidDate_Day_String)==false
                && String.IsNullOrEmpty(ValidDate_Month_String)==false && String.IsNullOrEmpty(ValidDate_Year_String)==false && String.IsNullOrEmpty(DSA_Type) == false) 
            {
                if(File.Exists(TLAUOpsRSASubFolder+"Modulus.txt")==true && File.Exists(TLAUOpsRSASubFolder + "Exponent.txt")==true
                    && File.Exists(TLAUOpsRSASubFolder + "D.txt")==true && File.Exists(TLAUOpsRSASubFolder + "P.txt")==true
                    && File.Exists(TLAUOpsRSASubFolder + "Q.txt")==true && File.Exists(TLAUOpsRSASubFolder + "DP.txt")==true
                    && File.Exists(TLAUOpsRSASubFolder + "DQ.txt")==true && File.Exists(TLAUOpsRSASubFolder + "InverseQ.txt") == true) 
                {
                    //If the developer can ensure in supported proramming languages like Java/Go/Node.JS/TypeScript can 
                    //fully avoid the use of String data type, then cryptographic software side channel attacks can be mitigated.
                    //This applies to both client side and server side.
                    //However, if such use of String data type can't be avoided when dealing with sensitive data such as 
                    //cryptographic secret/private key and API key, then the best optimum intermediary choice for the programming language
                    //will be C# due to the language's structure provide legitimate GCHandle and IntPtr. 
                    //In addition, C/C++ in a pure way can be used..
                    Byte[] ModulusBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Modulus.txt");
                    Byte[] ExponentBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Exponent.txt");
                    Byte[] DBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "D.txt");
                    Byte[] PBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "P.txt");
                    Byte[] QBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Q.txt");
                    Byte[] DPBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "DP.txt");
                    Byte[] DQBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "DQ.txt");
                    Byte[] InverseQBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "InverseQ.txt");
                    int ValidDate_Day = int.Parse(ValidDate_Day_String);
                    int ValidDate_Month = int.Parse(ValidDate_Month_String);
                    int ValidDate_Year = int.Parse(ValidDate_Year_String);
                    if (String.IsNullOrEmpty(Private_Contact) == true)
                    {
                        Private_Contact = "";
                    }
                    TLAUInfoModel MyModel = new TLAUInfoModel();
                    MyModel.User_ID = User_ID;
                    MyModel.Public_Contact = Public_Contact;
                    MyModel.Private_Contact = Private_Contact;
                    MyModel.Sign_PK = Sign_PK;
                    MyModel.Auth_PK = Auth_PK;
                    MyModel.OOB_PK = OOB_PK;
                    MyModel.ValidDate_Day = ValidDate_Day;
                    MyModel.ValidDate_Month = ValidDate_Month;
                    MyModel.ValidDate_Year = ValidDate_Year;
                    MyModel.DSA_Type = DSA_Type;
                    String JSONString = JsonConvert.SerializeObject(MyModel);
                    (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(JSONString, "gtkTFlA1yXTFl_k-OjjltMn5IEqA-YpcD6SuYRksNhVKj8eP3IZ0zREbhQpI2P9aIdEaXxzRhCum89Xe-xEnnHKsmB1CcLMuVSXOtuUz9xQ0XCX3L2hxoytWqviGkn16Cx8_YeOGuHWdJVqjF-oZVY2-Q32kHBbT79AniJHCFxTFuYYIo2YXPD24yVxFgjuySg2LtLo5ImYBkPjs-fnrKW8jAPMr-gmPSgaq7dLf95GBYKIQLjY13ABUaSvODbjBgKHXhB3N6ZALfrPzMLe6pl-_onAvNGzXZXeKyHnY-ar1wnPpGEo8QUXjkQrimBjYJhlE1DxC9J5K7KJgQ2xkLbTPpgfNwQxVUwN5b1CBokxBLUJtCzqxC0ZZC3WEA7ZEqpb0IEeAY7g20O3dN9aJw9VpYaoKjYOVRqmUMmE_XgDtglAVtV1X03-OyYZS3Ss_tz3bUWlv1XvxiW3sDFLLYs9nRkPvEklqT4280uRJbfMkLcgW9wlfzJwPgFJ5MTm9fD5PKGRDOCcNLrXVlacdnLQ_9YlWV9UFgu6CSZsH7v1_frA5VGitK3mfrhvuKJN1ZxszolcwJJAbbw1P-0DbrGF5B6KRE01-f_5v35sBgEm6K4umYbaJ5LFdkpHOn1uPP0H8XSeT_TfG69F7lLHG_YCWXiQzYBeWKK2xyJhjMjU",
                    ModulusBytes, ExponentBytes, DBytes, PBytes, QBytes, DPBytes, DQBytes, InverseQBytes);
                    FirstTLAUOpsTextBoxArray[10].Text = MyResults.TransactionID + " is the transaction ID for Arweave. However, due to some constraints on my side or the Arweave network, you have to check via https://viewblock.io/arweave/address/{wallet_address} to see if the transaction was actually submitted.";
                    String DataString = User_ID + "," + MyResults.TransactionID;
                    String FinalDataString = "";
                    String[] DataStringArray = new String[] { };
                    if (File.Exists(TLAUOpsAUSubFolder + "Anchored_AU.txt") == false)
                    {
                        File.WriteAllText(TLAUOpsAUSubFolder + "Anchored_AU.txt", DataString);
                    }
                    else
                    {
                        DataStringArray = File.ReadAllLines(TLAUOpsAUSubFolder + "Anchored_AU.txt");
                        FinalDataString = String.Join(Environment.NewLine, DataStringArray);
                        FinalDataString += Environment.NewLine + DataString;
                        File.WriteAllText(TLAUOpsAUSubFolder + "Anchored_AU.txt", FinalDataString);
                    }
                }
                else 
                {
                    FirstTLAUOpsTextBoxArray[10].Text = "Error: Neccessary RSA key materials in bytes format were missing..";
                }
            }
            else 
            {
                FirstTLAUOpsTextBoxArray[10].Text = "Error: Some or all information were missing..";
            }
        }
        else if(TLAUOpsUIChooser == 2) 
        {
            String User_ID = SecondTLAUOpsTextBoxArray[0].Text;
            String ONode_User_IDs_RawString = SecondTLAUOpsTextBoxArray[1].Text;
            String Signed_Auth_PKs_RawString = SecondTLAUOpsTextBoxArray[2].Text;
            String Signed_Sign_PKs_RawString = SecondTLAUOpsTextBoxArray[3].Text;
            //GMT+8
            DateTime SigningDateTime = DateTime.UtcNow.AddHours(8);
            if(String.IsNullOrEmpty(User_ID)==false && String.IsNullOrEmpty(ONode_User_IDs_RawString)==false
                && String.IsNullOrEmpty(Signed_Auth_PKs_RawString)==false && String.IsNullOrEmpty(Signed_Sign_PKs_RawString) == false) 
            {
                if(ONode_User_IDs_RawString.Contains(",")==true && Signed_Auth_PKs_RawString.Contains(",")==true
                    && Signed_Sign_PKs_RawString.Contains(",") == true) 
                {
                    String[] ONode_User_IDs = ONode_User_IDs_RawString.Split(",");
                    String[] Signed_Auth_PKs = Signed_Auth_PKs_RawString.Split(",");
                    String[] Signed_Sign_PKs = Signed_Sign_PKs_RawString.Split(",");
                    int[] SignDate_Days = new int[ONode_User_IDs.Length];
                    int[] SignDate_Months = new int[Signed_Auth_PKs.Length];
                    int[] SignDate_Years = new int[Signed_Sign_PKs.Length];
                    TLONSignedCredentialsModel[] SignedRecords = new TLONSignedCredentialsModel[ONode_User_IDs.Length];
                    int x = 0;
                    while (x < ONode_User_IDs.Length) 
                    {
                        SignDate_Days[x] = SigningDateTime.Day;
                        SignDate_Months[x] = SigningDateTime.Month;
                        SignDate_Years[x] = SigningDateTime.Year;
                        SignedRecords[x] = new TLONSignedCredentialsModel();
                        x += 1;
                    }
                    x = 0;
                    while (x < SignedRecords.Length) 
                    {
                        SignedRecords[x].ONode_User_ID = ONode_User_IDs[x]; //This line..
                        SignedRecords[x].Signed_Auth_PK = Signed_Auth_PKs[x];
                        SignedRecords[x].Signed_Sign_PK = Signed_Sign_PKs[x];
                        SignedRecords[x].SignDate_Day = SignDate_Days[x];
                        SignedRecords[x].SignDate_Month = SignDate_Months[x];
                        SignedRecords[x].SignDate_Year = SignDate_Years[x];
                        x += 1;
                    }
                    TLAUCertModel MyModel = new TLAUCertModel();
                    MyModel.User_ID = User_ID;
                    MyModel.SignedCredentials = SignedRecords;
                    if (File.Exists(TLAUOpsRSASubFolder + "Modulus.txt") == true && File.Exists(TLAUOpsRSASubFolder + "Exponent.txt") == true
                    && File.Exists(TLAUOpsRSASubFolder + "D.txt") == true && File.Exists(TLAUOpsRSASubFolder + "P.txt") == true
                    && File.Exists(TLAUOpsRSASubFolder + "Q.txt") == true && File.Exists(TLAUOpsRSASubFolder + "DP.txt") == true
                    && File.Exists(TLAUOpsRSASubFolder + "DQ.txt") == true && File.Exists(TLAUOpsRSASubFolder + "InverseQ.txt") == true)
                    {
                        Byte[] ModulusBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Modulus.txt");
                        Byte[] ExponentBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Exponent.txt");
                        Byte[] DBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "D.txt");
                        Byte[] PBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "P.txt");
                        Byte[] QBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Q.txt");
                        Byte[] DPBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "DP.txt");
                        Byte[] DQBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "DQ.txt");
                        Byte[] InverseQBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "InverseQ.txt");
                        String JSONString = JsonConvert.SerializeObject(MyModel);
                        (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(JSONString, "gtkTFlA1yXTFl_k-OjjltMn5IEqA-YpcD6SuYRksNhVKj8eP3IZ0zREbhQpI2P9aIdEaXxzRhCum89Xe-xEnnHKsmB1CcLMuVSXOtuUz9xQ0XCX3L2hxoytWqviGkn16Cx8_YeOGuHWdJVqjF-oZVY2-Q32kHBbT79AniJHCFxTFuYYIo2YXPD24yVxFgjuySg2LtLo5ImYBkPjs-fnrKW8jAPMr-gmPSgaq7dLf95GBYKIQLjY13ABUaSvODbjBgKHXhB3N6ZALfrPzMLe6pl-_onAvNGzXZXeKyHnY-ar1wnPpGEo8QUXjkQrimBjYJhlE1DxC9J5K7KJgQ2xkLbTPpgfNwQxVUwN5b1CBokxBLUJtCzqxC0ZZC3WEA7ZEqpb0IEeAY7g20O3dN9aJw9VpYaoKjYOVRqmUMmE_XgDtglAVtV1X03-OyYZS3Ss_tz3bUWlv1XvxiW3sDFLLYs9nRkPvEklqT4280uRJbfMkLcgW9wlfzJwPgFJ5MTm9fD5PKGRDOCcNLrXVlacdnLQ_9YlWV9UFgu6CSZsH7v1_frA5VGitK3mfrhvuKJN1ZxszolcwJJAbbw1P-0DbrGF5B6KRE01-f_5v35sBgEm6K4umYbaJ5LFdkpHOn1uPP0H8XSeT_TfG69F7lLHG_YCWXiQzYBeWKK2xyJhjMjU",
                        ModulusBytes, ExponentBytes, DBytes, PBytes, QBytes, DPBytes, DQBytes, InverseQBytes);
                        SecondTLAUOpsTextBoxArray[7].Text = MyResults.TransactionID + " is the transaction ID for Arweave. However, due to some constraints on my side or the Arweave network, you have to check via https://viewblock.io/arweave/address/{wallet_address} to see if the transaction was actually submitted.";
                        SecondTLAUOpsTextBoxArray[6].Text = SigningDateTime.Year.ToString();
                        SecondTLAUOpsTextBoxArray[5].Text = SigningDateTime.Month.ToString();
                        SecondTLAUOpsTextBoxArray[4].Text = SigningDateTime.Day.ToString();
                        String DataString = User_ID + "," + MyResults.TransactionID;
                        String FinalDataString = "";
                        String[] DataStringArray = new String[] { };
                        if (File.Exists(TLAUOpsONAUSubFolder + "ONode_AU_Cert.txt") == false)
                        {
                            File.WriteAllText(TLAUOpsAUSubFolder + "ONode_AU_Cert.txt", DataString);
                        }
                        else
                        {
                            DataStringArray = File.ReadAllLines(TLAUOpsAUSubFolder + "ONode_AU_Cert.txt");
                            FinalDataString = String.Join(Environment.NewLine, DataStringArray);
                            FinalDataString += Environment.NewLine + DataString;
                            File.WriteAllText(TLAUOpsAUSubFolder + "ONode_AU_Cert.txt", FinalDataString);
                        }
                    }
                }
                else 
                {
                    SecondTLAUOpsTextBoxArray[7].Text = "Error: The information for the second to fourth textboxes are not mixed data";
                }
            }
            else 
            {
                SecondTLAUOpsTextBoxArray[7].Text = "Error: The information for the first 4 textboxes are empty";
            }
        }
        else if(TLAUOpsUIChooser == 3) 
        {
            String SNode_User_ID = ThirdTLAUOpsTextBoxArray[0].Text;
            String PNode_User_IDs_RawString = ThirdTLAUOpsTextBoxArray[1].Text;
            String Signed_Auth_PKs_RawString = ThirdTLAUOpsTextBoxArray[2].Text;
            String Signed_Sign_PKs_RawString = ThirdTLAUOpsTextBoxArray[3].Text;
            DateTime SigningDateTime = DateTime.UtcNow.AddHours(8);
            if (String.IsNullOrEmpty(SNode_User_ID) == false && String.IsNullOrEmpty(PNode_User_IDs_RawString) == false
                && String.IsNullOrEmpty(Signed_Auth_PKs_RawString) == false && String.IsNullOrEmpty(Signed_Sign_PKs_RawString) == false)
            {
                if (PNode_User_IDs_RawString.Contains(",") == true && Signed_Auth_PKs_RawString.Contains(",") == true
                    && Signed_Sign_PKs_RawString.Contains(",") == true)
                {
                    String[] PNode_User_IDs = PNode_User_IDs_RawString.Split(",");
                    String[] Signed_Auth_PKs = Signed_Auth_PKs_RawString.Split(",");
                    String[] Signed_Sign_PKs = Signed_Sign_PKs_RawString.Split(",");
                    int[] SignDate_Days = new int[PNode_User_IDs.Length];
                    int[] SignDate_Months = new int[Signed_Auth_PKs.Length];
                    int[] SignDate_Years = new int[Signed_Sign_PKs.Length];
                    MLSNSignedCredentialsModel[] SignedRecords = new MLSNSignedCredentialsModel[PNode_User_IDs.Length];
                    int x = 0;
                    while (x < PNode_User_IDs.Length)
                    {
                        SignDate_Days[x] = SigningDateTime.Day;
                        SignDate_Months[x] = SigningDateTime.Month;
                        SignDate_Years[x] = SigningDateTime.Year;
                        SignedRecords[x] = new MLSNSignedCredentialsModel();
                        x += 1;
                    }
                    x = 0;
                    while (x < SignedRecords.Length)
                    {
                        SignedRecords[x].PNode_User_ID = PNode_User_IDs[x];
                        SignedRecords[x].Signed_Auth_PK = Signed_Auth_PKs[x];
                        SignedRecords[x].Signed_Sign_PK = Signed_Sign_PKs[x];
                        SignedRecords[x].SignDate_Day = SignDate_Days[x];
                        SignedRecords[x].SignDate_Month = SignDate_Months[x];
                        SignedRecords[x].SignDate_Year = SignDate_Years[x];
                        x += 1;
                    }
                    MLAUCertModel MyModel = new MLAUCertModel();
                    MyModel.SNode_User_ID = SNode_User_ID;
                    MyModel.SignedCredentials = SignedRecords;
                    if (File.Exists(TLAUOpsRSASubFolder + "Modulus.txt") == true && File.Exists(TLAUOpsRSASubFolder + "Exponent.txt") == true
                    && File.Exists(TLAUOpsRSASubFolder + "D.txt") == true && File.Exists(TLAUOpsRSASubFolder + "P.txt") == true
                    && File.Exists(TLAUOpsRSASubFolder + "Q.txt") == true && File.Exists(TLAUOpsRSASubFolder + "DP.txt") == true
                    && File.Exists(TLAUOpsRSASubFolder + "DQ.txt") == true && File.Exists(TLAUOpsRSASubFolder + "InverseQ.txt") == true)
                    {
                        Byte[] ModulusBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Modulus.txt");
                        Byte[] ExponentBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Exponent.txt");
                        Byte[] DBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "D.txt");
                        Byte[] PBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "P.txt");
                        Byte[] QBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "Q.txt");
                        Byte[] DPBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "DP.txt");
                        Byte[] DQBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "DQ.txt");
                        Byte[] InverseQBytes = File.ReadAllBytes(TLAUOpsRSASubFolder + "InverseQ.txt");
                        String JSONString = JsonConvert.SerializeObject(MyModel);
                        (String Status, String TransactionID) MyResults = await ArweaveSecureCreateAndPostDataHelper.UploadData(JSONString, "gtkTFlA1yXTFl_k-OjjltMn5IEqA-YpcD6SuYRksNhVKj8eP3IZ0zREbhQpI2P9aIdEaXxzRhCum89Xe-xEnnHKsmB1CcLMuVSXOtuUz9xQ0XCX3L2hxoytWqviGkn16Cx8_YeOGuHWdJVqjF-oZVY2-Q32kHBbT79AniJHCFxTFuYYIo2YXPD24yVxFgjuySg2LtLo5ImYBkPjs-fnrKW8jAPMr-gmPSgaq7dLf95GBYKIQLjY13ABUaSvODbjBgKHXhB3N6ZALfrPzMLe6pl-_onAvNGzXZXeKyHnY-ar1wnPpGEo8QUXjkQrimBjYJhlE1DxC9J5K7KJgQ2xkLbTPpgfNwQxVUwN5b1CBokxBLUJtCzqxC0ZZC3WEA7ZEqpb0IEeAY7g20O3dN9aJw9VpYaoKjYOVRqmUMmE_XgDtglAVtV1X03-OyYZS3Ss_tz3bUWlv1XvxiW3sDFLLYs9nRkPvEklqT4280uRJbfMkLcgW9wlfzJwPgFJ5MTm9fD5PKGRDOCcNLrXVlacdnLQ_9YlWV9UFgu6CSZsH7v1_frA5VGitK3mfrhvuKJN1ZxszolcwJJAbbw1P-0DbrGF5B6KRE01-f_5v35sBgEm6K4umYbaJ5LFdkpHOn1uPP0H8XSeT_TfG69F7lLHG_YCWXiQzYBeWKK2xyJhjMjU",
                        ModulusBytes, ExponentBytes, DBytes, PBytes, QBytes, DPBytes, DQBytes, InverseQBytes);
                        ThirdTLAUOpsTextBoxArray[7].Text = MyResults.TransactionID + " is the transaction ID for Arweave. However, due to some constraints on my side or the Arweave network, you have to check via https://viewblock.io/arweave/address/{wallet_address} to see if the transaction was actually submitted."; ;
                        ThirdTLAUOpsTextBoxArray[6].Text = SigningDateTime.Year.ToString();
                        ThirdTLAUOpsTextBoxArray[5].Text = SigningDateTime.Month.ToString();
                        ThirdTLAUOpsTextBoxArray[4].Text = SigningDateTime.Day.ToString();
                        String DataString = SNode_User_ID + "," + MyResults.TransactionID;
                        String FinalDataString = "";
                        String[] DataStringArray = new String[] { };
                        int Loop = 0;
                        if (File.Exists(TLAUOpsSNAUSubFolder + "SNode_AU_Cert.txt") == false)
                        {
                            File.WriteAllText(TLAUOpsSNAUSubFolder + "SNode_AU_Cert.txt", DataString);
                        }
                        else
                        {
                            DataStringArray = File.ReadAllLines(TLAUOpsSNAUSubFolder + "SNode_AU_Cert.txt");
                            FinalDataString = String.Join(Environment.NewLine, DataStringArray);
                            FinalDataString += Environment.NewLine + DataString;
                            File.WriteAllText(TLAUOpsAUSubFolder + "ONode_AU_Cert.txt", FinalDataString);
                        }
                    }
                }
                else
                {
                    ThirdTLAUOpsTextBoxArray[7].Text = "Error: The information for the second to fourth textboxes are not mixed data";
                }
            }
            else
            {
                ThirdTLAUOpsTextBoxArray[7].Text = "Error: The information for the first 4 textboxes are empty";
            }
        }
    }
}
