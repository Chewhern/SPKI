﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_ON_App.SPKIDataModel
{
    public class TLCompromisedAUsInfosModel
    {
        public String[] TLAUInfoArweaveTransactionIDs { get; set; }
    }
}
