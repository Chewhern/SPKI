﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_ON_App.SPKIDataModel
{
    public class MLAUCertModel
    {
        public String SNode_User_ID { get; set; }

        public MLSNSignedCredentialsModel[] SignedCredentials { get; set; }
    }
}
