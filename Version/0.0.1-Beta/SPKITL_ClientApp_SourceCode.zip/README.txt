==Set up RSA Credentials==
1. Use any way to export arweave-keyfile-<wallet-address>.json from any Arweave default wallet application.
2. Copy the field from "e" all the way to "qi" in a separate manner one after another.
3. For each of the field, use "SimplifiedArweaveSDK" C# SDK.
4. Use the SDK to convert the strings into Byte[] equivalent.
5. Use "File.WriteAllBytes(<Path>,RSAExponentBytes);" to create and write into files in a binary format.
6. Inside "ArweaveOps/RSACredentials" folder/directory, make sure "D.txt","DP.txt","DQ.txt","Exponent.txt","InverseQ.txt","Modulus.txt","P.txt","Q.txt" were present.

==ON Application==
The anchoring of authorized users' information or certificates rely on manual data checking and insertion operations. If you are responsible for nodes all the way to ML server application' nodes, the likelihood of human errors will be big.

==AR minimum amount requirement==
26 USD equivalent of AR will be more than sufficient for TL and ML operations. 