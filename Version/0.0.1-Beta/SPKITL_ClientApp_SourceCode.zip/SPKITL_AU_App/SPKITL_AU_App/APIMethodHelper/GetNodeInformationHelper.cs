﻿using SPKITL_AU_App.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_AU_App.APIMethodHelper
{
    public static class GetNodeInformationHelper
    {
        public static String GetNodeInfo()
        {
            String NodeInformation = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetNodeInformation");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    NodeInformation = Result.Substring(1, Result.Length - 2);
                }
            }
            return NodeInformation;
        }
    }
}
