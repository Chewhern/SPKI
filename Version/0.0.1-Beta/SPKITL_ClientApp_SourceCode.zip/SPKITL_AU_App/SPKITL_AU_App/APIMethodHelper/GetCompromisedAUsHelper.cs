﻿using Newtonsoft.Json;
using SPKITL_AU_App.Helper;
using SPKITL_AU_App.SPKIDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace SPKITL_AU_App.APIMethodHelper
{
    public static class GetCompromisedAUsHelper
    {
        public static String GetCompromisedAUs()
        {
            String CompromisedAUs_ArweaveIDs = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("CompromisedOps");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    TLCompromisedAUsInfosModel MyModel = JsonConvert.DeserializeObject<TLCompromisedAUsInfosModel>(Result);
                    CompromisedAUs_ArweaveIDs = String.Join(",",MyModel.TLAUInfoArweaveTransactionIDs);
                }
            }
            return CompromisedAUs_ArweaveIDs;
        }
    }
}
