﻿using System;

namespace SPKITL_AU_App.DataModel
{
    public class NodeArweaveCertModel
    {
        public String NodeAUInfoArweaveID { get; set; }

        public String NodeAUCertInfoArweaveID { get; set; }

        public String[] ONodeAUInfoArweaveIDs { get; set; }

        public String Status { get; set; }
    }
}
