﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using SimplifiedArweaveSDK.ArweaveHelper;
using SimplifiedArweaveSDK.ArweaveSubHelper;
using SPKITL_AU_App.APIMethodHelper;
using SPKITL_AU_App.DataModel;
using SPKITL_AU_App.Helper;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace SPKITL_AU_App.Views;

public partial class MainView : UserControl
{
    //For PCOT, needs to add 'include Contact' and 'include OOB_PK' features..
    private static int ServerOpsAppUIChooser = 0;
    private static int AUOpsAppUIChooser = 0;
    private static int OOBOpsAppUIChooser = 0;
    private static int CertInfoOpsAppUIChooser = 0;

    //..
    private static TextBlock[] FirstServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FourthServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FourthServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FourthServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FifthServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FifthServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FifthServerOpsAppButtonArray = new Button[] { };
    //...
    private static TextBlock[] FirstAUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstAUOpsAppTextBoxArray = new TextBox[] { };
    private static RadioButton[] FirstAUOpsAppRadioButtonArray = new RadioButton[] { };
    private static Button[] FirstAUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondAUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondAUOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondAUOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] SecondAUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdAUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdAUOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] ThirdAUOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] ThirdAUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FourthAUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FourthAUOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] FourthAUOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] FourthAUOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FifthAUOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FifthAUOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] FifthAUOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] FifthAUOpsAppButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstOOBOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstOOBOpsButtonArray = new Button[] { };
    private static TextBlock[] SecondOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondOOBOpsAppTextBoxArray = new TextBox[] { };
    private static ComboBox[] SecondOOBOpsAppComboBoxArray = new ComboBox[] { };
    private static Button[] SecondOOBOpsAppButtonArray = new Button[] { };
    private static TextBlock[] ThirdOOBOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] ThirdOOBOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] ThirdOOBOpsAppButtonArray = new Button[] { };
    //..
    private static TextBlock[] FirstCertInfoOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstCertInfoOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstCertInfoOpsAppButtonArray = new Button[] { };
    private static TextBlock[] SecondCertInfoOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondCertInfoOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondCertInfoOpsAppButtonArray = new Button[] { };
    //..
    private static String AUOpsAppServerRootFolder = "";
    private static String AUOpsAppCertificateFolder = "";
    private static String AUOPsAppRootFolder = "";
    private static String OOBOpsAppRootFolder = "";
    //Might be better if there's a signed records folder..
    //so that AUs can trace back but given the offline nature,
    //i don't think this is as important as i thought it might be..
    private static Boolean HasServerOpsAppUIRendered = false;
    private static Boolean HasAUOpsAppUIRendered = false;
    private static Boolean HasOOBOpsAppUIRendered = false;
    private static Boolean HasCertInfoOpsAppUIRendered = false;

    public MainView()
    {
        InitializeComponent();
        ServerOpsAppInitialization();
        AUOpsAppInitialization();
        OOBOpsAppInitialization();
        CertInfoOpsAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
        {
            AUOpsAppServerRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
            AUOpsAppCertificateFolder = AppContext.BaseDirectory + "\\AU_Cert\\";
            AUOPsAppRootFolder = AppContext.BaseDirectory + "\\Users\\";
            OOBOpsAppRootFolder = AppContext.BaseDirectory + "\\OOB\\";
        }
        else 
        {
            AUOpsAppServerRootFolder = AppContext.BaseDirectory + "/ServerIP/";
            AUOpsAppCertificateFolder = AppContext.BaseDirectory + "/AU_Cert/";
            AUOPsAppRootFolder = AppContext.BaseDirectory + "/Users/";
            OOBOpsAppRootFolder = AppContext.BaseDirectory + "/OOB/";
        }
        if (Directory.Exists(AUOpsAppServerRootFolder) == false) 
        {
            Directory.CreateDirectory(AUOpsAppServerRootFolder);
        }
        if (Directory.Exists(AUOpsAppCertificateFolder) == false) 
        {
            Directory.CreateDirectory(AUOpsAppCertificateFolder);
        }
        if (Directory.Exists(AUOPsAppRootFolder) == false) 
        {
            Directory.CreateDirectory(AUOPsAppRootFolder);
        }
        if (Directory.Exists(OOBOpsAppRootFolder) == false) 
        {
            Directory.CreateDirectory(OOBOpsAppRootFolder);
        }
        StartupFunction();
    }

    private void StartupFunction() 
    {
        if (Directory.Exists(AUOpsAppServerRootFolder) == true)
        {
            if (File.Exists(AUOpsAppServerRootFolder + "IP.txt") == true)
            {
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
    }

    private void ServerOpsAppInitialization() 
    {
        ServerOpsAppUIChooser = 0;
        ServerOpsAppToggleBTN1.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN2.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN3.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN4.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
        ServerOpsAppToggleBTN5.IsCheckedChanged += ServerOpsAppToggleBTNSFunction;
    }

    private void AUOpsAppInitialization() 
    {
        AUOpsAppUIChooser = 0;
        AUOpsAppToggleBTN1.IsCheckedChanged += AUOpsAppToggleBTNSFunction;
        AUOpsAppToggleBTN2.IsCheckedChanged += AUOpsAppToggleBTNSFunction;
        AUOpsAppToggleBTN3.IsCheckedChanged += AUOpsAppToggleBTNSFunction;
        AUOpsAppToggleBTN4.IsCheckedChanged += AUOpsAppToggleBTNSFunction;
        AUOpsAppToggleBTN5.IsCheckedChanged += AUOpsAppToggleBTNSFunction;
    }

    private void OOBOpsAppInitialization() 
    {
        OOBOpsAppUIChooser = 0;
        OOBOpsAppToggleBTN1.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN2.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
        OOBOpsAppToggleBTN3.IsCheckedChanged += OOBOpsAppToggleBTNSFunction;
    }

    private void CertInfoOpsAppInitialization() 
    {
        CertInfoOpsAppUIChooser = 0;
        CertInfoOpsAppToggleBTN1.IsCheckedChanged += CertInfoOpsAppToggleBTNSFunction;
        CertInfoOpsAppToggleBTN2.IsCheckedChanged += CertInfoOpsAppToggleBTNSFunction;
    }

    private void ServerOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(ServerOpsAppToggleBTN1.IsChecked == true) 
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 1;
        }
        else if(ServerOpsAppToggleBTN2.IsChecked == true) 
        {
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 2;
        }
        else if(ServerOpsAppToggleBTN3.IsChecked == true) 
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 3;
        }
        else if(ServerOpsAppToggleBTN4.IsChecked == true) 
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppToggleBTN5.IsChecked = false;
            ServerOpsAppUIChooser = 4;
        }
        else if (ServerOpsAppToggleBTN5.IsChecked == true)
        {
            ServerOpsAppToggleBTN2.IsChecked = false;
            ServerOpsAppToggleBTN3.IsChecked = false;
            ServerOpsAppToggleBTN4.IsChecked = false;
            ServerOpsAppToggleBTN1.IsChecked = false;
            ServerOpsAppUIChooser = 5;
        }
        else 
        {
            ResetServerOpsAppUI();
        }
        ServerOpsAppDrawUI();
    }

    private void AUOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (AUOpsAppToggleBTN1.IsChecked == true) 
        {
            AUOpsAppToggleBTN2.IsChecked = false;
            AUOpsAppToggleBTN3.IsChecked = false;
            AUOpsAppToggleBTN4.IsChecked = false;
            AUOpsAppToggleBTN5.IsChecked = false;
            AUOpsAppUIChooser = 1;
        }
        else if(AUOpsAppToggleBTN2.IsChecked == true) 
        {
            AUOpsAppToggleBTN1.IsChecked = false;
            AUOpsAppToggleBTN3.IsChecked = false;
            AUOpsAppToggleBTN4.IsChecked = false;
            AUOpsAppToggleBTN5.IsChecked = false;
            AUOpsAppUIChooser = 2;
        }
        else if(AUOpsAppToggleBTN3.IsChecked == true) 
        {
            AUOpsAppToggleBTN2.IsChecked = false;
            AUOpsAppToggleBTN1.IsChecked = false;
            AUOpsAppToggleBTN4.IsChecked = false;
            AUOpsAppToggleBTN5.IsChecked = false;
            AUOpsAppUIChooser = 3;
        }
        else if(AUOpsAppToggleBTN4.IsChecked == true)
        {
            AUOpsAppToggleBTN2.IsChecked = false;
            AUOpsAppToggleBTN3.IsChecked = false;
            AUOpsAppToggleBTN1.IsChecked = false;
            AUOpsAppToggleBTN5.IsChecked = false;
            AUOpsAppUIChooser = 4;
        }
        else if(AUOpsAppToggleBTN5.IsChecked == true) 
        {
            AUOpsAppToggleBTN2.IsChecked = false;
            AUOpsAppToggleBTN3.IsChecked = false;
            AUOpsAppToggleBTN4.IsChecked = false;
            AUOpsAppToggleBTN1.IsChecked = false;
            AUOpsAppUIChooser = 5;
        }
        else 
        {
            ResetAUOpsAppUI();
        }
        AUOpsAppDrawUI();
    }

    private void OOBOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (OOBOpsAppToggleBTN1.IsChecked == true) 
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsAppUIChooser = 1;
        }
        else if(OOBOpsAppToggleBTN2.IsChecked == true) 
        {
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppToggleBTN3.IsChecked = false;
            OOBOpsAppUIChooser = 2;
        }
        else if(OOBOpsAppToggleBTN3.IsChecked == true) 
        {
            OOBOpsAppToggleBTN2.IsChecked = false;
            OOBOpsAppToggleBTN1.IsChecked = false;
            OOBOpsAppUIChooser = 3;
        }
        else 
        {
            ResetOOBOpsAppUI();
        }
        OOBOpsAppDrawUI();
    }

    private void CertInfoOpsAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (CertInfoOpsAppToggleBTN1.IsChecked == true)
        {
            CertInfoOpsAppToggleBTN2.IsChecked = false;
            CertInfoOpsAppUIChooser = 1;
        }
        else if (CertInfoOpsAppToggleBTN2.IsChecked == true)
        {
            CertInfoOpsAppToggleBTN1.IsChecked = false;
            CertInfoOpsAppUIChooser = 2;
        }
        else
        {
            ResetCertInfoOpsAppUI();
        }
        CertInfoOpsAppDrawUI();
    }

    private void ServerOpsAppDrawUI() 
    {
        if(ServerOpsAppUIChooser == 1) 
        {
            if (HasServerOpsAppUIRendered == false) 
            {
                FirstServerOpsAppTextBlockArray = new TextBlock[2];
                FirstServerOpsAppTextBlockArray[0] = new TextBlock();
                FirstServerOpsAppTextBlockArray[1] = new TextBlock();
                FirstServerOpsAppTextBlockArray[0].Text = "Server API IP address of SPKITL?";
                FirstServerOpsAppTextBlockArray[1].Text = "Server IP address status (Read Only/RO)";
                FirstServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstServerOpsAppTextBoxArray = new TextBox[2];
                FirstServerOpsAppTextBoxArray[0] = new TextBox();
                FirstServerOpsAppTextBoxArray[1] = new TextBox();
                FirstServerOpsAppTextBoxArray[0].Height = 125;
                FirstServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstServerOpsAppTextBoxArray[0].Width = 250;
                FirstServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstServerOpsAppTextBoxArray[1].Height = 125;
                FirstServerOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstServerOpsAppTextBoxArray[1].Width = 250;
                FirstServerOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstServerOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstServerOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstServerOpsAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstServerOpsAppTextBoxArray[1].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstServerOpsAppButtonArray = new Button[1];
                FirstServerOpsAppButtonArray[0] = new Button();
                FirstServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstServerOpsAppButtonArray[0].Content = "Add and establish a connection";
                FirstServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if(ServerOpsAppUIChooser == 2) 
        {
            if (HasServerOpsAppUIRendered == false)
            {
                SecondServerOpsAppTextBlockArray = new TextBlock[5];
                SecondServerOpsAppTextBlockArray[0] = new TextBlock();
                SecondServerOpsAppTextBlockArray[1] = new TextBlock();
                SecondServerOpsAppTextBlockArray[2] = new TextBlock();
                SecondServerOpsAppTextBlockArray[3] = new TextBlock();
                SecondServerOpsAppTextBlockArray[4] = new TextBlock();
                SecondServerOpsAppTextBlockArray[0].Text = "User ID";
                SecondServerOpsAppTextBlockArray[1].Text = "User Arweave ID (RO)";
                SecondServerOpsAppTextBlockArray[2].Text = "User Arweave Cert ID (RO)";
                SecondServerOpsAppTextBlockArray[3].Text = "Signers Arweave IDs (RO)";
                SecondServerOpsAppTextBlockArray[4].Text = "Status (RO)";
                SecondServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondServerOpsAppTextBoxArray = new TextBox[5];
                SecondServerOpsAppTextBoxArray[0] = new TextBox();
                SecondServerOpsAppTextBoxArray[1] = new TextBox();
                SecondServerOpsAppTextBoxArray[2] = new TextBox();
                SecondServerOpsAppTextBoxArray[3] = new TextBox();
                SecondServerOpsAppTextBoxArray[4] = new TextBox();
                SecondServerOpsAppTextBoxArray[0].Height = 50;
                SecondServerOpsAppTextBoxArray[0].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[1].Height = 50;
                SecondServerOpsAppTextBoxArray[1].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[2].Height = 50;
                SecondServerOpsAppTextBoxArray[2].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[3].Height = 50;
                SecondServerOpsAppTextBoxArray[3].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[4].Height = 50;
                SecondServerOpsAppTextBoxArray[4].MaxHeight = 50;
                SecondServerOpsAppTextBoxArray[0].Width = 250;
                SecondServerOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[1].Width = 250;
                SecondServerOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[2].Width = 250;
                SecondServerOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[3].Width = 250;
                SecondServerOpsAppTextBoxArray[3].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[4].Width = 250;
                SecondServerOpsAppTextBoxArray[4].MaxWidth = 250;
                SecondServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                SecondServerOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondServerOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondServerOpsAppTextBoxArray[3].IsReadOnly = true;
                SecondServerOpsAppTextBoxArray[4].IsReadOnly = true;
                SecondServerOpsAppButtonArray = new Button[1];
                SecondServerOpsAppButtonArray[0] = new Button();
                SecondServerOpsAppButtonArray[0].Content = "Fetch Certificate";
                SecondServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                SecondServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBlockArray[4]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppTextBoxArray[4]);
                ServerOpsAppLowerRightLPSP.Children.Add(SecondServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if(ServerOpsAppUIChooser == 3) 
        {
            if (HasServerOpsAppUIRendered == false)
            {
                ThirdServerOpsAppTextBlockArray = new TextBlock[1];
                ThirdServerOpsAppTextBlockArray[0] = new TextBlock();
                ThirdServerOpsAppTextBlockArray[0].Text = "Server's AR balance (RO)";
                ThirdServerOpsAppTextBoxArray = new TextBox[1];
                ThirdServerOpsAppTextBoxArray[0] = new TextBox();
                ThirdServerOpsAppTextBoxArray[0].IsReadOnly = true;
                ThirdServerOpsAppTextBoxArray[0].Width = 250;
                ThirdServerOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdServerOpsAppTextBoxArray[0].Height = 50;
                ThirdServerOpsAppTextBoxArray[0].MaxHeight = 50;
                ThirdServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdServerOpsAppButtonArray = new Button[1];
                ThirdServerOpsAppButtonArray[0] = new Button();
                ThirdServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdServerOpsAppButtonArray[0].Content = "Inquire Server AR";
                ThirdServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(ThirdServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(ThirdServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(ThirdServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if(ServerOpsAppUIChooser == 4) 
        {
            if (HasServerOpsAppUIRendered == false)
            {
                FourthServerOpsAppTextBlockArray = new TextBlock[5];
                FourthServerOpsAppTextBlockArray[0] = new TextBlock();
                FourthServerOpsAppTextBlockArray[1] = new TextBlock();
                FourthServerOpsAppTextBlockArray[2] = new TextBlock();
                FourthServerOpsAppTextBlockArray[3] = new TextBlock();
                FourthServerOpsAppTextBlockArray[4] = new TextBlock();
                FourthServerOpsAppTextBlockArray[0].Text = "IP Address (RO)";
                FourthServerOpsAppTextBlockArray[1].Text = "API IP Address (RO)";
                FourthServerOpsAppTextBlockArray[2].Text = "NO Contact (RO)";
                FourthServerOpsAppTextBlockArray[3].Text = "NO OOB PK (RO)";
                FourthServerOpsAppTextBlockArray[4].Text = "Communication Channel (RO)";
                FourthServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppTextBoxArray = new TextBox[5];
                FourthServerOpsAppTextBoxArray[0] = new TextBox();
                FourthServerOpsAppTextBoxArray[1] = new TextBox();
                FourthServerOpsAppTextBoxArray[2] = new TextBox();
                FourthServerOpsAppTextBoxArray[3] = new TextBox();
                FourthServerOpsAppTextBoxArray[4] = new TextBox();
                FourthServerOpsAppTextBoxArray[0].IsReadOnly = true;
                FourthServerOpsAppTextBoxArray[0].Width = 250;
                FourthServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FourthServerOpsAppTextBoxArray[0].Height = 125;
                FourthServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FourthServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FourthServerOpsAppButtonArray = new Button[1];
                FourthServerOpsAppButtonArray[0] = new Button();
                FourthServerOpsAppButtonArray[0].Content = "Get Node Information";
                FourthServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[2]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[3]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBlockArray[4]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppTextBoxArray[4]);
                ServerOpsAppLowerRightLPSP.Children.Add(FourthServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else if (ServerOpsAppUIChooser == 5)
        {
            if (HasServerOpsAppUIRendered == false)
            {
                FifthServerOpsAppTextBlockArray = new TextBlock[1];
                FifthServerOpsAppTextBlockArray[0] = new TextBlock();
                FifthServerOpsAppTextBlockArray[0].Text = "Compromised AUs (RO)";
                FifthServerOpsAppTextBoxArray = new TextBox[1];
                FifthServerOpsAppTextBoxArray[0] = new TextBox();
                FifthServerOpsAppTextBoxArray[0].IsReadOnly = true;
                FifthServerOpsAppTextBoxArray[0].Width = 250;
                FifthServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FifthServerOpsAppTextBoxArray[0].Height = 125;
                FifthServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FifthServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FifthServerOpsAppButtonArray = new Button[1];
                FifthServerOpsAppButtonArray[0] = new Button();
                FifthServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthServerOpsAppButtonArray[0].Content = "Get Compromised AUs";
                FifthServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FifthServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FifthServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FifthServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetServerOpsAppUI();
        }
    }

    private void AUOpsAppDrawUI() 
    {
        if (AUOpsAppUIChooser == 1) 
        {
            if(HasAUOpsAppUIRendered== false) 
            {
                FirstAUOpsAppTextBlockArray = new TextBlock[9];
                FirstAUOpsAppTextBlockArray[0] = new TextBlock();
                FirstAUOpsAppTextBlockArray[1] = new TextBlock();
                FirstAUOpsAppTextBlockArray[2] = new TextBlock();
                FirstAUOpsAppTextBlockArray[3] = new TextBlock();
                FirstAUOpsAppTextBlockArray[4] = new TextBlock();
                FirstAUOpsAppTextBlockArray[5] = new TextBlock();
                FirstAUOpsAppTextBlockArray[6] = new TextBlock();
                FirstAUOpsAppTextBlockArray[7] = new TextBlock();
                FirstAUOpsAppTextBlockArray[8] = new TextBlock();
                FirstAUOpsAppTextBlockArray[0].Text = "User ID (Read Only)";
                FirstAUOpsAppTextBlockArray[1].Text = "Contact";
                FirstAUOpsAppTextBlockArray[2].Text = "Auth PK (Read Only)";
                FirstAUOpsAppTextBlockArray[3].Text = "Sign PK (Read Only)";
                FirstAUOpsAppTextBlockArray[4].Text = "OOB PK (Read Only)";
                FirstAUOpsAppTextBlockArray[5].Text = "ASPK Day (Read Only)";
                FirstAUOpsAppTextBlockArray[6].Text = "ASPK Month (Read Only)";
                FirstAUOpsAppTextBlockArray[7].Text = "ASPK Year (Read Only)";
                FirstAUOpsAppTextBlockArray[8].Text = "What's the DSA?";
                FirstAUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBlockArray[8].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstAUOpsAppTextBoxArray = new TextBox[8];
                FirstAUOpsAppTextBoxArray[0] = new TextBox();
                FirstAUOpsAppTextBoxArray[1] = new TextBox();
                FirstAUOpsAppTextBoxArray[2] = new TextBox();
                FirstAUOpsAppTextBoxArray[3] = new TextBox();
                FirstAUOpsAppTextBoxArray[4] = new TextBox();
                FirstAUOpsAppTextBoxArray[5] = new TextBox();
                FirstAUOpsAppTextBoxArray[6] = new TextBox();
                FirstAUOpsAppTextBoxArray[7] = new TextBox();
                FirstAUOpsAppTextBoxArray[0].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[2].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[3].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[4].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[5].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[6].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[7].IsReadOnly = true;
                FirstAUOpsAppTextBoxArray[0].Width = 250;
                FirstAUOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[1].Width = 250;
                FirstAUOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[2].Width = 250;
                FirstAUOpsAppTextBoxArray[2].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[3].Width = 250;
                FirstAUOpsAppTextBoxArray[3].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[4].Width = 250;
                FirstAUOpsAppTextBoxArray[4].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[5].Width = 250;
                FirstAUOpsAppTextBoxArray[5].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[6].Width = 250;
                FirstAUOpsAppTextBoxArray[6].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[7].Width = 250;
                FirstAUOpsAppTextBoxArray[7].MaxWidth = 250;
                FirstAUOpsAppTextBoxArray[0].Height = 125;
                FirstAUOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstAUOpsAppTextBoxArray[1].Height = 125;
                FirstAUOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstAUOpsAppTextBoxArray[2].Height = 125;
                FirstAUOpsAppTextBoxArray[2].MaxHeight = 125;
                FirstAUOpsAppTextBoxArray[3].Height = 125;
                FirstAUOpsAppTextBoxArray[3].MaxHeight = 125;
                FirstAUOpsAppTextBoxArray[4].Height = 125;
                FirstAUOpsAppTextBoxArray[4].MaxHeight = 125;
                FirstAUOpsAppTextBoxArray[5].Height = 50;
                FirstAUOpsAppTextBoxArray[5].MaxHeight = 50;
                FirstAUOpsAppTextBoxArray[6].Height = 50;
                FirstAUOpsAppTextBoxArray[6].MaxHeight = 50;
                FirstAUOpsAppTextBoxArray[7].Height = 50;
                FirstAUOpsAppTextBoxArray[7].MaxHeight = 50;
                FirstAUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                FirstAUOpsAppRadioButtonArray = new RadioButton[2];
                FirstAUOpsAppRadioButtonArray[0] = new RadioButton();
                FirstAUOpsAppRadioButtonArray[1] = new RadioButton();
                FirstAUOpsAppRadioButtonArray[0].GroupName = "CurveTypes";
                FirstAUOpsAppRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                FirstAUOpsAppRadioButtonArray[0].IsChecked = true;
                FirstAUOpsAppRadioButtonArray[1].GroupName = "CurveTypes";
                FirstAUOpsAppRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                FirstAUOpsAppButtonArray = new Button[1];
                FirstAUOpsAppButtonArray[0] = new Button();
                FirstAUOpsAppButtonArray[0].Content = "Local Registration";
                FirstAUOpsAppButtonArray[0].Click += AUOpsAppBTN_Click;
                FirstAUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[4]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[5]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[5]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[6]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[6]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[7]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBoxArray[7]);
                MyStackPanel.Children.Add(FirstAUOpsAppTextBlockArray[8]);
                MyStackPanel.Children.Add(FirstAUOpsAppRadioButtonArray[0]);
                MyStackPanel.Children.Add(FirstAUOpsAppRadioButtonArray[1]);
                MyStackPanel.Children.Add(FirstAUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                AUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasAUOpsAppUIRendered = true;
            }
        }
        else if(AUOpsAppUIChooser == 2) 
        {
            if (HasAUOpsAppUIRendered == false)
            {
                SecondAUOpsAppTextBlockArray = new TextBlock[10];
                SecondAUOpsAppTextBlockArray[0] = new TextBlock();
                SecondAUOpsAppTextBlockArray[1] = new TextBlock();
                SecondAUOpsAppTextBlockArray[2] = new TextBlock();
                SecondAUOpsAppTextBlockArray[3] = new TextBlock();
                SecondAUOpsAppTextBlockArray[4] = new TextBlock();
                SecondAUOpsAppTextBlockArray[5] = new TextBlock();
                SecondAUOpsAppTextBlockArray[6] = new TextBlock();
                SecondAUOpsAppTextBlockArray[7] = new TextBlock();
                SecondAUOpsAppTextBlockArray[8] = new TextBlock();
                SecondAUOpsAppTextBlockArray[9] = new TextBlock();
                SecondAUOpsAppTextBlockArray[0].Text = "User ID?";
                SecondAUOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                SecondAUOpsAppTextBlockArray[2].Text = "Contact (Read Only)";
                SecondAUOpsAppTextBlockArray[3].Text = "Auth PK (Read Only)";
                SecondAUOpsAppTextBlockArray[4].Text = "Sign PK (Read Only)";
                SecondAUOpsAppTextBlockArray[5].Text = "OOB PK (Read Only)";
                SecondAUOpsAppTextBlockArray[6].Text = "ASPK Day (Read Only)";
                SecondAUOpsAppTextBlockArray[7].Text = "ASPK Month (Read Only)";
                SecondAUOpsAppTextBlockArray[8].Text = "ASPK Year (Read Only)";
                SecondAUOpsAppTextBlockArray[9].Text = "What's the DSA?";
                SecondAUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBlockArray[7].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppTextBoxArray = new TextBox[9];
                SecondAUOpsAppTextBoxArray[0] = new TextBox();
                SecondAUOpsAppTextBoxArray[1] = new TextBox();
                SecondAUOpsAppTextBoxArray[2] = new TextBox();
                SecondAUOpsAppTextBoxArray[3] = new TextBox();
                SecondAUOpsAppTextBoxArray[4] = new TextBox();
                SecondAUOpsAppTextBoxArray[5] = new TextBox();
                SecondAUOpsAppTextBoxArray[6] = new TextBox();
                SecondAUOpsAppTextBoxArray[7] = new TextBox();
                SecondAUOpsAppTextBoxArray[8] = new TextBox();
                SecondAUOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[3].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[4].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[5].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[6].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[7].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[8].IsReadOnly = true;
                SecondAUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[6].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[7].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[8].TextWrapping = TextWrapping.Wrap;
                SecondAUOpsAppTextBoxArray[0].Width = 250;
                SecondAUOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[0].Height = 125;
                SecondAUOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondAUOpsAppTextBoxArray[1].Width = 250;
                SecondAUOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[1].Height = 125;
                SecondAUOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondAUOpsAppTextBoxArray[2].Width = 250;
                SecondAUOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[2].Height = 125;
                SecondAUOpsAppTextBoxArray[2].MaxHeight = 125;
                SecondAUOpsAppTextBoxArray[3].Width = 250;
                SecondAUOpsAppTextBoxArray[3].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[3].Height = 125;
                SecondAUOpsAppTextBoxArray[3].MaxHeight = 125;
                SecondAUOpsAppTextBoxArray[4].Width = 250;
                SecondAUOpsAppTextBoxArray[4].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[4].Height = 125;
                SecondAUOpsAppTextBoxArray[4].MaxHeight = 125;
                SecondAUOpsAppTextBoxArray[5].Width = 250;
                SecondAUOpsAppTextBoxArray[5].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[5].Height = 50;
                SecondAUOpsAppTextBoxArray[5].MaxHeight = 50;
                SecondAUOpsAppTextBoxArray[6].Width = 250;
                SecondAUOpsAppTextBoxArray[6].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[6].Height = 50;
                SecondAUOpsAppTextBoxArray[6].MaxHeight = 50;
                SecondAUOpsAppTextBoxArray[7].Width = 250;
                SecondAUOpsAppTextBoxArray[7].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[7].Height = 50;
                SecondAUOpsAppTextBoxArray[7].MaxHeight = 50;
                SecondAUOpsAppTextBoxArray[8].Width = 250;
                SecondAUOpsAppTextBoxArray[8].MaxWidth = 250;
                SecondAUOpsAppTextBoxArray[8].Height = 125;
                SecondAUOpsAppTextBoxArray[8].MaxHeight = 125;
                SecondAUOpsAppComboBoxArray = new ComboBox[1];
                SecondAUOpsAppComboBoxArray[0] = new ComboBox();
                SecondAUOpsAppComboBoxArray[0].MaxWidth = 250;
                AUOpsAppLoadUserIDs();
                SecondAUOpsAppComboBoxArray[0].SelectionChanged += AUOpsAppComboBoxSelectedItemsChanged;
                SecondAUOpsAppButtonArray = new Button[1];
                SecondAUOpsAppButtonArray[0] = new Button();
                SecondAUOpsAppButtonArray[0].Content = "Get Info";
                SecondAUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondAUOpsAppButtonArray[0].Click += AUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(SecondAUOpsAppComboBoxArray[0]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[5]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[4]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[6]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[5]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[7]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[6]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[8]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[7]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBlockArray[9]);
                MyStackPanel.Children.Add(SecondAUOpsAppTextBoxArray[8]);
                MyStackPanel.Children.Add(SecondAUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                AUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasAUOpsAppUIRendered = true;
            }
        }
        else if(AUOpsAppUIChooser == 3) 
        {
            if (HasAUOpsAppUIRendered == false) 
            {
                ThirdAUOpsAppTextBlockArray = new TextBlock[7];
                ThirdAUOpsAppTextBlockArray[0] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[1] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[2] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[3] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[4] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[5] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[6] = new TextBlock();
                ThirdAUOpsAppTextBlockArray[0].Text = "User ID?";
                ThirdAUOpsAppTextBlockArray[1].Text = "User ID (RO)";
                ThirdAUOpsAppTextBlockArray[2].Text = "ONode User ID";
                ThirdAUOpsAppTextBlockArray[3].Text = "Auth PK";
                ThirdAUOpsAppTextBlockArray[4].Text = "Sign PK";
                ThirdAUOpsAppTextBlockArray[5].Text = "Signed Auth PK (RO)";
                ThirdAUOpsAppTextBlockArray[6].Text = "Signed Sign PK (RO)";
                ThirdAUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppTextBoxArray = new TextBox[6];
                ThirdAUOpsAppTextBoxArray[0] = new TextBox();
                ThirdAUOpsAppTextBoxArray[1] = new TextBox();
                ThirdAUOpsAppTextBoxArray[2] = new TextBox();
                ThirdAUOpsAppTextBoxArray[3] = new TextBox();
                ThirdAUOpsAppTextBoxArray[4] = new TextBox();
                ThirdAUOpsAppTextBoxArray[5] = new TextBox();
                ThirdAUOpsAppTextBoxArray[0].IsReadOnly = true;
                ThirdAUOpsAppTextBoxArray[4].IsReadOnly = true;
                ThirdAUOpsAppTextBoxArray[5].IsReadOnly = true;
                ThirdAUOpsAppTextBoxArray[0].Width = 250;
                ThirdAUOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdAUOpsAppTextBoxArray[0].Height = 50;
                ThirdAUOpsAppTextBoxArray[0].MaxHeight = 50;
                ThirdAUOpsAppTextBoxArray[1].Width = 250;
                ThirdAUOpsAppTextBoxArray[1].MaxWidth = 250;
                ThirdAUOpsAppTextBoxArray[1].Height = 50;
                ThirdAUOpsAppTextBoxArray[1].MaxHeight = 50;
                ThirdAUOpsAppTextBoxArray[2].Width = 250;
                ThirdAUOpsAppTextBoxArray[2].MaxWidth = 250;
                ThirdAUOpsAppTextBoxArray[2].Height = 50;
                ThirdAUOpsAppTextBoxArray[2].MaxHeight = 50;
                ThirdAUOpsAppTextBoxArray[3].Width = 250;
                ThirdAUOpsAppTextBoxArray[3].MaxWidth = 250;
                ThirdAUOpsAppTextBoxArray[3].Height = 50;
                ThirdAUOpsAppTextBoxArray[3].MaxHeight = 50;
                ThirdAUOpsAppTextBoxArray[4].Width = 250;
                ThirdAUOpsAppTextBoxArray[4].MaxWidth = 250;
                ThirdAUOpsAppTextBoxArray[4].Height = 50;
                ThirdAUOpsAppTextBoxArray[4].MaxHeight = 50;
                ThirdAUOpsAppTextBoxArray[5].Width = 250;
                ThirdAUOpsAppTextBoxArray[5].MaxWidth = 250;
                ThirdAUOpsAppTextBoxArray[5].Height = 50;
                ThirdAUOpsAppTextBoxArray[5].MaxHeight = 50;
                ThirdAUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdAUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdAUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdAUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                ThirdAUOpsAppTextBoxArray[4].TextWrapping = TextWrapping.Wrap;
                ThirdAUOpsAppTextBoxArray[5].TextWrapping = TextWrapping.Wrap;
                ThirdAUOpsAppComboBoxArray = new ComboBox[1];
                ThirdAUOpsAppComboBoxArray[0] = new ComboBox();
                ThirdAUOpsAppComboBoxArray[0].MaxWidth = 250;
                AUOpsAppLoadUserIDs();
                ThirdAUOpsAppComboBoxArray[0].SelectionChanged += AUOpsAppComboBoxSelectedItemsChanged;
                ThirdAUOpsAppButtonArray = new Button[1];
                ThirdAUOpsAppButtonArray[0] = new Button();
                ThirdAUOpsAppButtonArray[0].Content = "Sign ONode AU";
                ThirdAUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdAUOpsAppButtonArray[0].Click += AUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(ThirdAUOpsAppComboBoxArray[0]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[5]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBoxArray[4]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBlockArray[6]);
                MyStackPanel.Children.Add(ThirdAUOpsAppTextBoxArray[5]);
                MyStackPanel.Children.Add(ThirdAUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                AUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasAUOpsAppUIRendered = true;
            }
        }
        else if(AUOpsAppUIChooser == 4) 
        {
            if (HasAUOpsAppUIRendered == false)
            {
                FourthAUOpsAppTextBlockArray = new TextBlock[7];
                FourthAUOpsAppTextBlockArray[0] = new TextBlock();
                FourthAUOpsAppTextBlockArray[1] = new TextBlock();
                FourthAUOpsAppTextBlockArray[2] = new TextBlock();
                FourthAUOpsAppTextBlockArray[3] = new TextBlock();
                FourthAUOpsAppTextBlockArray[4] = new TextBlock();
                FourthAUOpsAppTextBlockArray[5] = new TextBlock();
                FourthAUOpsAppTextBlockArray[6] = new TextBlock();
                FourthAUOpsAppTextBlockArray[0].Text = "User ID?";
                FourthAUOpsAppTextBlockArray[1].Text = "User ID (RO)";
                FourthAUOpsAppTextBlockArray[2].Text = "SNode User ID";
                FourthAUOpsAppTextBlockArray[3].Text = "Auth PK";
                FourthAUOpsAppTextBlockArray[4].Text = "Sign PK";
                FourthAUOpsAppTextBlockArray[5].Text = "Signed Auth PK (RO)";
                FourthAUOpsAppTextBlockArray[6].Text = "Signed Sign PK (RO)";
                FourthAUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppTextBlockArray[5].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppTextBlockArray[6].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppTextBoxArray = new TextBox[6];
                FourthAUOpsAppTextBoxArray[0] = new TextBox();
                FourthAUOpsAppTextBoxArray[1] = new TextBox();
                FourthAUOpsAppTextBoxArray[2] = new TextBox();
                FourthAUOpsAppTextBoxArray[3] = new TextBox();
                FourthAUOpsAppTextBoxArray[4] = new TextBox();
                FourthAUOpsAppTextBoxArray[5] = new TextBox();
                FourthAUOpsAppTextBoxArray[0].IsReadOnly = true;
                FourthAUOpsAppTextBoxArray[4].IsReadOnly = true;
                FourthAUOpsAppTextBoxArray[5].IsReadOnly = true;
                FourthAUOpsAppTextBoxArray[0].Width = 250;
                FourthAUOpsAppTextBoxArray[0].MaxWidth = 250;
                FourthAUOpsAppTextBoxArray[0].Height = 50;
                FourthAUOpsAppTextBoxArray[0].MaxHeight = 50;
                FourthAUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FourthAUOpsAppTextBoxArray[1].Width = 250;
                FourthAUOpsAppTextBoxArray[1].MaxWidth = 250;
                FourthAUOpsAppTextBoxArray[1].Height = 50;
                FourthAUOpsAppTextBoxArray[1].MaxHeight = 50;
                FourthAUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FourthAUOpsAppTextBoxArray[2].Width = 250;
                FourthAUOpsAppTextBoxArray[2].MaxWidth = 250;
                FourthAUOpsAppTextBoxArray[2].Height = 50;
                FourthAUOpsAppTextBoxArray[2].MaxHeight = 50;
                FourthAUOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FourthAUOpsAppTextBoxArray[3].Width = 250;
                FourthAUOpsAppTextBoxArray[3].MaxWidth = 250;
                FourthAUOpsAppTextBoxArray[3].Height = 50;
                FourthAUOpsAppTextBoxArray[3].MaxHeight = 50;
                FourthAUOpsAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FourthAUOpsAppComboBoxArray = new ComboBox[1];
                FourthAUOpsAppComboBoxArray[0] = new ComboBox();
                FourthAUOpsAppComboBoxArray[0].MaxWidth = 250;
                AUOpsAppLoadUserIDs();
                FourthAUOpsAppComboBoxArray[0].SelectionChanged += AUOpsAppComboBoxSelectedItemsChanged;
                FourthAUOpsAppButtonArray = new Button[1];
                FourthAUOpsAppButtonArray[0] = new Button();
                FourthAUOpsAppButtonArray[0].Content = "Sign SNode AU";
                FourthAUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FourthAUOpsAppButtonArray[0].Click += AUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FourthAUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(FourthAUOpsAppComboBoxArray[0]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBlockArray[3]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBoxArray[2]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBlockArray[4]);
                MyStackPanel.Children.Add(FourthAUOpsAppTextBoxArray[3]);
                MyStackPanel.Children.Add(FourthAUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                AUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasAUOpsAppUIRendered = true;
            }
        }
        else if(AUOpsAppUIChooser == 5) 
        {
            if (HasAUOpsAppUIRendered == false)
            {
                FifthAUOpsAppTextBlockArray = new TextBlock[3];
                FifthAUOpsAppTextBlockArray[0] = new TextBlock();
                FifthAUOpsAppTextBlockArray[1] = new TextBlock();
                FifthAUOpsAppTextBlockArray[2] = new TextBlock();
                FifthAUOpsAppTextBlockArray[0].Text = "User ID?";
                FifthAUOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                FifthAUOpsAppTextBlockArray[2].Text = "Status (Read Only)";
                FifthAUOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthAUOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthAUOpsAppTextBoxArray = new TextBox[2];
                FifthAUOpsAppTextBoxArray[0] = new TextBox();
                FifthAUOpsAppTextBoxArray[1] = new TextBox();
                FifthAUOpsAppTextBoxArray[0].IsReadOnly = true;
                FifthAUOpsAppTextBoxArray[0].Width = 250;
                FifthAUOpsAppTextBoxArray[0].MaxWidth = 250;
                FifthAUOpsAppTextBoxArray[0].Height = 125;
                FifthAUOpsAppTextBoxArray[0].MaxHeight = 125;
                FifthAUOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FifthAUOpsAppTextBoxArray[1].IsReadOnly = true;
                FifthAUOpsAppTextBoxArray[1].Width = 250;
                FifthAUOpsAppTextBoxArray[1].MaxWidth = 250;
                FifthAUOpsAppTextBoxArray[1].Height = 125;
                FifthAUOpsAppTextBoxArray[1].MaxHeight = 125;
                FifthAUOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FifthAUOpsAppComboBoxArray = new ComboBox[1];
                FifthAUOpsAppComboBoxArray[0] = new ComboBox();
                FifthAUOpsAppComboBoxArray[0].MaxWidth = 250;
                AUOpsAppLoadUserIDs();
                FifthAUOpsAppComboBoxArray[0].SelectionChanged += AUOpsAppComboBoxSelectedItemsChanged;
                FifthAUOpsAppButtonArray = new Button[1];
                FifthAUOpsAppButtonArray[0] = new Button();
                FifthAUOpsAppButtonArray[0].Content = "Delete User";
                FifthAUOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FifthAUOpsAppButtonArray[0].Click += AUOpsAppBTN_Click;
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FifthAUOpsAppTextBlockArray[0]);
                MyStackPanel.Children.Add(FifthAUOpsAppComboBoxArray[0]);
                MyStackPanel.Children.Add(FifthAUOpsAppTextBlockArray[1]);
                MyStackPanel.Children.Add(FifthAUOpsAppTextBoxArray[0]);
                MyStackPanel.Children.Add(FifthAUOpsAppTextBlockArray[2]);
                MyStackPanel.Children.Add(FifthAUOpsAppTextBoxArray[1]);
                MyStackPanel.Children.Add(FifthAUOpsAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                AUOpsAppLowerRightSP.Children.Add(MyScrollViewer);
                HasAUOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetAUOpsAppUI();
        }
    }

    private void OOBOpsAppDrawUI() 
    {
        if(OOBOpsAppUIChooser == 1) 
        {
            if(HasOOBOpsAppUIRendered == false) 
            {
                FirstOOBOpsAppTextBlockArray = new TextBlock[2];
                FirstOOBOpsAppTextBlockArray[0] = new TextBlock();
                FirstOOBOpsAppTextBlockArray[1] = new TextBlock();
                FirstOOBOpsAppTextBlockArray[0].Text = "Challenge Bytes? (>=16 bytes)";
                FirstOOBOpsAppTextBlockArray[1].Text = "Generated Challenge (Base64)";
                FirstOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsAppTextBoxArray = new TextBox[2];
                FirstOOBOpsAppTextBoxArray[0] = new TextBox();
                FirstOOBOpsAppTextBoxArray[1] = new TextBox();
                FirstOOBOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstOOBOpsAppTextBoxArray[0].Width = 250;
                FirstOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstOOBOpsAppTextBoxArray[0].Height = 125;
                FirstOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsAppTextBoxArray[1].Width = 250;
                FirstOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstOOBOpsAppTextBoxArray[1].Height = 125;
                FirstOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstOOBOpsButtonArray = new Button[1];
                FirstOOBOpsButtonArray[0] = new Button();
                FirstOOBOpsButtonArray[0].Content = "Generate Challenge";
                FirstOOBOpsButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstOOBOpsButtonArray[0].Click += OOBOpsAppBTN_Click;                
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(FirstOOBOpsButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else if(OOBOpsAppUIChooser == 2) 
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                SecondOOBOpsAppTextBlockArray = new TextBlock[4];
                SecondOOBOpsAppTextBlockArray[0] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[1] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[2] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[3] = new TextBlock();
                SecondOOBOpsAppTextBlockArray[0].Text = "User ID?";
                SecondOOBOpsAppTextBlockArray[1].Text = "User ID (Read Only)";
                SecondOOBOpsAppTextBlockArray[2].Text = "Challenge";
                SecondOOBOpsAppTextBlockArray[3].Text = "Signed Challenge (Read Only)";
                SecondOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppTextBoxArray = new TextBox[3];
                SecondOOBOpsAppTextBoxArray[0] = new TextBox();
                SecondOOBOpsAppTextBoxArray[1] = new TextBox();
                SecondOOBOpsAppTextBoxArray[2] = new TextBox();
                SecondOOBOpsAppTextBoxArray[0].IsReadOnly = true;
                SecondOOBOpsAppTextBoxArray[2].IsReadOnly = true;
                SecondOOBOpsAppTextBoxArray[0].Width = 250;
                SecondOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[0].Height = 125;
                SecondOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppTextBoxArray[1].Width = 250;
                SecondOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[1].Height = 125;
                SecondOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppTextBoxArray[2].Width = 250;
                SecondOOBOpsAppTextBoxArray[2].MaxWidth = 250;
                SecondOOBOpsAppTextBoxArray[2].Height = 125;
                SecondOOBOpsAppTextBoxArray[2].MaxHeight = 125;
                SecondOOBOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                SecondOOBOpsAppComboBoxArray = new ComboBox[1];
                SecondOOBOpsAppComboBoxArray[0] = new ComboBox();
                SecondOOBOpsAppComboBoxArray[0].MaxWidth = 250;
                OOBOpsAppLoadUserIDs();
                SecondOOBOpsAppComboBoxArray[0].SelectionChanged += OOBOpsAppComboBoxSelectedItemsChanged;
                SecondOOBOpsAppButtonArray = new Button[1];
                SecondOOBOpsAppButtonArray[0] = new Button();
                SecondOOBOpsAppButtonArray[0].Content = "Sign Challenge";
                SecondOOBOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondOOBOpsAppButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppComboBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBlockArray[3]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(SecondOOBOpsAppButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else if(OOBOpsAppUIChooser == 3) 
        {
            if (HasOOBOpsAppUIRendered == false)
            {
                ThirdOOBOpsAppTextBlockArray = new TextBlock[3];
                ThirdOOBOpsAppTextBlockArray[0] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[1] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[2] = new TextBlock();
                ThirdOOBOpsAppTextBlockArray[0].Text = "Signed Challenge";
                ThirdOOBOpsAppTextBlockArray[1].Text = "Others' DSA Public Key";
                ThirdOOBOpsAppTextBlockArray[2].Text = "Status (Read Only)";
                ThirdOOBOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppTextBoxArray = new TextBox[3];
                ThirdOOBOpsAppTextBoxArray[0] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[1] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[2] = new TextBox();
                ThirdOOBOpsAppTextBoxArray[2].IsReadOnly = true;
                ThirdOOBOpsAppTextBoxArray[0].Width = 250;
                ThirdOOBOpsAppTextBoxArray[0].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[0].Height = 125;
                ThirdOOBOpsAppTextBoxArray[0].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppTextBoxArray[1].Width = 250;
                ThirdOOBOpsAppTextBoxArray[1].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[1].Height = 125;
                ThirdOOBOpsAppTextBoxArray[1].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppTextBoxArray[2].Width = 250;
                ThirdOOBOpsAppTextBoxArray[2].MaxWidth = 250;
                ThirdOOBOpsAppTextBoxArray[2].Height = 125;
                ThirdOOBOpsAppTextBoxArray[2].MaxHeight = 125;
                ThirdOOBOpsAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                ThirdOOBOpsAppButtonArray = new Button[1];
                ThirdOOBOpsAppButtonArray[0] = new Button();
                ThirdOOBOpsAppButtonArray[0].Content = "Verify Signed Challenge";
                ThirdOOBOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ThirdOOBOpsAppButtonArray[0].Click += OOBOpsAppBTN_Click;
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[0]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[1]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBlockArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppTextBoxArray[2]);
                OOBOpsAppLowerRightSP.Children.Add(ThirdOOBOpsAppButtonArray[0]);
                HasOOBOpsAppUIRendered = true;
            }
        }
        else 
        {
            ResetOOBOpsAppUI();
        }
    }

    private void CertInfoOpsAppDrawUI() 
    {
        if (CertInfoOpsAppUIChooser==1) 
        {
            if (HasCertInfoOpsAppUIRendered == false) 
            {
                FirstCertInfoOpsAppTextBlockArray = new TextBlock[2];
                FirstCertInfoOpsAppTextBlockArray[0] = new TextBlock();
                FirstCertInfoOpsAppTextBlockArray[1] = new TextBlock();
                FirstCertInfoOpsAppTextBlockArray[0].Text = "AU's Arweave ID?";
                FirstCertInfoOpsAppTextBlockArray[1].Text = "Decoded AU's Arweave Info (RO)";
                FirstCertInfoOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCertInfoOpsAppTextBoxArray = new TextBox[2];
                FirstCertInfoOpsAppTextBoxArray[0] = new TextBox();
                FirstCertInfoOpsAppTextBoxArray[1] = new TextBox();
                FirstCertInfoOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstCertInfoOpsAppTextBoxArray[0].Width = 300;
                FirstCertInfoOpsAppTextBoxArray[0].MaxWidth = 300;
                FirstCertInfoOpsAppTextBoxArray[0].Height = 50;
                FirstCertInfoOpsAppTextBoxArray[0].MaxHeight = 50;
                FirstCertInfoOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstCertInfoOpsAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstCertInfoOpsAppTextBoxArray[1].Width = 400;
                FirstCertInfoOpsAppTextBoxArray[1].MaxWidth = 400;
                FirstCertInfoOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstCertInfoOpsAppTextBoxArray[1].Height = 125;
                FirstCertInfoOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstCertInfoOpsAppButtonArray = new Button[1];
                FirstCertInfoOpsAppButtonArray[0] = new Button();
                FirstCertInfoOpsAppButtonArray[0].Content = "Decode AU Info";
                FirstCertInfoOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstCertInfoOpsAppButtonArray[0].Click += CertInfoOpsAppBTN_Click;
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBlockArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBoxArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBlockArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppTextBoxArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(FirstCertInfoOpsAppButtonArray[0]);
                HasCertInfoOpsAppUIRendered = true;
            }
        }
        else if (CertInfoOpsAppUIChooser == 2) 
        {
            if (HasCertInfoOpsAppUIRendered == false)
            {
                SecondCertInfoOpsAppTextBlockArray = new TextBlock[2];
                SecondCertInfoOpsAppTextBlockArray[0] = new TextBlock();
                SecondCertInfoOpsAppTextBlockArray[1] = new TextBlock();
                SecondCertInfoOpsAppTextBlockArray[0].Text = "AU Cert's Arweave ID?";
                SecondCertInfoOpsAppTextBlockArray[1].Text = "Decoded AU Cert (RO)";
                SecondCertInfoOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCertInfoOpsAppTextBoxArray = new TextBox[2];
                SecondCertInfoOpsAppTextBoxArray[0] = new TextBox();
                SecondCertInfoOpsAppTextBoxArray[1] = new TextBox();
                SecondCertInfoOpsAppTextBoxArray[1].IsReadOnly = true;
                SecondCertInfoOpsAppTextBoxArray[0].Width = 300;
                SecondCertInfoOpsAppTextBoxArray[0].MaxWidth = 300;
                SecondCertInfoOpsAppTextBoxArray[0].Height = 50;
                SecondCertInfoOpsAppTextBoxArray[0].MaxHeight = 50;
                SecondCertInfoOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondCertInfoOpsAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                SecondCertInfoOpsAppTextBoxArray[1].MaxWidth = 400;
                SecondCertInfoOpsAppTextBoxArray[1].Width = 400;
                SecondCertInfoOpsAppTextBoxArray[1].MaxHeight = 125;
                SecondCertInfoOpsAppTextBoxArray[1].Height = 125;
                SecondCertInfoOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondCertInfoOpsAppButtonArray = new Button[1];
                SecondCertInfoOpsAppButtonArray[0] = new Button();
                SecondCertInfoOpsAppButtonArray[0].Content = "Decode Cert";
                SecondCertInfoOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondCertInfoOpsAppButtonArray[0].Click += CertInfoOpsAppBTN_Click;
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBlockArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBoxArray[0]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBlockArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppTextBoxArray[1]);
                CertInfoOpsAppLowerRightSP.Children.Add(SecondCertInfoOpsAppButtonArray[0]);
                HasCertInfoOpsAppUIRendered = true;
            }
        }
        else
        {
            ResetCertInfoOpsAppUI();
        }
    }

    private void ResetServerOpsAppUI() 
    {
        ServerOpsAppUIChooser = 0;
        FirstServerOpsAppTextBlockArray = new TextBlock[] { };
        FirstServerOpsAppTextBoxArray = new TextBox[] { };
        FirstServerOpsAppButtonArray = new Button[] { };
        SecondServerOpsAppTextBlockArray = new TextBlock[] { };
        SecondServerOpsAppTextBoxArray = new TextBox[] { };
        SecondServerOpsAppButtonArray = new Button[] { };
        ThirdServerOpsAppTextBlockArray = new TextBlock[] { };
        ThirdServerOpsAppTextBoxArray = new TextBox[] { };
        ThirdServerOpsAppButtonArray = new Button[] { };
        FourthServerOpsAppTextBlockArray = new TextBlock[] { };
        FourthServerOpsAppTextBoxArray = new TextBox[] { };
        FourthServerOpsAppButtonArray = new Button[] { };
        ServerOpsAppLowerRightLPSP.Children.Clear();
        HasServerOpsAppUIRendered = false;
    }

    private void ResetAUOpsAppUI() 
    {
        AUOpsAppUIChooser = 0;
        FirstAUOpsAppTextBlockArray = new TextBlock[] { };
        FirstAUOpsAppTextBoxArray = new TextBox[] { };
        FirstAUOpsAppRadioButtonArray = new RadioButton[] { };
        FirstAUOpsAppButtonArray = new Button[] { };
        SecondAUOpsAppTextBlockArray = new TextBlock[] { };
        SecondAUOpsAppTextBoxArray = new TextBox[] { };
        SecondAUOpsAppComboBoxArray = new ComboBox[] { };
        SecondAUOpsAppButtonArray = new Button[] { };
        ThirdAUOpsAppTextBlockArray = new TextBlock[] { };
        ThirdAUOpsAppTextBoxArray = new TextBox[] { };
        ThirdAUOpsAppComboBoxArray = new ComboBox[] { };
        ThirdAUOpsAppButtonArray = new Button[] { };
        FourthAUOpsAppTextBlockArray = new TextBlock[] { };
        FourthAUOpsAppTextBoxArray = new TextBox[] { };
        FourthAUOpsAppComboBoxArray = new ComboBox[] { };
        FourthAUOpsAppButtonArray = new Button[] { };
        FifthAUOpsAppTextBlockArray = new TextBlock[] { };
        FifthAUOpsAppTextBoxArray = new TextBox[] { };
        FifthAUOpsAppComboBoxArray = new ComboBox[] { };
        FifthAUOpsAppButtonArray = new Button[] { };
        AUOpsAppLowerRightSP.Children.Clear();
        HasAUOpsAppUIRendered = false;
    }

    private void ResetOOBOpsAppUI() 
    {
        OOBOpsAppUIChooser = 0;
        FirstOOBOpsAppTextBlockArray = new TextBlock[] { };
        FirstOOBOpsAppTextBoxArray = new TextBox[] { };
        FirstOOBOpsButtonArray = new Button[] { };
        SecondOOBOpsAppTextBlockArray = new TextBlock[] { };
        SecondOOBOpsAppTextBoxArray = new TextBox[] { };
        SecondOOBOpsAppComboBoxArray = new ComboBox[] { };
        SecondOOBOpsAppButtonArray = new Button[] { };
        ThirdOOBOpsAppTextBlockArray = new TextBlock[] { };
        ThirdOOBOpsAppTextBoxArray = new TextBox[] { };
        ThirdOOBOpsAppButtonArray = new Button[] { };
        OOBOpsAppLowerRightSP.Children.Clear();
        HasOOBOpsAppUIRendered = false;
    }

    private void ResetCertInfoOpsAppUI()
    {
        CertInfoOpsAppUIChooser = 0;
        FirstCertInfoOpsAppTextBlockArray = new TextBlock[] { };
        FirstCertInfoOpsAppTextBoxArray = new TextBox[] { };
        FirstCertInfoOpsAppButtonArray = new Button[] { };
        SecondCertInfoOpsAppTextBlockArray = new TextBlock[] { };
        SecondCertInfoOpsAppTextBoxArray = new TextBox[] { };
        SecondCertInfoOpsAppButtonArray = new Button[] { };
        CertInfoOpsAppLowerRightSP.Children.Clear();
        HasCertInfoOpsAppUIRendered = false;
    }

    private void AUOpsAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e) 
    {
        if (AUOpsAppUIChooser == 2) 
        {
            if (SecondAUOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                SecondAUOpsAppTextBoxArray[0].Text = SecondAUOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
        else if (AUOpsAppUIChooser == 3) 
        {
            if (ThirdAUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                ThirdAUOpsAppTextBoxArray[0].Text = ThirdAUOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
        else if(AUOpsAppUIChooser == 4) 
        {
            if (FourthAUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                FourthAUOpsAppTextBoxArray[0].Text = FourthAUOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
        else if(AUOpsAppUIChooser == 5) 
        {
            if (FifthAUOpsAppComboBoxArray[0].SelectedIndex != -1)
            {
                FifthAUOpsAppTextBoxArray[0].Text = FifthAUOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void OOBOpsAppComboBoxSelectedItemsChanged(object? sender, SelectionChangedEventArgs e) 
    {
        if (OOBOpsAppUIChooser == 2) 
        {
            if (SecondOOBOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                SecondOOBOpsAppTextBoxArray[0].Text = SecondOOBOpsAppComboBoxArray[0].SelectedItem.ToString();
            }
        }
    }

    private void ServerOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (ServerOpsAppUIChooser == 1) 
        {
            String IPAddress = FirstServerOpsAppTextBoxArray[0].Text;
            if(IPAddress!=null && IPAddress.CompareTo("") != 0) 
            {
                if (File.Exists(AUOpsAppServerRootFolder + "IP.txt") == true) 
                {
                    ServerIPStatusTB.Text = "";
                }
                File.WriteAllText(AUOpsAppServerRootFolder + "IP.txt", IPAddress);
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
                FirstServerOpsAppTextBoxArray[1].Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
        else if (ServerOpsAppUIChooser == 2) 
        {
            String User_ID = SecondServerOpsAppTextBoxArray[0].Text;
            if(User_ID!=null && User_ID.CompareTo("") != 0) 
            {
                NodeArweaveCertModel MyModel = new NodeArweaveCertModel();
                MyModel.ONodeAUInfoArweaveIDs = new String[] { };
                MyModel.NodeAUInfoArweaveID = "";
                MyModel.NodeAUCertInfoArweaveID = "";
                MyModel.Status = "";
                GetAUFullCertHelper.GetFullCert(User_ID, AUOpsAppCertificateFolder + User_ID, ref MyModel);
                if (MyModel.Status.Contains("Error") == false) 
                {
                    SecondServerOpsAppTextBoxArray[1].Text = MyModel.NodeAUInfoArweaveID;
                    SecondServerOpsAppTextBoxArray[2].Text = MyModel.NodeAUCertInfoArweaveID;
                    SecondServerOpsAppTextBoxArray[3].Text = String.Join(",", MyModel.ONodeAUInfoArweaveIDs);
                    SecondServerOpsAppTextBoxArray[4].Text = "Neccessary information fetched. You can check '" + AUOpsAppCertificateFolder + User_ID + "' folder for your reference.";
                }
                else 
                {
                    SecondServerOpsAppTextBoxArray[4].Text = MyModel.Status;
                }
            }
        }
        else if(ServerOpsAppUIChooser == 3) 
        {
            ThirdServerOpsAppTextBoxArray[0].Text = GetServerARHelper.GetAR();
        }
        else if(ServerOpsAppUIChooser == 4) 
        {
            String RawNodeInformation = GetNodeInformationHelper.GetNodeInfo();
            String[] NodeInformationArray = RawNodeInformation.Split(",");
            FourthServerOpsAppTextBoxArray[0].Text = NodeInformationArray[0];
            FourthServerOpsAppTextBoxArray[1].Text = NodeInformationArray[1];
            FourthServerOpsAppTextBoxArray[2].Text = NodeInformationArray[2];
            FourthServerOpsAppTextBoxArray[3].Text = NodeInformationArray[3];
            FourthServerOpsAppTextBoxArray[4].Text = NodeInformationArray[4];
        }
        else if(ServerOpsAppUIChooser == 5) 
        {
            FifthServerOpsAppTextBoxArray[0].Text = GetCompromisedAUsHelper.GetCompromisedAUs();
        }
    }

    private void AUOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (AUOpsAppUIChooser == 1) 
        {
            String Contact = FirstAUOpsAppTextBoxArray[1].Text;
            String AuthenticationPublicKeyB64String = "";
            String SigningPublicKeyB64String = "";
            String OOBPublicKeyB64String = "";
            //about 6 months..
            //change this number if you want to..
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(182);
            String User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
            if (User_ID.Length > 32)
            {
                User_ID = User_ID.Substring(0, 32);
            }
            while (Directory.Exists(AUOPsAppRootFolder + User_ID) == true) 
            {
                User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
                if (User_ID.Length > 32) 
                {
                    User_ID = User_ID.Substring(0, 32);
                }
            }
            Directory.CreateDirectory(AUOPsAppRootFolder + User_ID);
            Directory.CreateDirectory(OOBOpsAppRootFolder + User_ID);
            if (FirstAUOpsAppRadioButtonArray[0].IsChecked == true) 
            {
                RevampedKeyPair MyAuthenticationKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair MySigningKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                RevampedKeyPair MyOOBKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                {
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(AUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED25519");
                }
                else 
                {
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(AUOPsAppRootFolder + User_ID + "/AlgorithmType.txt", "ED25519");
                }
                AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                MyAuthenticationKeyPair.Clear();
                MySigningKeyPair.Clear();
                MyOOBKeyPair.Clear();
            }
            else 
            {
                ED448RevampedKeyPair MyAuthenticationKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair MySigningKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                ED448RevampedKeyPair MyOOBKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(AUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt", "ED448");
                }
                else
                {
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "APrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt", MySigningKeyPair.PrivateKey);
                    File.WriteAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt", MySigningKeyPair.PublicKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt", MyOOBKeyPair.PrivateKey);
                    File.WriteAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt", MyOOBKeyPair.PublicKey);
                    File.WriteAllText(AUOPsAppRootFolder + User_ID + "/AlgorithmType.txt", "ED448");
                }
                AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                SigningPublicKeyB64String = Convert.ToBase64String(MySigningKeyPair.PublicKey);
                OOBPublicKeyB64String = Convert.ToBase64String(MyOOBKeyPair.PublicKey);
                MyAuthenticationKeyPair.Clear();
                MySigningKeyPair.Clear();
                MyOOBKeyPair.Clear();
            }
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
            {
                File.WriteAllText(AUOPsAppRootFolder + User_ID + "\\ASPK_ValidDay.txt",CurrentDateTime.Day.ToString());
                File.WriteAllText(AUOPsAppRootFolder + User_ID + "\\ASPK_ValidMonth.txt", CurrentDateTime.Month.ToString());
                File.WriteAllText(AUOPsAppRootFolder + User_ID + "\\ASPK_ValidYear.txt", CurrentDateTime.Year.ToString());
            }
            else 
            {
                File.WriteAllText(AUOPsAppRootFolder + User_ID + "/ASPK_ValidDay.txt", CurrentDateTime.Day.ToString());
                File.WriteAllText(AUOPsAppRootFolder + User_ID + "/ASPK_ValidMonth.txt", CurrentDateTime.Month.ToString());
                File.WriteAllText(AUOPsAppRootFolder + User_ID + "/ASPK_ValidYear.txt", CurrentDateTime.Year.ToString());
            }
            if(Contact!=null && Contact.CompareTo("") != 0) 
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    File.WriteAllText(AUOPsAppRootFolder + User_ID + "\\Contact.txt", Contact);
                }
                else
                {
                    File.WriteAllText(AUOPsAppRootFolder + User_ID + "/Contact.txt", Contact);
                }
            }
            FirstAUOpsAppTextBoxArray[0].Text = User_ID;
            FirstAUOpsAppTextBoxArray[2].Text = AuthenticationPublicKeyB64String;
            FirstAUOpsAppTextBoxArray[3].Text = SigningPublicKeyB64String;
            FirstAUOpsAppTextBoxArray[4].Text = OOBPublicKeyB64String;
            FirstAUOpsAppTextBoxArray[5].Text = CurrentDateTime.Day.ToString();
            FirstAUOpsAppTextBoxArray[6].Text = CurrentDateTime.Month.ToString();
            FirstAUOpsAppTextBoxArray[7].Text = CurrentDateTime.Year.ToString();
            AUOpsAppLoadUserIDs();
        }
        else if(AUOpsAppUIChooser == 2) 
        {
            if (SecondAUOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                String User_ID = SecondAUOpsAppTextBoxArray[0].Text;
                String Contact = "";
                Byte[] AuthenticationPublicKey = new Byte[] { };
                Byte[] SigningPublicKey = new Byte[] { };
                Byte[] OOBPublicKey = new Byte[] { };
                String ASPK_ValidDayString = "";
                String ASPK_ValidMonthString = "";
                String ASPK_ValidYearString = "";
                String AlgorithmType = "";
                String AuthPublicKeyB64 = "";
                String SigningPublicKeyB64 = "";
                String OOBPublicKeyB64 = "";
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                {
                    if (File.Exists(AUOPsAppRootFolder + User_ID + "\\Contact.txt") == true) 
                    {
                        Contact = File.ReadAllText(AUOPsAppRootFolder + User_ID + "\\Contact.txt");
                    }
                    AuthenticationPublicKey = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "APublicKey.txt");
                    SigningPublicKey = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPublicKey.txt");
                    OOBPublicKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPublicKey.txt");
                    ASPK_ValidDayString = File.ReadAllText(AUOPsAppRootFolder + User_ID + "\\ASPK_ValidDay.txt");
                    ASPK_ValidMonthString = File.ReadAllText(AUOPsAppRootFolder + User_ID + "\\ASPK_ValidMonth.txt");
                    ASPK_ValidYearString = File.ReadAllText(AUOPsAppRootFolder + User_ID + "\\ASPK_ValidYear.txt");
                    AlgorithmType = File.ReadAllText(AUOPsAppRootFolder + User_ID + "\\AlgorithmType.txt");
                }
                else 
                {
                    if (File.Exists(AUOPsAppRootFolder + User_ID + "/Contact.txt") == true) 
                    {
                        Contact = File.ReadAllText(AUOPsAppRootFolder + User_ID + "/Contact.txt");
                    }
                    AuthenticationPublicKey = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "APublicKey.txt");
                    SigningPublicKey = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPublicKey.txt");
                    OOBPublicKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPublicKey.txt");
                    ASPK_ValidDayString = File.ReadAllText(AUOPsAppRootFolder + User_ID + "/ASPK_ValidDay.txt");
                    ASPK_ValidMonthString = File.ReadAllText(AUOPsAppRootFolder + User_ID + "/ASPK_ValidMonth.txt");
                    ASPK_ValidYearString = File.ReadAllText(AUOPsAppRootFolder + User_ID + "/ASPK_ValidYear.txt");
                    AlgorithmType = File.ReadAllText(AUOPsAppRootFolder + User_ID + "/AlgorithmType.txt");
                }
                AuthPublicKeyB64 = Convert.ToBase64String(AuthenticationPublicKey);
                SigningPublicKeyB64 = Convert.ToBase64String(SigningPublicKey);
                OOBPublicKeyB64 = Convert.ToBase64String(OOBPublicKey);
                SecondAUOpsAppTextBoxArray[1].Text = Contact;
                SecondAUOpsAppTextBoxArray[2].Text = AuthPublicKeyB64;
                SecondAUOpsAppTextBoxArray[3].Text = SigningPublicKeyB64;
                SecondAUOpsAppTextBoxArray[4].Text = OOBPublicKeyB64;
                SecondAUOpsAppTextBoxArray[5].Text = ASPK_ValidDayString;
                SecondAUOpsAppTextBoxArray[6].Text = ASPK_ValidMonthString;
                SecondAUOpsAppTextBoxArray[7].Text = ASPK_ValidYearString;
                SecondAUOpsAppTextBoxArray[8].Text = AlgorithmType;
            }
        }
        else if(AUOpsAppUIChooser == 3) 
        {
            if (ThirdAUOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                String User_ID = ThirdAUOpsAppTextBoxArray[0].Text;
                String ONode_User_ID = ThirdAUOpsAppTextBoxArray[1].Text;
                String Auth_PK_B64 = ThirdAUOpsAppTextBoxArray[2].Text;
                String Sign_PK_B64 = ThirdAUOpsAppTextBoxArray[3].Text;
                if(String.IsNullOrEmpty(ONode_User_ID)==false && String.IsNullOrEmpty(Auth_PK_B64)==false && String.IsNullOrEmpty(Sign_PK_B64) == false) 
                {
                    Byte[] AuthPKBytes = new Byte[] { };
                    Byte[] SignPKBytes = new Byte[] { };
                    Byte[] UserOwnSignaturePrivateKeyBytes = new Byte[] { };
                    Byte[] SignedAuthPKBytes = new Byte[] { };
                    Byte[] SignedSignPKBytes = new Byte[] { };
                    Boolean AbleToParse = true;
                    try 
                    {
                        AuthPKBytes = Convert.FromBase64String(Auth_PK_B64);
                        SignPKBytes = Convert.FromBase64String(Sign_PK_B64);
                    }
                    catch 
                    {
                        AbleToParse = false;
                    }
                    if (AbleToParse) 
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                        {
                            UserOwnSignaturePrivateKeyBytes = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt");
                        }
                        else 
                        {
                            UserOwnSignaturePrivateKeyBytes = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt");
                        }
                        if (UserOwnSignaturePrivateKeyBytes.Length == 64) 
                        {
                            SignedAuthPKBytes = SodiumPublicKeyAuth.Sign(AuthPKBytes, UserOwnSignaturePrivateKeyBytes);
                            SignedSignPKBytes = SodiumPublicKeyAuth.Sign(SignPKBytes, UserOwnSignaturePrivateKeyBytes, true);
                        }
                        else 
                        {
                            SignedAuthPKBytes = SecureED448.GenerateSignatureMessage(UserOwnSignaturePrivateKeyBytes, AuthPKBytes, new Byte[] { });
                            SignedSignPKBytes = SecureED448.GenerateSignatureMessage(UserOwnSignaturePrivateKeyBytes, SignPKBytes, new Byte[] { }, true);
                        }
                        ThirdAUOpsAppTextBoxArray[4].Text = Convert.ToBase64String(SignedAuthPKBytes);
                        ThirdAUOpsAppTextBoxArray[5].Text = Convert.ToBase64String(SignedSignPKBytes);
                    }
                    else 
                    {
                        ThirdAUOpsAppTextBoxArray[4].Text = "Error: Auth PK and Sign PK were not base 64 encoded";
                    }
                }
                else 
                {
                    ThirdAUOpsAppTextBoxArray[4].Text = "Error: ONode User ID, Auth PK and Sign PK must not be null/empty";
                }
            }
        }
        else if(AUOpsAppUIChooser == 4) 
        {
            if (FourthAUOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                String User_ID = FourthAUOpsAppTextBoxArray[0].Text;
                String SNode_User_ID = FourthAUOpsAppTextBoxArray[1].Text;
                String Auth_PK_B64 = FourthAUOpsAppTextBoxArray[2].Text;
                String Sign_PK_B64 = FourthAUOpsAppTextBoxArray[3].Text;
                if (String.IsNullOrEmpty(SNode_User_ID) == false && String.IsNullOrEmpty(Auth_PK_B64) == false && String.IsNullOrEmpty(Sign_PK_B64) == false)
                {
                    Byte[] AuthPKBytes = new Byte[] { };
                    Byte[] SignPKBytes = new Byte[] { };
                    Byte[] UserOwnSignaturePrivateKeyBytes = new Byte[] { };
                    Byte[] SignedAuthPKBytes = new Byte[] { };
                    Byte[] SignedSignPKBytes = new Byte[] { };
                    Boolean AbleToParse = true;
                    try
                    {
                        AuthPKBytes = Convert.FromBase64String(Auth_PK_B64);
                        SignPKBytes = Convert.FromBase64String(Sign_PK_B64);
                    }
                    catch
                    {
                        AbleToParse = false;
                    }
                    if (AbleToParse)
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            UserOwnSignaturePrivateKeyBytes = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "\\" + User_ID + "SPrivateKey.txt");
                        }
                        else
                        {
                            UserOwnSignaturePrivateKeyBytes = File.ReadAllBytes(AUOPsAppRootFolder + User_ID + "/" + User_ID + "SPrivateKey.txt");
                        }
                        if (UserOwnSignaturePrivateKeyBytes.Length == 64)
                        {
                            SignedAuthPKBytes = SodiumPublicKeyAuth.Sign(AuthPKBytes, UserOwnSignaturePrivateKeyBytes);
                            SignedSignPKBytes = SodiumPublicKeyAuth.Sign(SignPKBytes, UserOwnSignaturePrivateKeyBytes, true);
                        }
                        else
                        {
                            SignedAuthPKBytes = SecureED448.GenerateSignatureMessage(UserOwnSignaturePrivateKeyBytes, AuthPKBytes, new Byte[] { });
                            SignedSignPKBytes = SecureED448.GenerateSignatureMessage(UserOwnSignaturePrivateKeyBytes, SignPKBytes, new Byte[] { }, true);
                        }
                        FourthAUOpsAppTextBoxArray[4].Text = Convert.ToBase64String(SignedAuthPKBytes);
                        FourthAUOpsAppTextBoxArray[5].Text = Convert.ToBase64String(SignedSignPKBytes);
                    }
                    else
                    {
                        FourthAUOpsAppTextBoxArray[4].Text = "Error: Auth PK and Sign PK were not base 64 encoded";
                    }
                }
                else
                {
                    FourthAUOpsAppTextBoxArray[4].Text = "Error: ONode User ID, Auth PK and Sign PK must not be null/empty";
                }
            }
        }
        else if(AUOpsAppUIChooser == 5) 
        {
            FifthAUOpsAppTextBoxArray[1].Text = "";
            if (FifthAUOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                String User_ID = FifthAUOpsAppTextBoxArray[0].Text;
                Boolean AbleToDelete = true;
                try
                {
                    Directory.Delete(AUOPsAppRootFolder + User_ID, true);
                    Directory.Delete(OOBOpsAppRootFolder + User_ID, true);
                }
                catch 
                {
                    AbleToDelete = false;
                }
                if (AbleToDelete == true) 
                {
                    FifthAUOpsAppTextBoxArray[1].Text = "Success: This user's all information had been deleted locally";
                    AUOpsAppLoadUserIDs();
                }
                else 
                {
                    FifthAUOpsAppTextBoxArray[1].Text = "Error: Unable to find such user ID or the info had been deleted";
                }
            }
        }
    }

    private void OOBOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(OOBOpsAppUIChooser == 1) 
        {
            String ChallengeLengthString = FirstOOBOpsAppTextBoxArray[0].Text;
            Boolean AbleToParse = true;
            Boolean IsGreaterOrEqual16Bytes = true;
            int ChallengeLength = 0;
            Byte[] Challenge = new Byte[] { };
            if(ChallengeLengthString!=null && ChallengeLengthString.CompareTo("") != 0) 
            {
                try 
                {
                    ChallengeLength = int.Parse(ChallengeLengthString);
                    if (ChallengeLength < 16) 
                    {
                        IsGreaterOrEqual16Bytes = false;
                    }
                }
                catch 
                {
                    AbleToParse = false;
                }
                if(AbleToParse == true && IsGreaterOrEqual16Bytes == true) 
                {
                    Challenge = SodiumRNG.GetRandomBytes(ChallengeLength);
                    FirstOOBOpsAppTextBoxArray[1].Text = Convert.ToBase64String(Challenge);
                }
                else 
                {
                    FirstOOBOpsAppTextBlockArray[1].Text = "Error: Either you didn't put in round number or the challenge length is not at least 16 bytes";
                }
            }
        }
        else if(OOBOpsAppUIChooser == 2) 
        {
            if (SecondOOBOpsAppComboBoxArray[0].SelectedIndex != -1) 
            {
                String User_ID = SecondOOBOpsAppTextBoxArray[0].Text;
                String ChallengeString = SecondOOBOpsAppTextBoxArray[1].Text;
                Byte[] Challenge = new Byte[] { };
                Byte[] SignedChallenge = new Byte[] { };
                Byte[] UserOOBPrivateKey = new Byte[] { };
                Boolean AbleToParse = true;
                if(ChallengeString!=null && ChallengeString.CompareTo("") != 0) 
                {
                    try 
                    {
                        Challenge = Convert.FromBase64String(ChallengeString);
                    }
                    catch 
                    {
                        AbleToParse = false;
                    }
                    if (AbleToParse) 
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
                        {
                            UserOOBPrivateKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "\\" + User_ID + "OOBPrivateKey.txt");
                        }
                        else 
                        {
                            UserOOBPrivateKey = File.ReadAllBytes(OOBOpsAppRootFolder + User_ID + "/" + User_ID + "OOBPrivateKey.txt");
                        }
                        if (UserOOBPrivateKey.Length == 64) 
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, UserOOBPrivateKey, true);
                        }
                        else 
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(UserOOBPrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SecondOOBOpsAppTextBoxArray[2].Text = Convert.ToBase64String(SignedChallenge);
                    }
                    else 
                    {
                        SecondOOBOpsAppTextBoxArray[2].Text = "Error: The challenge was not properly encoded with base64";
                    }
                }
            }
        }
        else if(OOBOpsAppUIChooser == 3) 
        {
            String SignedChallengeString = ThirdOOBOpsAppTextBoxArray[0].Text;
            String OtherOOBPublicKeyString = ThirdOOBOpsAppTextBoxArray[1].Text;
            Byte[] SignedChallenge = new Byte[] { };
            Byte[] Challenge = new Byte[] { };
            Byte[] OtherOOBPublicKey = new Byte[] { };
            Boolean AbleToParse = true;
            Boolean AbleToVerify = true;
            if(SignedChallengeString!=null && SignedChallengeString.CompareTo("")!=0 && OtherOOBPublicKeyString!=null && OtherOOBPublicKeyString.CompareTo("") != 0) 
            {
                try 
                {
                    SignedChallenge = Convert.FromBase64String(SignedChallengeString);
                    OtherOOBPublicKey = Convert.FromBase64String(OtherOOBPublicKeyString);
                }
                catch 
                {
                    AbleToParse = false;
                }
                if (AbleToParse == true) 
                {
                    try 
                    {
                        if (OtherOOBPublicKey.Length == 32) 
                        {
                            Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge,OtherOOBPublicKey);
                        }
                        else 
                        {
                            Challenge = SecureED448.GetMessageFromSignatureMessage(OtherOOBPublicKey, SignedChallenge, new Byte[] { });
                        }
                    }
                    catch 
                    {
                        AbleToVerify = false;
                    }
                    if (AbleToVerify) 
                    {
                        ThirdOOBOpsAppTextBoxArray[2].Text = "Success: Able to verify the signed challenge with given digital signature public key from other user";
                    }
                    else 
                    {
                        ThirdOOBOpsAppTextBoxArray[2].Text = "Error: Unable to verify this signed challenge with given digital signature public key from other user";
                    }
                }
                else 
                {
                    ThirdOOBOpsAppTextBoxArray[2].Text = "Error: Signed Challenge or other user's out of band digital signature public key was not encoded in base64";
                }
            }
        }
    }

    private void CertInfoOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (CertInfoOpsAppUIChooser == 1)
        {
            String ArweaveID = FirstCertInfoOpsAppTextBoxArray[0].Text;
            if (String.IsNullOrEmpty(ArweaveID) == false) 
            {
                Boolean IsValidArweaveID = true;
                String TXData = "";
                try 
                {
                    TXData = GetTransactionDataHelper.GetTransactionData(ArweaveID);
                }
                catch 
                {
                    IsValidArweaveID = false;
                }
                if (IsValidArweaveID) 
                {
                    Byte[] DecodedArweaveTXData = Base64URLEncodeDecodeHelper.Decode(TXData);
                    String OriginalArweaveTXData = Encoding.UTF8.GetString(DecodedArweaveTXData);
                    FirstCertInfoOpsAppTextBoxArray[1].Text = OriginalArweaveTXData;
                }
                else 
                {
                    FirstCertInfoOpsAppTextBoxArray[1].Text = TXData;
                }
            }
            else 
            {
                FirstCertInfoOpsAppTextBoxArray[1].Text = "Error: There's no specified Arweave ID";
            }
        }
        else if (CertInfoOpsAppUIChooser == 2)
        {
            String ArweaveID = SecondCertInfoOpsAppTextBoxArray[0].Text;
            if (String.IsNullOrEmpty(ArweaveID) == false)
            {
                Boolean IsValidArweaveID = true;
                String TXData = "";
                try
                {
                    TXData = GetTransactionDataHelper.GetTransactionData(ArweaveID);
                }
                catch
                {
                    IsValidArweaveID = false;
                }
                if (IsValidArweaveID)
                {
                    Byte[] DecodedArweaveTXData = Base64URLEncodeDecodeHelper.Decode(TXData);
                    String OriginalArweaveTXData = Encoding.UTF8.GetString(DecodedArweaveTXData);
                    SecondCertInfoOpsAppTextBoxArray[1].Text = OriginalArweaveTXData;
                }
                else
                {
                    SecondCertInfoOpsAppTextBoxArray[1].Text = TXData;
                }
            }
            else
            {
                SecondCertInfoOpsAppTextBoxArray[1].Text = "Error: There's no specified Arweave ID";
            }
        }
    }

    private void AUOpsAppLoadUserIDs()
    { 
        if (AUOpsAppUIChooser>=2 && AUOpsAppUIChooser<=5) 
        {
            String[] User_IDWithDirectoryPath = Directory.GetDirectories(AUOPsAppRootFolder);
            String[] User_ID = new String[User_IDWithDirectoryPath.Length];
            int Loop = 0;
            while (Loop < User_IDWithDirectoryPath.Length) 
            {
                User_ID[Loop] = User_IDWithDirectoryPath[Loop].Remove(0, AUOPsAppRootFolder.Length);
                Loop += 1;
            }
            if (AUOpsAppUIChooser == 2) 
            {
                SecondAUOpsAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length) 
                {
                    SecondAUOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
            else if (AUOpsAppUIChooser == 3) 
            {
                ThirdAUOpsAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    ThirdAUOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
            else if (AUOpsAppUIChooser == 4) 
            {
                FourthAUOpsAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    FourthAUOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
            else if (AUOpsAppUIChooser == 5) 
            {
                FifthAUOpsAppComboBoxArray[0].Items.Clear();
                Loop = 0;
                while (Loop < User_ID.Length)
                {
                    FifthAUOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                    Loop += 1;
                }
            }
        }
    }

    private void OOBOpsAppLoadUserIDs() 
    {
        String[] User_IDWithDirectoryPath = Directory.GetDirectories(OOBOpsAppRootFolder);
        String[] User_ID = new String[User_IDWithDirectoryPath.Length];
        int Loop = 0;
        if (OOBOpsAppUIChooser == 2) 
        {
            SecondOOBOpsAppComboBoxArray[0].Items.Clear();
            while (Loop < User_IDWithDirectoryPath.Length)
            {
                User_ID[Loop] = User_IDWithDirectoryPath[Loop].Remove(0, OOBOpsAppRootFolder.Length);
                SecondOOBOpsAppComboBoxArray[0].Items.Add(User_ID[Loop]);
                Loop += 1;
            }
        }
    }
}
