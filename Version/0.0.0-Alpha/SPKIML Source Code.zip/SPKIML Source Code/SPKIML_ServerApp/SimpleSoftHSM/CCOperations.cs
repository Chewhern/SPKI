﻿using ASodium;
using BCASodium;
using System.Runtime.InteropServices;

namespace SPKIML_ServerApp.SimpleSoftHSM
{
    public static class CCOperations
    {
        private static IntPtr TempMasterMACKeyIntPtr;
        private static IntPtr TempMasterEncryptionKeyIntPtr;
        //Can change to other nonce hexadecimal value if you want to..
        private static Byte[] Nonce1 = SodiumHelper.HexToBinary("352b66077513f1abe7da139522739e16244d0f2f044e6524");
        private static Byte[] Nonce2 = SodiumHelper.HexToBinary("924400f379fbd71f6d9f66b436159078715548e1282600e1");

        public static void InitializeOperations() 
        {
            InitializeIntPtrs();
            CreateMasterKeys_Version2();
        }

        private static void InitializeIntPtrs() 
        {
            Boolean IsZeroPtr1 = true;
            Boolean IsZeroPtr2 = true;
            while(IsZeroPtr1 == true || IsZeroPtr2 == true) 
            {
                TempMasterMACKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZeroPtr1, 32);
                TempMasterEncryptionKeyIntPtr = SodiumGuardedHeapAllocation.Sodium_Malloc(ref IsZeroPtr2, 32);
            }
        }


        private static void CreateMasterKeys_Version2() 
        {
            //Input your seedsources here, you can use libsodium's binary to hex converter to replace the 00
            Byte[] SeedSource1 = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
            Byte[] SeedSource2 = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
            Byte[] EncryptedMACKeyWithMAC = File.ReadAllBytes("<Path>");
            Byte[] EncryptedEncryptionKeyWithMAC = File.ReadAllBytes("<Path>");
            Byte[] PreGeneratedMACKey = SodiumRNG.GetSeededRandomBytes(32, SeedSource1, true);
            Byte[] PreGeneratedEncryptionKey = SodiumRNG.GetSeededRandomBytes(32, SeedSource2, true);
            if (EncryptedMACKeyWithMAC.Length == EncryptedEncryptionKeyWithMAC.Length) 
            {
                Byte[] EncryptedMACKeyMAC = new Byte[64];
                Byte[] EncryptedEncryptionKeyMAC = new Byte[64];
                Byte[] EncryptedMACKey = new Byte[EncryptedMACKeyWithMAC.Length - EncryptedMACKeyMAC.Length];
                Byte[] EncryptedEncryptionKey = new Byte[EncryptedEncryptionKeyWithMAC.Length - EncryptedEncryptionKeyMAC.Length];
                Buffer.BlockCopy(EncryptedMACKeyWithMAC,0,EncryptedMACKeyMAC,0,EncryptedEncryptionKeyMAC.Length);
                Buffer.BlockCopy(EncryptedMACKeyWithMAC, EncryptedEncryptionKeyMAC.Length, EncryptedMACKey, 0, EncryptedMACKey.Length);
                Buffer.BlockCopy(EncryptedEncryptionKeyWithMAC, 0, EncryptedEncryptionKeyMAC, 0, EncryptedEncryptionKeyMAC.Length);
                Buffer.BlockCopy(EncryptedEncryptionKeyWithMAC, EncryptedEncryptionKeyMAC.Length, EncryptedEncryptionKey, 0, EncryptedEncryptionKey.Length);
                Boolean AbleToVerifyHMAC = SodiumHMACSHA512.VerifyMAC(EncryptedMACKeyMAC, EncryptedMACKey, PreGeneratedMACKey);
                Boolean AbleToVerifyHMAC2 = SodiumHMACSHA512.VerifyMAC(EncryptedEncryptionKeyMAC, EncryptedEncryptionKey, PreGeneratedMACKey);
                if(AbleToVerifyHMAC==true && AbleToVerifyHMAC2 == true) 
                {
                    Byte[] DecryptedMACKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedMACKey, Nonce1, PreGeneratedEncryptionKey);
                    Byte[] DecryptedEncryptionKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedEncryptionKey, Nonce2, PreGeneratedEncryptionKey);
                    Marshal.Copy(DecryptedMACKey, 0, TempMasterMACKeyIntPtr, 32);
                    Marshal.Copy(DecryptedEncryptionKey, 0, TempMasterEncryptionKeyIntPtr, 32);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
                    SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
                    SodiumSecureMemory.SecureClearBytes(DecryptedMACKey);
                    SodiumSecureMemory.SecureClearBytes(DecryptedEncryptionKey);
                    SodiumSecureMemory.SecureClearBytes(PreGeneratedMACKey);
                    SodiumSecureMemory.SecureClearBytes(PreGeneratedEncryptionKey);
                }
                else 
                {
                    SodiumSecureMemory.SecureClearBytes(PreGeneratedMACKey);
                    SodiumSecureMemory.SecureClearBytes(PreGeneratedEncryptionKey);
                    throw new Exception("Error: Unable to verify HMAC");
                }
            }
            else 
            {
                SodiumSecureMemory.SecureClearBytes(PreGeneratedMACKey);
                SodiumSecureMemory.SecureClearBytes(PreGeneratedEncryptionKey);
                throw new Exception("Error: These two private keys length must be the same");
            }
        }

        public static void GenerateAndEncryptSignaturePrivateKey(Boolean IsED25519=true) 
        {
            Boolean DoesNodeSignatureKeyPairExist = File.Exists("<Path>");
            if (DoesNodeSignatureKeyPairExist == true)
            {
                Byte[] EncryptedNodeSPrivateKey = new Byte[] { };
                Byte[] NodeSPublicKey = new Byte[] { };
                if (IsED25519)
                {
                    RevampedKeyPair NodeED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    EncryptedNodeSPrivateKey = EncryptNodeSignaturePrivateKey(NodeED25519KeyPair.PrivateKey);
                    NodeSPublicKey = NodeED25519KeyPair.PublicKey;
                    NodeED25519KeyPair.Clear();
                }
                else
                {
                    ED448RevampedKeyPair NodeED448KeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    EncryptedNodeSPrivateKey = EncryptNodeSignaturePrivateKey(NodeED448KeyPair.PrivateKey);
                    NodeSPublicKey = NodeED448KeyPair.PublicKey;
                    NodeED448KeyPair.Clear();
                }
                ExportNodeSignaturePrivateKey();
                File.WriteAllBytes("<Path>", EncryptedNodeSPrivateKey);
                File.WriteAllBytes("<Path>", NodeSPublicKey);
            }
        }

        private static Byte[] EncryptNodeSignaturePrivateKey(Byte[] PrivateKey,Boolean ClearKey=false) 
        {
            Byte[] EncryptedPrivateKeyWithMAC = new Byte[] { };
            Byte[] MasterMACKey = new Byte[32];
            Byte[] MasterEncryptionKey = new Byte[32];
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterEncryptionKeyIntPtr);
            Marshal.Copy(TempMasterMACKeyIntPtr, MasterMACKey, 0, 32);
            Marshal.Copy(TempMasterEncryptionKeyIntPtr, MasterEncryptionKey, 0, 32);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
            Byte[] MAC = new Byte[64];
            Byte[] EncryptedNodeSignaturePrivateKey = new Byte[PrivateKey.Length];
            Byte[] CipherTextWithMAC = new Byte[MAC.Length + EncryptedNodeSignaturePrivateKey.Length];
            Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
            TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
            EncryptedNodeSignaturePrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(PrivateKey, TempNonce, MasterEncryptionKey);
            MAC = SodiumHMACSHA512.ComputeMAC(EncryptedNodeSignaturePrivateKey, MasterMACKey);
            CipherTextWithMAC = MAC.Concat(EncryptedNodeSignaturePrivateKey).ToArray();
            EncryptedPrivateKeyWithMAC = CipherTextWithMAC;
            if (ClearKey == true) 
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
            SodiumSecureMemory.SecureClearBytes(MasterMACKey);
            SodiumSecureMemory.SecureClearBytes(MasterEncryptionKey);
            return EncryptedPrivateKeyWithMAC;
        }

        public static Byte[] DecryptNodeSignaturePrivateKey(Boolean ClearKey = false) 
        {
            Byte[] EncryptedPrivateKeyWithMAC = File.ReadAllBytes("<Path>");
            Byte[] MasterMACKey = new Byte[32];
            Byte[] MasterEncryptionKey = new Byte[32];
            Byte[] EncryptedPrivateKeyMAC = new Byte[64];
            Byte[] EncryptedPrivateKey = new Byte[EncryptedPrivateKeyWithMAC.Length - EncryptedPrivateKeyMAC.Length];
            Byte[] DecryptedPrivateKey = new Byte[EncryptedPrivateKey.Length];
            MasterMACKey = new Byte[32];
            MasterEncryptionKey = new Byte[32];
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterEncryptionKeyIntPtr);
            Marshal.Copy(TempMasterMACKeyIntPtr, MasterMACKey, 0, 32);
            Marshal.Copy(TempMasterEncryptionKeyIntPtr, MasterEncryptionKey, 0, 32);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
            Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
            TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
            Array.Copy(EncryptedPrivateKeyWithMAC, 0, EncryptedPrivateKeyMAC, 0, EncryptedPrivateKeyMAC.Length);
            Array.Copy(EncryptedPrivateKeyWithMAC, EncryptedPrivateKeyMAC.Length, EncryptedPrivateKey, 0, EncryptedPrivateKey.Length);
            Boolean AbleToVerify = SodiumHMACSHA512.VerifyMAC(EncryptedPrivateKeyMAC, EncryptedPrivateKey, MasterMACKey);
            if (AbleToVerify == true)
            {
                DecryptedPrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedPrivateKey, TempNonce, MasterEncryptionKey);
            }
            else
            {
                throw new Exception("Error: Unable to verify MAC on encrypted node signature private key");
            }
            if (ClearKey == true)
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
            SodiumSecureMemory.SecureClearBytes(MasterMACKey);
            SodiumSecureMemory.SecureClearBytes(MasterEncryptionKey);
            return DecryptedPrivateKey;
        }

        private static void ExportNodeSignaturePrivateKey(Boolean ClearKey=false) 
        {
            Byte[] DecryptedNodeSignaturePrivateKey = DecryptNodeSignaturePrivateKey();
            //Add public key here on StringB64..
            String X25519OrX448MACPublicKeyStringB64 = "";
            Byte[] X25519OrX448MACPublicKey = Convert.FromBase64String(X25519OrX448MACPublicKeyStringB64);
            String X25519OrX448EncryptionPublicKeyStringB64 = "";
            Byte[] X25519OrX448EncryptionPublicKey = Convert.FromBase64String(X25519OrX448EncryptionPublicKeyStringB64);
            Byte[] MACSharedSecret = new Byte[] { };
            Byte[] EncryptionSharedSecret = new Byte[] { };
            Byte[] ActualMACSharedSecret = new Byte[] { };
            Byte[] ActualEncryptionSharedSecret = new Byte[] { };
            Byte[] ServerEphemeralX25519OrX448PublicKeys = new Byte[] { };
            Byte[] TempNonce = new Byte[] { };
            Byte[] EncryptedNodeSignaturePrivateKey = new Byte[] { };
            Byte[] MACOfEncryptedNodeSignaturePrivateKey = new Byte[] { };
            Byte[] MACWithEncryptedNodeSignaturePrivateKey = new Byte[] { };
            Byte[] ActualEncryptedNodeSignaturePrivateKey = new Byte[] { };
            if(X25519OrX448MACPublicKey.Length==0 || X25519OrX448EncryptionPublicKey.Length == 0) 
            {
                throw new Exception("Error: Either one of the key exchange public keys was empty");
            }
            if(X25519OrX448MACPublicKey.Length != X25519OrX448EncryptionPublicKey.Length) 
            {
                throw new Exception("Error: Both key exchange public keys must have equal legnth");
            }
            if (X25519OrX448MACPublicKey.Length == 32) 
            {
                RevampedKeyPair ServerEphemeralX25519MACKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                RevampedKeyPair ServerEphemeralX25519EncryptionKeyPair = SodiumPublicKeyBox.GenerateRevampedKeyPair();
                MACSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(ServerEphemeralX25519MACKeyPair.PrivateKey, X25519OrX448MACPublicKey,true);
                EncryptionSharedSecret = SodiumPublicKeyBox.GenerateSharedSecret(ServerEphemeralX25519EncryptionKeyPair.PrivateKey, X25519OrX448EncryptionPublicKey, true);
                ServerEphemeralX25519OrX448PublicKeys = ServerEphemeralX25519MACKeyPair.PublicKey.Concat(ServerEphemeralX25519EncryptionKeyPair.PublicKey).ToArray();
                TempNonce = X25519OrX448MACPublicKey.Concat(X25519OrX448EncryptionPublicKey).Concat(ServerEphemeralX25519OrX448PublicKeys).ToArray();
                TempNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), TempNonce);
                EncryptedNodeSignaturePrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DecryptedNodeSignaturePrivateKey, TempNonce, EncryptionSharedSecret,true);
                MACOfEncryptedNodeSignaturePrivateKey = SodiumHMACSHA512.ComputeMAC(EncryptedNodeSignaturePrivateKey, MACSharedSecret,true);
                ServerEphemeralX25519MACKeyPair.Clear();
                ServerEphemeralX25519EncryptionKeyPair.Clear();
            }
            else 
            {
                X448RevampedKeyPair ServerEphemeralX448MACKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                X448RevampedKeyPair ServerEphemeralX448EncryptionKeyPair = SecureX448.GenerateX448RevampedKeyPair();
                MACSharedSecret = SecureX448.CalculateSecret(X25519OrX448MACPublicKey, ServerEphemeralX448MACKeyPair.PrivateKey, true);
                EncryptionSharedSecret = SecureX448.CalculateSecret(X25519OrX448EncryptionPublicKey, ServerEphemeralX448EncryptionKeyPair.PrivateKey, true);
                ActualMACSharedSecret = SodiumKDF.KDFFunction(32, 1, "MAC'sKDF", MACSharedSecret,true);
                ActualEncryptionSharedSecret = SodiumKDF.KDFFunction(32, 1, "ENC'sKDF", EncryptionSharedSecret,true);
                ServerEphemeralX25519OrX448PublicKeys = ServerEphemeralX448MACKeyPair.PublicKey.Concat(ServerEphemeralX448EncryptionKeyPair.PublicKey).ToArray();
                TempNonce = X25519OrX448MACPublicKey.Concat(X25519OrX448EncryptionPublicKey).Concat(ServerEphemeralX25519OrX448PublicKeys).ToArray();
                TempNonce = SodiumGenericHash.ComputeHash((Byte)SodiumStreamCipherXChaCha20.GetXChaCha20NonceBytesLength(), TempNonce);
                EncryptedNodeSignaturePrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(DecryptedNodeSignaturePrivateKey, TempNonce, ActualEncryptionSharedSecret, true);
                MACOfEncryptedNodeSignaturePrivateKey = SodiumHMACSHA512.ComputeMAC(EncryptedNodeSignaturePrivateKey, ActualMACSharedSecret, true);
                ServerEphemeralX448MACKeyPair.Clear();
                ServerEphemeralX448EncryptionKeyPair.Clear();
            }
            MACWithEncryptedNodeSignaturePrivateKey = MACOfEncryptedNodeSignaturePrivateKey.Concat(EncryptedNodeSignaturePrivateKey).ToArray();
            ActualEncryptedNodeSignaturePrivateKey = ServerEphemeralX25519OrX448PublicKeys.Concat(MACWithEncryptedNodeSignaturePrivateKey).ToArray();
            File.WriteAllBytes("<Path>", ActualEncryptedNodeSignaturePrivateKey);
            SodiumSecureMemory.SecureClearBytes(DecryptedNodeSignaturePrivateKey);
            if (ClearKey == true)
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
        }

        public static Byte[] DecryptUserSignaturePrivateKey(String PrivateKeyPath,Boolean ClearKey=false) 
        {
            Byte[] EncryptedUserPrivateKeyWithMAC = File.ReadAllBytes(PrivateKeyPath);
            Byte[] EncryptedUserPrivateKeyMAC = new Byte[64];
            Byte[] EncryptedUserPrivateKey = new Byte[EncryptedUserPrivateKeyWithMAC.Length - EncryptedUserPrivateKeyMAC.Length];
            Byte[] DecryptedUserPrivateKey = new Byte[EncryptedUserPrivateKey.Length];
            Byte[] MasterMACKey = new Byte[32];
            Byte[] MasterEncryptionKey = new Byte[32];
            MasterMACKey = new Byte[32];
            MasterEncryptionKey = new Byte[32];
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadOnly(TempMasterEncryptionKeyIntPtr);
            Marshal.Copy(TempMasterMACKeyIntPtr, MasterMACKey, 0, 32);
            Marshal.Copy(TempMasterEncryptionKeyIntPtr, MasterEncryptionKey, 0, 32);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_NoAccess(TempMasterEncryptionKeyIntPtr);
            Byte[] TempNonce = Nonce1.Concat(Nonce2).ToArray();
            TempNonce = SodiumGenericHash.ComputeHash((Byte)Nonce1.Length, TempNonce);
            Array.Copy(EncryptedUserPrivateKeyWithMAC, 0, EncryptedUserPrivateKeyMAC, 0, EncryptedUserPrivateKeyMAC.Length);
            Array.Copy(EncryptedUserPrivateKeyWithMAC, EncryptedUserPrivateKeyMAC.Length, EncryptedUserPrivateKey, 0, EncryptedUserPrivateKey.Length);
            Boolean AbleToVerify = SodiumHMACSHA512.VerifyMAC(EncryptedUserPrivateKeyMAC, EncryptedUserPrivateKey, MasterMACKey);
            if (AbleToVerify == true)
            {
                DecryptedUserPrivateKey = SodiumStreamCipherXChaCha20.XChaCha20Encrypt(EncryptedUserPrivateKey, TempNonce, MasterEncryptionKey);
            }
            else
            {
                throw new Exception("Error: Unable to verify MAC on encrypted node signature private key");
            }
            if (ClearKey == true)
            {
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
                SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
            }
            SodiumSecureMemory.SecureClearBytes(MasterMACKey);
            SodiumSecureMemory.SecureClearBytes(MasterEncryptionKey);
            return DecryptedUserPrivateKey;
        }

        public static void ClearKeys() 
        {
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_MProtect_ReadWrite(TempMasterEncryptionKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_Free(TempMasterMACKeyIntPtr);
            SodiumGuardedHeapAllocation.Sodium_Free(TempMasterEncryptionKeyIntPtr);
        }
    }
}
