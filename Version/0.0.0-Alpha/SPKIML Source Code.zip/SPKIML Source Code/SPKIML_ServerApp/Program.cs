using ASodium;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

builder.WebHost.ConfigureKestrel(serverOptions =>
{
    //Can change 1001 port to other ports
    serverOptions.Listen(System.Net.IPAddress.Parse("0.0.0.0"), 1001);
}
);

var app = builder.Build();

app.Lifetime.ApplicationStarted.Register(() =>
{
    SodiumInit.Init();
});

// Configure the HTTP request pipeline.

//app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
