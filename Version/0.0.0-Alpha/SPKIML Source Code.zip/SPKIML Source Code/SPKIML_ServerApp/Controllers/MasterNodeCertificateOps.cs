﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKIML_ServerApp.Helper;
using SPKIML_ServerApp.SimpleSoftHSM;
using SPKIML_ServerApp.DataModel;
using SPKIML_ServerApp.PostDataModel;
using System.Net.Http.Headers;
using System.Text;
using SPKIML_ServerApp.APIHelper;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterNodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public AuthorizedUserFullCertificateModel GiveTLCertificateToNodeUser(String User_ID)
        {
            AuthorizedUserFullCertificateModel MyModel = new AuthorizedUserFullCertificateModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String CurrentNodeIPAddress = "";
            int Count = 0;
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBPARNU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    MyModel.SignedDateTimes = new DateTime[Count];
                    MyModel.Signed_TNode_User_Auth_PKs = new String[Count];
                    MyModel.Signed_TNode_User_Sign_PKs = new String[Count];
                    MyModel.SNode_IP_Addresses = new String[Count];
                    MyModel.SNode_User_IDs = new String[Count];
                    MyModel.TNode_IP_Address = CurrentNodeIPAddress;
                    MyModel.TNode_User_ID = User_ID;
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users_SBPARNU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyDataReader = MySQLGeneralQuery.ExecuteReader();
                    while (MyDataReader.Read())
                    {
                        MyModel.SNode_IP_Addresses[Loop] = MyDataReader.GetString("PNode_IP_Address");
                        MyModel.SNode_User_IDs[Loop] = MyDataReader.GetString("PNode_User_ID");
                        MyModel.Signed_TNode_User_Auth_PKs[Loop] = MyDataReader.GetString("Signed_Auth_PK");
                        MyModel.Signed_TNode_User_Sign_PKs[Loop] = MyDataReader.GetString("Signed_Sign_PK");
                        MyModel.SignedDateTimes[Loop] = MyDataReader.GetDateTime("Valid_DT");
                        Loop += 1;
                    }
                    MyModel.Status = "Success: Full certificate for this node's authorized user had been retrieved";
                }
                else
                {
                    MyModel.Status = "Error: This user does not have any partial chain of trusts..";
                }
            }
            else
            {
                MyModel.Status = "Error: This specified user had not been registered";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }

        [HttpGet("UserHelper")]
        public String GetParentNodeAPIIPAddress(String IP_Address)
        {
            String API_IP_Address = "";
            String Final_API_IP_Address = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `PNode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetNodeAPIIPAddress");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    Final_API_IP_Address = Result;
                }
                else
                {
                    throw new Exception("Error: Parent Node encounter some issues");
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();

            return Final_API_IP_Address;
        }

        //TNodeIPAddress = Sub node
        //RNodeIPAddress = Parent Node
        [HttpPost]
        public String VerifyNodeUserCertificate(VerifyAuthorizedUserPartialCertificateModel NodeUserFullCert)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallenge = new Byte[] { };
            Byte[] Challenge = new Byte[] { };
            String SignedChallengeB64 = "";
            List<String> API_IP_Addresses = new List<String>();
            String ResultString = "";
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUserFullCert.TNode_User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                //==
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ASPK_Valid_DT` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUserFullCert.TNode_User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                if (MyTimeSpan.TotalDays < 32)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBPARNU_Log` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUserFullCert.TNode_User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count > 0)
                    {
                        while (Loop < NodeUserFullCert.SNode_User_IDs.Length)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBPARNU_Log` WHERE `PNode_User_ID`=@PNode_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK AND `Valid_DT`=@Valid_DT";
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUserFullCert.TNode_User_ID;
                            MySQLGeneralQuery.Parameters.Add("@PNode_User_ID", MySqlDbType.Text).Value = NodeUserFullCert.SNode_User_IDs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = NodeUserFullCert.Signed_TNode_User_Auth_PKs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = NodeUserFullCert.Signed_TNode_User_Sign_PKs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = NodeUserFullCert.SignedDateTimes[Loop];
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 0)
                            {
                                ResultString = "Error: Unable to find signature record for this node user";
                                break;
                            }
                            Loop += 1;
                        }
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        myMyOwnMySQLConnection.ClearConnectionString();
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        //..
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `PNode_Information` WHERE `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = NodeUserFullCert.RNode_IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DataReader = MySQLGeneralQuery.ExecuteReader();
                        while (DataReader.Read())
                        {
                            API_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                        }
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        myMyOwnMySQLConnection.ClearConnectionString();
                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                        CCOperations.InitializeOperations();
                        Byte[] DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                        CCOperations.ClearKeys();
                        Challenge = GetSNodeChallenge.GetChallenge(API_IP_Addresses[0]);
                        if (DecryptedNodePrivateKey.Length == 64)
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKey, true);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SignedChallengeB64 = Convert.ToBase64String(SignedChallenge);
                        NodeUserFullCert.SignedChallenge = SignedChallengeB64;
                        String JSONBodyString = "";
                        StringContent PostRequestData = new StringContent("");
                        JSONBodyString = JsonConvert.SerializeObject(NodeUserFullCert);
                        PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                        using (var client = new HttpClient())
                        {
                            client.BaseAddress = new Uri(API_IP_Addresses[0]);
                            client.DefaultRequestHeaders.Accept.Clear();
                            client.DefaultRequestHeaders.Accept.Add(
                                new MediaTypeWithQualityHeaderValue("application/json"));
                            var response = client.PostAsync("SNodeCertificateOps", PostRequestData);
                            response.Wait();
                            var result = response.Result;
                            if (result.IsSuccessStatusCode)
                            {
                                var readTask = result.Content.ReadAsStringAsync();
                                readTask.Wait();

                                var Result = readTask.Result;

                                if (Result.Contains("Error") == true)
                                {
                                    ResultString = Result;
                                }
                            }
                            else
                            {
                                ResultString = "Error: Parent Node encounter some issues";
                            }
                        }
                        if (ResultString.CompareTo("") == 0)
                        {
                            ResultString = "Success: This certificate from this node user is trusted/verified";
                        }
                    }
                    else
                    {
                        ResultString = "Error: This user does not have any signed records..";
                    }
                }
                else
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = NodeUserFullCert.TNode_IP_Address;
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUserFullCert.TNode_User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    ResultString = "Error: This node user's public keys had expired.. deleting this user..";
                }
                //==
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("PNodeUserGetSignatureRecords")]
        public AuthorizedUserSignedRecordsModel GetSignatureRecords(String User_ID, String SignedChallenge)
        {
            AuthorizedUserSignedRecordsModel MyModel = new AuthorizedUserSignedRecordsModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String CurrentNodeIPAddress = "";
            List<String> SNode_User_IDs = new List<String>();
            List<String> Signed_Auth_PKs = new List<String>();
            List<String> Signed_Sign_PKs = new List<String>();
            List<String> TNode_IP_Addresses = new List<String>();
            List<String> TNode_User_IDs = new List<String>();
            List<String> TNodeUsers_Signed_Auth_PKs = new List<String>();
            List<String> TNodeUsers_Signed_Sign_PKs = new List<String>();
            List<DateTime> Signed_Dates = new List<DateTime>();
            Byte[] Signed_Auth_PKBytes = new Byte[] { };
            Byte[] Signed_Sign_PKBytes = new Byte[] { };
            Byte[] Auth_PKBytes = new Byte[] { };
            Byte[] Sign_PKBytes = new Byte[] { };
            String User_DSA_PK = "";
            Byte[] User_DSA_PKBytes = new Byte[] { };
            Boolean IsAllEndUsersPublicKeyAbleToVerify = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    //Need to verify locally on all the authorized user's signed public key records by other nodes
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT * FROM `EU_SBNU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DataReader = MySQLGeneralQuery.ExecuteReader();
                    while (DataReader.Read())
                    {
                        SNode_User_IDs.Add(DataReader.GetString("End_User_ID"));
                        Signed_Auth_PKs.Add(DataReader.GetString("Signed_Auth_PK"));
                        Signed_Sign_PKs.Add(DataReader.GetString("Signed_Sign_PK"));
                    }
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Sign_PK` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    User_DSA_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                    User_DSA_PKBytes = Convert.FromBase64String(User_DSA_PK);
                    while (Loop < SNode_User_IDs.Count)
                    {
                        Signed_Auth_PKBytes = Convert.FromBase64String(Signed_Auth_PKs[Loop]);
                        Signed_Sign_PKBytes = Convert.FromBase64String(Signed_Sign_PKs[Loop]);
                        try
                        {
                            if (User_DSA_PKBytes.Length == 32)
                            {
                                Auth_PKBytes = SodiumPublicKeyAuth.Verify(Signed_Auth_PKBytes, User_DSA_PKBytes);
                                Sign_PKBytes = SodiumPublicKeyAuth.Verify(Signed_Sign_PKBytes, User_DSA_PKBytes);
                            }
                            else
                            {
                                Auth_PKBytes = SecureED448.GetMessageFromSignatureMessage(User_DSA_PKBytes, Signed_Auth_PKBytes, new Byte[] { });
                                Sign_PKBytes = SecureED448.GetMessageFromSignatureMessage(User_DSA_PKBytes, Signed_Sign_PKBytes, new Byte[] { });
                            }
                        }
                        catch
                        {
                            IsAllEndUsersPublicKeyAbleToVerify = false;
                            break;
                        }
                        Loop += 1;
                    }
                    if (IsAllEndUsersPublicKeyAbleToVerify == true)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Auth_PK` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        User_DSA_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                        Auth_PKBytes = Convert.FromBase64String(User_DSA_PK);
                        SignedChallengeBytes = Convert.FromBase64String(SignedChallenge); //Here .. switch to node user's authentication pk..
                        if (Auth_PKBytes.Length == 32)
                        {
                            ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, Auth_PKBytes);
                        }
                        else
                        {
                            ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(Auth_PKBytes, SignedChallengeBytes, new Byte[] { });
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count == 1)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `Node_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                            if (MyTimeSpan.TotalMinutes < 8)
                            {
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT * FROM `EU_SBNU_Log` WHERE `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DataReader = MySQLGeneralQuery.ExecuteReader();
                                while (DataReader.Read())
                                {
                                    TNode_User_IDs.Add(DataReader.GetString("End_User_ID"));
                                    TNodeUsers_Signed_Auth_PKs.Add(DataReader.GetString("Signed_Auth_PK"));
                                    TNodeUsers_Signed_Sign_PKs.Add(DataReader.GetString("Signed_Sign_PK"));
                                    Signed_Dates.Add(DataReader.GetDateTime("Valid_DT"));
                                }
                                MyModel.Status = "Success: Successfully retrieved signed records";
                                MyModel.TNode_IP_Addresses = new String[] { };
                                MyModel.TNode_User_IDs = TNode_User_IDs.ToArray();
                                MyModel.Signed_Auth_PKs = TNodeUsers_Signed_Auth_PKs.ToArray();
                                MyModel.Signed_Sign_PKs = TNodeUsers_Signed_Sign_PKs.ToArray();
                                MyModel.Signed_Dates = Signed_Dates.ToArray();
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                            }
                            else
                            {
                                MyModel.Status = "Error: This challenge had expired.. unable to fetch signed records..";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            MyModel.Status = "Error: This challenge doesn't exist";
                        }
                    }
                    else
                    {
                        MyModel.Status = "Error: Some of current node users' public keys unable to verify signed records";
                    }
                }
                else
                {
                    MyModel.Status = "Error: Node user doesn't have any signed records..";
                }
            }
            else
            {
                MyModel.Status = "Error: Node user doesn't sign any other end users' public keys";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }
    }
}
