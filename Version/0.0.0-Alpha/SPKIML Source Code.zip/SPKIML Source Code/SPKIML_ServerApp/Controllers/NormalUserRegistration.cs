﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp.Helper;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NormalUserRegistration : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String RegisterEndUser(String User_ID,String Auth_PK, String Sign_PK, String Valid_DTString, String Contact = "",String OOB_PK="")
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String SNode_API_IP_Address = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "INSERT INTO `End_Users`(`User_ID`, `Contact`,`Auth_PK`, `Sign_PK`, `OOB_PK` ,`ASPK_Valid_DT`) VALUES (@User_ID,@Contact,@Auth_PK,@Sign_PK,@OOB_PK,@ASPK_Valid_DT)";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Parameters.Add("@Contact", MySqlDbType.Text).Value = Contact;
                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Sign_PK;
                MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = OOB_PK;
                MySQLGeneralQuery.Parameters.Add("@ASPK_Valid_DT", MySqlDbType.DateTime).Value = DateTime.Parse(Valid_DTString);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                ResultString = "Success: End user had been added..";
            }
            else
            {
                ResultString = "Error: End user existed aborting insertion..";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("UpdateEndUserInfo")]
        public String UpdateEndUser(String User_ID, String SignedChallenge, String Auth_PK, String Sign_PK, String Valid_DTString,String OOB_PK="",String Contact="")
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String EU_Old_Auth_PK = "";
            Byte[] EU_Old_Auth_PK_Bytes = new Byte[] { };
            String EU_Old_Sign_PK = "";
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            DateTime OldValidDT = new DateTime();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                //In future need to verify locally with the signed records from authorized users of this node..
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Auth_PK` FROM `End_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                EU_Old_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Sign_PK` FROM `End_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                EU_Old_Sign_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                EU_Old_Auth_PK_Bytes = Convert.FromBase64String(EU_Old_Auth_PK);
                SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                if (EU_Old_Auth_PK_Bytes.Length == 32)
                {
                    ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, EU_Old_Auth_PK_Bytes);
                }
                else
                {
                    ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(EU_Old_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                    if (MyTimeSpan.TotalMinutes < 8)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                        MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count > 0)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "UPDATE `End_Users` SET `Contact`=@Contact,`OOB_PK`=@OOB_PK WHERE `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Parameters.Add("@Contact", MySqlDbType.Text).Value = Contact;
                            MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = OOB_PK;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            ResultString = "Success: Some of this end user's info had been updated..";
                        }
                        else
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `ASPK_Valid_DT` FROM `End_Users` WHERE `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            OldValidDT = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "INSERT INTO `EU_PKs_Log`(`End_User_ID`, `Auth_PK`, `Sign_PK`, `Change_Date`) VALUES (@End_User_ID,@Auth_PK,@Sign_PK,@Change_Date)";
                            MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = EU_Old_Auth_PK;
                            MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = EU_Old_Sign_PK;
                            MySQLGeneralQuery.Parameters.Add("@Change_Date", MySqlDbType.DateTime).Value = OldValidDT;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "UPDATE `End_Users` SET `Auth_PK`=@Auth_PK,`Contact`=@Contact,`Sign_PK`=@Sign_PK,`OOB_PK`=@OOB_PK,`ASPK_Valid_DT`=@ASPK_Valid_DT WHERE `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Parameters.Add("@Contact", MySqlDbType.Text).Value = Contact;
                            MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                            MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Sign_PK;
                            MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = OOB_PK;
                            MySQLGeneralQuery.Parameters.Add("@ASPK_Valid_DT", MySqlDbType.DateTime).Value = DateTime.Parse(Valid_DTString);
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                            ResultString = "Success: All of this end user's info had been updated..";
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge had expired.. deleting now..";
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `EU_Challenge` WHERE `Challenge`=@Challenge AND `End_User_ID`=@End_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                    }
                }
                else
                {
                    ResultString = "Error: This verified challenge no longer exists..";
                }
            }
            else
            {
                ResultString = "Error: This end user does not exist";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}
