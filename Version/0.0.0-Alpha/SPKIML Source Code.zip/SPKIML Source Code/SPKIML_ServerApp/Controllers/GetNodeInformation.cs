﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp.Helper;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetNodeInformation : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String GetInfo()
        {
            String ResultString = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String IP_Address = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            //Add your own contact here
            String NodeOperator_Contact = "";
            String NodeOperator_OOB_Auth_PK = "";
            String NodeOperator_AuthorizedUsers_CommunicationChannel = "";
            ResultString = IP_Address + "," + NodeOperator_Contact + "," + NodeOperator_OOB_Auth_PK + "," + NodeOperator_AuthorizedUsers_CommunicationChannel;
            return ResultString;
        }
    }
}
