﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKIML_ServerApp.APIHelper;
using SPKIML_ServerApp.DataModel;
using SPKIML_ServerApp.Helper;
using SPKIML_ServerApp.PostDataModel;
using SPKIML_ServerApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Text;

namespace SPKIML_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public AuthorizedUserFullCertificateModel GiveTLCertificateToNodeUser(String User_ID)
        {
            AuthorizedUserFullCertificateModel MyModel = new AuthorizedUserFullCertificateModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String CurrentNodeIPAddress = "";
            int Count = 0;
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    MyModel.SignedDateTimes = new DateTime[Count];
                    MyModel.Signed_TNode_User_Auth_PKs = new String[Count];
                    MyModel.Signed_TNode_User_Sign_PKs = new String[Count];
                    MyModel.SNode_User_IDs = new String[Count];
                    MyModel.TNode_IP_Address = CurrentNodeIPAddress;
                    MyModel.TNode_User_ID = User_ID;
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT * FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                    MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyDataReader = MySQLGeneralQuery.ExecuteReader();
                    while (MyDataReader.Read())
                    {
                        MyModel.SNode_User_IDs[Loop] = MyDataReader.GetString("User_ID");
                        MyModel.Signed_TNode_User_Auth_PKs[Loop] = MyDataReader.GetString("Signed_Auth_PK");
                        MyModel.Signed_TNode_User_Sign_PKs[Loop] = MyDataReader.GetString("Signed_Sign_PK");
                        MyModel.SignedDateTimes[Loop] = MyDataReader.GetDateTime("Valid_DT");
                        Loop += 1;
                    }
                    MyModel.Status = "Success: Full certificate for this end user had been retrieved";
                }
                else
                {
                    MyModel.Status = "Error: This end user does not have any partial chain of trusts..";
                }
            }
            else
            {
                MyModel.Status = "Error: This specified end user had not been registered";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }

        [HttpPost]
        public String VerifyEndUserCertificate(VerifyAuthorizedUserPartialCertificateModel EndUserFullCert)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallenge = new Byte[] { };
            Byte[] Challenge = new Byte[] { };
            String SignedChallengeB64 = "";
            List<String> API_IP_Addresses = new List<String>();
            String ResultString = "";
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `End_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = EndUserFullCert.TNode_User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ASPK_Valid_DT` FROM `End_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = EndUserFullCert.TNode_User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                if (MyTimeSpan.TotalDays < 32)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID";
                    MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUserFullCert.TNode_User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count > 0)
                    {
                        while (Loop < EndUserFullCert.SNode_User_IDs.Length)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `EU_SBNU_Log` WHERE `User_ID`=@User_ID AND `End_User_ID`=@End_User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK AND `Valid_DT`=@Valid_DT";
                            MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUserFullCert.TNode_User_ID;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = EndUserFullCert.SNode_User_IDs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = EndUserFullCert.Signed_TNode_User_Auth_PKs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = EndUserFullCert.Signed_TNode_User_Sign_PKs[Loop];
                            MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = EndUserFullCert.SignedDateTimes[Loop];
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 0)
                            {
                                ResultString = "Error: Unable to find signature record for this end user";
                                break;
                            }
                            Loop += 1;
                        }
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        myMyOwnMySQLConnection.ClearConnectionString();
                        if (ResultString.CompareTo("") == 0)
                        {
                            ResultString = "Success: This certificate from this end user is trusted/verified";
                        }
                    }
                    else
                    {
                        ResultString = "Error: This end user does not have any signed records..";
                    }
                }
                else
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `End_Users` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = EndUserFullCert.TNode_User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    ResultString = "Error: This end user's public keys had expired.. deleting this end user..";
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                }
            }
            else
            {
                ResultString = "Error: This end user don't exist in this node";
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
            }
            return ResultString;
        }
    }
}
