-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 27, 2025 at 03:06 AM
-- Server version: 8.0.42-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SPKIMLDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `End_Users`
--

CREATE TABLE `End_Users` (
  `User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Contact` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `OOB_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `ASPK_Valid_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `EU_Challenge`
--

CREATE TABLE `EU_Challenge` (
  `End_User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `EU_PKs_Log`
--

CREATE TABLE `EU_PKs_Log` (
  `End_User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Change_Date` datetime DEFAULT NULL,
  `EUPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `EU_SBNU_Log`
--

CREATE TABLE `EU_SBNU_Log` (
  `User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `End_User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL,
  `EUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Challenge`
--

CREATE TABLE `Node_Challenge` (
  `User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Information`
--

CREATE TABLE `Node_Information` (
  `IP_Address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Node_Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Node_Info_Register_DT` datetime DEFAULT NULL,
  `Node_Info_Update_DT` datetime DEFAULT NULL,
  `PK_Update_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_PK_Log`
--

CREATE TABLE `Node_PK_Log` (
  `Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Add_DT` datetime DEFAULT NULL,
  `NPKL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users`
--

CREATE TABLE `Node_Users` (
  `User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Contact` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `OOB_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `ASPK_Valid_DT` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users_PKs_Log`
--

CREATE TABLE `Node_Users_PKs_Log` (
  `User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Change_Date` datetime DEFAULT NULL,
  `NUPKL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users_SBPARNU_Log`
--

CREATE TABLE `Node_Users_SBPARNU_Log` (
  `PNode_IP_Address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `PNode_User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL,
  `NUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PNode_Information`
--

CREATE TABLE `PNode_Information` (
  `IP_Address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `End_Users`
--
ALTER TABLE `End_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `EU_Challenge`
--
ALTER TABLE `EU_Challenge`
  ADD PRIMARY KEY (`End_User_ID`);

--
-- Indexes for table `EU_PKS_Log`
--
ALTER TABLE `EU_PKS_Log`
  ADD PRIMARY KEY (`EUPL_ID`);

--
-- Indexes for table `EU_SBNU_Log`
--
ALTER TABLE `EU_SBNU_Log`
  ADD PRIMARY KEY (`EUSL_ID`);

--
-- Indexes for table `Node_Challenge`
--
ALTER TABLE `Node_Challenge`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Information`
--
ALTER TABLE `Node_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `Node_PK_Log`
--
ALTER TABLE `Node_PK_Log`
  ADD PRIMARY KEY (`NPKL_ID`);

--
-- Indexes for table `Node_Users`
--
ALTER TABLE `Node_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Users_PKs_Log`
--
ALTER TABLE `Node_Users_PKs_Log`
  ADD PRIMARY KEY (`NUPKL_ID`);

--
-- Indexes for table `Node_Users_SBPARNU_Log`
--
ALTER TABLE `Node_Users_SBPARNU_Log`
  ADD PRIMARY KEY (`NUSL_ID`);

--
-- Indexes for table `PNode_Information`
--
ALTER TABLE `PNode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `EU_PKS_Log`
--
ALTER TABLE `EU_PKS_Log`
  MODIFY `EUPL_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `EU_SBNU_Log`
--
ALTER TABLE `EU_SBNU_Log`
  MODIFY `EUSL_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Node_PK_Log`
--
ALTER TABLE `Node_PK_Log`
  MODIFY `NPKL_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Node_Users_PKs_Log`
--
ALTER TABLE `Node_Users_PKs_Log`
  MODIFY `NUPKL_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Node_Users_SBPARNU_Log`
--
ALTER TABLE `Node_Users_SBPARNU_Log`
  MODIFY `NUSL_ID` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
