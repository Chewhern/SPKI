﻿using SPKIML_ServerApp_CApp.Helper;
using MySql.Data.MySqlClient;

namespace SPKIML_ServerApp_CApp.UtilityHelper
{
    public static class UpdateLocalNodeAuthPK
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void UpdateNodeAuthPK(String NewAuthPK) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String LastPKB64 = "";
            DateTime LastPKUpdateDT = new DateTime();
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(30);
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `PK_Update_DT` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            LastPKUpdateDT = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `Node_Auth_PK` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            LastPKB64 = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "INSERT INTO `Node_PK_Log`(`Auth_PK`, `Add_DT`) VALUES (@Auth_PK,@Add_DT)";
            MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = LastPKB64;
            MySQLGeneralQuery.Parameters.Add("@Add_DT", MySqlDbType.DateTime).Value = LastPKUpdateDT;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MySQLGeneralQuery.ExecuteNonQuery();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "UPDATE `Node_Information` SET `Node_Auth_PK`=@Node_Auth_PK,`PK_Update_DT`=@PK_Update_DT";
            MySQLGeneralQuery.Parameters.Add("@Node_Auth_PK", MySqlDbType.Text).Value = NewAuthPK;
            MySQLGeneralQuery.Parameters.Add("@PK_Update_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MySQLGeneralQuery.ExecuteNonQuery();
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
