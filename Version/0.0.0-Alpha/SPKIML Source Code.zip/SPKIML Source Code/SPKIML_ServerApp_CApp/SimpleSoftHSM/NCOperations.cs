﻿using ASodium;
using BCASodium;

namespace SPKIML_ServerApp_CApp.SimpleSoftHSM
{
    public static class NCOperations
    {
        public static String[] GetEncryptedUserPrivateKeysPath() 
        {
            return Directory.GetFiles("<Path>");
        }
    }
}
