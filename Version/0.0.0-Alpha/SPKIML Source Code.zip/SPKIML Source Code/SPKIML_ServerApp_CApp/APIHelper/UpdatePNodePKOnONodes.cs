﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.UtilityHelper;

namespace SPKIML_ServerApp_CApp.APIHelper
{
    public static class UpdatePNodePKOnONodes
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void NodeUpdatePKsOnParentNodes(String New_Auth_PK) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyReader;
            String ExceptionString = "";
            String PNode_API_IP_Address = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `PNode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read()) 
            {
                PNode_API_IP_Address = MyReader.GetString("API_IP_Address");
                SingleONodePKUpdate.UpdateParentNodePKOnOneONode(PNode_API_IP_Address,New_Auth_PK);
                PNode_API_IP_Address = "";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            UpdateLocalNodeAuthPK.UpdateNodeAuthPK(New_Auth_PK);
        }
    }
}
