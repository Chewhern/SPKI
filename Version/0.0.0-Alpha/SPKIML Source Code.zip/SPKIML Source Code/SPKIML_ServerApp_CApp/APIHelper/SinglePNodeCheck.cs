﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKIML_ServerApp_CApp.APIHelper
{
    public static class SinglePNodeCheck
    {
        public static int CheckParentNodeExistence(String PNode_API_IP_Address,String IP_Address) 
        {
            int Count = 0;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(PNode_API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("SNode_Registration/CheckNodeExistence?IP_Address=" + HttpUtility.UrlEncode(IP_Address));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    if (Result.Contains("Error") == true)
                    {
                        throw new Exception("Error:" + Result.Substring(1, Result.Length - 2));
                    }
                    else 
                    {
                        Count = int.Parse(Result.Substring(1, Result.Length - 2));
                    }
                }
                else
                {
                    Console.WriteLine("Error: Parent Node encounter some issues");
                }
            }
            return Count;
        }
    }
}
