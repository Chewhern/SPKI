﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.UtilityHelper;

namespace SPKIML_ServerApp_CApp.APIHelper
{
    public static class CurrentNodeVerifyPCOTs
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void VerifyPCOTsForAllNodeUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            List<String> Node_User_IDs = new List<String>();
            List<String> PNode_IPs = new List<String>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `PNode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read())
            {
                PNode_IPs.Add(MyDataReader.GetString("IP_Address"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `Node_Users`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read())
            {
                Node_User_IDs.Add(MyDataReader.GetString("User_ID"));
            }
            int Loop1 = 0;
            int Loop2 = 0;
            while (Loop1 < PNode_IPs.Count)
            {
                while (Loop2 < Node_User_IDs.Count)
                {
                    VerifySinglePNUserPCOT.VerifyPCOTForSinglePNUser(PNode_IPs[Loop1], Node_User_IDs[Loop2]);
                    Loop2 += 1;
                }
                Loop2 = 0;
                Loop1 += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
