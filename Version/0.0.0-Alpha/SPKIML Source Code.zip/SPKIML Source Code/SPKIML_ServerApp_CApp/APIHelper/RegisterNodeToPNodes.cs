﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.LocalAPISubHelper;

namespace SPKIML_ServerApp_CApp.APIHelper
{
    public static class RegisterNodeToPNodes
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void RegisteringCurrentNode() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyReader;
            String ExceptionString = "";
            List<String> PNode_API_IP_Addresses_List = new List<String>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `PNode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                PNode_API_IP_Addresses_List.Add(MyReader.GetString("API_IP_Address"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            if (File.Exists("<Path>")==true) 
            {
                String[] PNode_API_IP_Addresses = File.ReadAllLines("<Path>");
                int Loop = 0;
                if (PNode_API_IP_Addresses.Length > 0)
                {
                    while (Loop < PNode_API_IP_Addresses.Length)
                    {
                        SinglePNodeRegistration.RegisterNodeInformationOnSPNode(PNode_API_IP_Addresses[Loop]);
                        Loop += 1;
                    }
                    File.WriteAllText("<Path>","");
                }
                else
                {
                    while (Loop < PNode_API_IP_Addresses_List.Count)
                    {
                        SinglePNodeRegistration.RegisterNodeInformationOnSPNode(PNode_API_IP_Addresses_List[Loop]);
                        Loop += 1;
                    }
                }
            }
        }
    }
}
