﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using System.Net.Http.Headers;
using System.Web;

namespace SPKIML_ServerApp_CApp.APIHelper
{
    public class GetSNodeChallenge
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static Byte[] GetChallenge(String Parent_Node_API_IP_Address) 
        {
            Byte[] Challenge = new Byte[] { };
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                IP_Address = MyReader.GetString("IP_Address");
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Parent_Node_API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("SNChallengeRequestor?IP_Address=" + HttpUtility.UrlEncode(IP_Address));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    if (Result.Contains("Error") == true)
                    {
                        throw new Exception("Error:" + Result);
                    }
                    else
                    {
                        Challenge = Convert.FromBase64String(Result);
                    }
                }
                else
                {
                    throw new Exception("Error: Other Node encounter some issues");
                }
            }

            return Challenge;
        }
    }
}
