﻿using ASodium;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.APIHelper;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.LocalAPIHelper;
using SPKIML_ServerApp_CApp.SimpleSoftHSM;

namespace SPKIML_ServerApp_CApp.StartupHelper
{
    public static class InitializationHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        private static Boolean HasBeenFirstInitialized = true;
        private static Boolean HasBeenSecondInitialized = true;
        private static Boolean HasBeenThirdInitialized = true;

        private static void InitialCheck() 
        {
            if (Directory.Exists("<Path>") == false) 
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
            if (Directory.Exists("<Path>") == false) 
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
            if (Directory.Exists("<Path>") == false) 
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
            if (Directory.Exists("<Path>") == false) 
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
            if (Directory.Exists("<Path>") == false) 
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
            if (Directory.Exists("<Path>") == false)
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
            if (Directory.Exists("<Path>") == false)
            {
                Directory.CreateDirectory("<Path>");
                HasBeenFirstInitialized = false;
            }
        }

        private static void IntermediateCheck() 
        {
            if(HasBeenFirstInitialized == true) 
            {
                if (File.Exists("<Path>") == false)
                {
                    HasBeenSecondInitialized = false;
                }
                if (File.Exists("<Path>") == false)
                {
                    HasBeenSecondInitialized = false;
                }
                if (File.Exists("<Path>") == false)
                {
                    HasBeenSecondInitialized = false;
                }
            }
        }

        private static void FinalCheck() 
        {
            if(HasBeenFirstInitialized==true && HasBeenSecondInitialized == true) 
            {
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                MySqlDataReader MyReader;
                String ExceptionString = "";
                int Count = 0;
                String IP_Address = "";
                String API_IP_Address = "";
                String Node_Auth_PK = "";
                DateTime PK_Update_DT = new DateTime();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Information`";
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 0) 
                {
                    HasBeenThirdInitialized = false;
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                if (Count == 1) 
                {
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyReader = MySQLGeneralQuery.ExecuteReader();
                    while (MyReader.Read())
                    {
                        IP_Address = MyReader.GetString("IP_Address");
                        API_IP_Address = MyReader.GetString("API_IP_Address");
                        Node_Auth_PK = MyReader.GetString("Node_Auth_PK");
                        PK_Update_DT = MyReader.GetDateTime("PK_Update_DT");
                    }
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    if (IP_Address == null) 
                    {
                        HasBeenThirdInitialized = false;
                    }
                    else 
                    {
                        if (IP_Address.CompareTo("") == 0) 
                        {
                            HasBeenThirdInitialized = false;
                        }
                    }
                    if(API_IP_Address == null) 
                    {
                        HasBeenThirdInitialized = false;
                    }
                    else 
                    {
                        if (API_IP_Address.CompareTo("") == 0)
                        {
                            HasBeenThirdInitialized = false;
                        }
                    }
                    if(Node_Auth_PK == null) 
                    {
                        HasBeenThirdInitialized = false;
                    }
                    else 
                    {
                        if (Node_Auth_PK.CompareTo("") == 0)
                        {
                            HasBeenThirdInitialized = false;
                        }
                    }
                    if(PK_Update_DT.CompareTo(DateTime.MinValue) == 0) 
                    {
                        HasBeenThirdInitialized = false;
                    }
                }
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users`";
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 0) 
                {
                    HasBeenThirdInitialized = false;
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
            }
            else 
            {
                HasBeenThirdInitialized = false;
            }
        }

        private static void InitializeNodeInformationOrUpdateNodePK() 
        {
            if(HasBeenFirstInitialized == true && HasBeenSecondInitialized == true && HasBeenThirdInitialized== true) 
            {
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                String ExceptionString = "";
                MySqlDataReader MyReader;
                String Auth_PK = "";
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MyReader = MySQLGeneralQuery.ExecuteReader();
                while (MyReader.Read())
                {
                    Auth_PK = MyReader.GetString("Node_Auth_PK");
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                RegisterNodeToPNodes.RegisteringCurrentNode();
            }
        }

        private static void RegisterAndUpdateNodeUsers() 
        {
            if (HasBeenFirstInitialized == true && HasBeenSecondInitialized == true && HasBeenThirdInitialized == true)
            {
                NodeRegisterUsersToPNodesHelper.RegisterNodeUsersToONodes();
                NodeUpdateUsersOnPNodesHelper.UpdateNodeUsersToParentNodes();
            }
        }

        private static void InitializeSimpleSoftHSM() 
        {
            if (HasBeenFirstInitialized == true && HasBeenSecondInitialized == true && HasBeenThirdInitialized == true)
            {
                CCOperations.InitializeOperations();
            }
        }

        public static void Initialize() 
        {
            InitialCheck();
            IntermediateCheck();
            FinalCheck();
            InitializeSimpleSoftHSM();
            InitializeNodeInformationOrUpdateNodePK();
            RegisterAndUpdateNodeUsers();
        }

        public static Boolean IsAllInitialized() 
        {
            return (HasBeenFirstInitialized == true && HasBeenSecondInitialized == true && HasBeenThirdInitialized == true);
        }
    }
}
