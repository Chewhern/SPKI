﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.LocalAPISubHelper;

namespace SPKIML_ServerApp_CApp.LocalAPIHelper
{
    public static class NodeUpdateUsersOnPNodesHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void UpdateNodeUsersToParentNodes()
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            List<String> API_IP_Addresses = new List<String>();
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `PNode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                API_IP_Addresses.Add(MyReader.GetString("API_IP_Address"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            while (Loop < API_IP_Addresses.Count)
            {
                NodeUpdateUsersOnPNodeHelper.UpdateNodeUsersOnPNode(API_IP_Addresses[Loop]);
                Loop += 1;
            }
        }
    }
}
