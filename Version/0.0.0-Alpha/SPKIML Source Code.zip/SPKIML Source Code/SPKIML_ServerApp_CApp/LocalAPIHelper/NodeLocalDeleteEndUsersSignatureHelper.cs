﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;

namespace SPKIML_ServerApp_CApp.LocalAPIHelper
{
    public static class NodeLocalDeleteEndUsersSignatureHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void DeleteEndUsersSignature() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            List<String> EndUsersIDsToBeDeleted = new List<String>();
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `End_Users` WHERE TIMESTAMPDIFF(DAY, `ASPK_Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) >= 32";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read())
            {
                EndUsersIDsToBeDeleted.Add(DataReader.GetString("User_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            while (Loop < EndUsersIDsToBeDeleted.Count)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `EU_SBNU_Log` WHERE `End_User_ID`=@End_User_ID";
                MySQLGeneralQuery.Parameters.Add("@End_User_ID", MySqlDbType.Text).Value = EndUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                Loop += 1;
            }
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "DELETE FROM `EU_SBNU_Log` WHERE TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) >= 31";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MySQLGeneralQuery.ExecuteNonQuery();
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
