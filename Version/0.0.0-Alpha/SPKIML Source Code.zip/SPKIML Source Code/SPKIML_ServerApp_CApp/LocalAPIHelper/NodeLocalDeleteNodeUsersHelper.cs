﻿using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.SimpleSoftHSM;

namespace SPKIML_ServerApp_CApp.LocalAPIHelper
{
    public static class NodeLocalDeleteNodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void DeleteNodeUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            String[] EncryptedNodeUsersSignaturePrivateKeyPath = NCOperations.GetEncryptedUserPrivateKeysPath();
            List<String> NodeUsersIDsToBeDeleted = new List<String>();
            int Loop = 0;
            int Loop2 = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users` WHERE TIMESTAMPDIFF(DAY, `ASPK_Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) >= 32";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read()) 
            {
                NodeUsersIDsToBeDeleted.Add(DataReader.GetString("User_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            while (Loop < EncryptedNodeUsersSignaturePrivateKeyPath.Length) 
            {
                while (Loop2 < NodeUsersIDsToBeDeleted.Count) 
                {
                    if (EncryptedNodeUsersSignaturePrivateKeyPath[Loop].Contains(NodeUsersIDsToBeDeleted[Loop2]) == true) 
                    {
                        File.Delete(EncryptedNodeUsersSignaturePrivateKeyPath[Loop]);
                    }
                    Loop2 += 1;
                }
                Loop2 = 0;
                Loop += 1;
            }
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            Loop2 = 0;
            while (Loop2 < NodeUsersIDsToBeDeleted.Count) 
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDsToBeDeleted[Loop2];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Users_PKs_Log` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                Loop2 += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
