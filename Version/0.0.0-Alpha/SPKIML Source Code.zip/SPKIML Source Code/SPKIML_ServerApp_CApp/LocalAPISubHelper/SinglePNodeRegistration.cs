﻿
using ASodium;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKIML_ServerApp_CApp.APIHelper;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.UtilityHelper;
using System.Net.Http.Headers;
using System.Web;

namespace SPKIML_ServerApp_CApp.LocalAPISubHelper
{
    public static class SinglePNodeRegistration
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void RegisterNodeInformationOnSPNode(String PNode_API_IP_Address)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            String API_IP_Address = "";
            String Auth_PK = "";
            DateTime PKLWDT = new DateTime();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                IP_Address = MyReader.GetString("IP_Address");
                API_IP_Address = MyReader.GetString("API_IP_Address");
                Auth_PK = MyReader.GetString("Node_Auth_PK");
                PKLWDT = MyReader.GetDateTime("PK_Update_DT");
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            int Count = SinglePNodeCheck.CheckParentNodeExistence(PNode_API_IP_Address,IP_Address);
            if (Count == 0)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(PNode_API_IP_Address);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.GetAsync("SNode_Registration?IP_Address=" + HttpUtility.UrlEncode(IP_Address) + "&API_IP_Address=" + HttpUtility.UrlEncode(API_IP_Address) + "&SNode_Auth_PK=" + HttpUtility.UrlEncode(Auth_PK) + "&UpdateTimeString=" + HttpUtility.UrlEncode(PKLWDT.ToString()));
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        if (Result.Contains("Error") == true)
                        {
                            throw new Exception("Error:" + Result.Substring(1, Result.Length - 2));
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Parent Node encounter some issues");
                    }
                }
            }
        }
    }
}
