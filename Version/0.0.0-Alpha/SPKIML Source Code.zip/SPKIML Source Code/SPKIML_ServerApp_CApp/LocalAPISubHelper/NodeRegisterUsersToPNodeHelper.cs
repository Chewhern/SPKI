﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKIML_ServerApp_CApp.APIHelper;
using SPKIML_ServerApp_CApp.Helper;
using SPKIML_ServerApp_CApp.SimpleSoftHSM;
using SPKIML_ServerApp_CApp.UtilityHelper;
using System.Net.Http.Headers;
using System.Web;

namespace SPKIML_ServerApp_CApp.LocalAPISubHelper
{
    public static class NodeRegisterUsersToPNodeHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void RegisterNodeUsersToPNode(String PNode_API_IP_Address) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            MySqlDataReader MyReader;
            String IP_Address = "";
            List<String> User_IDs = new List<String>();
            List<String> Auth_PKs = new List<String>();
            List<String> Sign_PKs = new List<String>();
            List<DateTime> ASPK_Valid_DTs = new List<DateTime>();
            Byte[] Challenge = new Byte[] { };
            Byte[] DecryptedNodePrivateKey = new Byte[] { };
            Byte[] SignedChallenge = new Byte[] { };
            String SignedChallengeString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read())
            {
                IP_Address = MyReader.GetString("IP_Address");
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users` WHERE TIMESTAMPDIFF(DAY, `ASPK_Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 32";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyReader = MySQLGeneralQuery.ExecuteReader();
            while (MyReader.Read()) 
            {
                User_IDs.Add(MyReader.GetString("User_ID"));
                Auth_PKs.Add(MyReader.GetString("Auth_PK"));
                Sign_PKs.Add(MyReader.GetString("Sign_PK"));
                ASPK_Valid_DTs.Add(MyReader.GetDateTime("ASPK_Valid_DT"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            int Count = SinglePNodeCheck.CheckParentNodeExistence(PNode_API_IP_Address,IP_Address);
            int Loop = 0;
            if (Count == 1)
            {
                while (Loop < User_IDs.Count) 
                {
                    Challenge = GetSNodeChallenge.GetChallenge(PNode_API_IP_Address);
                    if (Challenge.Length != 0) 
                    {
                        DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                        SignedChallenge = new Byte[] { };
                        if (DecryptedNodePrivateKey.Length == 64)
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKey, true);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                        }
                        SignedChallengeString = Convert.ToBase64String(SignedChallenge);
                        using (var client = new HttpClient())
                        {
                            client.BaseAddress = new Uri(PNode_API_IP_Address);
                            client.DefaultRequestHeaders.Accept.Clear();
                            client.DefaultRequestHeaders.Accept.Add(
                                new MediaTypeWithQualityHeaderValue("application/json"));
                            var response = client.GetAsync("SNode_Users_Registration?IP_Address=" + HttpUtility.UrlEncode(IP_Address) + "&SignedChallenge=" + HttpUtility.UrlEncode(SignedChallengeString) + "&User_ID=" + HttpUtility.UrlEncode(User_IDs[Loop]) + "&Auth_PK=" + HttpUtility.UrlEncode(Auth_PKs[Loop]) + "&Sign_PK=" + HttpUtility.UrlEncode(Sign_PKs[Loop]) + "&Valid_DTString=" + HttpUtility.UrlEncode(ASPK_Valid_DTs[Loop].ToString()));
                            response.Wait();
                            var result = response.Result;
                            if (result.IsSuccessStatusCode)
                            {
                                var readTask = result.Content.ReadAsStringAsync();
                                readTask.Wait();

                                var Result = readTask.Result;

                                if (Result.Contains("Error") == true)
                                {
                                    if (Result.Contains("Error: SNode user existed aborting insertion..") != true)
                                    {
                                        throw new Exception("Error:" + Result.Substring(1, Result.Length - 2));
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Error: Parent Node encounter some issues");
                            }
                        }
                    }
                    Loop += 1;
                }
            }
        }
    }
}
