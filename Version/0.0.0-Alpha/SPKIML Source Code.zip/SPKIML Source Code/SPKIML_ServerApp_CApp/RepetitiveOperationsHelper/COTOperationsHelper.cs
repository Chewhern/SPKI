﻿using SPKIML_ServerApp_CApp.APIHelper;
using SPKIML_ServerApp_CApp.StartupHelper;

namespace SPKIML_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class COTOperationsHelper
    {
        private static void FetchCOTForNodeUsers() 
        {
            if (InitializationHelper.IsAllInitialized() == true) 
            {
                CurrentNodeFetchPCOTs.CreatePCOTsForAllNodeUsers();
            }
        }

        private static void VerifyCOTForNodeUsers() 
        {
            if (InitializationHelper.IsAllInitialized() == true) 
            {
                CurrentNodeVerifyPCOTs.VerifyPCOTsForAllNodeUsers();
            }
        }

        public static void PerformCOTOperations() 
        {
            FetchCOTForNodeUsers();
            VerifyCOTForNodeUsers();
        }
    }
}
