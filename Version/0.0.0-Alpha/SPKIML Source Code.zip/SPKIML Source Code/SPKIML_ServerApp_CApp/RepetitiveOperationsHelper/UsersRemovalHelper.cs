﻿using SPKIML_ServerApp_CApp.LocalAPIHelper;

namespace SPKIML_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class UsersRemovalHelper
    {
        private static void RemovingUsers() 
        {
            NodeLocalDeleteEndUsersHelper.DeleteEndUsers();
            NodeLocalDeleteNodeUsersHelper.DeleteNodeUsers();
        }

        public static void RemoveUsers() 
        {
            RemovingUsers();
        }
    }
}
