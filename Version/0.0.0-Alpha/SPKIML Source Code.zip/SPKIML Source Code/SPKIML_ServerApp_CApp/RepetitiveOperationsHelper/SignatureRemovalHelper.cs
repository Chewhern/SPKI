﻿using SPKIML_ServerApp_CApp.LocalAPIHelper;

namespace SPKIML_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class SignatureRemovalHelper
    {
        private static void RemovingSignatures() 
        {
            NodeLocalDeleteEndUsersSignatureHelper.DeleteEndUsersSignature();
            NodeLocalDeleteNodeUserSignatureHelper.DeleteNodeUsersSignature();
        }

        public static void RemoveSignatures() 
        {
            RemovingSignatures();
        }
    }
}
