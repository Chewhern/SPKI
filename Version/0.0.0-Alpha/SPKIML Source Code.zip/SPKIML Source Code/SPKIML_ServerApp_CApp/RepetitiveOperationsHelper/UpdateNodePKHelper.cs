﻿using SPKIML_ServerApp_CApp.SimpleSoftHSM;
using SPKIML_ServerApp_CApp.StartupHelper;

namespace SPKIML_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class UpdateNodePKHelper
    {
        private static Boolean HasNodeBeenInitialized = InitializationHelper.IsAllInitialized();
        //Postpone for now..

        private static void UpdateNodePK() 
        {
            if(HasNodeBeenInitialized == true) 
            {
                CCOperations.GenerateAndEncryptSignaturePrivateKey();
            }
        }

        public static void UpdatePK() 
        {
            UpdateNodePK();
        }
    }
}
