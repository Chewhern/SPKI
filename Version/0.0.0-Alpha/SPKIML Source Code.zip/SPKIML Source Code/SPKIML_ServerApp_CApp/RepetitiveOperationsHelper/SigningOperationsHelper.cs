﻿using SPKIML_ServerApp_CApp.LocalAPIHelper;

namespace SPKIML_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class SigningOperationsHelper
    {
        private static void SigningUsers() 
        {
            NodeSignEndUsersHelper.SignAllEndUsers();
        }

        public static void GeneratePCOTForUsers() 
        {
            SigningUsers();
        }
    }
}
