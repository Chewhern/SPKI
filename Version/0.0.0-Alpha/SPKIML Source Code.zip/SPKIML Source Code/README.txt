Inside the "Project" is the list of folders/files that were required by the server in order to run.

You can configure it if you want to.

The private keys or secret keys in my case is safe to be public as the encryption and MAC seeds
were hold by me. These keys were also encrypted.

Hopefully the folder will serve as some sort of guidelines to node operators.

在"Project"里面是一系列被需要的文件夹或者文件。

你可以随意的配置。

这里所公开的私钥和密钥基本上是由我不公开的加密和MAC的种子加密了。

我希望这个文件夹会帮到你们一点。