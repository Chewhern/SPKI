﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeLocalDeleteSNodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void DeleteSNodeUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            List<String> SNodeUsersIDsToBeDeleted = new List<String>();
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `SNode_Users` WHERE TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) >= 32";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read())
            {
                SNodeUsersIDsToBeDeleted.Add(DataReader.GetString("User_ID"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            while (Loop < SNodeUsersIDsToBeDeleted.Count)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = SNodeUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Users_PKs_Log` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = SNodeUsersIDsToBeDeleted[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
