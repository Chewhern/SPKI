﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;

namespace SPKITL_ServerApp_CApp.LocalAPIHelper
{
    public static class PNodeSignSNodeUsersHelper
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void SignAllSNodeUsers()
        {
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8).AddDays(30);
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            int Loop2 = 0;
            String[] EncryptedNodeUsersSignaturePrivateKeyPath = NCOperations.GetEncryptedUserPrivateKeysPath();
            String NodeUsersSignaturePrivateKeyRootDirectory = "/Project/SPKITL/User_SignaturePrivateKeys/";
            String[] NodeUsersIDs = new String[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean[] IsNodeUsersPublicKeyMatched = new Boolean[EncryptedNodeUsersSignaturePrivateKeyPath.Length];
            Boolean IsSigned = true;
            String NodeUserSignaturePublicKeyString = "";
            Byte[] NodeUserSignaturePrivateKeyBytes = new Byte[] { };
            Byte[] NodeUserSignaturePublicKeyBytes = new Byte[] { };
            List<String> SNodeUserIDs = new List<String>();
            List<String> SNodeIPAddresses = new List<String>();
            List<String> SNodeUserSignPKsString = new List<String>();
            List<String> SNodeUserAuthPKsString = new List<String>();
            Byte[] SNodeUserPKBytes = new Byte[] { };
            Byte[] SignedSNodeUserPKBytes = new Byte[] { };
            String SignedSNodeUserSignPKString = "";
            String SignedSNodeUserAuthPKString = "";
            while (Loop < NodeUsersIDs.Length)
            {
                NodeUsersIDs[Loop] = EncryptedNodeUsersSignaturePrivateKeyPath[Loop].Remove(0, NodeUsersSignaturePrivateKeyRootDirectory.Length);
                NodeUsersIDs[Loop] = NodeUsersIDs[Loop].Remove(32, 15);
                Loop += 1;
            }
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT * FROM `SNode_Users`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            DataReader = MySQLGeneralQuery.ExecuteReader();
            while (DataReader.Read())
            {
                SNodeUserIDs.Add(DataReader.GetString("User_ID"));
                SNodeIPAddresses.Add(DataReader.GetString("IP_Address"));
                SNodeUserSignPKsString.Add(DataReader.GetString("Sign_PK"));
                SNodeUserAuthPKsString.Add(DataReader.GetString("Auth_PK"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            Loop = 0;
            while (Loop < NodeUsersIDs.Length)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBONU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0) 
                {
                    NodeUserSignaturePrivateKeyBytes = CCOperations.DecryptUserSignaturePrivateKey(EncryptedNodeUsersSignaturePrivateKeyPath[Loop]);
                    if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                    {
                        NodeUserSignaturePublicKeyBytes = SodiumPublicKeyAuth.GeneratePublicKey(NodeUserSignaturePrivateKeyBytes);
                    }
                    else
                    {
                        NodeUserSignaturePublicKeyBytes = SecureED448.GeneratePublicKey(NodeUserSignaturePrivateKeyBytes);
                    }
                    NodeUserSignaturePublicKeyString = Convert.ToBase64String(NodeUserSignaturePublicKeyBytes);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID AND `Sign_PK`=@Sign_PK";
                    MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = NodeUserSignaturePublicKeyString;
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count > 0)
                    {
                        while (Loop2 < SNodeUserIDs.Count)
                        {
                            if (NodeUserSignaturePrivateKeyBytes.Length == 64)
                            {
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserSignPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SodiumPublicKeyAuth.Sign(SNodeUserPKBytes, NodeUserSignaturePrivateKeyBytes);
                                SignedSNodeUserSignPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserAuthPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SodiumPublicKeyAuth.Sign(SNodeUserPKBytes, NodeUserSignaturePrivateKeyBytes);
                                SignedSNodeUserAuthPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                            }
                            else
                            {
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserSignPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, SNodeUserPKBytes, new Byte[] { });
                                SignedSNodeUserSignPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                                SNodeUserPKBytes = Convert.FromBase64String(SNodeUserAuthPKsString[Loop2]);
                                SignedSNodeUserPKBytes = SecureED448.GenerateSignatureMessage(NodeUserSignaturePrivateKeyBytes, SNodeUserPKBytes, new Byte[] { });
                                SignedSNodeUserAuthPKString = Convert.ToBase64String(SignedSNodeUserPKBytes);
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = SNodeIPAddresses[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop2];
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 0)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "INSERT INTO `SNode_Users_SBPNU_Log`(`SNode_IP_Address`, `SNode_User_ID`, `User_ID`, `Signed_Auth_PK`, `Signed_Sign_PK`, `Valid_DT`) VALUES (@SNode_IP_Address, @SNode_User_ID, @User_ID, @Signed_Auth_PK, @Signed_Sign_PK, @Valid_DT)";
                                MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = SNodeIPAddresses[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                            }
                            //Do something in future..
                            /*
                            else
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK";
                                MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = SNodeIPAddresses[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop2];
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                if (Count == 1)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "UPDATE `SNode_Users_SBPNU_Log` SET `Signed_Auth_PK`=@Signed_Auth_PK, `Signed_Sign_PK`=@Signed_Sign_PK, `Valid_DT`=@Valid_DT WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = SNodeIPAddresses[Loop2];
                                    MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = SNodeUserIDs[Loop2];
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = NodeUsersIDs[Loop];
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = SignedSNodeUserAuthPKString;
                                    MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = SignedSNodeUserSignPKString;
                                    MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = CurrentDateTime;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                }
                            }
                            */
                            Loop2 += 1;
                        }
                        IsNodeUsersPublicKeyMatched[Loop] = true;
                    }
                    else
                    {
                        IsNodeUsersPublicKeyMatched[Loop] = false;
                    }
                }
                else 
                {
                    IsSigned = false;
                    IsNodeUsersPublicKeyMatched[Loop] = false;
                }
                SodiumSecureMemory.SecureClearBytes(NodeUserSignaturePrivateKeyBytes);
                Loop2 = 0;
                Loop += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            Loop = 0;
            while (Loop < IsNodeUsersPublicKeyMatched.Length)
            {
                if (IsNodeUsersPublicKeyMatched[Loop] == false && IsSigned==true)
                {
                    throw new Exception("Error: Unable to proceed signing due to public keys mismatched.. or specified node user doesn't get signed by other nodes");
                }
                Loop += 1;
            }
        }
    }
}
