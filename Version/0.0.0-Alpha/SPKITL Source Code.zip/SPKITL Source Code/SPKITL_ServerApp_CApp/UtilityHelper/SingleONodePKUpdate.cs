﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.APIHelper;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Web;

namespace SPKITL_ServerApp_CApp.UtilityHelper
{
    public static class SingleONodePKUpdate
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        public static void UpdateParentNodePKOnOneONode(String ONode_API_IP_Address,String New_Auth_PK) 
        {
            Byte[] Challenge = GetONodeChallenge.GetChallenge(ONode_API_IP_Address);
            if (Challenge.Length != 0) 
            {
                Byte[] DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                Byte[] SignedChallenge = new Byte[] { };
                if (DecryptedNodePrivateKey.Length == 64) 
                {
                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKey, true);
                }
                else 
                {
                    SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { },true);
                }
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                String ExceptionString = "";
                String IP_Address = "";
                String API_IP_Address = "";
                DateTime LastPKUpdateDT = new DateTime();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery.CommandText = "SELECT `PK_Update_DT` FROM `Node_Information`";
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                LastPKUpdateDT = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `Node_Information`";
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ONode_API_IP_Address);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    var response = client.GetAsync("ONode_Registration/UpdateNodeAuthPK?IP_Address=" + HttpUtility.UrlEncode(IP_Address) + "&API_IP_Address=" + HttpUtility.UrlEncode(API_IP_Address) + "&SignedChallenge=" + HttpUtility.UrlEncode(Convert.ToBase64String(SignedChallenge)) +"&New_ONode_Auth_PK="+HttpUtility.UrlEncode(New_Auth_PK) +"&UpdateTimeString=" + HttpUtility.UrlEncode(LastPKUpdateDT.ToString()));
                    response.Wait();
                    var result = response.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var Result = readTask.Result;

                        if (Result.Contains("Error") == true)
                        {
                            throw new Exception("Error:" + Result.Substring(1, Result.Length - 2));
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Other Node encounter some issues");
                    }
                }
            }
        }
    }
}
