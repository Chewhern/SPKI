﻿using MySql.Data.MySqlClient;
using SPKITL_ServerApp_CApp.Helper;
using SPKITL_ServerApp_CApp.UtilityHelper;

namespace SPKITL_ServerApp_CApp.APIHelper
{
    public static class ParentNodeVerifyONodePCOTs
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();
        public static void VerifyPCOTsForAllPNodeUsers() 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            List<String> PNode_User_IDs = new List<String>();
            List<String> ONode_IPs = new List<String>();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `ONode_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read())
            {
                ONode_IPs.Add(MyDataReader.GetString("IP_Address"));
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `Node_Users`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            MyDataReader = MySQLGeneralQuery.ExecuteReader();
            while (MyDataReader.Read())
            {
                PNode_User_IDs.Add(MyDataReader.GetString("User_ID"));
            }
            int Loop1 = 0;
            int Loop2 = 0;
            while (Loop1 < ONode_IPs.Count)
            {
                while (Loop2 < PNode_User_IDs.Count)
                {
                    VerifySinglePNUserPCOT.VerifyPCOTForSinglePNUser(ONode_IPs[Loop1], PNode_User_IDs[Loop2]);
                    Loop2 += 1;
                }
                Loop2 = 0;
                Loop1 += 1;
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
        }
    }
}
