﻿using SPKITL_ServerApp_CApp.RepetitiveOperationsHelper;
using SPKITL_ServerApp_CApp.SimpleSoftHSM;

namespace SPKITL_ServerApp_CApp.StartupHelper
{
    public static class StartupOrBackgroundOpsHelper
    {
        public static void StartupFunction() 
        {
            SignatureRemovalHelper.RemoveSignatures();
            UsersRemovalHelper.RemoveUsers();
            SigningOperationsHelper.GeneratePCOTForUsers();
            COTOperationsHelper.PerformCOTOperations();
            UpdateNodePKHelper.UpdatePK();
            //Do something.. to make it detects.. whether run at least 1 time..
            if (File.Exists("<Path>") == false) 
            {
                File.WriteAllText("<Path>", "Yes");
            }
        }

        public static Boolean HasStartedUp() 
        {
            Boolean HasStarted = false;
            if (File.Exists("<Path>") == true)
            {
                String TestString = File.ReadAllText("<Path>");
                if(TestString!=null && TestString.CompareTo("Yes") == 0) 
                {
                    HasStarted = true;
                }
            }
            return HasStarted;
        }


        public static void BackgroundOperationsFunction() 
        {
            SignatureRemovalHelper.RemoveSignatures();
            UsersRemovalHelper.RemoveUsers();
            SigningOperationsHelper.GeneratePCOTForUsers();
            COTOperationsHelper.PerformCOTOperations();
            UpdateNodePKHelper.UpdatePK();
        }
    }
}
