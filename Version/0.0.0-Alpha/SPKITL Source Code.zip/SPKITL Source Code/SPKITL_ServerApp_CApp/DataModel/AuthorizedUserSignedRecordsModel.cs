﻿namespace SPKITL_ServerApp_CApp.DataModel
{
    public class AuthorizedUserSignedRecordsModel
    {
        public String Status { get; set; }

        public String[] TNode_IP_Addresses { get; set; }

        public String[] TNode_User_IDs { get; set; }

        public String[] Signed_Auth_PKs { get; set; }

        public String[] Signed_Sign_PKs { get; set; }

        public DateTime[] Signed_Dates { get; set; }
    }
}
