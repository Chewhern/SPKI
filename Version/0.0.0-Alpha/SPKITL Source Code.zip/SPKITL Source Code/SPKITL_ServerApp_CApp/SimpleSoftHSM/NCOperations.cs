﻿using ASodium;
using BCASodium;

namespace SPKITL_ServerApp_CApp.SimpleSoftHSM
{
    public static class NCOperations
    {
        public static String[] GetEncryptedUserPrivateKeysPath() 
        {
            return Directory.GetFiles("<Path>");
        }
    }
}
