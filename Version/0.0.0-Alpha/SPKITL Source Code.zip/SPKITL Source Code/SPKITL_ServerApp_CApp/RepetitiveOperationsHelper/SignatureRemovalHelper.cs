﻿using SPKITL_ServerApp_CApp.LocalAPIHelper;

namespace SPKITL_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class SignatureRemovalHelper
    {
        private static void RemovingSignatures() 
        {
            PNodeLocalDeleteSNodeUsersSignatureHelper.DeleteSNodeUsersSignature();
            PNodeLocalDeleteONodeUsersSignatureHelper.DeleteONodeUsersSignature();
            PNodeLocalDeleteNodeUserSignatureHelper.DeleteNodeUsersSignature();
        }

        public static void RemoveSignatures() 
        {
            RemovingSignatures();
        }
    }
}
