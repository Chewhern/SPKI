﻿using SPKITL_ServerApp_CApp.APIHelper;
using SPKITL_ServerApp_CApp.StartupHelper;

namespace SPKITL_ServerApp_CApp.RepetitiveOperationsHelper
{
    public static class COTOperationsHelper
    {
        private static void FetchCOTForNodeUsers() 
        {
            if (InitializationHelper.IsAllInitialized() == true) 
            {
                ParentNodeFetchONodePCOTs.CreatePCOTsForAllPNodeUsers();
            }
        }

        private static void VerifyCOTForNodeUsers() 
        {
            if (InitializationHelper.IsAllInitialized() == true) 
            {
                ParentNodeVerifyONodePCOTs.VerifyPCOTsForAllPNodeUsers();
            }
        }

        public static void PerformCOTOperations() 
        {
            FetchCOTForNodeUsers();
            VerifyCOTForNodeUsers();
        }
    }
}
