-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 13, 2025 at 07:06 AM
-- Server version: 8.0.42-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SPKITLDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Node_Challenge`
--

CREATE TABLE `Node_Challenge` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Information`
--

CREATE TABLE `Node_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Node_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Node_Info_Register_DT` datetime DEFAULT NULL,
  `Node_Info_Update_DT` datetime DEFAULT NULL,
  `PK_Update_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_OInformation`
--

CREATE TABLE `Node_OInformation` (
  `IP_Address` varchar(500) NOT NULL,
  `API_IP_Address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_PK_Log`
--

CREATE TABLE `Node_PK_Log` (
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Add_DT` datetime DEFAULT NULL,
  `NPKL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `Node_Users`
--

CREATE TABLE `Node_Users` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Contact` text COLLATE utf8mb4_general_ci,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `OOB_PK` text COLLATE utf8mb4_general_ci,
  `ASPK_Valid_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `Node_Users_PKs_Log`
--

CREATE TABLE `Node_Users_PKs_Log` (
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Change_Date` datetime DEFAULT NULL,
  `NUPKL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Node_Users_SBONU_Log`
--

CREATE TABLE `Node_Users_SBONU_Log` (
  `ONode_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `ONode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL,
  `NUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `ONode_Challenge`
--

CREATE TABLE `ONode_Challenge` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_Information`
--

CREATE TABLE `ONode_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `ONode_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ONode_PK_Log`
--

CREATE TABLE `ONode_PK_Log` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_DT` datetime NOT NULL,
  `OPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `ONode_Users`
--

CREATE TABLE `ONode_Users` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `ONode_Users_PKs_Log`
--

CREATE TABLE `ONode_Users_PKs_Log` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Change_Date` datetime DEFAULT NULL,
  `OUPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `ONode_Users_SBPNU_Log`
--

CREATE TABLE `ONode_Users_SBPNU_Log` (
  `ONode_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `ONode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL,
  `OUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `SNode_Challenge`
--

CREATE TABLE `SNode_Challenge` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Challenge` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_Duration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SNode_Information`
--

CREATE TABLE `SNode_Information` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `API_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `SNode_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `SNode_PK_Log`
--

CREATE TABLE `SNode_PK_Log` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Update_DT` datetime DEFAULT NULL,
  `SPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `SNode_Users`
--

CREATE TABLE `SNode_Users` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `SNode_Users_PKs_Log`
--

CREATE TABLE `SNode_Users_PKs_Log` (
  `IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Change_Date` datetime DEFAULT NULL,
  `SUPL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
--
-- Table structure for table `SNode_Users_SBPNU_Log`
--

CREATE TABLE `SNode_Users_SBPNU_Log` (
  `SNode_IP_Address` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `SNode_User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `User_ID` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Auth_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Signed_Sign_PK` text COLLATE utf8mb4_general_ci NOT NULL,
  `Valid_DT` datetime DEFAULT NULL,
  `SUSL_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Node_Challenge`
--
ALTER TABLE `Node_Challenge`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Information`
--
ALTER TABLE `Node_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `Node_OInformation`
--
ALTER TABLE `Node_OInformation`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `Node_PK_Log`
--
ALTER TABLE `Node_PK_Log`
  ADD PRIMARY KEY (`NPKL_ID`);

--
-- Indexes for table `Node_Users`
--
ALTER TABLE `Node_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `Node_Users_PKs_Log`
--
ALTER TABLE `Node_Users_PKs_Log`
  ADD PRIMARY KEY (`NUPKL_ID`);

--
-- Indexes for table `Node_Users_SBONU_Log`
--
ALTER TABLE `Node_Users_SBONU_Log`
  ADD PRIMARY KEY (`NUSL_ID`);

--
-- Indexes for table `ONode_Challenge`
--
ALTER TABLE `ONode_Challenge`
  ADD PRIMARY KEY (`IP_Address`);

--
-- Indexes for table `ONode_Information`
--
ALTER TABLE `ONode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `ONode_PK_Log`
--
ALTER TABLE `ONode_PK_Log`
  ADD PRIMARY KEY (`OPL_ID`);

--
-- Indexes for table `ONode_Users`
--
ALTER TABLE `ONode_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `ONode_Users_PKs_Log`
--
ALTER TABLE `ONode_Users_PKs_Log`
  ADD PRIMARY KEY (`OUPL_ID`);

--
-- Indexes for table `ONode_Users_SBPNU_Log`
--
ALTER TABLE `ONode_Users_SBPNU_Log`
  ADD PRIMARY KEY (`OUSL_ID`);

--
-- Indexes for table `SNode_Challenge`
--
ALTER TABLE `SNode_Challenge`
  ADD PRIMARY KEY (`IP_Address`);

--
-- Indexes for table `SNode_Information`
--
ALTER TABLE `SNode_Information`
  ADD PRIMARY KEY (`IP_Address`),
  ADD UNIQUE KEY `API_IP_Address` (`API_IP_Address`);

--
-- Indexes for table `SNode_PK_Log`
--
ALTER TABLE `SNode_PK_Log`
  ADD PRIMARY KEY (`SPL_ID`);

--
-- Indexes for table `SNode_Users`
--
ALTER TABLE `SNode_Users`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `SNode_Users_PKs_Log`
--
ALTER TABLE `SNode_Users_PKs_Log`
  ADD PRIMARY KEY (`SUPL_ID`);

--
-- Indexes for table `SNode_Users_SBPNU_Log`
--
ALTER TABLE `SNode_Users_SBPNU_Log`
  ADD PRIMARY KEY (`SUSL_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Node_PK_Log`
--
ALTER TABLE `Node_PK_Log`
  MODIFY `NPKL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `Node_Users_PKs_Log`
--
ALTER TABLE `Node_Users_PKs_Log`
  MODIFY `NUPKL_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Node_Users_SBONU_Log`
--
ALTER TABLE `Node_Users_SBONU_Log`
  MODIFY `NUSL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ONode_PK_Log`
--
ALTER TABLE `ONode_PK_Log`
  MODIFY `OPL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `ONode_Users_PKs_Log`
--
ALTER TABLE `ONode_Users_PKs_Log`
  MODIFY `OUPL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `ONode_Users_SBPNU_Log`
--
ALTER TABLE `ONode_Users_SBPNU_Log`
  MODIFY `OUSL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `SNode_PK_Log`
--
ALTER TABLE `SNode_PK_Log`
  MODIFY `SPL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `SNode_Users_PKs_Log`
--
ALTER TABLE `SNode_Users_PKs_Log`
  MODIFY `SUPL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `SNode_Users_SBPNU_Log`
--
ALTER TABLE `SNode_Users_SBPNU_Log`
  MODIFY `SUSL_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
