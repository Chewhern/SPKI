﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.Helper;
using SPKITL_ServerApp.DataModel;
using SPKITL_ServerApp.PostDataModel;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ONodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        //Parent node request PCOT from other node
        [HttpGet]
        public AuthorizedUserPartialCertificateModel GeneratePartialChainOfTrust(String IP_Address, String SignedChallenge,String User_ID) 
        {
            AuthorizedUserPartialCertificateModel MyModel = new AuthorizedUserPartialCertificateModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String CurrentNodeIPAddress = "";
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_DT` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays < 32) 
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0) 
                                    {
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MyModel.SNode_User_IDs = new String[Count];
                                        MyModel.SignedDateTimes = new DateTime[Count];
                                        MyModel.Signed_TNode_User_Sign_PKs = new String[Count];
                                        MyModel.Signed_TNode_User_Auth_PKs = new String[Count];
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = IP_Address;
                                        MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        DataReader = MySQLGeneralQuery.ExecuteReader();
                                        while (DataReader.Read()) 
                                        {
                                            MyModel.SNode_User_IDs[Loop] = DataReader.GetString("User_ID");
                                            MyModel.Signed_TNode_User_Auth_PKs[Loop] = DataReader.GetString("Signed_Auth_PK");
                                            MyModel.Signed_TNode_User_Sign_PKs[Loop] = DataReader.GetString("Signed_Sign_PK");
                                            MyModel.SignedDateTimes[Loop] = DataReader.GetDateTime("Valid_DT");
                                            Loop += 1;
                                        }
                                        MyModel.Status = "Success: Retrieved partial chain of trust..";
                                        MyModel.SNode_IP_Address = CurrentNodeIPAddress;
                                        MyModel.TNode_IP_Address = IP_Address;
                                        MyModel.TNode_User_ID = User_ID;
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                    }
                                    else 
                                    {
                                        MyModel.Status = "Error: This onode user does not have any signed records..";
                                    }
                                }
                                else 
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    MyModel.Status = "Error: This ONode User's public keys had expired.. deleting this ONode_User..";
                                }
                            }
                            else
                            {
                                MyModel.Status = "Error: This ONode user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            MyModel.Status = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        MyModel.Status = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    MyModel.Status = "Error: This other node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                MyModel.Status = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }

        //In future might need to extend the partial chain of trust other than signer and targeted node.
        //for mutual verification and validation purpose..
        
        [HttpPost]
        public String VerifyPartialChainOfTrust(VerifyAuthorizedUserPartialCertificateModel MyVAUPC) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String ResultString = "";
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, MyVAUPC.TNode_IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(MyVAUPC.SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_DT` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays < 32)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0)
                                    {
                                        while (Loop < MyVAUPC.SNode_User_IDs.Length) 
                                        {
                                            MySQLGeneralQuery = new MySqlCommand();
                                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK AND `Valid_DT`=@Valid_DT";
                                            MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                            MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.SNode_User_IDs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = MyVAUPC.Signed_TNode_User_Auth_PKs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = MyVAUPC.Signed_TNode_User_Sign_PKs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = MyVAUPC.SignedDateTimes[Loop];
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                            if (Count == 0) 
                                            {
                                                ResultString = "Error: Unable to find signature record for this onode user";
                                                break;
                                            }
                                            Loop += 1;
                                        }
                                        if (ResultString.CompareTo("") == 0) 
                                        {
                                            ResultString = "Success: Successfully verified the partial chain of trust on this ONode user";
                                        }
                                    }
                                    else
                                    {
                                        ResultString = "Error: This onode user does not have any signed records..";
                                    }
                                }
                                else
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    ResultString = "Error: This ONode User's public keys had expired.. deleting this ONode_User..";
                                }
                            }
                            else
                            {
                                ResultString = "Error: This ONode user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This other node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpPost("TNodeVerifyWithSignerNode")]
        public String VerifyPartialChainOfTrustForSignerNode(VerifyAuthorizedUserPartialCertificateModel MyVAUPC)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String ResultString = "";
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.RNode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.RNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.RNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, MyVAUPC.TNode_IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(MyVAUPC.SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.RNode_IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.RNode_IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `ASPK_Valid_DT` FROM `Node_Users` WHERE `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays < 32)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBONU_Log` WHERE `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0)
                                    {
                                        while (Loop < MyVAUPC.SNode_User_IDs.Length)
                                        {
                                            MySQLGeneralQuery = new MySqlCommand();
                                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBONU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK AND `Valid_DT`=@Valid_DT";
                                            MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = MyVAUPC.RNode_IP_Address;
                                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = MyVAUPC.Signed_TNode_User_Auth_PKs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = MyVAUPC.Signed_TNode_User_Sign_PKs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = MyVAUPC.SignedDateTimes[Loop];
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                            if (Count == 0)
                                            {
                                                ResultString = "Error: Unable to find signature record for this node user";
                                                break;
                                            }
                                            Loop += 1;
                                        }
                                        if (ResultString.CompareTo("") == 0)
                                        {
                                            ResultString = "Success: Successfully verified the partial chain of trust on this Node user";
                                        }
                                    }
                                    else
                                    {
                                        ResultString = "Error: This onode user does not have any signed records..";
                                    }
                                }
                                else
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Users` WHERE `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    ResultString = "Error: This Node User's public keys had expired.. deleting this Node_User..";
                                }
                            }
                            else
                            {
                                ResultString = "Error: This Node user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This signer node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        //Postpone for other non signer and targeted node partial chain of trust verification..


        //This API endpoint needs to be implemented on node operator panel..
        //It can't be implemented on node..
        //Schedule for future release
        //Postpone in MVP or prototype for now..
        /*[HttpGet("UpdateSignedONodeUserPartialCertStatus")]
        public String UpdateSignedONodeUserStatus(String IP_Address, String SignedChallenge, String User_ID) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address AND `API_IP_Address`!=@API_IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID";
                                MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                                ResultString = "Success: This ONode user chain of trust had been deleted.. It can be reinitiated again..";
                            }
                            else
                            {
                                ResultString = "Error: This ONode user doesn't exist aborting updating process...";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This other node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
        */
    }
}
