﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.DataModel;
using SPKITL_ServerApp.Helper;
using SPKITL_ServerApp.PostDataModel;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SNodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public AuthorizedUserPartialCertificateModel GenerateIntermediateChainOfTrust(String IP_Address, String SignedChallenge, String User_ID)
        {
            AuthorizedUserPartialCertificateModel MyModel = new AuthorizedUserPartialCertificateModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String SNode_API_IP_Address = "";
            String CurrentNodeIPAddress = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `SNode_Auth_PK` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                IsSNodePKNotChanged = VerifySNodePK.IsSNodePKChanged(SNode_Auth_PK, SNode_API_IP_Address);
                if (IsSNodePKNotChanged == true)
                {
                    SNode_Auth_PK_Bytes = Convert.FromBase64String(SNode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (SNode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, SNode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(SNode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_DT` FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays < 32)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0)
                                    {
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MyModel.SNode_User_IDs = new String[Count];
                                        MyModel.SignedDateTimes = new DateTime[Count];
                                        MyModel.Signed_TNode_User_Sign_PKs = new String[Count];
                                        MyModel.Signed_TNode_User_Auth_PKs = new String[Count];
                                        MySQLGeneralQuery = new MySqlCommand();
                                        MySQLGeneralQuery.CommandText = "SELECT * FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID";
                                        MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = IP_Address;
                                        MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = User_ID;
                                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                        MySQLGeneralQuery.Prepare();
                                        DataReader = MySQLGeneralQuery.ExecuteReader();
                                        while (DataReader.Read())
                                        {
                                            MyModel.SNode_User_IDs[Loop] = DataReader.GetString("User_ID");
                                            MyModel.Signed_TNode_User_Auth_PKs[Loop] = DataReader.GetString("Signed_Auth_PK");
                                            MyModel.Signed_TNode_User_Sign_PKs[Loop] = DataReader.GetString("Signed_Sign_PK");
                                            MyModel.SignedDateTimes[Loop] = DataReader.GetDateTime("Valid_DT");
                                            Loop += 1;
                                        }
                                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                        myMyOwnMySQLConnection.ClearConnectionString();
                                        myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                        MyModel.Status = "Success: Retrieved intermediate chain of trust..";
                                        MyModel.SNode_IP_Address = CurrentNodeIPAddress;
                                        MyModel.TNode_IP_Address = IP_Address;
                                        MyModel.TNode_User_ID = User_ID;
                                    }
                                    else
                                    {
                                        MyModel.Status = "Error: This snode user does not have any signed records..";
                                    }
                                }
                                else
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    MyModel.Status = "Error: This SNode User's public keys had expired.. deleting this SNode_User..";
                                }
                            }
                            else
                            {
                                MyModel.Status = "Error: This SNode user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            MyModel.Status = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        MyModel.Status = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    MyModel.Status = "Error: This sub node's PK does not match with parent node";
                }
            }
            else
            {
                MyModel.Status = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }

        [HttpPost]
        public String VerifyIntermediateChainOfTrust(VerifyAuthorizedUserPartialCertificateModel MyVAUPC)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String SNode_API_IP_Address = "";
            String ChallengeString = "";
            String ResultString = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `SNode_Auth_PK` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `SNode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                SNode_API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                IsSNodePKNotChanged = VerifySNodePK.IsSNodePKChanged(SNode_Auth_PK, SNode_API_IP_Address);
                if (IsSNodePKNotChanged == true)
                {
                    SNode_Auth_PK_Bytes = Convert.FromBase64String(SNode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(MyVAUPC.SignedChallenge);
                    if (SNode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, SNode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(SNode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_DT` FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                                if (MyTimeSpan.TotalDays < 32)
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                    if (Count > 0)
                                    {
                                        while (Loop < MyVAUPC.SNode_User_IDs.Length)
                                        {
                                            MySQLGeneralQuery = new MySqlCommand();
                                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `SNode_Users_SBPNU_Log` WHERE `SNode_IP_Address`=@SNode_IP_Address AND `SNode_User_ID`=@SNode_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK AND `Valid_DT`=@Valid_DT";
                                            MySQLGeneralQuery.Parameters.Add("@SNode_IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                            MySQLGeneralQuery.Parameters.Add("@SNode_User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.SNode_User_IDs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = MyVAUPC.Signed_TNode_User_Auth_PKs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = MyVAUPC.Signed_TNode_User_Sign_PKs[Loop];
                                            MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = MyVAUPC.SignedDateTimes[Loop];
                                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                            MySQLGeneralQuery.Prepare();
                                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                            if (Count == 0)
                                            {
                                                ResultString = "Error: Unable to find signature record for this snode user";
                                                break;
                                            }
                                            Loop += 1;
                                        }
                                        if (ResultString.CompareTo("") == 0)
                                        {
                                            ResultString = "Success: Successfully verified the intermediate chain of trust for this snode user";
                                        }
                                    }
                                    else
                                    {
                                        ResultString = "Error: This snode user does not have any signed records..";
                                    }
                                }
                                else
                                {
                                    MySQLGeneralQuery = new MySqlCommand();
                                    MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = MyVAUPC.TNode_User_ID;
                                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                    MySQLGeneralQuery.Prepare();
                                    MySQLGeneralQuery.ExecuteNonQuery();
                                    ResultString = "Error: This SNode User's public keys had expired.. deleting this SNode_User..";
                                }
                            }
                            else
                            {
                                ResultString = "Error: This SNode user doesn't exist";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `SNode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = MyVAUPC.TNode_IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from sub node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This sub node's PK does not match with parent node";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}
