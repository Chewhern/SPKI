﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.Helper;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ONode_Users_Registration : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String RegisterONodeUser(String IP_Address,String SignedChallenge,String User_ID,String Auth_PK,String Sign_PK,String Valid_DTString) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 0)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "INSERT INTO `ONode_Users`(`IP_Address`, `User_ID`, `Auth_PK`, `Sign_PK`, `Valid_DT`) VALUES (@IP_Address,@User_ID,@Auth_PK,@Sign_PK,@Valid_DT)";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Sign_PK;
                                MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = DateTime.Parse(Valid_DTString);
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                                ResultString = "Success: ONode user had been added for this " + IP_Address + " IP address";
                            }
                            else
                            {
                                ResultString = "Error: ONode user existed aborting insertion..";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This other node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("UpdateONodeUserPKs")]
        public String UpdateONodeUserPKs(String IP_Address, String SignedChallenge, String User_ID, String Auth_PK, String Sign_PK, String Valid_DTString)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            List<String> ExcludedAPI_IP_Addresses = new List<String>();
            String ONode_Auth_PK = "";
            Byte[] ONode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `ONode_Auth_PK` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONode_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`!=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                DataReader = MySQLGeneralQuery.ExecuteReader();
                while (DataReader.Read())
                {
                    ExcludedAPI_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                }
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                myMyOwnMySQLConnection.ClearConnectionString();
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(ONode_Auth_PK, IP_Address, ExcludedAPI_IP_Addresses.ToArray());
                if (IsONodePKNotChanged == true)
                {
                    ONode_Auth_PK_Bytes = Convert.FromBase64String(ONode_Auth_PK);
                    SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                    if (ONode_Auth_PK_Bytes.Length == 32)
                    {
                        ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, ONode_Auth_PK_Bytes);
                    }
                    else
                    {
                        ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(ONode_Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count == 1)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                        if (MyTimeSpan.TotalMinutes < 8)
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            if (Count == 1) 
                            {
                                String Old_Auth_PK = "";
                                String Old_Sign_PK = "";
                                DateTime OldValidDT = new DateTime();
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Auth_PK` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Old_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Sign_PK` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Old_Sign_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT `Valid_DT` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                OldValidDT = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "INSERT INTO `ONode_Users_PKs_Log`(`IP_Address`, `User_ID`, `Auth_PK`, `Sign_PK`, `Change_Date`) VALUES (@IP_Address,@User_ID,@Auth_PK,@Sign_PK,@Change_Date)";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Old_Auth_PK;
                                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Old_Sign_PK;
                                MySQLGeneralQuery.Parameters.Add("@Change_Date", MySqlDbType.DateTime).Value = OldValidDT;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "UPDATE `ONode_Users` SET `Auth_PK`=@Auth_PK,`Sign_PK`=@Sign_PK,`Valid_DT`=@Valid_DT WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                                MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Sign_PK;
                                MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = DateTime.Parse(Valid_DTString);
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                MySQLGeneralQuery.ExecuteNonQuery();
                                ResultString = "Success: This ONode user's PKs had been updated..";
                            }
                            else 
                            {
                                ResultString = "Error: This ONode user doesn't exist aborting updating process...";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else
                        {
                            ResultString = "Error: This verified challenge had expired.. deleting now..";
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Challenge` WHERE `Challenge`=@Challenge AND `IP_Address`=@IP_Address";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge coming from other node no longer exists..";
                    }
                }
                else
                {
                    ResultString = "Error: This other node's PK does not match with other nodes or encounter issues";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}
