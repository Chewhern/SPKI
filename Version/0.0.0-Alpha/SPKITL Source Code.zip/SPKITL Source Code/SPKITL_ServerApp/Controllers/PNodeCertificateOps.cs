﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using SPKITL_ServerApp.APIHelper;
using SPKITL_ServerApp.DataModel;
using SPKITL_ServerApp.Helper;
using SPKITL_ServerApp.PostDataModel;
using SPKITL_ServerApp.SimpleSoftHSM;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace SPKITL_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PNodeCertificateOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        //==Current parent node => Current parent node's users and current parent node
        //Fetch full chain of trust from other nodes as it's a request from current parent node
        //Verify full chain of trust from other nodes as it's a request from current parent node

        //Current parent node will be responsible in creating partial chain of trust

        [HttpGet]
        public AuthorizedUserFullCertificateModel GiveFullCertificateToPNodeUser(String User_ID) 
        {
            AuthorizedUserFullCertificateModel MyModel = new AuthorizedUserFullCertificateModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader MyDataReader;
            String ExceptionString = "";
            String CurrentNodeIPAddress = "";
            int Count = 0;
            int Loop = 0;
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBONU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0)
                {
                    MyModel.SignedDateTimes = new DateTime[Count];
                    MyModel.Signed_TNode_User_Auth_PKs = new String[Count];
                    MyModel.Signed_TNode_User_Sign_PKs = new String[Count];
                    MyModel.SNode_IP_Addresses = new String[Count];
                    MyModel.SNode_User_IDs = new String[Count];
                    MyModel.TNode_IP_Address = CurrentNodeIPAddress;
                    MyModel.TNode_User_ID = User_ID;
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users_SBONU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MyDataReader = MySQLGeneralQuery.ExecuteReader();
                    while (MyDataReader.Read()) 
                    {
                        MyModel.SNode_IP_Addresses[Loop] = MyDataReader.GetString("ONode_IP_Address");
                        MyModel.SNode_User_IDs[Loop] = MyDataReader.GetString("ONode_User_ID");
                        MyModel.Signed_TNode_User_Auth_PKs[Loop] = MyDataReader.GetString("Signed_Auth_PK");
                        MyModel.Signed_TNode_User_Sign_PKs[Loop] = MyDataReader.GetString("Signed_Sign_PK");
                        MyModel.SignedDateTimes[Loop] = MyDataReader.GetDateTime("Valid_DT");
                        Loop += 1;
                    }
                    MyModel.Status = "Success: Full certificate for this node's authorized user had been retrieved";
                }
                else
                {
                    MyModel.Status = "Error: This user does not have any partial chain of trusts..";
                }
            }
            else
            {
                MyModel.Status = "Error: This specified user had not been registered";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }

        [HttpGet("UserHelper")]
        public String GetONodeAPIIPAddress(String IP_Address) 
        {
            String API_IP_Address = "";
            String Final_API_IP_Address = "";
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            API_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(API_IP_Address);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("GetNodeAPIIPAddress");
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    Final_API_IP_Address = Result;
                }
                else
                {
                    throw new Exception("Error: Other Node encounter some issues");
                }
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();

            return Final_API_IP_Address;
        }

        //In future updates may need to also include verify not only with signer-target nodes
        //,also with signer-verifier nodes.
        [HttpPost]
        public String VerifyONodeUserCertificate(VerifyAuthorizedUserPartialCertificateModel ONodeUserFullCert) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallenge = new Byte[] { };
            Byte[] Challenge = new Byte[] { };
            String SignedChallengeB64 = "";
            String CurrentNodeIPAddress = "";
            String ONodeAPI_IP_Address = "";
            List<String> API_IP_Addresses = new List<String>();
            String ResultString = "";
            String Node_Auth_PK = "";
            Boolean IsONodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT `Node_Auth_PK` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Node_Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `IP_Address` FROM `Node_Information`";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            CurrentNodeIPAddress = MySQLGeneralQuery.ExecuteScalar().ToString();
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
            MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information` WHERE `IP_Address`=@IP_Address";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                ONodeAPI_IP_Address = MySQLGeneralQuery.ExecuteScalar().ToString();
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Valid_DT` FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                    if (MyTimeSpan.TotalDays < 32)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID";
                        MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
                        MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count > 0)
                        {
                            while (Loop < ONodeUserFullCert.SNode_User_IDs.Length)
                            {
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `ONode_IP_Address`=@ONode_IP_Address AND `ONode_User_ID`=@ONode_User_ID AND `User_ID`=@User_ID AND `Signed_Auth_PK`=@Signed_Auth_PK AND `Signed_Sign_PK`=@Signed_Sign_PK AND `Valid_DT`=@Valid_DT";
                                MySQLGeneralQuery.Parameters.Add("@ONode_IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
                                MySQLGeneralQuery.Parameters.Add("@ONode_User_ID", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_User_ID;
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = ONodeUserFullCert.SNode_User_IDs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Auth_PK", MySqlDbType.Text).Value = ONodeUserFullCert.Signed_TNode_User_Auth_PKs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Signed_Sign_PK", MySqlDbType.Text).Value = ONodeUserFullCert.Signed_TNode_User_Sign_PKs[Loop];
                                MySQLGeneralQuery.Parameters.Add("@Valid_DT", MySqlDbType.DateTime).Value = ONodeUserFullCert.SignedDateTimes[Loop];
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                                if (Count == 0)
                                {
                                    ResultString = "Error: Unable to find signature record for this onode user";
                                    break;
                                }
                                Loop += 1;
                            }
                            myMyOwnMySQLConnection.MyMySQLConnection.Close();
                            myMyOwnMySQLConnection.ClearConnectionString();
                            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `API_IP_Address` FROM `ONode_Information`";
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DataReader = MySQLGeneralQuery.ExecuteReader();
                            while (DataReader.Read())
                            {
                                API_IP_Addresses.Add(DataReader.GetString("API_IP_Address"));
                            }
                            IsONodePKNotChanged = VerifyONodePK.IsONodePKChanged(Node_Auth_PK, CurrentNodeIPAddress, API_IP_Addresses.ToArray());
                            if (IsONodePKNotChanged == true) 
                            {
                                CCOperations.InitializeOperations();
                                Byte[] DecryptedNodePrivateKey = CCOperations.DecryptNodeSignaturePrivateKey();
                                CCOperations.ClearKeys();
                                Challenge = GetONodeChallenge.GetChallenge(ONodeAPI_IP_Address);
                                if (DecryptedNodePrivateKey.Length == 64)
                                {
                                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, DecryptedNodePrivateKey, true);
                                }
                                else
                                {
                                    SignedChallenge = SecureED448.GenerateSignatureMessage(DecryptedNodePrivateKey, Challenge, new Byte[] { }, true);
                                }
                                SignedChallengeB64 = Convert.ToBase64String(SignedChallenge);
                                ONodeUserFullCert.SignedChallenge = SignedChallengeB64;
                                ONodeUserFullCert.RNode_IP_Address = CurrentNodeIPAddress;
                                String JSONBodyString = "";
                                StringContent PostRequestData = new StringContent("");
                                JSONBodyString = JsonConvert.SerializeObject(ONodeUserFullCert);
                                PostRequestData = new StringContent(JSONBodyString, Encoding.UTF8, "application/json");
                                using (var client = new HttpClient())
                                {
                                    client.BaseAddress = new Uri(ONodeAPI_IP_Address);
                                    client.DefaultRequestHeaders.Accept.Clear();
                                    client.DefaultRequestHeaders.Accept.Add(
                                        new MediaTypeWithQualityHeaderValue("application/json"));
                                    var response = client.PostAsync("ONodeCertificateOps/TNodeVerifyWithSignerNode", PostRequestData);
                                    response.Wait();
                                    var result = response.Result;
                                    if (result.IsSuccessStatusCode)
                                    {
                                        var readTask = result.Content.ReadAsStringAsync();
                                        readTask.Wait();

                                        var Result = readTask.Result;

                                        if (Result.Contains("Error") == true)
                                        {
                                            ResultString = Result;
                                        }
                                    }
                                    else
                                    {
                                        ResultString= "Error: Other Node encounter some issues";
                                    }
                                }
                            }
                            else 
                            {
                                ResultString = "Error: This node's PK does not match with other nodes or encounter issues";
                            }
                            if (ResultString.CompareTo("") == 0)
                            {
                                ResultString = "Success: This certificate from this onode user is trusted/verified";
                            }
                        }
                        else
                        {
                            ResultString = "Error: This onode user does not have any signed records..";
                        }
                    }
                    else
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `ONode_Users` WHERE `IP_Address`=@IP_Address AND `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@IP_Address", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_IP_Address;
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = ONodeUserFullCert.TNode_User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        ResultString = "Error: This ONode User's public keys had expired.. deleting this ONode_User..";
                    }
                }
                else
                {
                    ResultString = "Error: This ONode user doesn't exist";
                }
            }
            else
            {
                ResultString = "Error: This IP address don't exist in this node";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("PNodeUserGetSignatureRecords")]
        public AuthorizedUserSignedRecordsModel GetSignatureRecords(String User_ID,String SignedChallenge) 
        {
            AuthorizedUserSignedRecordsModel MyModel = new AuthorizedUserSignedRecordsModel();
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            MySqlDataReader DataReader;
            String ExceptionString = "";
            int Count = 0;
            int Loop = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String CurrentNodeIPAddress = "";
            List<String> ONode_User_IDs = new List<String>();
            List<String> Signed_Auth_PKs = new List<String>();
            List<String> Signed_Sign_PKs = new List<String>();
            List<String> TNode_IP_Addresses = new List<String>();
            List<String> TNode_User_IDs = new List<String>();
            List<String> TNodeUsers_Signed_Auth_PKs = new List<String>();
            List<String> TNodeUsers_Signed_Sign_PKs = new List<String>();
            List<DateTime> Signed_Dates = new List<DateTime>();
            Byte[] Signed_Auth_PKBytes = new Byte[] { };
            Byte[] Signed_Sign_PKBytes = new Byte[] { };
            Byte[] Auth_PKBytes = new Byte[] { };
            Byte[] Sign_PKBytes = new Byte[] { };
            String ONode_User_Sign_PK = "";
            Byte[] ONode_User_Sign_PKBytes = new Byte[] { };
            Boolean IsONodePKNotChanged = true;
            Boolean IsAllONodeUsersPublicKeyAbleToVerify = true;
            Boolean IsVerifiedPKsMatched = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `ONode_Users_SBPNU_Log` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users_SBONU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count > 0) 
                {
                    //Need to verify locally on all the authorized user's signed public key records by other nodes
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT * FROM `Node_Users_SBONU_Log` WHERE `User_ID`=@User_ID AND TIMESTAMPDIFF(DAY, `Valid_DT`, CONVERT_TZ(NOW(), '+00:00', '+08:00')) < 31";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DataReader = MySQLGeneralQuery.ExecuteReader();
                    while (DataReader.Read()) 
                    {
                        ONode_User_IDs.Add(DataReader.GetString("ONode_User_ID"));
                        Signed_Auth_PKs.Add(DataReader.GetString("Signed_Auth_PK"));
                        Signed_Sign_PKs.Add(DataReader.GetString("Signed_Sign_PK"));
                    }
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.ClearConnectionString();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    while (Loop < ONode_User_IDs.Count) 
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Sign_PK` FROM `ONode_Users` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = ONode_User_IDs[Loop];
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        ONode_User_Sign_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                        ONode_User_Sign_PKBytes = Convert.FromBase64String(ONode_User_Sign_PK);
                        Signed_Auth_PKBytes = Convert.FromBase64String(Signed_Auth_PKs[Loop]);
                        Signed_Sign_PKBytes = Convert.FromBase64String(Signed_Sign_PKs[Loop]);
                        try 
                        {
                            if (ONode_User_Sign_PKBytes.Length == 32) 
                            {
                                Auth_PKBytes = SodiumPublicKeyAuth.Verify(Signed_Auth_PKBytes,ONode_User_Sign_PKBytes);
                                Sign_PKBytes = SodiumPublicKeyAuth.Verify(Signed_Sign_PKBytes, ONode_User_Sign_PKBytes);
                            }
                            else 
                            {
                                Auth_PKBytes = SecureED448.GetMessageFromSignatureMessage(ONode_User_Sign_PKBytes, Signed_Auth_PKBytes, new Byte[] { });
                                Sign_PKBytes = SecureED448.GetMessageFromSignatureMessage(ONode_User_Sign_PKBytes, Signed_Sign_PKBytes, new Byte[] { });
                            }
                        }
                        catch 
                        {
                            IsAllONodeUsersPublicKeyAbleToVerify = false;
                            break;
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Users` WHERE `User_ID`=@User_ID AND `Auth_PK`=@Auth_PK AND `Sign_PK`=@Sign_PK";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Convert.ToBase64String(Auth_PKBytes);
                        MySQLGeneralQuery.Parameters.Add("@Sign_PK", MySqlDbType.Text).Value = Convert.ToBase64String(Sign_PKBytes);
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count != 1) 
                        {
                            IsVerifiedPKsMatched = false;
                            break;
                        }
                        Loop += 1;
                    }
                    if(IsAllONodeUsersPublicKeyAbleToVerify == true && IsVerifiedPKsMatched == true) 
                    {
                        SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                        if (Auth_PKBytes.Length == 32)
                        {
                            ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, Auth_PKBytes);
                        }
                        else
                        {
                            ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(Auth_PKBytes, SignedChallengeBytes, new Byte[] { });
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Node_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count == 1) 
                        {
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `Node_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                            MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                            if (MyTimeSpan.TotalMinutes < 8) 
                            {
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                                MySQLGeneralQuery = new MySqlCommand();
                                MySQLGeneralQuery.CommandText = "SELECT * FROM `ONode_Users_SBPNU_Log` WHERE `User_ID`=@User_ID";
                                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                                MySQLGeneralQuery.Prepare();
                                DataReader = MySQLGeneralQuery.ExecuteReader();
                                while (DataReader.Read()) 
                                {
                                    TNode_IP_Addresses.Add(DataReader.GetString("ONode_IP_Address"));
                                    TNode_User_IDs.Add(DataReader.GetString("ONode_User_ID"));
                                    TNodeUsers_Signed_Auth_PKs.Add(DataReader.GetString("Signed_Auth_PK"));
                                    TNodeUsers_Signed_Sign_PKs.Add(DataReader.GetString("Signed_Sign_PK"));
                                    Signed_Dates.Add(DataReader.GetDateTime("Valid_DT"));
                                }
                                MyModel.Status = "Success: Successfully retrieved signed records";
                                MyModel.TNode_IP_Addresses = TNode_IP_Addresses.ToArray();
                                MyModel.TNode_User_IDs = TNode_User_IDs.ToArray();
                                MyModel.Signed_Auth_PKs = TNodeUsers_Signed_Auth_PKs.ToArray();
                                MyModel.Signed_Sign_PKs = TNodeUsers_Signed_Sign_PKs.ToArray();
                                MyModel.Signed_Dates = Signed_Dates.ToArray();
                                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                                myMyOwnMySQLConnection.ClearConnectionString();
                                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                            }
                            else 
                            {
                                MyModel.Status = "Error: This challenge had expired.. unable to fetch signed records..";
                            }
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "DELETE FROM `Node_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            MySQLGeneralQuery.ExecuteNonQuery();
                        }
                        else 
                        {
                            MyModel.Status = "Error: This challenge doesn't exist";
                        }
                    }
                    else 
                    {
                        MyModel.Status = "Error: Either onode users' public keys unable to verify signed records or verified signed public keys unmatch with node user";
                    }
                }
                else 
                {
                    MyModel.Status = "Error: Node user doesn't have any signed records..";
                }
            }
            else
            {
                MyModel.Status = "Error: Node user doesn't sign any other nodes' public keys";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return MyModel;
        }
    }
}
