The structure is roughly the same as ML.

You can refer to that README for some info..

ML和TL的构造基本上差不了太多。。

你可以查看ML的readme。