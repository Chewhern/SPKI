﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.SPKIDataModel
{
    public class MLPNEUSignedCredentialsModel
    {
        public String ArweaveMLAUInfoTransactionID { get; set; }

        public String ArweaveMLAUCertTransactionID { get; set; }

        public String Signed_Auth_PK { get; set; }

        public String Signed_Sign_PK { get; set; }

        public int SignDate_Day { get; set; }

        public int SignDate_Month { get; set; }

        public int SignDate_Year { get; set; }

        public int ValidDate_Day { get; set; }

        public int ValidDate_Month { get; set; }

        public int ValidDate_Year { get; set; }
    }
}
