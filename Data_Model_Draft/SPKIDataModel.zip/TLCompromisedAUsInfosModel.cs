﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.SPKIDataModel
{
    public class TLCompromisedAUsInfosModel
    {
        public String[] TLAUInfoArweaveTransactionIDs { get; set; }
    }
}
