﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.SPKIDataModel
{
    public class MLAUCertModel
    {
        public String User_ID { get; set; }

        public MLPNSignedCredentialsModel[] SignedCredentials { get; set; }
    }
}
