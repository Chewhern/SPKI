﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.SPKIDataModel
{
    public class MLEUCertModel
    {
        public String User_ID { get; set; }

        public MLPNEUSignedCredentialsModel[] SignedCredentials { get; set; }
    }
}
